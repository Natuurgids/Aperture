# Aperture Definition Model

**Status:** Conceptual domain baseline

## 1. Observation

A preserved account of a moment, place, context, or experience.

An observation may concern multiple subjects and domains. It is not required to correspond to one database row or one classified object.

Key attributes:

- stable identity;
- creator or recorder;
- observed time and time certainty;
- place and place certainty;
- narrative or notes;
- relationships to evidence;
- ownership and access policy;
- lifecycle state.

## 2. Evidence

A preserved source that supports an observation or later enrichment.

Examples:

- photograph;
- audio;
- video;
- sensor reading;
- document;
- specimen record;
- measurement;
- witness statement;
- laboratory result.

Evidence is not identical to an interpretation. Original evidence is preserved independently wherever policy and rights permit.

## 3. Enrichment

A versioned, attributed addition of meaning, context, analysis, or proof.

Examples:

- species identification;
- behaviour classification;
- weather context;
- historical comparison;
- authenticity assessment;
- conservation assessment;
- AI suggestion;
- expert review;
- insurance valuation;
- immutable-proof reference.

An enrichment never silently rewrites the evidence it interprets.

## 4. Semantic Enrichment

A specialised enrichment that records an evolution in the meaning or representation of an information environment.

It contains:

- semantic-enrichment identity;
- source semantic model;
- target semantic model;
- reason and intended meaning;
- source and target concepts;
- transformation definitions;
- lineage relationships;
- assumptions and decision evidence;
- validation specification;
- coexistence policy;
- authority-transition policy;
- approval and provenance.

A migration is an execution of one or more semantic enrichments.

## 5. Semantic Model

A versioned description of concepts, relationships, constraints, meanings, and authority within an information environment.

A semantic model is distinct from a physical database schema. Several physical schemas may implement the same semantic model, and one semantic change may require changes in several schemas.

## 6. Physical Model

A technology-specific implementation of information, such as tables, columns, files, indexes, document structures, or API payloads.

Physical models are replaceable. Their relationship to the semantic model must be explicit and versioned.

## 7. Migration Definition

An executable or interpretable specification that applies a semantic enrichment to a source environment.

It includes:

- source and target model versions;
- extraction rules;
- transformation rules;
- load or publication rules;
- lineage emission;
- exception handling;
- validation and reconciliation;
- deterministic dependencies;
- software and package versions.

## 8. Migration Run

One controlled execution of a migration definition against an identified source snapshot.

A run records:

- run identity;
- source snapshot;
- target workspace;
- definition and software versions;
- executor and authorization;
- timestamps;
- record and object counts;
- warnings, failures, and exceptions;
- validation results;
- approval state;
- resulting target snapshot.

## 9. Preservation Generation

A verified, self-describing state of an information environment retained for restoration and historical interpretation.

A generation includes the data, models, documentation, integrity proofs, and migration evidence required to understand its place in the evolution chain.

## 10. Snapshot

A fixed representation of an environment at a defined point.

A snapshot is not trusted merely because it exists. It must have identity, scope, integrity verification, creation provenance, and restoration validation.

## 11. Lineage Node

A versioned object participating in semantic evolution.

A lineage node may represent:

- a source row;
- a target row;
- a document;
- an observation;
- a field value;
- a concept instance;
- an aggregate;
- an exception.

## 12. Lineage Relationship

A directed, attributed relationship explaining how source nodes contributed to target nodes.

Relationship types include:

- copied;
- renamed;
- normalised;
- split;
- merged;
- derived;
- aggregated;
- reclassified;
- defaulted;
- rejected;
- quarantined;
- superseded;
- retained unchanged.

Each relationship identifies the rule, reason, run, validation, and confidence or certainty where relevant.

## 13. Coexistence Window

A controlled period during which legacy and target representations remain simultaneously available for proof and comparison.

The window defines:

- start and end conditions;
- authoritative representation;
- read and write rules;
- reconciliation frequency;
- discrepancy handling;
- retention after retirement.

## 14. Authority State

The declared operational status of a representation:

- proposed;
- shadow;
- comparison;
- authoritative;
- historical evidence;
- retired from operation;
- rejected.

Authority is explicit; it must not be inferred from which table an application currently reads.

## 15. Validation Specification

A versioned definition of the evidence required to accept a migration result.

It may include:

- checksums;
- counts;
- totals and balances;
- relationship checks;
- semantic rules;
- licence and policy checks;
- sampling;
- expert review;
- exception thresholds.

## 16. Validation Result

The recorded outcome of applying a validation specification to a migration run or preservation generation.

Results include supporting evidence, failed rules, exceptions, reviewer identity, and disposition.

## 17. Decision Record

A durable explanation of why a semantic or architectural choice was made.

It records alternatives, assumptions, consequences, approval, and supersession. A mapping script alone is not a decision record.

## 18. Provenance

The traceable history of origin, custody, creation, processing, attribution, and change.

Provenance applies to observations, evidence, enrichments, semantic models, transformation rules, software, migration runs, and approvals.

## 19. Ownership

The legal or recognised control of information or evidence.

Ownership is distinct from custody, access, licence, authorship, and authority to process.

## 20. Licence

The explicit terms under which information may be used, shared, transformed, published, or redistributed.

Migration preserves licence constraints and must not create broader rights by technical convenience.

## 21. Immutable Proof Enrichment

A proof record that anchors selected evidence or statements in an external immutable or highly trusted mechanism.

It may contain:

- content hash;
- timestamp;
- authority;
- ledger or registry;
- transaction or registration identifier;
- verification method.

The underlying evidence remains outside the proof mechanism.

## 22. Core relationship model

```text
Observation --supported by--> Evidence
Observation --has--> Enrichment
Enrichment --has--> Provenance
Semantic Model --evolves through--> Semantic Enrichment
Semantic Enrichment --executed by--> Migration Definition
Migration Definition --instantiated as--> Migration Run
Migration Run --reads--> Source Snapshot
Migration Run --produces--> Target Snapshot
Lineage Relationship --connects--> Source and Target Nodes
Accepted Target Snapshot --becomes--> Preservation Generation
```
