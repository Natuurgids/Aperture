# ADR — Semantic Evolution Is Implemented as Enrichment

**Status:** Proposed consolidated decision  
**Scope:** Aperture, Aperture Science, and the Semantic Migration Platform

## Context

Long-lived information systems must evolve as knowledge, regulation, scientific understanding, and organisational meaning change.

Ordinary schema migrations are often treated as technical operations. This loses the reason for change and provides inadequate proof when one source record becomes several target records, several source records merge, or meanings are reinterpreted.

Transformations are not generally reversible. The source must therefore be preserved independently.

## Decision

Evolution of an information model is represented as a versioned Semantic Enrichment.

A migration is an execution of that enrichment against a verified source snapshot.

The platform preserves:

- source and target semantic models;
- semantic reason;
- transformation definition;
- full lineage;
- validation;
- coexistence and authority transition;
- approvals;
- source and target preservation generations.

No migration destroys its source.

## Consequences

### Positive

- semantic intent becomes auditable;
- complex cardinality is represented accurately;
- future custodians can understand why the environment changed;
- migrations can be rerun from a verified source;
- technology can change without erasing model history;
- the same enrichment philosophy applies across all Aperture products.

### Costs

- more metadata and governance are required;
- source and target generations consume storage;
- lineage can be large;
- semantic modelling requires domain participation;
- acceptance takes longer than a purely technical cutover.

### Risks

- coexistence can create ambiguity if authority is not explicit;
- poor semantic definitions can formalise incorrect assumptions;
- audit packages can become dependent on proprietary formats if export is neglected;
- excessive retention can become operationally expensive.

## Required controls

- explicit authority states;
- open export of models, lineage, and audit evidence;
- verified snapshots and restoration tests;
- versioned validation specifications;
- exception governance;
- retention classification;
- approval by accountable domain owners.

## Principle

> **Everything evolves through enrichment, and every enrichment preserves the evidence of what came before.**
