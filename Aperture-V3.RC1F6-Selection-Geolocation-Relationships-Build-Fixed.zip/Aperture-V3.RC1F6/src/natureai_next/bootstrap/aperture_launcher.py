"""Windowless Windows launcher for the Aperture desktop application."""

from __future__ import annotations

from pathlib import Path

from natureai_next.bootstrap.cli import main as cli_main
from natureai_next.bootstrap.launcher_log import write_launcher_log

# Compatibility guard: the shared configuration service resolves
# os.environ.get("APPDATA") and stores data under
# root / "NatureAI" / "NatureAI Next" / "launcher.json".


def _bootstrap_log(status: str, detail: str = "") -> None:
    write_launcher_log("aperture-bootstrap.jsonl", status, detail)


def _configured_library() -> Path | None:
    from natureai_next.application.launcher_configuration import LauncherConfigurationStore
    return LauncherConfigurationStore().load().last_library


def _message_box(message: str, *, error: bool = True) -> None:
    try:
        import ctypes

        icon = 0x10 if error else 0x40
        ctypes.windll.user32.MessageBoxW(0, message, "Aperture", icon)
    except Exception:
        return


def main() -> int:
    _bootstrap_log("process-started")
    library = _configured_library()
    if library is None:
        _bootstrap_log("configuration-missing")
        _message_box(
            "No Aperture Library is configured. Use 'Aperture - Select Library' and try again."
        )
        return 1
    if not (library / "library.json").is_file() or not (library / "library.sqlite3").is_file():
        _bootstrap_log("library-unavailable", str(library))
        _message_box(
            "The configured Aperture Library is unavailable or incomplete. "
            "Use 'Aperture - Select Library' to choose a valid library."
        )
        return 1
    try:
        result = int(cli_main(["--library", str(library), "--log-level", "INFO"]))
    except Exception as exc:
        _bootstrap_log("bootstrap-failed", f"{type(exc).__name__}: {exc}")
        _message_box(
            "Aperture could not start.\n\n"
            f"{type(exc).__name__}: {exc}\n\n"
            "Use Aperture (Debug) for diagnostic output."
        )
        return 1
    _bootstrap_log("process-exited", str(result))
    return result
