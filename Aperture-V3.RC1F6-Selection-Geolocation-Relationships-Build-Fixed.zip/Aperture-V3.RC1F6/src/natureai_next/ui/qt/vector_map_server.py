"""Loopback-only HTTP transport for independent vector MBTiles databases.

MapLibre workers are most reliable when vector tiles, JavaScript, CSS, and the
map document share an ordinary HTTP origin.  This server binds only to
127.0.0.1, uses an unguessable path token, opens the selected MBTiles database
read-only per request, and never touches the Aperture operational database.
"""
from __future__ import annotations

import gzip
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import mimetypes
from pathlib import Path
import secrets
import sqlite3
import threading
from typing import Any
from urllib.parse import urlparse
import zlib

EMPTY_MVT = b"\x1a\x0d\x0a\x06_empty\x28\x80\x20\x78\x02"


def _tile_bytes(package: Any, zoom: int, x: int, y: int) -> bytes:
    if zoom < 0 or x < 0 or y < 0:
        raise ValueError("tile coordinates must be non-negative")
    limit = (1 << zoom) - 1
    if x > limit or y > limit:
        return EMPTY_MVT
    path = Path(package.package_path)
    if not path.is_file():
        raise FileNotFoundError(path)
    stored_y = limit - y if getattr(package, "tile_scheme", "tms") == "tms" else y
    connection = sqlite3.connect(
        f"file:{path.as_posix()}?mode=ro&immutable=1",
        uri=True,
        isolation_level=None,
        timeout=2.0,
    )
    try:
        row = connection.execute(
            "SELECT tile_data FROM tiles WHERE zoom_level=? AND tile_column=? AND tile_row=?",
            (zoom, x, stored_y),
        ).fetchone()
    finally:
        connection.close()
    if row is None:
        return EMPTY_MVT
    data = bytes(row[0])
    if data[:2] == b"\x1f\x8b":
        data = gzip.decompress(data)
    elif len(data) >= 2 and data[0] == 0x78:
        try:
            data = zlib.decompress(data)
        except zlib.error:
            pass
    return data or EMPTY_MVT


class VectorMapLoopbackServer:
    """Own one same-origin HTTP endpoint for one installed map database."""

    def __init__(self, package: Any, asset_root: Path, document_factory: Any) -> None:
        self._package = package
        self._asset_root = asset_root.resolve()
        self._token = secrets.token_urlsafe(24)
        owner = self

        class Handler(BaseHTTPRequestHandler):
            server_version = "ApertureVectorMap/1"

            def log_message(self, _format: str, *_args: object) -> None:
                return

            def do_GET(self) -> None:  # noqa: N802
                try:
                    parsed = urlparse(self.path)
                    prefix = f"/{owner._token}/"
                    if not parsed.path.startswith(prefix):
                        self.send_error(404)
                        return
                    relative = parsed.path[len(prefix):]
                    if relative == "map.html":
                        body = document_factory(owner.base_url).encode("utf-8")
                        self._reply(200, b"text/html; charset=utf-8", body, no_store=True)
                        return
                    if relative.startswith("assets/"):
                        name = relative.removeprefix("assets/")
                        if name not in {"maplibre-gl.js", "maplibre-gl.css"}:
                            self.send_error(404)
                            return
                        path = (owner._asset_root / name).resolve()
                        if path.parent != owner._asset_root or not path.is_file():
                            self.send_error(404)
                            return
                        mime = mimetypes.guess_type(path.name)[0] or "application/octet-stream"
                        self._reply(200, mime.encode("ascii"), path.read_bytes())
                        return
                    if relative.startswith("tile/") and relative.endswith(".pbf"):
                        parts = relative.split("/")
                        if len(parts) != 4:
                            raise ValueError("invalid tile path")
                        zoom = int(parts[1]); x = int(parts[2]); y = int(parts[3][:-4])
                        body = _tile_bytes(owner._package, zoom, x, y)
                        self._reply(200, b"application/vnd.mapbox-vector-tile", body)
                        return
                    self.send_error(404)
                except (ValueError, OSError, sqlite3.Error, gzip.BadGzipFile):
                    self.send_error(500)

            def _reply(self, status: int, content_type: bytes, body: bytes, *, no_store: bool = False) -> None:
                self.send_response(status)
                self.send_header("Content-Type", content_type.decode("ascii"))
                self.send_header("Content-Length", str(len(body)))
                self.send_header("Access-Control-Allow-Origin", "*")
                self.send_header("Cache-Control", "no-store" if no_store else "public, max-age=31536000, immutable")
                self.end_headers()
                self.wfile.write(body)

        self._httpd = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
        self._httpd.daemon_threads = True
        self._thread = threading.Thread(target=self._httpd.serve_forever, name="aperture-vector-map", daemon=True)
        self._thread.start()

    @property
    def base_url(self) -> str:
        host, port = self._httpd.server_address[:2]
        return f"http://{host}:{port}/{self._token}"

    @property
    def document_url(self) -> str:
        return self.base_url + "/map.html"

    def close(self) -> None:
        self._httpd.shutdown()
        self._httpd.server_close()
