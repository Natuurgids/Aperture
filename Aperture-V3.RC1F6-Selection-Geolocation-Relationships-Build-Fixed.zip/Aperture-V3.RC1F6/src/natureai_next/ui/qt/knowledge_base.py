"""Independent Knowledge Base workspace for AI review and taxonomy enrichment."""
from __future__ import annotations

import sqlite3
from pathlib import Path

from PySide6.QtCore import QSettings, Qt, QTimer, Slot
from PySide6.QtWidgets import (
    QAbstractItemView,
    QComboBox,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QPushButton,
    QSplitter,
    QTableWidget,
    QTableWidgetItem,
    QTabWidget,
    QVBoxLayout,
    QWidget,
    QHeaderView,
)


class KnowledgeDataView(QWidget):
    """Searchable, read-only cross-provider view over library knowledge records."""

    def __init__(self, library_database: Path, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self._database = Path(library_database)
        self._search = QLineEdit()
        self._search.setPlaceholderText("Search filename, AI prediction, scientific name, common name, provider, or state…")
        self._provider = QComboBox(); self._provider.addItems(("All providers", "BioCLIP", "GBIF"))
        self._state = QComboBox(); self._state.addItems(("All states", "pending", "deferred", "accepted", "rejected", "superseded"))
        self._table = QTableWidget(0, 8)
        self._table.setHorizontalHeaderLabels(("Photo", "Provider", "Prediction / taxon", "Confidence", "State", "Rank", "Source / model", "Updated"))
        self._table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self._table.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
        self._table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        header = self._table.horizontalHeader()
        header.setSectionResizeMode(0, QHeaderView.ResizeMode.Stretch)
        header.setSectionResizeMode(2, QHeaderView.ResizeMode.Stretch)
        for column in (1, 3, 4, 5, 6, 7):
            header.setSectionResizeMode(column, QHeaderView.ResizeMode.ResizeToContents)
        self._status = QLabel("Knowledge data is read directly from the active Library database.")
        self._status.setWordWrap(True)
        refresh = QPushButton("Refresh"); refresh.clicked.connect(self.refresh)
        row = QHBoxLayout(); row.addWidget(self._search, 1); row.addWidget(self._provider); row.addWidget(self._state); row.addWidget(refresh)
        layout = QVBoxLayout(self); layout.addLayout(row); layout.addWidget(self._table, 1); layout.addWidget(self._status)
        self._timer = QTimer(self); self._timer.setSingleShot(True); self._timer.setInterval(220); self._timer.timeout.connect(self.refresh)
        self._search.textChanged.connect(lambda _text: self._timer.start())
        self._provider.currentTextChanged.connect(lambda _text: self.refresh())
        self._state.currentTextChanged.connect(lambda _text: self.refresh())
        self.refresh()

    def _connect(self) -> sqlite3.Connection:
        connection = sqlite3.connect(f"file:{self._database.as_posix()}?mode=ro", uri=True)
        connection.row_factory = sqlite3.Row
        return connection

    @staticmethod
    def _tables(connection: sqlite3.Connection) -> set[str]:
        return {str(row[0]) for row in connection.execute("SELECT name FROM sqlite_master WHERE type='table'")}

    @Slot()
    def refresh(self) -> None:
        if not self._database.is_file():
            self._table.setRowCount(0); self._status.setText("The active Library database is not available."); return
        query = self._search.text().strip().casefold()
        provider = self._provider.currentText()
        state = self._state.currentText()
        rows: list[tuple[str, ...]] = []
        try:
            with self._connect() as connection:
                tables = self._tables(connection)
                if "ai_suggestions" in tables:
                    sql = """
                        SELECT COALESCE(fi.normalized_path,a.title,a.public_id) photo,
                               COALESCE(s.candidate_label,t.scientific_name,'Unlabelled suggestion') label,
                               COALESCE(s.calibrated_score,s.raw_score) confidence,
                               s.review_state state, COALESCE(s.taxonomic_level,t.rank,'') rank,
                               COALESCE(mp.model_identity,'BioCLIP') source,
                               COALESCE(s.reviewed_at_us,s.created_at_us,0) updated
                        FROM ai_suggestions s
                        LEFT JOIN assets a ON a.id=s.asset_id
                        LEFT JOIN file_instances fi ON fi.id=a.primary_file_instance_id
                        LEFT JOIN taxa t ON t.id=s.candidate_taxon_id
                        LEFT JOIN inference_runs ir ON ir.id=s.inference_run_id
                        LEFT JOIN model_variants mv ON mv.id=ir.model_variant_id
                        LEFT JOIN model_packages mp ON mp.id=mv.package_id
                        ORDER BY updated DESC LIMIT 5000
                    """
                    for item in connection.execute(sql):
                        candidate = " ".join(str(item[key] or "") for key in item.keys()).casefold()
                        if provider == "GBIF" or (state != "All states" and item["state"] != state) or (query and query not in candidate): continue
                        score = "" if item["confidence"] is None else f"{float(item['confidence']):.3f}"
                        rows.append((str(item["photo"] or ""), "BioCLIP", str(item["label"] or ""), score, str(item["state"] or ""), str(item["rank"] or ""), str(item["source"] or "BioCLIP"), str(item["updated"] or "")))
                if "asset_taxonomy_enrichments" in tables and state in ("All states", "accepted"):
                    sql = """
                        SELECT COALESCE(fi.normalized_path,a.title,a.public_id) photo,
                               e.scientific_name,COALESCE(e.vernacular_name,'') vernacular,
                               COALESCE(e.rank,'') rank,e.source_key,e.source_database_identity,e.modified_at_us
                        FROM asset_taxonomy_enrichments e
                        JOIN assets a ON a.id=e.asset_id
                        LEFT JOIN file_instances fi ON fi.id=a.primary_file_instance_id
                        ORDER BY e.modified_at_us DESC LIMIT 5000
                    """
                    for item in connection.execute(sql):
                        candidate = " ".join(str(item[key] or "") for key in item.keys()).casefold()
                        if provider == "BioCLIP" or (query and query not in candidate): continue
                        label = str(item["scientific_name"] or "")
                        if item["vernacular"]: label += f" — {item['vernacular']}"
                        rows.append((str(item["photo"] or ""), str(item["source_key"] or "GBIF").upper(), label, "", "accepted", str(item["rank"] or ""), str(item["source_database_identity"] or ""), str(item["modified_at_us"] or "")))
            rows.sort(key=lambda row: row[7], reverse=True)
            self._table.setRowCount(len(rows))
            for r, values in enumerate(rows):
                for c, value in enumerate(values): self._table.setItem(r, c, QTableWidgetItem(value))
            self._status.setText(f"{len(rows):,} knowledge record(s) shown • BioCLIP and GBIF remain independent providers.")
        except Exception as exc:
            self._table.setRowCount(0); self._status.setText(f"Knowledge search unavailable: {exc}")


class KnowledgeBaseWorkspace(QWidget):
    """Top-level, independently persisted workspace for all enrichment knowledge."""

    def __init__(self, *, library_database: Path, ai_review: QWidget, gbif_taxonomy: QWidget, reference_taxonomy: QWidget | None = None, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.setObjectName("knowledgeBaseWorkspace")
        self._settings = QSettings()
        self._active = False
        self._data = KnowledgeDataView(library_database, self)
        self._tabs = QTabWidget(); self._tabs.setObjectName("knowledgeBaseTabs")
        self._tabs.addTab(self._data, "All Knowledge")
        self._tabs.addTab(ai_review, "AI Review · BioCLIP")
        self._tabs.addTab(gbif_taxonomy, "Taxonomy · GBIF")
        if reference_taxonomy is not None: self._tabs.addTab(reference_taxonomy, "Reference Knowledge")
        navigation = QWidget(); navigation.setMinimumWidth(180); navigation.setMaximumWidth(280)
        nav_layout = QVBoxLayout(navigation)
        title = QLabel("Knowledge Base"); title.setStyleSheet("font-size: 18px; font-weight: 600;")
        nav_layout.addWidget(title)
        intro = QLabel("Search and review AI predictions, independent taxonomy sources, and applied enrichment without crowding the Library inspector.")
        intro.setWordWrap(True); nav_layout.addWidget(intro)
        for text, index in (("All Knowledge", 0), ("AI Review · BioCLIP", 1), ("Taxonomy · GBIF", 2)):
            button = QPushButton(text); button.clicked.connect(lambda _checked=False, i=index: self._tabs.setCurrentIndex(i)); nav_layout.addWidget(button)
        nav_layout.addStretch(1)
        self._splitter = QSplitter(Qt.Orientation.Horizontal); self._splitter.setObjectName("knowledgeBaseMainSplitter")
        self._splitter.addWidget(navigation); self._splitter.addWidget(self._tabs); self._splitter.setStretchFactor(0, 0); self._splitter.setStretchFactor(1, 1)
        layout = QVBoxLayout(self); layout.setContentsMargins(0, 0, 0, 0); layout.addWidget(self._splitter)
        saved = self._settings.value("ui/knowledge_base/main_splitter")
        if saved is not None: self._splitter.restoreState(saved)
        else: self._splitter.setSizes((220, 980))
        self._ai_review = ai_review; self._gbif = gbif_taxonomy; self._reference = reference_taxonomy

    def activate(self) -> None:
        self._active = True
        current = self._tabs.currentWidget()
        if hasattr(current, "refresh"): current.refresh()

    def deactivate(self) -> None:
        self._active = False
        self._settings.setValue("ui/knowledge_base/main_splitter", self._splitter.saveState())

    def show_ai_review(self) -> None:
        self._tabs.setCurrentIndex(1)
        if hasattr(self._ai_review, "refresh"): self._ai_review.refresh()

    def show_taxonomy(self) -> None:
        self._tabs.setCurrentIndex(2)
        if hasattr(self._gbif, "refresh"): self._gbif.refresh()

    def show_taxon(self, taxon_public_id: str, local_identity: bool = True) -> None:
        if self._reference is not None and hasattr(self._reference, "show_taxon"):
            self._tabs.setCurrentWidget(self._reference); self._reference.show_taxon(taxon_public_id, local_identity=local_identity)
        else: self.show_taxonomy()

    def refresh(self) -> None:
        self._data.refresh()
        current = self._tabs.currentWidget()
        if current is not self._data and hasattr(current, "refresh"): current.refresh()
