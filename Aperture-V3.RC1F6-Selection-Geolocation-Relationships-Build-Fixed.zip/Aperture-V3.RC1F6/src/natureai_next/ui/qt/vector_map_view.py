"""Lazy WebEngine view shell for independent local vector MBTiles databases."""
from __future__ import annotations

import html
import json
from pathlib import Path
from typing import Any

from natureai_next.ui.qt.map_archive_scheme import package_authority, package_id_from_scheme_url
from natureai_next.ui.qt.vector_style import load_aperture_street_style


def vector_overlay_data(result: Any, temporal_frame: Any = None, gps_track: Any = None) -> dict[str, object]:
    """Convert map projections into local GeoJSON overlay collections."""
    observations = result.observations if temporal_frame is None else temporal_frame.observations

    def point(longitude: float, latitude: float, **properties: object) -> dict[str, object]:
        return {
            "type": "Feature",
            "geometry": {"type": "Point", "coordinates": [longitude, latitude]},
            "properties": properties,
        }

    observation_features = [
        point(item.longitude, item.latitude, kind="observation",
              public_id=item.observation_public_id,
              label=item.scientific_name or "Observation")
        for item in observations
    ]
    asset_features = [
        point(item.longitude, item.latitude, kind="photo",
              public_id=item.asset_public_id, label="Photograph")
        for item in result.assets
    ]
    site_features = [
        point(item.longitude, item.latitude, kind="site",
              public_id=item.public_id, label=item.name)
        for item in result.sites
        if item.latitude is not None and item.longitude is not None
    ]
    track_features: list[dict[str, object]] = []
    if temporal_frame is not None and temporal_frame.track is not None:
        coordinates = [[item.longitude, item.latitude] for item in temporal_frame.track.points]
        if len(coordinates) >= 2:
            track_features.append({
                "type": "Feature",
                "geometry": {"type": "LineString", "coordinates": coordinates},
                "properties": {"kind": "track"},
            })
    if gps_track is not None:
        for segment in gps_track.segments:
            coordinates = [[item.longitude, item.latitude] for item in segment]
            if len(coordinates) >= 2:
                track_features.append({
                    "type": "Feature",
                    "geometry": {"type": "LineString", "coordinates": coordinates},
                    "properties": {"kind": "gpx", "name": gps_track.name},
                })

    def collection(features: list[dict[str, object]]) -> dict[str, object]:
        return {"type": "FeatureCollection", "features": features}

    return {
        "aperture-observations": collection(observation_features),
        "aperture-assets": collection(asset_features),
        "aperture-sites": collection(site_features),
        "aperture-track": collection(track_features),
    }


def vector_map_html(package_public_id: str, asset_root: Path, *, longitude: float = 0.0, latitude: float = 0.0, zoom: int = 2, base_url: str | None = None) -> str:
    """Build a local MapLibre document backed by direct MBTiles tile requests."""
    authority = package_authority(package_public_id)
    package_id_from_scheme_url("aperture-map", authority, "/tile/0/0/0.pbf")
    if base_url:
        css = base_url + "/assets/maplibre-gl.css"
        maplibre = base_url + "/assets/maplibre-gl.js"
        tile_url = base_url + "/tile/{z}/{x}/{y}.pbf"
    else:
        css = (asset_root / "maplibre-gl.css").resolve().as_uri()
        maplibre = (asset_root / "maplibre-gl.js").resolve().as_uri()
        tile_url = f"aperture-map://{authority}/tile/{{z}}/{{x}}/{{y}}.pbf"
    style = load_aperture_street_style(asset_root / "aperture-streets-v1.json", tile_url)
    config = json.dumps({"style": style, "center": [longitude, latitude], "zoom": zoom})
    return f"""<!doctype html>
<html><head><meta charset=\"utf-8\"><meta name=\"referrer\" content=\"no-referrer\">
<link rel=\"stylesheet\" href=\"{html.escape(css, quote=True)}\">
<style>html,body,#map{{width:100%;height:100%;margin:0}}#status,#coordinates,#legend{{position:absolute;z-index:2;padding:8px;background:#fffffff0;font:12px sans-serif}}#coordinates{{right:8px;bottom:24px}}#legend{{left:8px;bottom:24px;line-height:1.6}}.key{{display:inline-block;width:10px;height:10px;border-radius:50%;margin-right:5px}}</style>
</head><body><div id=\"status\">Preparing offline vector map…</div><div id=\"coordinates\">Coordinates unavailable</div><div id=\"legend\"><span class=\"key\" style=\"background:#be3a34\"></span>Observation&nbsp; <span class=\"key\" style=\"background:#2f8f5b\"></span>Photo&nbsp; <span class=\"key\" style=\"background:#285c9d\"></span>Site&nbsp; <span class=\"key\" style=\"background:#e07b24\"></span>GPS track</div><div id=\"map\"></div>
<script src=\"{html.escape(maplibre, quote=True)}\"></script>
<script>const aperture={config};
try {{
const map=new maplibregl.Map({{container:'map',style:aperture.style,center:aperture.center,zoom:aperture.zoom,maxZoom:18}});
window.apertureMap={{map:map}}; window.apertureOverlayData={{}};
map.addControl(new maplibregl.NavigationControl({{showCompass:true,showZoom:true}}),'top-right');
map.on('error',event=>{{const message=(event&&event.error&&event.error.message)||'Unknown vector tile error';const status=document.getElementById('status');if(status){{status.style.display='block';status.textContent='Offline basemap error: '+message;}}console.error(event&&event.error?event.error:event);}});
map.once('load',()=>{{
const empty={{type:'FeatureCollection',features:[]}};
for(const name of ['aperture-observations','aperture-assets','aperture-sites','aperture-track']) map.addSource(name,{{type:'geojson',data:empty}});
map.addLayer({{id:'aperture-track-line',type:'line',source:'aperture-track',paint:{{'line-color':['case',['==',['get','kind'],'gpx'],'#e07b24','#6f3fb6'],'line-width':4}}}});
map.addLayer({{id:'aperture-photo-points',type:'circle',source:'aperture-assets',paint:{{'circle-radius':5,'circle-color':'#2f8f5b','circle-stroke-color':'#fff','circle-stroke-width':2}}}});
map.addLayer({{id:'aperture-site-points',type:'circle',source:'aperture-sites',paint:{{'circle-radius':6,'circle-color':'#285c9d','circle-stroke-color':'#fff','circle-stroke-width':2}}}});
map.addLayer({{id:'aperture-observation-points',type:'circle',source:'aperture-observations',paint:{{'circle-radius':7,'circle-color':'#be3a34','circle-stroke-color':'#fff','circle-stroke-width':2}}}});
for(const [name,data] of Object.entries(window.apertureOverlayData)){{const source=map.getSource(name);if(source)source.setData(data);}}
const status=document.getElementById('status');if(status){{status.textContent='Offline basemap loaded';setTimeout(()=>{{status.style.display='none';}},1500);}}
}});
const coordinates=document.getElementById('coordinates');
map.on('mousemove',event=>coordinates.textContent=event.lngLat.lat.toFixed(5)+', '+event.lngLat.lng.toFixed(5)+' • zoom '+map.getZoom().toFixed(1));
map.on('moveend',()=>{{const center=map.getCenter();coordinates.textContent=center.lat.toFixed(5)+', '+center.lng.toFixed(5)+' • zoom '+map.getZoom().toFixed(1);if(window.apertureSuppressMove){{window.apertureSuppressMove=false;}}else{{document.title='aperture-view:'+JSON.stringify({{latitude:center.lat,longitude:center.lng,zoom:map.getZoom()}});}}}});
}} catch(error) {{ const status=document.getElementById('status');if(status)status.textContent='MBTiles renderer v2 unavailable: '+error.message;console.error(error); }}
</script></body></html>"""


def create_vector_map_view(profile: Any, package: Any, parent: Any = None) -> Any:
    """Create a page on the explicit map-only profile; import WebEngine lazily."""
    from PySide6.QtWebEngineCore import QWebEnginePage
    from PySide6.QtWebEngineWidgets import QWebEngineView

    asset_root = Path(__file__).resolve().parents[2] / "resources" / "map_renderer"
    page = QWebEnginePage(profile, parent)
    view = QWebEngineView(parent)
    view.setPage(page)
    from natureai_next.application.map_workspace import package_viewpoint
    from natureai_next.ui.qt.vector_map_server import VectorMapLoopbackServer
    viewpoint = package_viewpoint(package)
    def document_factory(base_url: str) -> str:
        return vector_map_html(
            package.public_id, asset_root,
            longitude=viewpoint.longitude, latitude=viewpoint.latitude, zoom=viewpoint.zoom,
            base_url=base_url,
        )
    server = VectorMapLoopbackServer(package, asset_root, document_factory)
    view.aperture_map_server = server
    view.destroyed.connect(lambda *_: server.close())
    from PySide6.QtCore import QUrl
    view.setUrl(QUrl(server.document_url))
    viewpoint_callbacks: list[Any] = []
    def title_changed(title: str) -> None:
        if not title.startswith("aperture-view:"):
            return
        try:
            payload = json.loads(title.removeprefix("aperture-view:"))
            latitude = float(payload["latitude"])
            longitude = float(payload["longitude"])
            zoom = float(payload["zoom"])
        except (KeyError, TypeError, ValueError, json.JSONDecodeError):
            return
        for callback in tuple(viewpoint_callbacks):
            callback(latitude, longitude, zoom)
    page.titleChanged.connect(title_changed)
    def set_viewpoint(longitude: float, latitude: float, zoom: int) -> None:
        options = json.dumps({"center": [longitude, latitude], "zoom": zoom})
        page.runJavaScript(f"if(window.apertureMap){{window.apertureSuppressMove=true;window.apertureMap.map.jumpTo({options});}}")
    def connect_viewpoint(callback: Any) -> None:
        viewpoint_callbacks.append(callback)
    def set_overlays(result: Any, temporal_frame: Any = None, gps_track: Any = None) -> None:
        payload = json.dumps(vector_overlay_data(result, temporal_frame, gps_track))
        page.runJavaScript(
            "window.apertureOverlayData=" + payload
            + ";if(window.apertureMap){for(const [name,data] of Object.entries(window.apertureOverlayData)"
            + ")){const source=window.apertureMap.map.getSource(name);if(source)source.setData(data);}}"
        )
    view.aperture_set_viewpoint = set_viewpoint
    view.aperture_connect_viewpoint = connect_viewpoint
    view.aperture_set_overlays = set_overlays
    return view
