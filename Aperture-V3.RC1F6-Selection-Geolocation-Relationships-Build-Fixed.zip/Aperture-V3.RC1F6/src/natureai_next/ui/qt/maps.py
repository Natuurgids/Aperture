"""Lightweight Qt workspace for local OpenStreetMap-compatible MBTiles."""
from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass
import math
from pathlib import Path

from natureai_next.application.map_workspace import OfflineMapWorkspaceService, lat_to_tile_y, lon_to_tile_x, package_viewpoint
from natureai_next.application.temporal_map import TemporalMapService, TemporalPlaybackState
from natureai_next.domain.temporal_movement import TemporalDisplayMode, TemporalStep, TimeWindow
from natureai_next.domain.maps import GpsTrack
from natureai_next.ports.gps_tracks import GpsTrackLoader

try:
    from PySide6.QtCore import Qt, QRectF, Signal, QDateTime, QTimer
    from PySide6.QtGui import QBrush, QColor, QPainter, QPen, QPixmap
    from PySide6.QtWidgets import (
        QComboBox, QDateTimeEdit, QGraphicsEllipseItem, QGraphicsLineItem, QGraphicsPixmapItem, QGraphicsScene, QGraphicsTextItem,
        QFileDialog, QGraphicsView, QGridLayout, QHBoxLayout, QLabel, QMessageBox,
        QPushButton, QStackedWidget, QVBoxLayout, QWidget,
    )
except ImportError as exc:  # pragma: no cover
    raise RuntimeError("PySide6 is required; install natureai-next[gui]") from exc


@dataclass(slots=True)
class MapViewState:
    latitude: float = 0.0
    longitude: float = 0.0
    zoom: int = 2


class OfflineMapCanvas(QGraphicsView):
    observation_requested = Signal(str)

    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.setRenderHint(QPainter.RenderHint.SmoothPixmapTransform, True)
        self.setScene(QGraphicsScene(self))
        self.setMinimumSize(640, 480)
        self.setBackgroundBrush(QBrush(QColor("#d8dde3")))

    def show_result(self, service: OfflineMapWorkspaceService, state: MapViewState, temporal_frame=None, gps_track: GpsTrack | None = None) -> tuple[str, str]:
        scene = self.scene(); scene.clear()
        result = service.workspace(latitude=state.latitude, longitude=state.longitude, zoom=state.zoom)
        tile_size = 256
        center_x = lon_to_tile_x(state.longitude, state.zoom)
        center_y = lat_to_tile_y(state.latitude, state.zoom)
        base_x = math.floor(center_x) - 1
        base_y = math.floor(center_y) - 1
        world_count = 1 << state.zoom
        package = result.package
        for row in range(3):
            for column in range(3):
                tile_x = base_x + column
                tile_y = base_y + row
                rect = QRectF(column * tile_size, row * tile_size, tile_size, tile_size)
                if package is not None and 0 <= tile_y < world_count:
                    wrapped_x = tile_x % world_count
                    tile = service.tile(package.public_id, state.zoom, wrapped_x, tile_y)
                    if tile is not None:
                        pixmap = QPixmap(); pixmap.loadFromData(tile.data)
                        item = QGraphicsPixmapItem(pixmap)
                        item.setPos(rect.x(), rect.y()); scene.addItem(item)
                        continue
                scene.addRect(rect, QPen(QColor("#a7adb5")), QBrush(QColor("#eef1f4")))

        def marker_position(latitude: float, longitude: float) -> tuple[float, float]:
            x = (lon_to_tile_x(longitude, state.zoom) - base_x) * tile_size
            y = (lat_to_tile_y(latitude, state.zoom) - base_y) * tile_size
            return x, y

        observations = result.observations if temporal_frame is None else temporal_frame.observations
        for observation in observations:
            x, y = marker_position(observation.latitude, observation.longitude)
            marker = QGraphicsEllipseItem(x - 6, y - 6, 12, 12)
            marker.setBrush(QBrush(QColor("#be3a34"))); marker.setPen(QPen(QColor("white"), 2))
            marker.setToolTip(observation.scientific_name or observation.observation_public_id)
            marker.setData(0, observation.observation_public_id); scene.addItem(marker)
        for asset in result.assets:
            x, y = marker_position(asset.latitude, asset.longitude)
            marker = QGraphicsEllipseItem(x - 5, y - 5, 10, 10)
            marker.setBrush(QBrush(QColor("#2f8f5b"))); marker.setPen(QPen(QColor("white"), 2))
            marker.setToolTip(f"Photograph {asset.asset_public_id}")
            scene.addItem(marker)
        if temporal_frame is not None and temporal_frame.track is not None:
            points = temporal_frame.track.points
            for first, second in zip(points, points[1:]):
                x1, y1 = marker_position(first.latitude, first.longitude)
                x2, y2 = marker_position(second.latitude, second.longitude)
                line = QGraphicsLineItem(x1, y1, x2, y2)
                pen = QPen(QColor("#6f3fb6"), 3)
                if not (first.verified and second.verified):
                    pen.setStyle(Qt.PenStyle.DashLine)
                line.setPen(pen); scene.addItem(line)
        if gps_track is not None:
            for segment in gps_track.segments:
                for first, second in zip(segment, segment[1:]):
                    x1, y1 = marker_position(first.latitude, first.longitude)
                    x2, y2 = marker_position(second.latitude, second.longitude)
                    line = QGraphicsLineItem(x1, y1, x2, y2)
                    line.setPen(QPen(QColor("#e07b24"), 3)); scene.addItem(line)
        for site in result.sites:
            if site.latitude is None or site.longitude is None: continue
            x, y = marker_position(site.latitude, site.longitude)
            marker = QGraphicsEllipseItem(x - 5, y - 5, 10, 10)
            marker.setBrush(QBrush(QColor("#285c9d"))); marker.setPen(QPen(QColor("white"), 2))
            marker.setToolTip(site.name); scene.addItem(marker)

        if package is None:
            text = QGraphicsTextItem("No enabled offline map package covers this view")
            text.setDefaultTextColor(QColor("#333333")); text.setPos(18, 18); scene.addItem(text)
        scene.setSceneRect(0, 0, tile_size * 3, tile_size * 3)
        self.fitInView(scene.sceneRect(), Qt.AspectRatioMode.KeepAspectRatio)
        return result.attribution, result.attribution_url

    def mouseDoubleClickEvent(self, event) -> None:  # type: ignore[no-untyped-def]
        item = self.itemAt(event.position().toPoint())
        if item is not None:
            public_id = item.data(0)
            if isinstance(public_id, str):
                self.observation_requested.emit(public_id)
                return
        super().mouseDoubleClickEvent(event)


class OfflineMapWorkspace(QWidget):
    """First offline map UI; service creation stays lazy until the workspace opens."""

    observation_requested = Signal(str)

    def __init__(self, service_factory: Callable[[], OfflineMapWorkspaceService], temporal_service_factory: Callable[[], TemporalMapService] | None = None, vector_view_factory: Callable[[object, QWidget], QWidget] | None = None, gps_track_loader: GpsTrackLoader | None = None, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self._service_factory = service_factory
        self._temporal_service_factory = temporal_service_factory
        self._temporal_service: TemporalMapService | None = None
        self._service: OfflineMapWorkspaceService | None = None
        self._vector_view_factory = vector_view_factory
        self._vector_view: QWidget | None = None
        self._vector_package_id: str | None = None
        self._gps_track_loader = gps_track_loader
        self._gps_track: GpsTrack | None = None
        self._state = MapViewState()
        self._updating_areas = False
        layout = QVBoxLayout(self)
        controls = QHBoxLayout()
        for label, dlat, dlon in (("←", 0, -1), ("↑", 1, 0), ("↓", -1, 0), ("→", 0, 1)):
            button = QPushButton(label); button.setToolTip("Pan map")
            button.clicked.connect(lambda _checked=False, a=dlat, b=dlon: self._pan(a, b))
            controls.addWidget(button)
        self._zoom = QComboBox(); self._zoom.addItems(str(value) for value in range(0, 19)); self._zoom.setCurrentText("2")
        self._zoom.currentTextChanged.connect(self._set_zoom); controls.addWidget(QLabel("Zoom")); controls.addWidget(self._zoom)
        self._areas = QComboBox()
        self._areas.setToolTip("Enabled offline map areas")
        self._areas.currentIndexChanged.connect(self._area_changed)
        controls.addWidget(QLabel("Area")); controls.addWidget(self._areas)
        self._zoom_to_area = QPushButton("Zoom to Area")
        self._zoom_to_area.clicked.connect(self._zoom_to_selected_area)
        controls.addWidget(self._zoom_to_area)
        refresh = QPushButton("Refresh")
        refresh.clicked.connect(lambda: self.refresh(auto_center=True))
        controls.addWidget(refresh)
        self._open_gpx = QPushButton("Open GPX Track…")
        self._open_gpx.setEnabled(gps_track_loader is not None)
        self._open_gpx.clicked.connect(self._open_gpx_track)
        controls.addWidget(self._open_gpx)
        self._clear_gpx = QPushButton("Clear Track")
        self._clear_gpx.setEnabled(False)
        self._clear_gpx.clicked.connect(self._clear_gpx_track)
        controls.addWidget(self._clear_gpx); controls.addStretch(1)
        layout.addLayout(controls)
        timeline = QGridLayout()
        self._start = QDateTimeEdit(QDateTime.currentDateTime().addYears(-1)); self._start.setCalendarPopup(True)
        self._end = QDateTimeEdit(QDateTime.currentDateTime()); self._end.setCalendarPopup(True)
        self._mode = QComboBox(); self._mode.addItems([mode.value for mode in TemporalDisplayMode])
        self._step = QComboBox(); self._step.addItems([step.value for step in TemporalStep]); self._step.setCurrentText(TemporalStep.MONTH.value)
        self._series = QComboBox(); self._series.setEditable(True); self._series.setToolTip("Series public ID required for trail mode")
        self._play = QPushButton("Play"); self._play.clicked.connect(self._toggle_playback)
        timeline.addWidget(QLabel("From"),0,0); timeline.addWidget(self._start,0,1)
        timeline.addWidget(QLabel("To"),0,2); timeline.addWidget(self._end,0,3)
        timeline.addWidget(QLabel("Mode"),1,0); timeline.addWidget(self._mode,1,1)
        timeline.addWidget(QLabel("Step"),1,2); timeline.addWidget(self._step,1,3)
        timeline.addWidget(QLabel("Series"),2,0); timeline.addWidget(self._series,2,1,1,2); timeline.addWidget(self._play,2,3)
        for control in (self._start,self._end,self._mode,self._step,self._series):
            if hasattr(control, "dateTimeChanged"): control.dateTimeChanged.connect(self.refresh)
            elif hasattr(control, "currentTextChanged"): control.currentTextChanged.connect(self.refresh)
        layout.addLayout(timeline)
        self._timer = QTimer(self); self._timer.setInterval(1000); self._timer.timeout.connect(self._advance_playback)
        self._canvas = OfflineMapCanvas(self); self._canvas.observation_requested.connect(self.observation_requested)
        self._map_stack = QStackedWidget(self); self._map_stack.addWidget(self._canvas)
        layout.addWidget(self._map_stack, 1)
        self._status = QLabel("Open the map to activate the optional offline-map database.")
        self._status.setWordWrap(True); layout.addWidget(self._status)
        self._renderer_status = QLabel("")
        self._renderer_status.setWordWrap(True); layout.addWidget(self._renderer_status)
        self._attribution = QLabel(""); self._attribution.setOpenExternalLinks(True); layout.addWidget(self._attribution)

    def showEvent(self, event) -> None:  # type: ignore[no-untyped-def]
        super().showEvent(event)
        self.refresh(auto_center=True)

    def refresh(self, *, auto_center: bool = False) -> None:
        try:
            if self._service is None:
                self._service = self._service_factory()
            packages = self._refresh_area_selector()
            capabilities = self._service.package_capabilities()
            ready = sum(1 for item in capabilities if item.renderable)
            blocked = [item for item in capabilities if item.package_format in {"vector-mbtiles", "pmtiles"} and not item.renderable]
            if blocked:
                blocker = blocked[0].message
                self._renderer_status.setText(
                    f"Map engine: {ready} package(s) ready; {len(blocked)} valid vector package(s) blocked. {blocker}."
                )
            elif capabilities:
                self._renderer_status.setText(f"Map engine: {ready} installed package(s) ready in the current renderer.")
            else:
                self._renderer_status.setText("Map engine: no installed offline map packages.")
            current = self._service.workspace(
                latitude=self._state.latitude,
                longitude=self._state.longitude,
                zoom=self._state.zoom,
            )
            if auto_center and current.package is None and packages:
                self._set_state_to_package(packages[0])
            temporal_frame = None
            base = self._service.workspace(
                latitude=self._state.latitude,
                longitude=self._state.longitude,
                zoom=self._state.zoom,
            )
            if self._temporal_service_factory is not None:
                if self._temporal_service is None:
                    self._temporal_service = self._temporal_service_factory()
                start_us = self._start.dateTime().toMSecsSinceEpoch() * 1000
                end_us = self._end.dateTime().toMSecsSinceEpoch() * 1000
                window = TimeWindow(start_us, end_us)
                mode = TemporalDisplayMode(self._mode.currentText())
                series = self._series.currentText().strip() or None
                temporal_frame = self._temporal_service.frame(bounds=base.bounds, window=window, display_mode=mode, series_public_id=series)
            selected_id = self._areas.currentData()
            selected = self._service.package(selected_id) if isinstance(selected_id, str) else None
            if selected is not None and selected.format == "vector-mbtiles" and self._vector_view_factory is not None:
                if self._vector_view is None or self._vector_package_id != selected.public_id:
                    if self._vector_view is not None:
                        self._map_stack.removeWidget(self._vector_view); self._vector_view.deleteLater()
                    self._vector_view = self._vector_view_factory(selected, self)
                    connector = getattr(self._vector_view, "aperture_connect_viewpoint", None)
                    if callable(connector): connector(self._vector_viewpoint_changed)
                    self._vector_package_id = selected.public_id; self._map_stack.addWidget(self._vector_view)
                self._map_stack.setCurrentWidget(self._vector_view)
                updater = getattr(self._vector_view, "aperture_set_viewpoint", None)
                if callable(updater): updater(self._state.longitude, self._state.latitude, self._state.zoom)
                overlay_updater = getattr(self._vector_view, "aperture_set_overlays", None)
                if callable(overlay_updater): overlay_updater(base, temporal_frame, self._gps_track)
                attribution, url = selected.attribution, selected.attribution_url
            else:
                self._map_stack.setCurrentWidget(self._canvas)
                attribution, url = self._canvas.show_result(
                    self._service, self._state, temporal_frame, self._gps_track
                )
            self._status.setText(f"Center {self._state.latitude:.4f}, {self._state.longitude:.4f} • zoom {self._state.zoom}")
            self._attribution.setText(f'<a href="{url}">{attribution}</a>' if attribution and url else attribution)
        except Exception as exc:  # isolate optional subsystem errors from the desktop shell
            self._status.setText(f"Offline map unavailable: {exc}")
            self._renderer_status.setText("Map engine readiness could not be determined.")
            self._attribution.clear()

    def _refresh_area_selector(self):
        assert self._service is not None
        packages = self._service.available_packages()
        selected = self._areas.currentData()
        self._updating_areas = True
        try:
            self._areas.clear()
            for package in packages:
                self._areas.addItem(package.package_name, package.public_id)
            if selected is not None:
                index = self._areas.findData(selected)
                if index >= 0:
                    self._areas.setCurrentIndex(index)
        finally:
            self._updating_areas = False
        self._areas.setEnabled(bool(packages))
        self._zoom_to_area.setEnabled(bool(packages))
        return packages

    def _area_changed(self, _index: int) -> None:
        if not self._updating_areas and self._areas.currentData() is not None:
            self._zoom_to_selected_area()

    def _zoom_to_selected_area(self) -> None:
        if self._service is None:
            self._service = self._service_factory()
        public_id = self._areas.currentData()
        if not isinstance(public_id, str):
            self._status.setText("No enabled offline map area is installed.")
            return
        try:
            package = self._service.package(public_id)
            self._set_state_to_package(package)
            self.refresh()
        except Exception as exc:
            self._status.setText(f"Cannot open offline map area: {exc}")

    def _set_state_to_package(self, package) -> None:
        viewpoint = package_viewpoint(package)
        self._state.latitude = viewpoint.latitude
        self._state.longitude = viewpoint.longitude
        self._state.zoom = viewpoint.zoom
        self._zoom.blockSignals(True)
        try:
            self._zoom.setCurrentText(str(viewpoint.zoom))
        finally:
            self._zoom.blockSignals(False)

    def _set_zoom(self, value: str) -> None:
        self._state.zoom = int(value); self.refresh()

    def _vector_viewpoint_changed(self, latitude: float, longitude: float, zoom: float) -> None:
        self._state.latitude = max(-85.0, min(85.0, latitude))
        self._state.longitude = ((longitude + 180.0) % 360.0) - 180.0
        self._state.zoom = max(0, min(18, int(round(zoom))))
        self._zoom.blockSignals(True)
        try:
            self._zoom.setCurrentText(str(self._state.zoom))
        finally:
            self._zoom.blockSignals(False)
        QTimer.singleShot(0, self.refresh)

    def _open_gpx_track(self) -> None:
        if self._gps_track_loader is None:
            return
        filename, _ = QFileDialog.getOpenFileName(
            self, "Open GPS track", "", "GPX tracks (*.gpx);;All files (*)"
        )
        if not filename:
            return
        try:
            self._gps_track = self._gps_track_loader.load(Path(filename))
        except (OSError, ValueError) as exc:
            QMessageBox.critical(self, "GPS track", str(exc))
            return
        self._clear_gpx.setEnabled(True)
        self._status.setText(
            f"Loaded GPS track {self._gps_track.name} ({self._gps_track.point_count} points)."
        )
        self.refresh()

    def _clear_gpx_track(self) -> None:
        self._gps_track = None
        self._clear_gpx.setEnabled(False)
        self.refresh()

    def _pan(self, latitude_direction: int, longitude_direction: int) -> None:
        step = max(0.05, 90.0 / (1 << max(0, self._state.zoom)))
        self._state.latitude = max(-85.0, min(85.0, self._state.latitude + latitude_direction * step))
        self._state.longitude = ((self._state.longitude + longitude_direction * step + 180.0) % 360.0) - 180.0
        self.refresh()

    def _toggle_playback(self) -> None:
        if self._timer.isActive():
            self._timer.stop(); self._play.setText("Play")
        else:
            self._timer.start(); self._play.setText("Pause")

    def _advance_playback(self) -> None:
        start = self._start.dateTime()
        end = self._end.dateTime()
        days = {"day":1,"week":7,"month":30,"season":91,"year":365}[self._step.currentText()]
        self._start.setDateTime(start.addDays(days))
        self._end.setDateTime(end.addDays(days))
        self.refresh()
