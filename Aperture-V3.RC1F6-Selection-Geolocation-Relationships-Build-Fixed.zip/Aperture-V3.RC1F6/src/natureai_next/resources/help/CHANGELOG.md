
## RC1F6 review workflow correction

- Accept now persists the selected row as accepted and records canonical enrichment.
- Renamed Accept & Next to Accept All Pending & Next. It affects only pending rows for the current photograph.
- Renamed Accept & Reject Rest to Accept Only & Next. It accepts the selected pending row and rejects only other pending rows.
- Both next actions advance to the next photograph that still has pending review.
- Accepted taxonomy enrichment is multi-valued per photograph; accepting multiple pending detections no longer supersedes earlier accepted detections.

# Changelog

## [3.0.0rc1.post2] — V3.RC1F2 Responsive Startup Splash

- Added an Aperture-branded startup splash using the existing packaged system logo.
- Added real startup milestone text and weighted progress.
- Reused one QApplication across splash and desktop construction.
- Added `startup-splash-visible` timing telemetry.
- Closed the splash immediately when the usable main window is shown.

# Aperture V3.RC1F1 — Integrated NatureAI release candidate

Version **3.0.0rc1.post1** promotes the completed Build 3.336 stabilization work into the first Version 3 release candidate.

## NatureAI engine

- BioCLIP, `pybioclip==2.1.5`, `TreeOfLifeClassifier`, the original BioCLIP v1 model identity, and the matching Tree-of-Life resources are installed and validated as one engine.
- Initial Full AI installation primes the Tree-of-Life classifier and activates it automatically; a CSV and GBIF are not required for the original NatureAI classification path.
- Aperture taxonomy prompt sets remain supported as optional bounded or custom classifiers. Empty prompt sets are not accepted as ready.
- GBIF remains an independent taxonomy/enrichment component and may resolve or enrich NatureAI results without being a prerequisite for inference.
- Maintenance Center can download, resume, import, validate, repair, and reactivate the complete NatureAI/BioCLIP environment.

## Knowledge Base and workspaces

- Knowledge Base exposes BioCLIP/NatureAI, GBIF taxonomy, and reference resources as independent components.
- Library and Collections retain independent workspaces, splitter state, and inspector containment.

## Upgrade notes

Install over the approved prior release, then run **Maintenance Center → Repair Full AI / NatureAI Engine** when upgrading an existing environment. Confirm **Tree of Life classifier: Ready** before starting AI Review. Existing libraries and GBIF databases are not replaced.

## Release identity

- Product release: **Aperture V3.RC1F1**
- Python package version: **3.0.0rc1.post1**
- Baseline implementation: Build 3.336 post22

---

## Build 3.326 — Detached Taxonomy Builder and Working Sets

- GBIF taxonomy construction now runs as a detached operating-system process that survives Aperture restarts.
- Added persistent JSON status, cooperative cancellation, 5,000-row checkpoints, and safe resume into the isolated `.next.sqlite3` database.
- Aperture reattaches to an existing source-build job instead of starting a duplicate import.
- Added read-only taxonomy working-set filters for kingdom, class, order/subgroup, family, and rank.
- Added cascading selection suitable for views such as Animalia → Aves → Accipitriformes (birds of prey).
- Working-set definitions are stored separately from both the source database and the operational Aperture Library.

## Build 3.325 — PMTiles Transport and Isolated Taxonomy Worker

- Replaced custom-scheme PMTiles query requests with a path-based byte-range endpoint to avoid Qt WebEngine HTTP 400 responses on Windows.
- Added explicit CORS response headers for local PMTiles byte responses.
- Runs GBIF Darwin Core parsing and isolated taxonomy database construction in a spawned worker process, keeping the Qt interface responsive.
- Keeps the active GBIF database read-only and available while a replacement source database is built and validated.
- Stores only compact observation enrichment links in the operational database; taxonomy source rows remain external.

## Build 3.323 — Reliable Concurrent Map Builds and PMTiles Rendering

### Fixed
- Serialized Planetiler conversions that share Natural Earth, water polygon, and tile-weight downloads, preventing Windows `*_inprogress` rename races when multiple regions are queued.
- Removed abandoned Planetiler `*_inprogress` files only while holding the shared-source lock.
- Registered each installed PMTiles archive explicitly with the browser protocol and supplied an explicit tile template after reading the archive header and metadata.
- Kept renderer errors visible after map load so a failed archive or source layer no longer appears as an unexplained blank basemap.

### Release
- Bumped Aperture to 2.0.0 RC3 post 2 / Build 3.323.

## Build 3.322 — Darwin Core Folder Import and Metadata Compatibility

- Fixed the bare `'index'` failure caused by Darwin Core metadata whose `id` or `field` elements omit explicit column indexes. Aperture now assigns columns in declaration order when indexes are absent and reports malformed indexes clearly.
- Added direct import of an already-extracted Darwin Core Archive folder. The selected folder must contain one `meta.xml`; the declared core data file is read in place without recompressing or rewriting the source.
- Improved ZIP compatibility by accepting a Darwin Core Archive stored inside a single enclosing folder and by resolving the core file relative to `meta.xml`.
- Added deterministic source identity for extracted folders and retained strict path-safety checks for both folders and ZIP archives.
- Added focused regression tests for indexed archives, implicit-index archives, extracted folders, records-only archives, and unsafe archive paths.
- Bumped the maintenance release to Aperture 2.0.0 RC3 post 1 / Build 3.322.

## Build 3.321 GBIF Taxonomy, Offline Streets, and Resilient AI Downloads

- Added a dedicated raw GBIF Darwin Core Archive taxonomy importer under Taxonomy Resources.
- Kept taxonomy package installation independent from BioCLIP model package installation and reconciled them through taxonomy embedding rebuilds.
- Replaced the invalid glyph-dependent offline style with a local-only glyph-independent PMTiles street style.
- Added visible MapLibre source/style error reporting to the map surface.
- Added persistent resumable BioCLIP downloads using HTTP Range and retained `.part` files.
- Bumped the release to Aperture 2.0.0 RC3 / Build 3.321.

## Build 3.320 GBIF, Notebook, and Map Regression Fix

- Made locally rebuilt signed model packages byte-for-byte reproducible and safely accept legacy timestamp-only ZIP checksum changes when the installed manifest and artifacts are identical.
- Fixed Notebook sidebar selection by preserving the clicked page identity while autosaving the previous page without rebuilding the list.
- Fixed Planetiler PMTiles conversion by ensuring the staged output filename ends in `.pmtiles` rather than `.partial`.
- Retained strict rejection when a package identity is genuinely reused for different manifest or artifact content.

## Unreleased — Offline map Windows crash diagnostic fix

- Runs tilemaker with both a single worker and its supported on-disk OSM store.
- Retains the complete converter log after native failures and reports its path.
- Removes temporary store data after success, failure, or cancellation.

- Redesigned the Aperture Library as a three-pane workspace with persistent organization and filters, a larger responsive photo grid, a focused metadata inspector, and a consolidated command/search bar.
# Changelog

### BioCLIP regional acquisition performance

- Replaced sequential per-species GBIF taxonomy retrieval with a bounded 16-worker parallel downloader.
- Added atomic per-species cache publication so partial downloads survive cancellation, restart, and network failure.
- Added retry and exponential backoff for throttling and transient GBIF failures.
- Added resume-aware progress reporting and deterministic package assembly from cached records.
- The worker count can be tuned with `APERTURE_GBIF_WORKERS` (2-32; default 16).


## Unreleased — Windows tilemaker large-region crash fix

- Moved Geofabrik vector conversion node/way indexing to tilemaker's supported on-disk store.
- Prevented native Windows fast-fail crashes on larger extracts such as Algeria.
- Cleans the temporary tilemaker store after success, failure, or cancellation.

## Unreleased — Builds 3.273–3.320 complete Maps vertical slice

- Activated conforming PMTiles after every renderer prerequisite passes.
- Added canonical private authorities for catalog IDs such as `geofabrik:noord-holland`.
- Strengthened PMTiles vector, zoom, and internal-range verification.
- Added live coordinate display, navigation compass, rotation, marker legend, and marker details.
- Added vector overlays for photos, observations, sites, temporal tracks, and GPX tracks.
- Added bounded GPX 1.0/1.1 loading and raster/vector track display.
- Synchronizes interactive MapLibre viewport changes with Aperture spatial queries.
- Cleans removed partial sources and superseded verified package files safely.
- Added elapsed-time and output-size heartbeats during local map creation.

## Unreleased — Build 3.272 standard vector overzoom correction

- Changed tile generation from native zoom 16 to standard base zoom 14.
- Kept street-level interaction through MapLibre vector overzoom.
- Updated package conformance to distinguish generated and displayed zoom.
- Identifies native Windows fast-fail exit codes in conversion diagnostics.
- Clears stale failure details and recommendations when an activity retry starts.

## Unreleased — Build 3.271 restore capacity-aware map processing

- Removed the forced single-tilemaker lock introduced in Builds 3.262–3.270.
- Restored the existing system-capacity-based multiprocessing behavior.
- Retained all independent conversion safety and storage controls.

## Unreleased — Builds 3.262–3.270 serialized map conversion

- Limited local tilemaker conversion to one active process.
- Added cancellable waiting with an explicit Activity Center status.
- Kept downloads and unrelated background activity independent.

## Unreleased — Build 3.261 tilemaker zoom configuration fix

- Fixed an invalid tilemaker profile where base zoom 14 was below maximum zoom 16.
- Added a configuration contract test for `basezoom >= maxzoom`.

## Unreleased — Builds 3.251–3.260 map preparation storage guard

- Added conservative storage reservation for provider entries with unknown sizes.
- Shows unknown-size counts and reserved working space before queueing maps.
- Recalculates required space from response length before writing bulk data.
- Accounts for resumed downloads and staged vector output.

## Unreleased — Builds 3.241–3.250 bounded street-map conversion runtime

- Fixed a converter output-pipe deadlock risk during long regional jobs.
- Added bounded failure diagnostics without retaining unbounded logs.
- Added graceful cancellation with force-stop fallback.
- Ensured partial output and temporary logs are removed on every exit path.

## Unreleased — Builds 3.231–3.240 packaged Windows street-map converter

- Bundled the official tilemaker 3.0.0 Windows x86-64 executable.
- Pinned the upstream archive and executable checksums.
- Composed the converter into desktop and Maintenance offline-map setup.
- Added packaged-tool integrity and composition tests.

## Unreleased — Builds 3.221–3.230 verified tilemaker conversion adapter

- Added the Aperture street-layer tilemaker configuration and Lua process.
- Added SHA-256-gated, shell-free, cancellable PMTiles conversion.
- Added structural output validation and atomic publication.
- Kept the Windows executable unbundled pending authoritative artifact verification.

## Unreleased — Builds 3.211–3.220 Geofabrik vector conversion boundary

- Selected Geofabrik `.osm.pbf` inputs for new street-map preparation.
- Added a replaceable vector converter port and PMTiles output contract.
- Declared the Aperture street schema and zoom 16 target at the provider boundary.
- Stopped before download when the verified converter toolchain is unavailable.
- Preserved existing raster MBTiles without silently generating new zoom-10 maps.

## Unreleased — Builds 3.201–3.210 live vector workspace activation

- Revealed installed packages according to renderer capability.
- Added lazy stacked raster/vector presentation in Maps.
- Composed the private archive profile only for live Map use.
- Forwarded pan, zoom, and area changes to MapLibre.
- Preserved raster fallback and optional-failure isolation.

## Unreleased — Builds 3.191–3.200 trusted street metadata lifecycle

- Carried street schema, layers, and label fields through catalogs and bundles.
- Rejected incomplete declarations before acquisition.
- Persisted declarations through registration and verification.
- Prevented structural verification metadata from erasing approved conformance metadata.

## Unreleased — Builds 3.181–3.190 street-package conformance gate

- Required explicit `aperture-streets-v1` metadata before renderer selection.
- Required all street layers, road/place label fields, zoom 16+, attribution, and licence.
- Reported generic vector containers as schema-incompatible without deleting them.
- Preserved renderer probing for conforming packages only.

## Unreleased — Builds 3.171–3.180 offline local-font labels

- Added offline road and place labels using MapLibre local-font support.
- Selected Segoe UI with Arial fallback for the supported Windows runtime.
- Extended the street schema with the `place` layer and named roads.
- Preserved the prohibition on glyph URLs, sprites, and network resources.

## Unreleased — Builds 3.161–3.170 Aperture street schema and offline base style

- Defined the `aperture-streets-v1` vector-layer contract.
- Added a network-free style for land use, water, buildings, and roads.
- Rejected online sources and unapproved glyph or sprite resources.
- Instantiated MapLibre in the isolated shell while keeping labels and full acceptance pending.

## Unreleased — Builds 3.151–3.160 isolated vector renderer view shell

- Added a lazy WebEngine page/view factory on the map-only profile.
- Loaded only approved local MapLibre/PMTiles assets and the private archive URL.
- Registered PMTiles without network resources or arbitrary package paths.
- Kept style/schema selection and street-level rendering pending.

## Unreleased — Builds 3.141–3.150 map-only WebEngine profile composition

- Added lazy Bootstrap composition for an off-the-record map-only WebEngine profile.
- Disabled HTTP cache and persistent cookies.
- Wired the private scheme handler to catalog-authorized PMTiles ranges.
- Kept profile creation out of normal Library startup and renderer view integration pending.

## Unreleased — Builds 3.131–3.140 approved renderer asset candidate

- Bundled MapLibre GL JS 5.24.0 and PMTiles JS 4.4.1 browser artifacts.
- Preserved BSD-3-Clause notices and npm provenance.
- Approved exact artifacts through the SHA-256 renderer manifest.
- Excluded MapLibre 6 prereleases and did not activate vector rendering.

## Unreleased — Builds 3.121–3.130 renderer-asset trust gate

- Added a replaceable renderer-asset verification port.
- Required exact approved asset membership, pinned versions, licences, and SHA-256 hashes.
- Rejected missing, extra, incomplete, unapproved, and modified asset sets.
- Kept candidate JavaScript assets outside the release pending approval.

## Unreleased — Builds 3.111–3.120 optional scheme Bootstrap registration

- Registered the private map scheme before Qt desktop application construction.
- Isolated missing or unloadable WebEngine as an optional renderer condition.
- Preserved normal Aperture startup when the renderer runtime is unavailable.
- Kept profile installation and vector rendering pending.

## Unreleased — Builds 3.101–3.110 Qt WebEngine archive scheme adapter

- Added a lazy in-process `aperture-map://` Qt WebEngine scheme adapter.
- Restricted requests to catalog package IDs, one archive path, GET, and explicit ranges.
- Added partial-content response headers and request-owned reply buffers.
- Avoided localhost listeners and top-level WebEngine imports.
- Kept profile installation and vector-renderer activation pending.

## Unreleased — Builds 3.91–3.100 browser-range translation

- Added strict Application translation from one explicit browser byte range to the archive-reader port.
- Added transport-neutral partial-content response metadata.
- Rejected open-ended, suffix, reversed, malformed, and multi-range requests before storage access.
- Kept Qt, JavaScript, filesystem paths, and network listeners outside the Application service.
- Did not mark the vector renderer ready.

## Unreleased — Builds 3.81–3.90 local map-archive range foundation

- Added a renderer-neutral byte-range projection and archive-reader port.
- Added catalog-authorized, bounded PMTiles reads with verified-size protection.
- Rejected disabled, uninstalled, changed, non-PMTiles, oversized, and invalid range requests.
- Kept arbitrary filesystem paths and network listeners outside the renderer boundary.
- Did not mark the browser-facing archive bridge or vector renderer ready.

## Unreleased — Builds 3.71–3.80 vector-renderer runtime gate

- Added a replaceable Qt WebEngine renderer readiness probe behind a port.
- Separated runtime, approved asset, and local archive-bridge blockers.
- Kept renderer probing lazy and isolated from Library startup.
- Replaced the generic vector-pending message with the first actionable blocker.
- Did not bundle or activate an unvalidated JavaScript renderer.

## Unreleased — Builds 3.61–3.70 map-renderer readiness

- Added a renderer-readiness Domain projection for installed map packages.
- Extended the map workspace port with package capability discovery.
- Reported the current raster renderer separately from vector packages awaiting the street-level renderer.
- Added clear Map workspace readiness counts without attempting to decode vector data.
- Preserved lazy subsystem activation and optional-failure isolation.

## Unreleased — Builds 3.51–3.60 desktop-launch regression fix

- Reverted the primary CMD-installed shortcut from the field-rejected copied runtime alias to the proven generated Aperture GUI entry point.
- Restored update, recovery, and Maintenance Center desktop restarts to the proven installed desktop command.
- Made Install/Repair remove the obsolete copied primary alias before rebuilding shortcuts.
- Retained purpose-named aliases for Maintenance Center, updater, and recovery.
- Added a dedicated `aperture-bootstrap.jsonl` desktop-launch diagnostic separate from `maintenance-bootstrap.jsonl`.
- Recorded field validation over the process-name assumption in ADR-033.

## Unreleased — Builds 3.41–3.50 street-level package compatibility

- Added explicit validation for vector MBTiles with PBF/MVT metadata.
- Added PMTiles v3 magic/version validation.
- Extended verified catalogs, downloads, file installation, and `.apkg` imports to vector MBTiles and PMTiles.
- Prevented the raster workspace from treating vector payloads as displayable image tiles.
- Added Maintenance Center format visibility and a clear `vector renderer pending` state.
- Preserved existing raster MBTiles, regional acquisition, checksums, attribution, and removal behavior.

## Unreleased — Builds 3.31–3.40 managed uninstall lifecycle

- Replaced the generic `pythonw.exe` uninstall blocker with Aperture, Maintenance Center, updater, recovery, NatureAI, or Background Service role labels.
- Made full-environment uninstall request graceful closure, wait for shutdown, and stop remaining headless managed processes.
- Restricted forced termination to executables located inside the selected Aperture environment.
- Kept package-only uninstall conservative when active work exists.
- Preserved all libraries, photographs, models, backups, and exports.

## Unreleased — Builds 3.21–3.30 Windows process identity

- Added purpose-named CMD-install runtime aliases for Aperture, Maintenance Center, updater, and recovery.
- Routed normal shortcuts, maintenance launches, update/recovery handoffs, and automatic restarts through the appropriate alias.
- Preserved canonical Python executables for environment management, verification, and fallback behavior.
- Reserved NatureAI process naming for actual out-of-process AI execution rather than import, thumbnails, indexing, matching, or repository enrichment.
- Kept the existing Install, Repair, and Uninstall CMD entry points.

## Unreleased — Builds 3.11–3.20 Collections isolation

- Stopped Collections navigation from displaying the complete Library grid before a collection is selected.
- Invalidated in-flight Library page results when entering Collections so late import refreshes cannot appear as collection membership.
- Preserved explicit manual membership and saved-query-only smart membership.
- Defined NatureAI Engine as the owner of AI processing and Aperture Background Services as the owner of non-AI asynchronous work.
- Assigned broader search and view usability to Build 6 rather than expanding Build 3.

## Unreleased — Builds 3.1–3.10 offline-map recovery and architecture

- Replaced the embedded Offline Map Setup dialog's hidden Maintenance Center global with a narrow Bootstrap-supplied platform boundary.
- Made the main desktop and standalone Maintenance Center compose the same map catalog, package verification, acquisition, and Activity Center workflow.
- Kept raster MBTiles compatibility while approving vector tiles as the street-level storage direction.
- Required a Windows-packaged renderer/converter prototype before replacing the current renderer.
- Preserved the existing command installers, offline operation, regional package ownership, attribution, resumable downloads, and prohibition on scraping public OpenStreetMap tile servers.

## Build 2 — Photography Workflow frozen

- Recorded successful Windows field validation and product approval of Builds 2.41–2.60.
- Froze Build 2 scope before beginning Build 3.

## Unreleased — Builds 2.41–2.60 consolidated Photography Workflow Completion Candidate

- Added LibRaw-backed camera RAW probing, baseline metadata, rendering, thumbnails, and previews.
- Kept Pillow as the primary JPEG/TIFF/PNG decoder through the existing media ports.
- Added embedded ICC-profile normalization toward sRGB for catalog derivatives.
- Consolidated existing EXIF/XMP, editing, Batch Review, collections, local search, exact duplicates, Viewer, and export workflows.
- Preserved unsupported-RAW isolation, original files, installer entry points, AI Review, and BioCLIP.
- Deferred Build 2 freeze until representative Windows RAW and end-to-end photographic field validation passes.

## Unreleased — Builds 2.36–2.40 consolidated exact-duplicate visibility

- Added an exact-duplicate structured-query field.
- Added local SHA-256 matching across available file instances.
- Excluded missing files from duplicate matches.
- Added an `Exact duplicates only` Library filter compatible with saved views.
- Intentionally withheld destructive resolution and perceptual similarity.
- Preserved Batch Review, offline Maps, AI Review, and BioCLIP.

## Unreleased — Builds 2.31–2.35 consolidated GPS bounds search

- Added optional south/north/west/east bounds to structured Library filters.
- Added complete-range, legal-coordinate, and ordering validation.
- Reused the existing parameterized local latitude/longitude query adapter.
- Added opt-in Library GPS controls with deterministic reset behavior.
- Preserved saved searches, smart collections, offline Maps, Batch Review, and BioCLIP.

## Unreleased — Builds 2.26–2.30 consolidated camera and lens search

- Added camera maker, camera model, and lens structured-query fields.
- Added escaped, case-insensitive partial matching against normalized image metadata.
- Added Library Camera Maker, Camera Model, and Lens filter controls.
- Reused the same fields in quick search, saved searches, and smart collections.
- Preserved existing text, keyword, date, rating, taxonomy, geography, Batch Review, and BioCLIP behavior.

## Unreleased — Builds 2.21–2.25 consolidated XMP metadata ingestion

- Added bounded, read-only XMP parsing with document-type/entity rejection.
- Added standard Dublin Core title and description ingestion.
- Added case-insensitively deduplicated import-sourced keywords.
- Added checksummed parsed-XMP metadata snapshots alongside preserved originals.
- Isolated malformed or oversized XMP so it cannot block photograph import.
- Kept XMP writing and metadata-conflict UI outside this delivery.

## Unreleased — Builds 2.16–2.20 consolidated XMP sidecar preservation

- Added an Application-facing sidecar resolver port and bounded filesystem adapter.
- Added case-insensitive discovery for `photo.ext.xmp` and `photo.xmp` companions.
- Registered XMP companions against their photograph asset with checksums and import provenance.
- Added verified Library-owned sidecar copies for managed and hybrid imports.
- Preserved move-import sources until sidecar copy and catalog commit succeed.
- Kept XMP ingestion/editing outside this delivery and preserved Batch Review and BioCLIP.

## Unreleased — Builds 2.11–2.15 consolidated batch review UI

- Added selection-aware Batch Review controls to Library.
- Distinguished unchanged fields from explicitly cleared ratings, labels, and flags.
- Fixed the batch patch contract before UI exposure so changing one field preserves the others.
- Added responsive worker execution plus atomic success/conflict feedback and refresh.
- Preserved single-photo editing, search/filtering, import, AI Review, and BioCLIP.

## Unreleased — Builds 2.6–2.10 consolidated batch review workflow

- Added batch rating, color-label, and pick/reject contracts.
- Added bounded Application validation and deterministic duplicate-selection rejection.
- Added atomic SQLite batch persistence with optimistic revision protection.
- Prevented stale or missing photographs from producing partially updated review sets.
- Preserved single-photo metadata, keywords, import, search, AI Review, and BioCLIP behavior.

## Unreleased — Builds 2.1–2.5 consolidated photography import foundation

- Added explicit rendered-photo, camera-RAW, metadata-sidecar, and unknown source classification.
- Prevented recognized XMP and other companion sidecars from being reported as corrupt standalone photographs.
- De-duplicated overlapping import roots.
- Fixed same-plan exact duplicates creating multiple assets while preserving attach-file-instance behavior.
- Added an actionable RAW decoder fallback status and regression coverage.
- Recorded the passed Build 1 field checkpoint and froze the Platform Foundation scope.

## Unreleased — Builds 1.25–1.29 consolidated Foundation architecture closure

- Moved Library lifecycle execution behind an Application port into Infrastructure.
- Injected Maintenance Center platform operations from Bootstrap.
- Closed all enforced Domain, Ports, Application, and UI architecture violations.
- Preserved Library lifecycle, migrations, locks, integrity, backups, restore, Maps, AI, and import behavior.
- Established and field-validated Build 1.29 as the frozen Platform Foundation baseline.

## Unreleased — Builds 1.20–1.24 consolidated resource, health, import, and Library value boundaries

- Moved AI resource operations behind an Application facade and Infrastructure backend.
- Added Health integrity and subsystem inspection ports.
- Formalized Import's injected unit-of-work factory contract.
- Moved Library manifest and integrity-report values into Domain.
- Added a Foundation checkpoint that limits remaining Application adapter debt to Library lifecycle.
- Preserved BioCLIP, resources, health checks, imports, backups, maps, and Library compatibility.

## Unreleased — Builds 1.15–1.19 consolidated map acquisition and AI generation boundaries

- Added Application-facing map acquisition ports.
- Added signed model-package construction through a port and retained the taxonomy-package builder port.
- Injected OpenCLIP execution and BioCLIP preprocessing from Bootstrap.
- Moved active-model and selected-asset queries into Infrastructure.
- Removed Map Acquisition, AI Setup, and AI Generation's direct Infrastructure dependencies.
- Preserved offline maps, signed BioCLIP setup, taxonomy resources, suggestions, provenance, and result persistence.

## Unreleased — Build 1.14 job command boundary

- Added an Application-facing job command and recent-history store port.
- Moved SQLite idempotency, unit-of-work handling, controls, and queries into Infrastructure.
- Injected job-service composition from Maintenance Center Bootstrap.
- Preserved durable job execution, failure isolation, progress, and controls.

## Unreleased — Build 1.13 AI runtime index boundary

- Added AI runtime repository and vector-index store ports.
- Removed inference and index orchestration's direct SQLite and local-index dependencies.
- Added an Infrastructure adapter over the existing checksummed local vector index.
- Preserved inference provenance, index validation, corruption fallback, and BioCLIP behavior.

## Unreleased — Build 1.12 AI embedding service boundary

- Added Application-facing embedding repository and compute-lease ports.
- Removed core AI embedding/search services' direct SQLite and GPU-coordinator dependencies.
- Preserved BioCLIP execution, preprocessing, persistence, retry, and similarity behavior.
- Added in-memory embedding and source-level boundary regression coverage.

## Unreleased — Build 1.11 map workspace query boundary

- Moved immutable offline map package and tile projections into Domain.
- Added Application-facing offline-map and spatial workspace query ports.
- Moved catalog, offline-tile, and SQLite spatial adapter selection to Bootstrap.
- Preserved installed-package selection, offline rendering, overlays, and attribution behavior.

## Unreleased — Build 1.10 retention history boundary

- Added an Application-facing retention-history store port.
- Moved durable job/outbox cleanup SQL into an Infrastructure adapter.
- Injected cleanup composition from the Maintenance Center Bootstrap.
- Preserved retention policy, dry-run, and temporary-file behavior.

## Unreleased — Build 1.9 temporal map query boundary

- Added an Application-facing temporal spatial-query port.
- Moved SQLite spatial-adapter selection from Temporal Map to Bootstrap.
- Preserved snapshot, cumulative, and movement-trail behavior.
- Added in-memory playback and source-level boundary regression coverage.

## Unreleased — Build 1.8 certification state boundary

- Moved the stable optional-subsystem lifecycle state into Domain.
- Removed Platform Certification's dependency on the Infrastructure registry implementation.
- Preserved registry import compatibility and existing certification behavior.
- Added source-level and compatibility regression coverage.

## Unreleased — Build 1.7 knowledge center projection boundary

- Moved the immutable taxonomy knowledge projection from Infrastructure to Domain.
- Removed Knowledge Center's direct Infrastructure dependency.
- Preserved taxonomy catalog compatibility and existing Knowledge Center behavior.
- Added in-memory service and source-level boundary regression coverage.

## Unreleased — Build 1.6 regional package boundary

- Added an Application-facing taxonomy-package builder port.
- Kept signed Ed25519 ZIP construction in an Infrastructure adapter selected by Bootstrap.
- Removed Regional Acquisition's direct Infrastructure dependency without changing taxonomy installation or BioCLIP behavior.
- Added acquisition and source-level boundary regression coverage.

## Unreleased — Build 1.5 asset analysis persistence boundary

- Added an Application-facing repository port for immutable Asset Analysis records.
- Removed the Application service's dependency on the SQLite analysis repository.
- Added an in-memory service test and source-level boundary regression test.

## Unreleased — Build 1.4 maintenance inventory boundary

- Reduced Application maintenance inventory to projections and a reader contract.
- Moved filesystem and read-only subsystem SQLite inspection to Infrastructure.
- Injected inventory composition into the Maintenance Center from Bootstrap.
- Added adapter, boundary, missing-path, and corrupt-subsystem regression tests.

## Unreleased — Build 1.3 subsystem composition boundary

- Moved optional map and taxonomy registry composition from Application to Bootstrap.
- Preserved lazy subsystem activation and existing database locations.
- Added descriptor ownership and non-activation regression tests.

## Unreleased — Build 1.2 configuration boundary

- Added an Application-facing configuration persistence port.
- Kept TOML parsing, atomic writes, and configuration backups in Infrastructure.
- Moved branding persistence to an Infrastructure adapter injected by Bootstrap.
- Added in-memory adapter and architecture-boundary regression tests.

## Unreleased — Build 1.1 development baseline

- Restored the RC2.2 source tree and Foundation regression suite as reviewable repository content.
- Updated historical tests for the approved RC2.2 navigation and integrated Help architecture.
- Restored installer guidance for Library growth, the `Aperture-Library` folder, and unattended installation.
- Restored the explicit no-database-migration statement and synchronized packaged Help.
- Corrected `.gitignore` naming and added the master build plan, development protocol, status, and build history.

## 2.0.0 RC2.2

- Replaced single-path Geofabrik tile rendering with a bounded multi-process NatureAI Nest render pool.
- Kept MBTiles database publication serialized while CPU-heavy tile generation runs across cores.
- Added adaptive memory-assisted resource workspaces with disk fallback.
- Added durable map checkpoints every 32 tiles.
- Preserved all resumable Activity Center work during history cleanup and added Open Tasks visibility.
- Made durable job worker sizing adaptive to logical processor count.

## 2.0.0 RC2.1 - Resource inventory and diagnostics

- Added inventory-first offline-map acquisition: verified current packages are reused without downloading or rendering again.
- Added developer performance diagnostics for process CPU, memory, threads, disk I/O, and Activity Center state when available.
- Refined shared Resource Manager delta planning and preserved the no-legacy-migration policy for pre-Version-5 playground builds.
- Kept seamless global “Show all offline maps” rendering in the later map-engine backlog.

## 2.0.0 RC2 - Resource reliability and responsiveness

- Added staged taxonomy import with family, genus, and species checkpoints and atomic publication.
- Reused stable taxon identities during updates, preventing duplicate `taxa.public_id` failures.
- Added shared GBIF region and species caches so added countries reuse existing downloads.
- Added the Resource Manager acquisition-planning foundation for delta/full resource decisions.
- Throttled Activity Center persistence and UI refresh to one update per second.
- Added logical user-facing failure messages, technical details, recommended actions, and safe activity cleanup.
- Added a required verified shutdown backup after successful taxonomy publication.
- Deferred seamless “Show all installed maps” rendering to the map-engine backlog.

# Aperture 2.0.0 RC1 — Release Candidate Freeze

- Frozen Release 2 functionality after successful end-to-end offline map field validation.
- Synchronized release identity, documentation, Help content, roadmap, backlog, and known limitations.
- Confirmed Species Dashboard search and higher-detail map generation as Release 3 backlog work.
- No new production functionality added after the R8 map integration build.

---

# Aperture 2.0.0.dev6968 — Shared Map Catalog and MBTiles Validation

- Map viewer now accepts all enabled installed MBTiles packages from the same catalog used by Offline Maps.
- Existing Geofabrik-generated packages registered with the legacy provider key remain discoverable without rerendering.
- New Geofabrik conversions register as `openstreetmap.mbtiles` while retaining source attribution.
- MBTiles installation now requires at least one tile plus valid bounds, zoom, and format metadata.
- Verification reports tile count and supported zoom range.

- Added an installed-area selector to the Maps workspace.
- Added **Zoom to Area** using the geographic bounds stored with each enabled MBTiles package.
- The Maps workspace now discovers newly installed packages when opened or refreshed.
- When the current view is not covered, Aperture automatically centers on the first enabled installed area.
- Existing pan, zoom, temporal overlays, observations, and offline-only tile reading remain unchanged.

# 2.0.0.dev6966

- Added VISION.md and PHILOSOPHY.md as authoritative project documents.
- Refreshed Help and About navigation while retaining complete development documentation.
- Clarified Aperture/NatureAI Next ownership and integration boundaries.

# Aperture Changelog

## 2.0.0.dev69652 — M6.9.6 R5.2 malformed geometry tolerance

- Isolated Geofabrik shape reads per record so invalid polygon records no longer fail an entire map job.
- Added defensive validation for empty points, invalid bounds, malformed parts, and non-finite coordinates.


## 2.0.0.dev69651 — M6.9.6 R5.1 Windows map cleanup reliability

- Explicitly closes every pyshp reader before temporary Geofabrik source files are removed.
- Reuses open layer readers during rendering instead of reopening DBF/SHP files for every tile.
- Added bounded Windows cleanup retries and defers stubborn temporary folders to Maintenance Center cleanup without invalidating a completed map.

- Moved Geofabrik region acquisition and raster MBTiles generation off the Qt UI thread into Activity Center operations.
- Added one-second throttled progress with transfer speed and rendered-tile counts.
- Added cancellation and retry payloads for individual regional map activities.

- Added `pyshp` to the installer core requirements used by all installation profiles.
- Changed Geofabrik conversion support to load `pyshp` only when a map conversion is started.
- Maintenance Center, Settings, health checks, and installed-map management now open even when optional conversion support is missing.
- Missing conversion support is reported as a repairable map-download error rather than a Maintenance Center bootstrap failure.


## 2.0.0.dev6963 — M6.9.6 R3

- Fixed Offline Maps installed-package refresh against the supported catalog API.
- Added Resources navigation entries for Offline Maps and Taxonomy Resources.
- Added cached map-catalog offline display and improved certification lock handling.
- Preserved separate, capability-specific acquisition workflows.

# M6.9.6 — Regional Taxonomy and Map Selection

- Connected Regional Knowledge GBIF package installation to the shared Taxonomy Reference database used by the Knowledge Center.
- Preserved the existing BioCLIP regional workflow and ranking behavior.
- Reworked Offline Map setup around continent/country filters and checkable regional packages.
- Moved map catalog source configuration under an Advanced section.

# Aperture 2.0.0.dev694 — M6.9.4 Settings and Maintenance Library Resolution

## 2.0.0.dev694 — M6.9.4 R1

- Fixed standalone Maintenance Center library discovery by using the same launcher configuration as Aperture.
- Added BOM-safe launcher configuration loading and a graphical library-selection fallback.
- Added Tools menu entries for Maintenance Center, Settings, and Help.
- Added a Settings landing workspace in the navigation pane.
- Added user-facing library selection that is remembered across launches.
- No schema or library-format changes.

---

# Aperture 2.0.0.dev693 — M6.9.3 Map Package Guidance and Bundle Import

- Added pre-download storage estimates and large-package guidance recommending regional increments.
- Added verified `.apkg` offline map bundle import for complete prepared map collections.
- Documented map catalog deployment, field preparation, bundle distribution, updates, and removal in user, operations, and developer manuals.
- Preserved the existing map renderer, core spatial data, and BioCLIP behavior.

## 2.0.0.dev693 — M6.9.3 Map Package Guidance and Bundle Import R1

- Synchronized runtime, packaging, installer-facing, release-note, and embedded Help version identity.
- Distinguished the Version 2 development package from the frozen Aperture 1.0.0 Foundation Release.
- Added release-manifest metadata and regenerated all file hashes after synchronization.

# Aperture 2.0 M6.9.1 — Platform Certification Build

- Added read-only Version 2 platform certification to the existing Maintenance Center.
- Certified core-library health, asset-enrichment integrity, optional maps/taxonomy state, Knowledge Engine capability registration, and maintenance boundaries.
- Preserved lazy optional-subsystem activation during certification.
- Added ADR-028 and focused regression coverage for certification failure isolation.

# Aperture 2.0 M5.2 — BioCLIP Asset-Enrichment Integration

- Connected local BioCLIP suggestion generation to immutable per-photo asset analyses.
- Linked review suggestions to the exact analysis execution while preserving historical unlinked suggestions.
- Stored ranked BioCLIP outputs as normalized analysis taxon candidates.
- Recorded succeeded and failed per-photo analysis outcomes without changing the validated review-authority workflow.
- Added ADR-016 and regression coverage for analysis/suggestion traceability.

# Aperture 1.0.0 — Foundation Release

- Promoted package version from `1.0.0rc1` to `1.0.0`.
- Added `VERSION2_DEVELOPMENT_CHARTER.md` to the source package and offline Help.
- Synchronized final release notes, project handover, validation title and start-here guidance.
- Preserved the validated runtime, database schema and library format without functional changes.

# Aperture 1.0.0 RC1 — Documentation Freeze

- Synchronized source documentation and packaged offline Help.
- Added Roadmap & Future Releases to Help.
- Added Version 1 project handover.
- Consolidated accepted Version 2–5 roadmap and backlog decisions.
- No runtime, schema, library-format, or AI-processing change.


## RC1 launcher and import-view correction

- Replaced the fragile WScript/PowerShell normal launcher with a direct `pythonw.exe` `.pyw` launcher.
- Added an explicit Library View selector with **All Library** and **Latest import** options.
- Import completion still shows the exact imported items, while users can return to the complete catalog without resetting filters manually.
## 1.0.0 RC1 stabilization polish

- Added structured first-paint startup timing diagnostics.
- Deferred Maintenance Center backup-history loading until after its window is shown.
- Added visible maintenance progress and disabled actions while history loads.
- Completed startup-performance and Taxonomy Library documentation.
- No database migration or workflow changes.

- Fixed clean-install ordering so a new `Aperture-Library` is initialized before launchers validate and register it.
# Changelog
- Fixed `Install Aperture.cmd` interactive launch when no installer arguments are supplied.

## 1.0.0 RC1

- Added BOM-tolerant and legacy-compatible library manifest reading.
- Added atomic manifest normalization with preservation of the original file.
- Added clear validation for malformed, incomplete, and unsupported manifests.
- Added regression coverage for all legacy fields encountered during field recovery.
- No database migration.

## 0.19.1

- Added operational-location diagnostics to Maintenance Center.
- Completed Viewer and Library Inspector shortcut documentation.
- Added release contracts for path diagnostics and shortcut completeness.
- No database migration.

## 0.19.0

- Added the visible Aperture Maintenance Center.
- Added updater progress and failure UI.
- Added a dedicated Maintenance Center launcher and installer shortcut.
- Preserved the legacy backup/recovery launcher as a compatibility alias.
- Added Maintenance Center documentation to packaged Help.

# Changelog

## 0.19.0

- Added a verified native-updater readiness handshake before Aperture closes.
- Made backup and no-backup update choices share the same handoff path.
- Added updater waiting for library-lock release before installation and relaunch.
- Added safe dead-process lock recovery as a reusable lifecycle operation.
- Added regression coverage for helper startup, failure acknowledgement, and lock-aware installation.

## 0.18.1

- Fixed friendly single-instance handling and stale Windows library-lock recovery.
- Added restore-without-backup and reliable lock-aware restore handoff.
- Removed synchronous database integrity scanning from the startup critical path.
- Updated launcher branding and lifecycle diagnostics.

- Added the Windows installer build guide and `scripts/build_aperture_windows_installer.ps1` to the source release and in-application Help.
## 0.18.0

- Consolidated Version 1 reliability and usability work.
- Added managed verified-backup history with restore, verify, and delete actions.
- Added persistent update history and post-install staging cleanup.
- Updated documentation and release QA contracts.

## 0.17.11 — Reliable Update Handoff

- Fixed the backup-to-update handoff so the updater starts before Aperture exits.
- Added Back Up and Install, Install Without Backup, and Cancel choices.
- Added updater startup verification and background-work safety checks.
- Added regression tests for handoff ordering and helper readiness.


## 0.17.10

- Added the standalone Aperture Backup & Recovery application and Windows shortcuts.
- Replaced user-facing restore scripts with automatic close, restore, rollback, and relaunch.
- Moved About Aperture to a separate top-level menu item.
- Fixed deployment preflight to use Conda Python instead of the Windows Store Python alias.

# 0.17.9 — Native Update & Recovery

- Replaces user-facing PowerShell update and restore steps with automatic background helpers.
- Adds restart-and-install and restart-and-restore workflows.
- Verifies staged packages and backups again after Aperture exits.
- Relaunches the same library after successful completion.
- Keeps PowerShell scripts only for developer and emergency support.

# 0.17.9 — Native Update & Recovery

- Replaces user-facing PowerShell update and restore steps with automatic background helpers.
- Adds restart-and-install and restart-and-restore workflows.
- Verifies staged packages and backups again after Aperture exits.
- Relaunches the same library after successful completion.
- Keeps PowerShell scripts only for developer and emergency support.

# Changelog

## 0.17.8 — Help System & Discoverability

- Added an integrated searchable offline Help browser.
- Added complete Help-menu access to bundled guides and release notes.
- Added context-sensitive F1 help.
- Documented and surfaced AI Review J/K, A, R, D, O, Ctrl+Z, and Shift+Enter shortcuts.
- Added in-workspace shortcut hints and documentation contract tests.
- No database migration.


## 0.17.6 — Installer and Deployment Hardening

- Added release-tree deployment preflight before installer mutations.
- Added structured preflight evidence and an installer diagnostics bundle.
- Added deployment, upgrade, repair, and uninstall guidance.
- Preserved Aperture branding and NatureAI_Next internals.


### Added

- Aperture Health Center with database, manifest, storage, backup, update-source, temporary-file, cache, and index checks.
- Full SQLite integrity-check action and clear healthy/warning/error summaries.
- Conservative **Repair Safe Items** action for missing standard directories and stale temporary files.
- Direct Health Center access to Backup, Restore, and Offline Updates.
- Version 1 release-readiness QA and Health Center documentation.
- Service and release-contract tests for health assessment and repair behavior.

### Compatibility

- No database migration or resource-format change.
- Internal NatureAI_Next identifiers remain unchanged; Aperture remains the user-facing brand.
- Version 2 design-system, maps, comparison, and major navigation work remains deferred.

## 0.17.4 - 2026-07-14

### Added

- Backup & Recovery Center with Restore Library, Verify Backup, and Manage Backups actions.
- Verified restore staging with mandatory emergency pre-restore backup.
- Rollback-capable PowerShell recovery utility and synchronized recovery documentation.
- Recovery verification, tamper rejection, staging, and release contract tests.

# Changelog

## 0.17.2 - Backup Button & Verified Snapshots

- Added Back Up Library to the toolbar, File menu, and Settings menu with Ctrl+Shift+B.
- Added verified, non-overwriting SQLite snapshots and SHA-256 JSON manifests.
- Added user-visible completion and failure reporting.
- Expanded backup and recovery documentation and automated release guards.
- Kept the release schema-neutral and preserved all NatureAI_Next formats and identifiers.

## 0.17.1 - Documentation & Release Hardening

- Added a packaged documentation center covering installation, quick start, core workflows, local AI resources, import/export, backup/recovery, troubleshooting, development, and release procedure.
- Added documentation contract coverage so required guides and branding boundaries remain release-gated.
- Clarified that Aperture is user-facing branding while NatureAI_Next package names, commands, libraries, databases, and resource formats remain unchanged.
- Kept the release schema-neutral and excluded Version 2 visual redesign, maps, and observation comparison work.

# 0.16.2

- Added a unified Species Dashboard with observation totals, timeline, evidence gallery, conservation, migration, habitats, source attribution, and a 12-month seasonal-presence display.
- Added “Why this suggestion?” to AI Review using visual rank/score, regional evidence, capture-month seasonality, ecological context, and personal history.
- NatureAI explicitly reports when feature-level visual explanations are unavailable instead of inventing traits.
- Ecological context remains informational and does not modify BioCLIP confidence or human confirmation.

## 0.16.1

- Added local conservation, seasonality, migration, and habitat context.
- Added migration 015 and ecological-context CSV import.
- Added ecological evidence to AI Review without altering visual confidence.

## 0.15.4 - Life Lists & Observation Statistics

- Added a Life Lists & Statistics workspace derived directly from human-confirmed observations.
- Shows totals for confirmed species, observations, evidence photographs, countries, and first observations in the current year.
- Groups the personal life list by installed taxonomy major group or kingdom.
- Shows the most frequently confirmed species.
- Statistics refresh immediately and require no migration or duplicated counter tables.

## 0.15.3.post1 - Observation Timeline Patch

- Fixed missing or non-refreshing entries in Observation History.
- Explicitly refreshes the timeline after species selection.
- Shows a visible entry count and a guaranteed usable timeline height.
- Selects the newest observation automatically and loads its evidence gallery immediately.
- Binds gallery selection to the timeline entry object rather than a fragile row index.
- Shows a clear empty state when no confirmed timeline entries exist.

## 0.15.3 - Observation Workspace and Species Dashboard

- Added a user-facing Observation History workspace.
- Added a species dashboard with confirmed-observation count, evidence-photo count, first/last dates, rank, and countries.
- Added a chronological observation timeline.
- Added a thumbnail evidence gallery for every photograph linked to an observation.
- Double-clicking evidence opens the existing Viewer.
- Added AI Review → Observation History navigation for the selected taxon.
- Added Accept & Next with Shift+Enter.
- Acceptance feedback now summarizes personal observation and photograph totals.
- Preserved stable observation identities, immutable originals, and the accepted Qt window lifecycle.

## 0.15.2 - Single-Photograph Taxonomy Resolution

- Added a Current photograph only review mode.
- Added atomic Accept & Reject Rest for one photograph.
- Added Reject Other Options after a normal acceptance.
- Kept accepted taxonomy, rejected alternatives, observation creation, audit events, and outbox events transactionally consistent.
- Preserved existing AI scores, provenance, and immutable originals.

## 0.15.1 - Observation Review Images and History

- Added a large cached photograph preview directly in AI Review.
- Added filename and capture-time context to prevent guesswork in large review queues.
- Added first/last observation dates and evidence-photo totals to personal observation context.
- Added first-observation confirmation feedback after acceptance.
- Preserved immutable originals and the accepted Qt window lifecycle.

## 0.15.0 - Observation Intelligence Phase 1

- Added stable multi-photo observation evidence links.
- Added personal observation-history queries and AI Review context.
- Added migration 014 and internal observation inspection.
- Preserved immutable originals and existing confirmation/reversal auditing.

## 0.14.6 - AI Workspace Consolidation

- Added Settings workspaces for AI Resources, Regional Knowledge, Health Check, and Preferences.
- Converted AI Resources into an in-window dashboard with BioCLIP, prompt, regional profile, quick setup, Activity Center, and advanced controls.
- Converted Regional Knowledge and Health Check into in-window pages.
- Routed the AI Review resource action and menu commands to the shared Settings pages.
- Kept compatibility menu shortcuts without duplicating implementation.

## 0.14.1 — Automatic Regional Knowledge Acquisition


## 0.14.3 - Activity Responsiveness Fix

- Removed the modal confirmation window shown after starting regional installation.
- Routed Activity Center progress, completion, and failure updates through queued Qt QObject slots on the main thread.
- Prevented worker-thread callbacks from mutating UI-facing activity state.
- Preserved the accepted regional acquisition, Activity Center, and Health Check workflows.

- Adds explicit one-click acquisition from the saved continent/country profile.
- Retrieves GBIF occurrence facets and Backbone Taxonomy records only after user confirmation.
- Builds, signs, verifies, installs, and activates the regional taxonomy package in the known NatureAI workspace.
- Generates and activates a BioCLIP prompt set and builds taxonomy embeddings when a compatible model is active.
- Reuses or creates the local signing identity automatically; no package or trusted-key browsing is required.
- Keeps photographs local and immutable.


## 0.13.8 — Release Packaging Integrity

- Corrected the Windows release archive so repository files are at the ZIP root instead of under an extra `src\` directory.
- Added a release-layout validation requirement for `pyproject.toml`, `scripts\install_windows.ps1`, and `src\natureai_next` at archive root.
- Preserves the BioCLIP runtime fix (`runtime: torch`) and rebuilds the existing local model package from the already-downloaded checkpoint.

## 0.13.2 - Local BioCLIP Generation

- Adds user-controlled **Generate selected** inference from the AI Review workspace.
- Uses the current Library selection and never scans or submits photographs without an explicit user action.
- Requires an active signed local model package, compatible active prompt set, and taxonomy text embeddings.
- Runs BioCLIP/OpenCLIP inference locally on the configured CUDA or CPU execution provider.
- Persists one auditable inference run plus ranked immutable suggestions with full model, prompt, preprocessing, provider, device, precision, and application provenance.
- Adds progress reporting, cancellation, per-asset failure isolation, and automatic review-queue refresh.
- Prevents application shutdown while generation is active, avoiding Qt worker teardown hazards.
- Does not download models, taxonomy, or prompt sets automatically and introduces no cloud inference.
- Existing libraries require no migration.

## [0.13.1] — QApplication Startup Fix

### Fixed
- Deferred AI Review QWidget construction until after QApplication creation.
- Added composition-order regression coverage.

## [0.13.0] — BioCLIP Review

### Added
- Production desktop composition for the existing AI Review subsystem.
- Active model, prompt-set, inference-run, and queue-status overview.
- Confidence filtering, review-state paging, provenance inspection, and keyboard review actions.
- Explicit empty states when no active local model or generated suggestions exist.

## 0.12.9 - Docked Core Panes

- Navigation is permanently docked on the left and Inspector on the right.
- Core panes can still be closed and reopened from the View menu, but cannot float as separate windows.
- Arbitrary Qt dock state is no longer persisted, preventing detached panes from returning after restart, upgrade, or display changes.
- Preserves the Windows-accepted 0.12.8 application lifecycle.

## 0.12.8 - Collection Reload Fix

- Fixed collection view reload/reset crash caused by passing QComboBox userData twice.
- Preserves the stable 0.12.7 Qt lifecycle rollback.

# Changelog

## 0.14.4 - Durable Background Tasks

- Blocks ordinary shutdown while background work is active.
- Adds explicit Keep running and Cancel tasks and exit choices.
- Persists Activity Center state and marks unfinished work as interrupted after restart.
- Adds Cancel and Resume / Retry controls.
- Adds safe regional acquisition checkpoints and cached GBIF taxonomy details.
- Reuses partial progress after network interruption, cancellation, or power loss.
- Keeps existing active resources until newly built resources reach verified installation.

## [0.12.7] — Stable Qt Lifecycle Rollback

- Restored the last Windows-confirmed crash-free Qt lifecycle from 0.12.2.
- Removed post-0.12.2 dock normalization and custom teardown changes.
- Retained Navigation/Inspector restore actions and collection assignment improvements.

## [0.12.7] — Navigation & Collection Workflow

### Fixed
- Restorable Navigation and Inspector docks through the View menu.
- Reset workspace layout action.
- Collections navigation now opens the live collection controls.
- Explicit manual-collection chooser for assigning selected photographs.


All notable NatureAI Next changes are recorded here. The project follows semantic versioning during pre-1.0 development.

## [0.12.1] — Smart Collections & Lock Recovery

### Added
- Safe stale-lock ownership detection and automatic same-host dead-process recovery.
- Smart collections backed by persisted structured queries.
- Collection rename, description editing, deletion, and manual member removal.

## [0.12.0] — Collections & Saved Searches

### Added
- Reusable saved searches backed by the versioned structured-query model.
- Manual collections with multi-selection membership and duplicate suppression.
- Live paged Library views for saved searches and collections.
- Asynchronous collection and saved-view persistence in the desktop workspace.

## [0.11.7] — Capture Date Filter Fix

### Fixed
- Capture-date From/To filters now match both authoritative UTC timestamps and EXIF local capture-date text.
- Date boundaries are inclusive and timezone is not fabricated when EXIF contains no zone.

## [0.11.6] — Structured Filters

### Added
- Asynchronous Library filters for rating, color, pick state, capture dates, dimensions, exact tags, and confirmed taxonomy names.
- Combined Quick Search and structured-filter query execution.
- Validated parameterized taxonomy-name matching across scientific, vernacular, and user-defined names.

## [0.11.5] — Quick Search

### Added
- Asynchronous Library quick search over filename, title, caption, notes, and tags.
- Debounced input, result counts, clear-to-library behavior, and keyset pagination.
- Stale search-result rejection and parameterized FTS/filename matching.

## [0.11.4] — Metadata

### Added
- Editable catalog title, caption, notes, rating, color label, pick state, and user tags.
- Dirty-state Save/Discard workflow with keyboard shortcuts.
- Atomic metadata and user-tag persistence with optimistic revision conflict handling.
- Architecture decision records for immutable originals and BioCLIP evidence separation.

## [0.11.3] — The Viewer

### Added
- Asynchronous full-image viewer.
- Wheel zoom, drag pan, Fit, 100%, double-click zoom toggle, and keyboard navigation.
- Stale preview-result rejection.
- Asynchronous Library inspector preview loading.

## [0.11.2] — Windows Productization

### Added
- Windows Installed Apps registration, repair, uninstall, and Start Menu integration.

## [0.11.1] — Windows Integration

### Added
- Machine-local launchers, shortcuts, default-library selection, and first-launch library picker.

## [0.11.0] — Persistent Thumbnails

### Added
- Persistent thumbnail and preview caches, placeholders, failure state, and retry.

## 0.13.3
- Added a local AI resources manager for signed model, prompt, and taxonomy packages.
- Added user-triggered taxonomy text embedding generation.
- Release the library lock from Qt `aboutToQuit`; library close is idempotent.

## 0.13.4
- Added `natureai-next-resources`, a reproducible offline AI resource packaging CLI.
- Added local Ed25519 signing-key generation and trusted-key export.
- Added signed model-package and taxonomy-package builders and validators.
- Added prompt-manifest validation and starter resource templates.

## 0.13.5

### Added
- Installer-managed current-user PATH entries for the NatureAI Conda environment and its Scripts directory.
- `natureai-next-resources workspace-init` for a reproducible local AI resource workspace with absolute model, taxonomy, prompt, signing, and package paths.
- Installation verification and smoke coverage for the resource CLI.

### Changed
- The uninstaller removes only the NatureAI environment PATH entries that the installer manages.

## 0.13.6

### Added
- Guided BioCLIP Quick Setup wizard for download/import, local signing, package installation, taxonomy CSV conversion, prompt generation, and embedding generation.
- Example taxonomy CSV template.

### Changed
- Manual resource-manifest editing is no longer required for the supported quick-setup workflow.

## 0.13.7

### Fixed
- Corrected BioCLIP Quick Setup and workspace manifests from unsupported `openclip` runtime to schema-compatible `torch`.
- Added early validation for unsupported model runtimes.

## 0.14.0
- Added per-library Regional Knowledge Profiles.
- Added continent/country/language setup and global fallback.
- Added regional occurrence evidence to AI Review.
- Added migration 013 and regional profile regression coverage.

## 0.14.2 - Activity Center and Regional Setup Polish
- Enlarged the Regional Knowledge setup dialog and added an explicit multi-minute first-install notice.
- Standardized the dialog actions as Cancel, Save, and Save & Install.
- Added View -> Activity Center for running, completed, and failed background work.
- Added a clickable status-bar activity indicator.
- Added Tools -> Health Check as a separate installation-status surface.
- Regional acquisition now continues after the setup dialog closes and reports live progress in Activity Center.

## 0.16.1
- Added ecological CSV import preview with matched and unmatched row counts.
- Added normalized scientific-name matching for authorship suffixes and hybrid x/× notation.
- Added accepted-name suggestions and unmatched-row CSV reports.


## 0.16.3
- Made the Species Dashboard interactive with country and collection filters.
- Added a personal-observation versus expected-season monthly summary.
- Added related observed taxa from the installed taxonomy.
- Kept map and observation-comparison work deferred to Version 2.

## 0.17.0

- Branded the user-facing desktop application as Aperture, powered by NatureAI_Next.
- Added editable Branding & Project settings backed by `branding.toml`.
- Added About Aperture and copyable Diagnostics workspaces.
- Replaced flat navigation with grouped expandable tree navigation.
- Applied the supplied Aperture icon to the Qt application and Windows integration.
- Renamed user-facing Windows shortcuts and Installed Apps display name while retaining all technical NatureAI_Next identifiers.
- Deferred house-style color coding to Version 2 using the approved Yourethos guide URL.

## 0.17.3 - 2026-07-14

- Added the offline trusted-folder Update Manager.
- Added Settings and Help menu update commands.
- Added update index compatibility and SHA-256 verification.
- Added automatic verified pre-update database backup and safe staging.
- Added a rollback-capable PowerShell staged installer.
- Added update service, UI contract, documentation, and corruption tests.

## 0.17.7 — Accessibility and UI polish

- Added keyboard-shortcut reference (`Ctrl+/`).
- Added conservative automatic accessible names and keyboard focus defaults.
- Improved explicit accessible names in the Health Center.
- Added accessibility and keyboard documentation and release contract tests.
- No database migration.

### RC1 packaging correction

- Corrected `Uninstall Aperture.cmd` PowerShell switch handling for package-only, environment-removal, and full-reset choices.

## 1.0.0 RC1 installer framework refresh

- Added guided storage-drive selection and automatic `Aperture-Library` creation.
- Added existing-library detection and reuse.
- Added unattended CMD installation parameters and an installation summary.
- Updated installation, quick-start, README, and packaged Help documentation.


## RC1 installer corrections

- Fixed Torch-build parameter forwarding and complete fixed-drive enumeration in the interactive installer.

## RC1 polish update

- automatic verified Miniconda bootstrap when Conda is absent;
- no separate system Python prerequisite;
- complete Maintenance Center shortcut cleanup during uninstall;
- startup milestone timing in structured logs;
- clearer Maintenance Center status and safety wording;
- synchronized installation and troubleshooting documentation.
- Fixed automatic Miniconda bootstrap failing with HTTP 404 when the optional `.sha256` sidecar was unavailable; verification now uses the official repository index.



### Conda channel isolation

The installer creates and maintains the Aperture environment with `--override-channels` and the `conda-forge` channel only. This avoids interactive Anaconda default-channel Terms of Service prompts during unattended installation.

- The Windows uninstaller now removes the `natureai-next` environment without initializing Conda channels, avoiding Anaconda Terms-of-Service prompts.
- Uninstall cleanup continues to remove the Aperture Maintenance Center desktop shortcut.

## RC1 Stabilization Sprint 2
- Corrected first-paint startup timing wiring so diagnostic records are actually written.
- Added process-exit fallback cleanup for held library locks.
- Added the latest startup timing and direct log access to Maintenance Center.

## 1.0.0 RC1 — Visible restore handoff correction

- Kept Maintenance Center visible during restore and added explicit stage progress.
- Created and verified emergency backups before closing Aperture.
- Added persistent restore history, foreign-key validation, failure reporting, and automatic relaunch.

- Fixed Windows Maintenance Center launcher resolution by using the active environment Scripts directory. Added pre-GUI bootstrap diagnostics in `%LOCALAPPDATA%\Aperture\Logs\maintenance-bootstrap.jsonl`.

## RC1 Maintenance window readiness fix

- Launch the Maintenance Center directly through the installed Python GUI runtime rather than relying on a generated console-script executable.
- Write `maintenance-launch.jsonl` before process creation so failed handoffs always leave evidence.
- Require a first-visible-window ready file before Aperture reports the Maintenance Center as opened.
- Keep Aperture open when the companion exits early or does not show within the readiness timeout.

### RC1 restore-button Windows handle fix
- Replaced the open `mkstemp` readiness placeholder with a unique non-created path.
- Prevents Windows file-handle deletion failures that made restore buttons appear unresponsive.
- Cleans stale `maintenance-ready-*.json*` handshake markers safely.

## RC1 restore handle release fix

- Explicitly closes SQLite cursors and connections before replacing a restored database on Windows.
- Adds bounded retry handling for short-lived antivirus or indexing locks.
- Records `validated-and-closed` and `replace-retry` stages in restore history.
- Keeps the previous database protected by rollback on failure.

## 1.0.0 RC1 — Final runtime freeze
- Normal Aperture shortcuts now use a detached, windowless `pythonw.exe` launch through Windows Script Host; only the Debug shortcut owns a console.
- Completed imports now open an exact “Latest import” view using the imported asset IDs, independent of the first catalog page, filters, or collections.
- Added `%LOCALAPPDATA%\Aperture\Logs\import-sync.jsonl` to record database/model synchronization after each import.

- Fixed the standard launcher reading the wrong configuration directory.
- Increased Library page size to 500 for deterministic RC1 catalog display.
- Added bounded thumbnail worker queue and corrected zero-import view behavior.

## 2.0.0 Development

### Observation context and geospatial provenance
- Added migration `v017_observation_context` for explicit observation time and location overrides.
- Added EXIF GPS normalization and capture-location linkage during import.
- Preserved asset-derived observation time and location as backward-compatible fallbacks.
- Added service support for user, import, plugin, and asset-metadata observation context sources.

## 2.0.0 development - M3 spatial and longitudinal foundation

- Added migration `v018_spatial_longitudinal`.
- Added monitoring projects, monitoring sites, observation series, and typed relationships between observations.
- Added map-ready spatial regions with validated bounding coordinates and JSON geometry payloads.
- Added map bookmarks for future offline-map views and saved geographic filters.
- Added additive links from observations to projects, sites, and longitudinal series.
- Added bounding-box repository queries for observations, assets, and monitoring sites.
- Preserved explicit observation location precedence with fallback to evidence-asset capture locations.

## 2.0.0 development - M3.2 optional subsystem database runtime

- Added a composition-root subsystem registry with stable dotted subsystem identifiers.
- Added lazy, idempotent database activation with independent migration histories.
- Added isolated subsystem health states that do not block core-library startup.
- Added the first `maps.offline` database and migration for offline map and geocoding package catalogs.
- Added map-package coverage lookup without opening or modifying the core library database.
- Added application-managed paths for subsystem databases and offline map package files.

## 2.0.0 development - M3.3 offline map package lifecycle

- Added a renderer-independent offline map provider contract.
- Added built-in validation providers for MBTiles and generic file-backed packages.
- Added independent package enable/disable lifecycle without changing subsystem availability.
- Added streaming SHA-256 package verification with separate declared and observed checksums.
- Added package verification metadata, file-size capture, status messages, and provider metadata.
- Added map package catalog migration version 2 and regression coverage for valid, missing, disabled, and re-enabled packages.

## Version 2 development — M3.5 Offline Map Workspace

- Added a lazily composed Map workspace to the Qt desktop shell.
- Added local OpenStreetMap-compatible MBTiles rendering with a lightweight 3×3 raster viewport.
- Added deterministic pan and zoom controls, observation and monitoring-site markers, map-bounds retrieval, and persistent attribution.
- Kept all tile access local; the workspace does not contact public OpenStreetMap tile servers.
- Isolated optional map failures from the core Aperture Library and remaining desktop workspaces.

### Aperture 2.0 M3.6 — Temporal Map and Movement Foundation

- Added schema v019 for temporal series semantics and verified movement segments.
- Added snapshot, cumulative, and trail-ready temporal queries.
- Added subject identity, tracking method, confidence, and connection policy.
- Added scientific distinction between observed distribution and confirmed movement.

## Version 2 M3.7 — Map Timelapse UI

- Added offline temporal playback controls to the Qt Map workspace.
- Added snapshot, cumulative, and trail display modes.
- Added day, week, month, season, and year playback steps.
- Added play/pause controls, editable time windows, series selection, and qualified trail rendering.
- Confirmed and unverified movement segments render distinctly; offline map attribution remains visible.

## Version 2 M4.1 — Taxonomy Reference Foundation

- Added the lazily activated `taxonomy.reference` subsystem database.
- Added independently migrated, versioned taxonomy datasets.
- Added sourced multilingual names, knowledge facts, distribution records, and external links.
- Added search and Knowledge Center profile projections without requiring the map subsystem or modifying Version 1 taxonomy records.

### Aperture 2.0 M4.2 — Knowledge Center synthesis foundation

- Added Knowledge Center application projections that combine shared taxonomy profiles with local observation histories at read time.
- Added search cards with preferred names, local observation/evidence counts, date range, and countries.
- Added resilient taxon pages for reference-only taxa and documented the no-cross-database-join rule in ADR-009.

### Version 2 M4.3 — Knowledge Center workspace and taxon linking

- Added a lazy Qt Knowledge Center workspace with scientific/common-name search and synthesized taxon pages.
- Added stable per-library local-to-reference taxon links in taxonomy subsystem migration v002.
- Added two-way navigation between Observation History and Knowledge Center pages.
- Preserved read-time synthesis and cross-database public-ID boundaries.

### Version 2 M4.4 — Authoritative taxonomy import

- Connected the signed taxonomy-package pipeline to the shared `taxonomy.reference` subsystem.
- Added atomic import of accepted Latin names, authorship, synonyms, multilingual common names, and regional occurrence records.
- Added dataset licence URL, redistribution permission, source URL, and package schema provenance.
- Added stable BioCLIP/model label mappings to authoritative reference taxa.
- Added licence enforcement preventing installation of packages not permitted for redistribution.

### Version 2 M4.5 — Taxonomy preferences and package lifecycle

- Added taxonomy subsystem migration v004.
- Added language and region preferences for common-name resolution.
- Added non-destructive taxonomy dataset enable/disable lifecycle and package inventory.
- Added Knowledge Center controls for preferred common-name language and region.

### Version 2 M5.1 — Asset analysis enrichment foundation

- Added core migration v020 for immutable, versioned asset analyses.
- Added normalized analysis taxon candidates, tags, and observation-promotion provenance.
- Added an application service and repository for asset-linked enrichment.
- Preserved the existing AI suggestion/review workflow with an optional parent-analysis link.
- Added ADR-015 and database/build rules for future AI and non-AI analysis engines.

## Aperture 2.0 M5.3 — Asset Removal and Enrichment Cleanup

- Added dependency previews for permanent asset deletion.
- Added full removal of asset-linked analyses, candidates, tags, suggestions, embeddings, derivatives, metadata, and file instances through database cascades.
- Added explicit observation policies for assets supporting authoritative knowledge.
- Added cancellation requests for active asset-specific jobs.
- Preserved reversible Trash behavior and legacy recoverable purge behavior.
- Added durable purge audit records that survive physical asset deletion.

## Aperture 2.0 M5.4 — Desktop Asset Removal Workflow

- Added bulk **Move to Trash** and **Permanently delete** actions to the Library workspace.
- Added dependency summaries covering managed files, derivatives, AI analyses, suggestions, observations, promotions, and active jobs.
- Added explicit user choices for retaining or deleting observations when evidence photographs are removed.
- Kept permanent deletion behind the reversible Trash boundary and moved destructive cleanup off the Qt UI thread.
- Wired the validated M5.3 removal service into production desktop composition.

### Version 2 M5.5 — Knowledge Engine Core

- Added the lazy capability registry and explicit capability dependencies.
- Added the Knowledge Engine cross-domain orchestration boundary.
- Added taxon evidence dossiers, spatial observation queries, and asset-enrichment dossiers.
- Added read-only asset analysis candidate projections.

### Version 2 M5.6 — Knowledge Engine Workspace Integration

- Routed Knowledge Center evidence summaries through `KnowledgeEngine` taxon dossiers.
- Added support for distinct shared-reference and local-library taxon identities during synthesis.
- Routed offline-map observation overlays through `KnowledgeEngine` spatial projections.
- Preserved map package/tile ownership in the offline map application service and lazy optional-database activation.
- Added regression coverage for workspace-level Knowledge Engine boundaries.

### Version 2 M5.7 — Knowledge Engine observation and AI integration

- Routed Observation History species, history, and related-taxon projections through the Knowledge Engine.
- Routed AI Review personal observation context through the Knowledge Engine.
- Added per-photo enrichment-history summaries to AI Review.
- Preserved existing review, promotion, observation, and lazy subsystem behavior.

### Version 2 M6.0 — Workflow, Event, and Retention Foundation

- Added versioned workflow definitions over the existing durable job engine.
- Added stable step dependencies, workflow run idempotency, and optional-step declarations.
- Added typed in-process domain-event dispatch with subscriber failure isolation.
- Added bounded cleanup for terminal job history, dispatched outbox events, and stale temporary files.
- Added dry-run cleanup reporting and per-job-type minimum-history preservation.
- Recorded ADR-021, ADR-022, and ADR-023.

### Version 2 M6.1 — Lean Embedded Runtime Constraints

- Recorded ADR-024 limiting Aperture Version 2 runtime infrastructure to the existing embedded desktop stack.
- Added an explicit embedded execution mode to workflow steps.
- Restricted workflow resource classes to local I/O, CPU, and GPU execution.
- Persisted the embedded execution mode in durable job payloads for auditability.
- Added regression coverage preventing accidental introduction of remote or service-backed workflow execution.

### Version 2 M6.2 — Lean cleanup visibility

- Added non-destructive cleanup previews with job, event, file, and byte estimates.
- Added conservative orphan detection limited to Aperture-owned temporary roots.
- Added empty temporary-directory pruning after successful file cleanup.
- Added Maintenance Center controls for previewing and running bounded cleanup.
- Added reclaimed-space reporting without introducing background services or new runtime technologies.

### Version 2 M6.3 — Existing Maintenance Center integration

- Extended the established library health service with background-work, optional-subsystem, capability-registry, and asset-analysis consistency checks.
- Added recent durable-job visibility to the existing Maintenance Center.
- Added Pause, Continue, and Stop controls using the existing SQLite job state machine.
- Preserved the existing backup, restore, health, recovery, and cleanup ownership; no parallel monitor, controller, daemon, or runtime service was introduced.
- Added ADR-026 defining the Maintenance Center as the sole operational surface for Version 2 health and work control.

### Version 2 M6.4 — Maintenance storage and package inventory
- Added read-only storage visibility to the existing Maintenance Center.
- Added installed offline-map and taxonomy package inventory without lazy-subsystem activation.
- Distinguished authoritative library storage from derived or managed data.

### Aperture 3.320 — Responsive Library and Collections layout

- Reworked the persistent Structured Filters pane into a narrow two-column form so every label and field remains visible at normal Windows desktop widths.
- Stacked Collections and saved-view actions into complete-width rows, eliminating clipped action buttons.
- Wrapped the always-visible Inspector in its own vertical scroll area and reduced oversized preview and text-editor minimums.
- Added non-collapsible, practical splitter defaults for the Filters, Grid, and Inspector panes.
- Shortened constrained selection-bar button labels without changing their actions.

## 2026-07-18 — BioCLIP activation and selected-image handoff

- BioCLIP Quick Setup now installs both CPU FP32 and CUDA FP16 variants.
- CPU-compatible inference is preferred on systems without a usable CUDA runtime.
- Installing BioCLIP automatically builds embeddings for an already-installed regional taxonomy and prompt set.
- Library selection is retained when moving to AI Review.
- Completing AI resource setup refreshes AI Review and starts classification for the retained Library selection.
- Regional taxonomy remains available to both the taxonomy browser and BioCLIP candidate generation.

## 2026-07-18 — Offline field notebook and responsiveness pass

- Added a dedicated Notebook workspace under Library.
- Notebook pages support title, field notes, taxonomy, location, tags, and linked Library images.
- Added New from Library selection and Attach selected Library images actions.
- Notebook pages autosave atomically to the active library and remain fully offline.
- Added notebook search and independent page management.
- Reduced Library query batches from 500 to 120 assets to keep the interface responsive.
- Reduced concurrent thumbnail decoding from eight workers to four to avoid CPU and disk saturation.
- Reduced preview decode size and increased search debounce to prevent repeated expensive work while typing.

## 2026-07-18 — Collection render latency pass

- Batched Library and Collections grid updates so Qt performs one layout and repaint per page instead of one per asset.
- Deferred thumbnail decoding until after the result grid has painted, keeping navigation responsive while images fill in.
- Replaced the thumbnail queue's linear-time front removal with a deque.
- Switched inspector preview scaling to the faster Qt transform path to reduce selection latency.

## 3.320 BioCLIP identity and rich Notebook maintenance
- BioCLIP and local taxonomy package identities are now content-addressed, so a changed checkpoint can be installed and activated without violating package immutability.
- Fixed New note and New from Library selection so the editor always switches to the newly created page.
- Notebook notes now persist rich HTML alongside a searchable plain-text projection.
- Added bold, italic, underline, headings, lists, quote indentation, and clear-format controls.

## Build 3.320 - Darwin Core Archive source import
- Added direct selection and validation of GBIF source archives in Darwin Core Archive (`.zip`) format.
- Preserves the source archive byte-for-byte and safely stages embedded photo/RAW members for the existing import pipeline.
- Rejects unsafe archive paths and bounded archive expansion protects against oversized/hostile ZIPs.
- Records-only archives now produce an actionable message explaining that remote media are not downloaded automatically.
