# Aperture V3.RC1F1 — Integrated NatureAI release candidate

Version **3.0.0rc1.post1** promotes the completed Build 3.336 stabilization work into the first Version 3 release candidate.

## NatureAI engine

- BioCLIP, `pybioclip==2.1.5`, `TreeOfLifeClassifier`, the original BioCLIP v1 model identity, and the matching Tree-of-Life resources are installed and validated as one engine.
- Initial Full AI installation primes the Tree-of-Life classifier and activates it automatically; a CSV and GBIF are not required for the original NatureAI classification path.
- Aperture taxonomy prompt sets remain supported as optional bounded or custom classifiers. Empty prompt sets are not accepted as ready.
- GBIF remains an independent taxonomy/enrichment component and may resolve or enrich NatureAI results without being a prerequisite for inference.
- Maintenance Center can download, resume, import, validate, repair, and reactivate the complete NatureAI/BioCLIP environment.

## Knowledge Base and workspaces

- Knowledge Base exposes BioCLIP/NatureAI, GBIF taxonomy, and reference resources as independent components.
- Library and Collections retain independent workspaces, splitter state, and inspector containment.

## Upgrade notes

Install over the approved prior release, then run **Maintenance Center → Repair Full AI / NatureAI Engine** when upgrading an existing environment. Confirm **Tree of Life classifier: Ready** before starting AI Review. Existing libraries and GBIF databases are not replaced.

## Release identity

- Product release: **Aperture V3.RC1F1**
- Python package version: **3.0.0rc1.post1**
- Baseline implementation: Build 3.336 post22

---

## Build 3.326 — Detached Taxonomy Builder and Working Sets

- GBIF taxonomy construction now runs as a detached operating-system process that survives Aperture restarts.
- Added persistent JSON status, cooperative cancellation, 5,000-row checkpoints, and safe resume into the isolated `.next.sqlite3` database.
- Aperture reattaches to an existing source-build job instead of starting a duplicate import.
- Added read-only taxonomy working-set filters for kingdom, class, order/subgroup, family, and rank.
- Added cascading selection suitable for views such as Animalia → Aves → Accipitriformes (birds of prey).
- Working-set definitions are stored separately from both the source database and the operational Aperture Library.

## Build 3.325 — PMTiles Transport and Isolated Taxonomy Worker

- Replaced custom-scheme PMTiles query requests with a path-based byte-range endpoint to avoid Qt WebEngine HTTP 400 responses on Windows.
- Added explicit CORS response headers for local PMTiles byte responses.
- Runs GBIF Darwin Core parsing and isolated taxonomy database construction in a spawned worker process, keeping the Qt interface responsive.
- Keeps the active GBIF database read-only and available while a replacement source database is built and validated.
- Stores only compact observation enrichment links in the operational database; taxonomy source rows remain external.

## Build 3.323 — Offline Map Reliability Update

This maintenance build fixes two related offline-map failures observed on Windows. Planetiler map builds now wait for exclusive access to shared Natural Earth and water-polygon source files, so starting a second region cannot interfere with a first build's temporary download rename. The map renderer now opens the installed PMTiles archive directly, reads its header and metadata, and supplies MapLibre with an explicit tile URL template. Renderer errors remain visible instead of disappearing after the empty background loads.

# Aperture 2.0.0 RC3 post 1 release notes

## Build 3.322 — Darwin Core Folder Import and Metadata Compatibility

This maintenance release fixes Darwin Core taxonomy imports that stopped with the unhelpful message `'index'`. Some source archives omit explicit `index` attributes on `id` or `field` declarations. Aperture now accepts those archives by using the declaration order, while still validating malformed or conflicting metadata.

Taxonomy Resources now provides two explicit choices: import the original GBIF Darwin Core ZIP, or import an already-extracted Darwin Core folder. Folder import reads `meta.xml` and its declared core table directly in place. It does not rebuild, normalize, recompress, or otherwise alter the source data. ZIP archives stored inside one enclosing directory are also accepted.

No database migration is required. Existing Aperture Libraries, taxonomy packages, models, maps, and observations remain available.

## Build 3.321 — GBIF Taxonomy, Offline Streets, and Resilient AI Downloads

This release separates taxonomy acquisition from AI model installation. **Resources → Taxonomy Resources** now imports a raw GBIF Darwin Core Archive directly as a signed local taxonomy package. Taxonomy can be installed without an AI model; when a compatible BioCLIP model and prompt set are active, Aperture rebuilds taxonomy embeddings so the two resources extend each other without sharing package identity. The original source archive is not normalized or modified.

Offline PMTiles rendering now uses a glyph-independent street style. The previous style declared text layers without an approved local glyph endpoint, which could cause MapLibre to reject the style and leave only the background visible. Roads, water, land use, and buildings now render without network access; street labels remain disabled until a bundled glyph pack is shipped. Renderer errors are surfaced in the map status overlay.

The official BioCLIP checkpoint downloader now keeps a persistent `.part` file, resumes with HTTP Range requests, retries transient TLS/connection failures six times, and never restarts a large successful partial download merely because the remote endpoint disconnected. Users can still select a local checkpoint instead.

No database migration is required. Existing Aperture Libraries and installed resources are preserved.

# Aperture 2.0.0 RC2.2 release notes

## Build delivery 2.41–2.60 — Photography Workflow Completion Candidate

This consolidated delivery adds LibRaw-backed camera RAW probing, baseline metadata, rendering, thumbnails, and previews while retaining Pillow for JPEG, TIFF, PNG, and other rendered formats. Catalog derivatives continue to apply EXIF orientation and now normalize embedded ICC profiles toward sRGB when possible.

The candidate consolidates the existing offline photographic workflow: file/folder import, managed/referenced storage, XMP preservation and bounded ingestion, metadata editing, Batch Review, collections and smart collections, metadata/GPS search, exact-duplicate visibility, Viewer, and verified original/metadata/derivative exports.

Build 2 is not frozen until representative NEF, CR3, ARW, and DNG samples plus the end-to-end workflow pass on Windows. Unsupported camera variants remain isolated with a clear fallback. Projects remain Build 7 Platform Activation; perceptual/destructive duplicate resolution remains future work. Offline Maps stay deferred to the Build 3 architectural evaluation. AI Review and BioCLIP are preserved.

## Build delivery 2.36–2.40 — Exact-duplicate visibility

Library now offers an `Exact duplicates only` filter for assets with at least two available file instances sharing the same SHA-256 checksum. Missing files are excluded, and the filter combines with existing metadata/GPS filters, saved searches, and smart collections.

This is deliberately non-destructive: no merge, remove, ignore-history, or perceptual-similarity action is included. Installer entry points, existing Libraries, Batch Review, offline Maps, AI Review, and BioCLIP remain unchanged.

## Build delivery 2.31–2.35 — GPS bounds search

Library now offers an optional GPS bounding-box filter for geotagged photographs. South, north, west, and east values are validated as one complete legal box and can be combined with existing camera, lens, rating, date, keyword, taxonomy, and other structured filters. Saved searches and smart collections retain the same versioned query representation.

No online geocoding, routing, or map redesign is included. Installer entry points, existing Libraries, offline Maps, Batch Review, AI Review, and BioCLIP remain unchanged.

## Build delivery 2.26–2.30 — Camera and lens search

Library now provides Camera Maker, Camera Model, and Lens filters. Matching is case-insensitive and accepts partial values, and the fields combine with existing rating, date, keyword, taxonomy, dimension, and other structured filters. Saved searches and smart collections use the same versioned query fields.

The installer, repair, and uninstaller entry points remain unchanged. No database migration is required, and existing Libraries, Batch Review, AI Review, and BioCLIP are preserved.

## Build delivery 2.21–2.25 — XMP metadata ingestion

Preserved XMP companions can now contribute standard Dublin Core title, description, and keyword metadata during import. Keywords are case-insensitively deduplicated and recorded as import-sourced tags, leaving user-authored tags independent. Parsed metadata receives a checksummed snapshot while the original XMP remains preserved.

Parsing is read-only and bounded; document types/entities and oversized payloads are rejected, while malformed XMP cannot block the photograph. XMP writing and metadata-conflict UI are not included. Installer entry points, existing Libraries, Batch Review, AI Review, and BioCLIP remain unchanged.

## Build delivery 2.16–2.20 — XMP sidecar preservation

Photo import now discovers conventional `photo.ext.xmp` and `photo.xmp` companions, registers them against the photograph, and prevents them from appearing as corrupt standalone assets. Managed and hybrid imports use checksummed Library-owned sidecar copies. A verified move removes source sidecars only after preservation and catalog commit succeed.

This delivery preserves XMP files but does not yet claim XMP field ingestion, editing/writing, or metadata conflict resolution. The installer, repair, and uninstaller entry points remain unchanged; no database migration is required, and Batch Review, AI Review, and BioCLIP are preserved.

## Build delivery 2.11–2.15 — Batch review UI

Library now exposes the atomic batch-review backend when two or more photographs are selected. Rating, color label, and pick/reject fields each offer “No change” separately from explicit clearing, so applying one value preserves unrelated review metadata. Work runs in the background and the Library refreshes after success or an all-or-nothing revision conflict.

The current installer, repair, and uninstaller entry points remain unchanged. No database migration is required, and existing Libraries, AI Review, and BioCLIP are preserved.

## Build delivery 2.6–2.10 — Batch review workflow

This consolidated Build 2 delivery adds the safe backend boundary for applying ratings, color labels, and pick/reject flags to a selection of photographs. Batches are validated and bounded to 500 assets, every optimistic revision is checked before changes begin, and the complete selection commits atomically. A stale or missing photograph leaves the whole selection unchanged.

The current installer, repair, and uninstaller entry points are unchanged. UI exposure is not claimed where the current desktop does not yet present the batch command; single-photo editing remains compatible. No database migration is required.

## Build delivery 2.1–2.5 — Photography import foundation

This consolidated delivery begins the approved Build 2 Photography Workflow after the field-validated Build 1 freeze. It adds deterministic photo/RAW/sidecar source classification, ignores recognized metadata sidecars as standalone import candidates, de-duplicates overlapping source selections, and correctly handles byte-identical photographs discovered within one plan. Recognized RAW files that the installed decoder cannot open now report `raw_decoder_unavailable` without stopping supported photographs in the folder.

This delivery does not claim complete RAW decoding, sidecar ingestion/writing, or metadata editing. Those remain later Build 2 work. No database migration is required, existing Libraries are preserved, and the current installer, repair, and uninstaller entry points remain unchanged.

RC2.2 hardens long-running resource processing and addresses the single-core render bottleneck observed during field testing.

No database migration is required for RC2.2, and existing Aperture Libraries are preserved. It remains part of Version 2 validation; back up important libraries before testing any release candidate.

## Implemented

- Map tile rendering now uses a bounded NatureAI Nest process pool. Tile generation runs across multiple CPU cores while MBTiles publication remains serialized in the parent process.
- Render worker count adapts to logical processor count and can be overridden with `NATUREAI_RENDER_WORKERS`.
- Map processing uses an adaptive workspace policy. Verified archives are held in memory when the available-memory budget permits; otherwise processing uses a hybrid disk workspace.
- MBTiles output is durably checkpointed every 32 completed tiles and on completion.
- The Activity Center now treats cleanup as history cleanup only. Open, interrupted, failed, cancelled, queued, and running tasks remain available for resume/retry.
- The Activity Center displays an Open Tasks count and explains that resumable work survives history cleanup.
- Durable job pools now size themselves from available logical processors and identify the engine as `NatureAI_Nest`.

## Safety model

Parallel workers generate independent tile payloads. Only the parent process writes to the MBTiles database, preserving a single atomic publication path and avoiding concurrent SQLite writers.

This is a release-candidate build for user testing. It is not release-approved until field validation is complete.

## Responsive Library workspace update

The Library and Collections workspaces now fit common Windows display sizes without truncating controls. Structured filters use a compact vertical form, collection actions are stacked into readable rows, and the always-visible Inspector scrolls independently when vertical space is limited.

### BioCLIP automatic activation fix
Downloaded BioCLIP resources are now activated immediately. Existing regional taxonomy prompts are embedded automatically, the Library selection is retained across workspace changes, and AI Review starts classification for those selected photographs after setup. A CPU FP32 model variant is included alongside CUDA FP16 so BioCLIP remains usable on Windows systems without compatible CUDA hardware.

## Field Notebook and performance update

Aperture now includes a fully offline field Notebook workspace. Notes can be linked directly to the images selected in Library and include taxonomy, location, tags, and free-form observations. Notes autosave to `notebook.json` in the active library using atomic replacement.

The Library now loads smaller pages and uses bounded thumbnail concurrency. This reduces long UI stalls on large libraries and slower disks. Expensive image work remains off the UI thread. The target is interactive feedback within two to three seconds; actual first-load timing still depends on image format, storage speed, antivirus scanning, and whether thumbnails are already cached.
