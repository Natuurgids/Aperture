"""Persistent, orientation-correct thumbnail and preview rendering for the catalog UI."""
from __future__ import annotations

import hashlib
import json
from io import BytesIO
from pathlib import Path
from threading import Lock
from typing import Protocol

from PIL import Image, ImageCms, ImageOps, UnidentifiedImageError

from natureai_next.infrastructure.filesystem.atomic import atomic_write_bytes
from natureai_next.domain.importing import ImportSourceKind, classify_import_source


class RawThumbnailRenderer(Protocol):
    def render_jpeg(self, source: Path, max_size: int, quality: int) -> bytes | None: ...


class PillowCatalogThumbnailProvider:
    """Render and persist bounded JPEG derivatives without mutating source images.

    The cache identity includes the canonical source path, source size, source
    modification timestamp, requested maximum dimension, renderer identity, and
    output quality.  A compatible derivative is therefore reusable across
    application restarts while a changed source automatically receives a new key.
    """

    renderer_identity = "natureai.pillow.catalog.v1"

    def __init__(
        self,
        *,
        thumbnail_root: Path | None = None,
        preview_root: Path | None = None,
        library_root: Path | None = None,
        quality: int = 85,
        raw_renderer: RawThumbnailRenderer | None = None,
    ) -> None:
        if not 1 <= quality <= 100:
            raise ValueError("quality must be between 1 and 100")
        self._thumbnail_root = thumbnail_root
        self._preview_root = preview_root or thumbnail_root
        self._library_root = library_root
        self._quality = quality
        self._raw_renderer = raw_renderer
        self._locks_guard = Lock()
        self._locks: dict[str, Lock] = {}

    def load(self, *, source_path: Path | None, cached_path: Path | None, max_size: int) -> bytes | None:
        if max_size <= 0:
            raise ValueError("max_size must be positive")

        explicit_cache = self._resolve_explicit_cache(cached_path)
        if explicit_cache is not None:
            data = self._read_valid_jpeg(explicit_cache, max_size)
            if data is not None:
                return data

        if source_path is None or not source_path.is_file():
            return None

        cache_path = self._cache_path(source_path, max_size)
        if cache_path is None:
            return self._render(source_path, max_size)

        key = cache_path.stem
        lock = self._lock_for(key)
        with lock:
            data = self._read_valid_jpeg(cache_path, max_size)
            if data is not None:
                return data
            data = self._render(source_path, max_size)
            if data is None:
                return None
            atomic_write_bytes(cache_path, data)
            return data

    def _resolve_explicit_cache(self, path: Path | None) -> Path | None:
        if path is None:
            return None
        if path.is_absolute():
            return path
        if self._library_root is not None:
            return self._library_root / path
        return None

    def _cache_path(self, source: Path, max_size: int) -> Path | None:
        root = self._preview_root if max_size > 384 else self._thumbnail_root
        if root is None:
            return None
        stat = source.stat()
        payload = {
            "source": str(source.resolve()).casefold(),
            "source_size": stat.st_size,
            "source_mtime_ns": stat.st_mtime_ns,
            "max_size": max_size,
            "quality": self._quality,
            "renderer": self.renderer_identity,
        }
        key = hashlib.sha256(json.dumps(payload, sort_keys=True, separators=(",", ":")).encode("utf-8")).hexdigest()
        return root / key[:2] / key[2:4] / f"{key}.jpg"

    def _render(self, source: Path, max_size: int) -> bytes | None:
        if classify_import_source(source) is ImportSourceKind.RAW_PHOTO and self._raw_renderer is not None:
            return self._raw_renderer.render_jpeg(source, max_size, self._quality)
        try:
            with Image.open(source) as opened:
                image = ImageOps.exif_transpose(opened)
                image = _to_srgb(image)
                if image.mode != "RGB":
                    image = image.convert("RGB")
                image.thumbnail((max_size, max_size), Image.Resampling.LANCZOS)
                output = BytesIO()
                image.save(output, format="JPEG", quality=self._quality, optimize=True)
                return output.getvalue()
        except (OSError, UnidentifiedImageError, ValueError):
            return None

    @staticmethod
    def _read_valid_jpeg(path: Path, max_size: int) -> bytes | None:
        if not path.is_file():
            return None
        try:
            data = path.read_bytes()
            with Image.open(BytesIO(data)) as image:
                if image.format != "JPEG" or image.width > max_size or image.height > max_size:
                    return None
                image.verify()
            return data
        except (OSError, UnidentifiedImageError, ValueError):
            return None

    def _lock_for(self, key: str) -> Lock:
        with self._locks_guard:
            return self._locks.setdefault(key, Lock())


def _to_srgb(image: Image.Image) -> Image.Image:
    profile = image.info.get("icc_profile")
    if not profile:
        return image
    try:
        source_profile = ImageCms.ImageCmsProfile(BytesIO(profile))
        target_profile = ImageCms.createProfile("sRGB")
        output_mode = "RGB" if image.mode not in {"RGB", "RGBA"} else image.mode
        return ImageCms.profileToProfile(image, source_profile, target_profile, outputMode=output_mode)
    except (OSError, TypeError, ValueError, ImageCms.PyCMSError):
        return image
