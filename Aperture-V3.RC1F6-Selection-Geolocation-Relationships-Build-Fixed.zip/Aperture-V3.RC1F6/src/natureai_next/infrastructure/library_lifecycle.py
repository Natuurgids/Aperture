"""SQLite/filesystem Library lifecycle backend."""
from __future__ import annotations
import shutil
from dataclasses import dataclass
from pathlib import Path

from natureai_next import __version__
from natureai_next.domain.library import IntegrityReport, LibraryLayout, LibraryManifest
from natureai_next.infrastructure.database.backup import create_database_backup
from natureai_next.infrastructure.database.connection import SqliteConnectionFactory
from natureai_next.infrastructure.database.integrity import check_integrity
from natureai_next.infrastructure.database.migrations import CORE_MIGRATIONS,MigrationRunner
from natureai_next.infrastructure.database.settings import SqliteSettings
from natureai_next.infrastructure.filesystem.library_lock import LibraryLock
from natureai_next.infrastructure.filesystem.library_manifest import read_manifest,write_manifest


@dataclass(slots=True)
class SqliteOpenLibrary:
    layout:LibraryLayout; manifest:LibraryManifest; connection_factory:SqliteConnectionFactory; lock:LibraryLock; _closed:bool=False
    def integrity(self,*,full:bool=False)->IntegrityReport:return check_integrity(self.connection_factory,full=full)
    def backup_database(self,destination:Path)->Path:return create_database_backup(self.connection_factory,destination)
    def close(self)->None:
        if self._closed:return
        self._closed=True; connection=self.connection_factory.connect()
        try:connection.execute("PRAGMA wal_checkpoint(TRUNCATE)")
        finally:connection.close();self.lock.release()
    def __enter__(self):return self
    def __exit__(self,*_:object)->None:self.close()


class SqliteLibraryLifecycleBackend:
    def __init__(self,clock,ids,settings=None)->None:self.clock=clock;self.ids=ids;self.settings=settings or SqliteSettings()
    def create(self,root:Path,*,display_name:str,default_locale:str="en")->SqliteOpenLibrary:
        layout=LibraryLayout.at(root)
        if layout.root.exists() and any(layout.root.iterdir()):raise FileExistsError(f"library directory is not empty: {layout.root}")
        layout.create_directories();lock=LibraryLock(layout.lock_file);lock.acquire();public_id=str(self.ids.new_uuid());created=int(self.clock.now_utc().timestamp()*1_000_000);manifest=LibraryManifest(1,public_id,display_name,created)
        try:
            write_manifest(layout.manifest,manifest);factory=SqliteConnectionFactory(layout.database,self.settings);connection=factory.connect()
            try:
                MigrationRunner(CORE_MIGRATIONS,__version__).apply(connection);connection.execute("BEGIN IMMEDIATE");connection.execute("INSERT INTO library_info(id,public_id,created_at_us,current_schema_version,minimum_app_version,display_name,default_locale) VALUES(1,?,?,?,?,?,?)",(public_id,created,len(CORE_MIGRATIONS),__version__,display_name,default_locale));connection.execute("COMMIT")
            finally:connection.close()
            opened=SqliteOpenLibrary(layout,manifest,factory,lock)
            if not opened.integrity().healthy:raise RuntimeError("new library failed integrity validation")
            return opened
        except Exception:lock.release();shutil.rmtree(layout.root,ignore_errors=True);raise
    def open(self,root:Path)->SqliteOpenLibrary:
        layout=LibraryLayout.at(root);manifest=read_manifest(layout.manifest);lock=LibraryLock(layout.lock_file);lock.acquire()
        try:
            factory=SqliteConnectionFactory(layout.database,self.settings);connection=factory.connect()
            try:MigrationRunner(CORE_MIGRATIONS,__version__).apply(connection);row=connection.execute("SELECT public_id FROM library_info WHERE id=1").fetchone()
            finally:connection.close()
            if row is None or row[0]!=manifest.library_public_id:raise RuntimeError("library manifest and database identity differ")
            return SqliteOpenLibrary(layout,manifest,factory,lock)
        except Exception:lock.release();raise
