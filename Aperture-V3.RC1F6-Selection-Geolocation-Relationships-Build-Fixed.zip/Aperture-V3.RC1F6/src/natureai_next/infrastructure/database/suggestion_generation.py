"""SQLite suggestion-generation prerequisite queries."""
from __future__ import annotations

import json
from collections.abc import Sequence
from pathlib import Path

from natureai_next.domain.ai import ActiveAIContext
from natureai_next.infrastructure.database.connection import SqliteConnectionFactory


class SqliteSuggestionGenerationSource:
    def __init__(self, factory: SqliteConnectionFactory) -> None:
        self._factory = factory

    def active_context(self) -> ActiveAIContext:
        connection = self._factory.connect(read_only=True)
        try:
            row = connection.execute(
                """SELECT v.id,p.model_identity,p.semantic_version,v.variant_identity,
                          v.precision,v.preprocessing_identity,v.input_size,
                          p.install_path_token,v.artifact_relative_path,ps.public_id,
                          v.device_requirements_json
                   FROM model_packages p
                   JOIN model_variants v ON v.package_id=p.id
                   LEFT JOIN prompt_sets ps ON ps.model_family=p.model_family AND ps.active=1
                   WHERE p.active=1 AND v.active=1
                   ORDER BY COALESCE(p.activated_at_us,p.installed_at_us) DESC,
                            CASE WHEN v.variant_identity='cpu-fp32' THEN 0 ELSE 1 END,
                            v.id DESC LIMIT 1"""
            ).fetchone()
            if row is None: raise RuntimeError("No active NatureAI BioCLIP engine or local model package is installed.")
            requirements = json.loads(str(row[10] or "{}"))
            external_tree_of_life = requirements.get("external_engine") == "natureai" and requirements.get("classifier") == "TreeOfLifeClassifier"
            if row[9] is None and not external_tree_of_life:
                raise RuntimeError("No active prompt set is installed for the active model.")
            input_size = int(row[6] or 0)
            if input_size <= 0: raise RuntimeError("The active model variant has no valid input size.")
            relative = str(row[8] or "").strip()
            if external_tree_of_life:
                artifact = Path("natureai-tree-of-life-managed")
            else:
                if not relative: raise RuntimeError("The active model variant has no artifact path.")
                artifact = Path(str(row[7])) / relative
                if not artifact.is_file(): raise RuntimeError(f"The active model artifact is missing: {artifact}")
            providers = tuple(str(value).casefold() for value in requirements.get("providers", ()))
            device = "cuda" if any("cuda" in value for value in providers) else "cpu"
            prompt_public_id = "natureai-tree-of-life-managed" if row[9] is None else str(row[9])
            provider = "pybioclip-tree-of-life" if external_tree_of_life else "openclip-local-v1"
            return ActiveAIContext(int(row[0]),str(row[1]),str(row[2]),str(row[3]),str(row[4]),str(row[5]),input_size,artifact,prompt_public_id,provider,device)
        finally:
            connection.close()

    def asset_paths(self, public_ids: Sequence[str]) -> tuple[tuple[str, Path], ...]:
        ordered = tuple(dict.fromkeys(str(value) for value in public_ids if str(value)))
        if not ordered: return ()
        placeholders = ",".join("?" for _ in ordered)
        connection = self._factory.connect(read_only=True)
        try:
            rows = connection.execute(
                f"""SELECT a.public_id,f.normalized_path FROM assets a
                    JOIN file_instances f ON f.id=a.primary_file_instance_id
                    WHERE a.lifecycle_state='active' AND a.public_id IN ({placeholders})""", ordered
            ).fetchall()
        finally:
            connection.close()
        by_id = {str(row[0]): Path(str(row[1])) for row in rows}
        return tuple((public_id, by_id[public_id]) for public_id in ordered if public_id in by_id)
