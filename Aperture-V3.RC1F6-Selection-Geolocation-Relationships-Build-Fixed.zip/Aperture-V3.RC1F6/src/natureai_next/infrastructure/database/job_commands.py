"""SQLite adapter for Application job commands and recent-history queries."""
from __future__ import annotations

from natureai_next.domain.jobs import JobRecord
from natureai_next.infrastructure.database.connection import SqliteConnectionFactory
from natureai_next.infrastructure.database.repositories import SqliteJobRepository
from natureai_next.infrastructure.database.unit_of_work import SqliteUnitOfWork


class SqliteJobCommandStore:
    def __init__(self, factory: SqliteConnectionFactory) -> None:
        self._factory = factory

    def submit(self, record: JobRecord) -> JobRecord:
        with SqliteUnitOfWork(self._factory) as uow:
            if record.idempotency_key:
                row = uow.connection.execute("SELECT public_id FROM jobs WHERE idempotency_key=?", (record.idempotency_key,)).fetchone()
                if row is not None:
                    existing = uow.jobs.get(row[0]); uow.commit()
                    if existing is None: raise RuntimeError("idempotent job disappeared")
                    return existing
            created = uow.jobs.add(record); uow.commit(); return created

    def request_cancel(self, public_id: str, now_us: int) -> bool:
        return self._change(lambda jobs: jobs.request_cancel(public_id, now_us))

    def request_pause(self, public_id: str, now_us: int) -> bool:
        return self._change(lambda jobs: jobs.request_pause(public_id, now_us))

    def resume(self, public_id: str, now_us: int) -> bool:
        return self._change(lambda jobs: jobs.resume(public_id, now_us))

    def list_recent(self, limit: int = 100) -> tuple[JobRecord, ...]:
        connection = self._factory.connect(read_only=True)
        try: return SqliteJobRepository(connection).list_recent(limit)
        finally: connection.close()

    def _change(self, operation) -> bool:
        with SqliteUnitOfWork(self._factory) as uow:
            changed = operation(uow.jobs); uow.commit(); return changed
