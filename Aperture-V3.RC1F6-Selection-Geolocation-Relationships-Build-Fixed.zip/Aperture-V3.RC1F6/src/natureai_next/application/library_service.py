"""Application facade for Library lifecycle operations."""
from __future__ import annotations

from pathlib import Path

from natureai_next.ports.clock import Clock
from natureai_next.ports.identity import UuidGenerator
from natureai_next.ports.library_lifecycle import LibraryBackendFactory, OpenLibraryPort, default_library_backend

OpenLibrary=OpenLibraryPort


class LibraryService:
    def __init__(self,clock:Clock,ids:UuidGenerator,settings:object|None=None,*,backend_factory:LibraryBackendFactory|None=None)->None:
        self._backend=(backend_factory or default_library_backend())(clock,ids,settings)
    def create(self,root:Path,*,display_name:str,default_locale:str="en")->OpenLibraryPort:
        return self._backend.create(root,display_name=display_name,default_locale=default_locale)
    def open(self,root:Path)->OpenLibraryPort:
        return self._backend.open(root)
