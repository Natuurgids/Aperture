"""Application service for the first offline map workspace."""
from __future__ import annotations

from dataclasses import dataclass
import math

from natureai_next.application.knowledge_engine import KnowledgeEngine
from natureai_next.domain.maps import MapPackageCapability, OfflineMapPackage, OfflineRasterTile
from natureai_next.domain.spatial_intelligence import GeoBounds, MonitoringSiteSummary, SpatialAsset, SpatialObservation
from natureai_next.ports.map_workspace import OfflineMapQuery, SpatialMapQuery


@dataclass(frozen=True, slots=True)
class MapWorkspaceResult:
    package: OfflineMapPackage | None
    bounds: GeoBounds
    observations: tuple[SpatialObservation, ...]
    assets: tuple[SpatialAsset, ...]
    sites: tuple[MonitoringSiteSummary, ...]
    attribution: str
    attribution_url: str


class OfflineMapWorkspaceService:
    """Combines optional map packages with core-library spatial records."""

    def __init__(self, *, maps: OfflineMapQuery, spatial: SpatialMapQuery, knowledge_engine: KnowledgeEngine | None = None) -> None:
        self._maps = maps
        self._spatial = spatial
        self._knowledge_engine = knowledge_engine

    def workspace(self, *, latitude: float, longitude: float, zoom: int) -> MapWorkspaceResult:
        zoom = max(0, min(22, int(zoom)))
        bounds = viewport_bounds(latitude, longitude, zoom, tile_radius=1)
        packages = tuple(
            package for package in self._maps.covering(latitude, longitude)
            if package.format == "mbtiles"
            and (package.min_zoom is None or zoom >= package.min_zoom)
            and (package.max_zoom is None or zoom <= package.max_zoom)
        )
        package = packages[0] if packages else None
        return MapWorkspaceResult(
            package=package,
            bounds=bounds,
            observations=(
                self._knowledge_engine.observations_in_area(bounds)
                if self._knowledge_engine is not None
                else self._spatial.observations_in_bounds(bounds)
            ),
            assets=self._spatial.assets_in_bounds(bounds),
            sites=self._spatial.list_sites_in_bounds(bounds),
            attribution="" if package is None else package.attribution,
            attribution_url="" if package is None else package.attribution_url,
        )

    def available_packages(self) -> tuple[OfflineMapPackage, ...]:
        """Return enabled packages with a currently available renderer."""
        renderable = {item.package_public_id for item in self._maps.capabilities() if item.renderable}
        return tuple(
            package for package in self._maps.list_all()
            if package.enabled
            and package.status == "installed"
            and package.public_id in renderable
        )

    def package_capabilities(self) -> tuple[MapPackageCapability, ...]:
        """Report package/renderer readiness without attempting tile decoding."""
        return self._maps.capabilities()

    def package(self, public_id: str) -> OfflineMapPackage:
        package = self._maps.get(public_id)
        if package not in self.available_packages():
            raise ValueError("offline map package is not enabled and displayable")
        return package

    def tile(self, package_public_id: str, zoom: int, x: int, y: int) -> OfflineRasterTile | None:
        return self._maps.tile(package_public_id, zoom, x, y)


@dataclass(frozen=True, slots=True)
class MapPackageViewpoint:
    latitude: float
    longitude: float
    zoom: int


def package_viewpoint(package: OfflineMapPackage) -> MapPackageViewpoint:
    """Return a practical initial viewport for one bounded offline package."""
    if None in (package.west, package.south, package.east, package.north):
        raise ValueError("the installed package has no geographic bounds")
    west, south = float(package.west), float(package.south)
    east, north = float(package.east), float(package.north)
    longitude = (west + east) / 2.0 if east >= west else ((west + east + 360.0) / 2.0 + 180.0) % 360.0 - 180.0
    latitude = (south + north) / 2.0
    minimum = 0 if package.min_zoom is None else int(package.min_zoom)
    maximum = 18 if package.max_zoom is None else int(package.max_zoom)
    chosen = minimum
    for zoom in range(minimum, maximum + 1):
        width = abs(lon_to_tile_x(east, zoom) - lon_to_tile_x(west, zoom))
        height = abs(lat_to_tile_y(south, zoom) - lat_to_tile_y(north, zoom))
        if width <= 2.5 and height <= 2.5:
            chosen = zoom
        else:
            break
    return MapPackageViewpoint(
        latitude=max(-85.0, min(85.0, latitude)),
        longitude=longitude,
        zoom=chosen,
    )


def lon_to_tile_x(longitude: float, zoom: int) -> float:
    return (longitude + 180.0) / 360.0 * (1 << zoom)


def lat_to_tile_y(latitude: float, zoom: int) -> float:
    latitude = max(-85.05112878, min(85.05112878, latitude))
    radians = math.radians(latitude)
    return (1.0 - math.asinh(math.tan(radians)) / math.pi) / 2.0 * (1 << zoom)


def tile_x_to_lon(x: float, zoom: int) -> float:
    return x / (1 << zoom) * 360.0 - 180.0


def tile_y_to_lat(y: float, zoom: int) -> float:
    return math.degrees(math.atan(math.sinh(math.pi * (1.0 - 2.0 * y / (1 << zoom)))))


def viewport_bounds(latitude: float, longitude: float, zoom: int, *, tile_radius: int = 1) -> GeoBounds:
    center_x = lon_to_tile_x(longitude, zoom)
    center_y = lat_to_tile_y(latitude, zoom)
    return GeoBounds(
        min_latitude=tile_y_to_lat(center_y + tile_radius + 0.5, zoom),
        min_longitude=max(-180.0, tile_x_to_lon(center_x - tile_radius - 0.5, zoom)),
        max_latitude=tile_y_to_lat(center_y - tile_radius - 0.5, zoom),
        max_longitude=min(180.0, tile_x_to_lon(center_x + tile_radius + 0.5, zoom)),
    )
