from pathlib import Path

import natureai_next


def test_v3_rc1_version_identity() -> None:
    root = Path(__file__).resolve().parents[1]
    assert natureai_next.__version__ == "3.0.0rc1.post6"
    assert (root / "VERSION").read_text(encoding="utf-8").strip() == "3.0.0rc1.post6"
    assert 'version = "3.0.0rc1.post6"' in (root / "pyproject.toml").read_text(encoding="utf-8")
    assert "Aperture V3.RC1F6" in (root / "RELEASE_NOTES.md").read_text(encoding="utf-8")
