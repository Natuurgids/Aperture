Aperture 3.0 RC1

Release: V3.RC1
Version: 3.0.0rc1.post2
Engine: NatureAI with integrated BioCLIP Tree of Life

Start with QUICKSTART_WINDOWS.md. The Full AI installation now installs, validates, and activates the BioCLIP model, pybioclip runtime, TreeOfLifeClassifier, and matching Tree-of-Life resources as one NatureAI engine. GBIF remains an optional independent taxonomy and enrichment resource.

For existing installations, open Maintenance Center and run Repair Full AI / NatureAI Engine, then verify that the AI Resources page reports the Tree of Life classifier ready before analysing photographs.
