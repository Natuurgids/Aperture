## 3.0.0rc1.post6 — Aperture V3.RC1F6

- Added safe legacy path/data discovery and cleanup tooling.
- Added selected-disk installation configuration at `config/installation.json`.
- Protected current data root and shared third-party caches from accidental removal.

## 3.0.0rc1.post2 — V3.RC1F2

- Added responsive branded startup splash using the packaged Aperture logo.
- Added real weighted milestone progress during blocking desktop construction.
- Reused one QApplication for splash and main window.
- Added startup-splash-visible telemetry.

## 3.0.0rc1.post1 — V3.RC1F1

- Added a NatureAI-owned engine-state database and an Aperture bridge handshake.
- Full AI installation now records BioCLIP, TreeOfLifeClassifier, TreeOfLife-10M, device, and readiness as one activated NatureAI engine.
- Aperture libraries discover the ready NatureAI engine at startup and create only non-owning provenance bridge records.
- AI Resources now reflects the active NatureAI engine without requiring duplicate model ownership or GBIF/CSV resources.
- Tree-of-Life classification accepts the managed NatureAI prompt profile and no longer requires a local model artifact path.

# Aperture V3.RC1F1 — Integrated NatureAI release candidate

Version **3.0.0rc1.post1** promotes the completed Build 3.336 stabilization work into the first Version 3 release candidate.

## NatureAI engine

- BioCLIP, `pybioclip==2.1.5`, `TreeOfLifeClassifier`, the original BioCLIP v1 model identity, and the matching Tree-of-Life resources are installed and validated as one engine.
- Initial Full AI installation primes the Tree-of-Life classifier and activates it automatically; a CSV and GBIF are not required for the original NatureAI classification path.
- Aperture taxonomy prompt sets remain supported as optional bounded or custom classifiers. Empty prompt sets are not accepted as ready.
- GBIF remains an independent taxonomy/enrichment component and may resolve or enrich NatureAI results without being a prerequisite for inference.
- Maintenance Center can download, resume, import, validate, repair, and reactivate the complete NatureAI/BioCLIP environment.

## Knowledge Base and workspaces

- Knowledge Base exposes BioCLIP/NatureAI, GBIF taxonomy, and reference resources as independent components.
- Library and Collections retain independent workspaces, splitter state, and inspector containment.

## Upgrade notes

Install over the approved prior release, then run **Maintenance Center → Repair Full AI / NatureAI Engine** when upgrading an existing environment. Confirm **Tree of Life classifier: Ready** before starting AI Review. Existing libraries and GBIF databases are not replaced.

## Release identity

- Product release: **Aperture V3.RC1F1**
- Python package version: **3.0.0rc1.post1**
- Baseline implementation: Build 3.336 post22

---

## 2.0.0rc3.post21

- Restored legacy NatureAI TreeOfLifeClassifier inference as a fallback independent of GBIF/CSV taxonomy resources.
- Added pybioclip 2.1.5 to the AI dependency profile.
- Added provenance identifying the classification source.

## 2.0.0rc3.post19 — Local BioCLIP import and Maintenance Center resource setup

- Added complete BioCLIP folder import and offline activation.
- Added BioCLIP download/import controls to the standalone Maintenance Center.
- Redesigned the Maintenance Center as a scrollable, viewport-safe screen.

# Build 3.336 post18 — Legacy BioCLIP flow restoration and GBIF schema reconnection

- Uses the completed GBIF importer database and its `taxa`/`taxon_names` schema exclusively.
- Adds explicit taxonomy-root discovery and schema diagnostics; obsolete `names` queries are removed.
- Restores the proven BioCLIP setup sequence while retaining component enable/disable controls.
- Downloads the official BioCLIP checkpoint through the resumable Hugging Face cache first, with the direct range downloader only as fallback.
- Pins the verified BioCLIP model revision and adds `huggingface-hub` to the AI installation profile.

## Build 3.336 BioCLIP resource audit (post17)

- Pinned the official original Imageomics BioCLIP paper model revision instead of following a mutable upstream main branch.
- Added a signed resource descriptor containing repository, revision, OpenCLIP architecture, and checkpoint SHA-256.
- OpenCLIP now verifies the installed checkpoint before inference and rejects mismatched architectures.
- Added reusable BioCLIP installation audit diagnostics; legacy unpinned installs are reported as requiring repair.

# Build 3.336 post16 — Component reconnection correction

- Reconnects Knowledge Base · GBIF to the independent database published by the completed Darwin Core importer through `sources.json`.
- Supports the importer schema (`taxa` + `taxon_names`) while retaining legacy `names` compatibility.
- Restores BioCLIP/OpenCLIP as an independently switchable AI engine without deleting models or prior suggestions.
- Adds Settings → Resource Components with persistent GBIF and BioCLIP enable/disable controls and diagnostics.
- Keeps enrichment asset-oriented so photos work now and future media types can reuse the same link/provenance layer.

# Build 3.336 — Knowledge Base Architecture

- Adds Knowledge Base as an independent top-level workspace.
- Moves BioCLIP AI Review and independent GBIF taxonomy enrichment into dedicated Knowledge Base tabs.
- Adds a searchable full-data view across AI suggestions and applied external taxonomy records.
- Preserves legacy AI Review and Taxonomy navigation routes as deep links.
- Persists Knowledge Base splitter geometry independently from Library and Collections.
- Keeps the Library focused on photo management while enrichment remains explicit and auditable.

# Build 3.335 — Independent Library and Collections workspace foundation

This increment implements the highest-risk Phase 1 corrections from the Build 3.335 specification:

- persistent, separately instantiated Library and Collections workspaces
- independent splitter object names and QSettings keys
- safe splitter-state restoration with zero-width rejection
- bounded, scrollable inspector containment
- activate/deactivate workspace lifecycle without reconstruction
- guarded catalog refresh to prevent recursive refresh loops
- navigation through QStackedWidget.setCurrentWidget
- regression coverage for workspace separation and containment

The map renderer, normal photo importer, Darwin Core importer, and independent taxonomy database architecture are unchanged.

Validation: 23 tests passed.

# Build 3.334 — Restore Library and Collections panels

- Restored `ui/qt/library.py` to the last known-good pre-taxonomy-panel implementation.
- Removed taxonomy-workspace signals that changed the active Library and Collections views.
- Kept the independent GBIF Taxonomy workspace as a separate top-level workspace.
- Preserved photo-only Library import and the loopback MBTiles renderer.

### BioCLIP acquisition reliability
- Renamed the normal AI download option to the complete supported BioCLIP model and explicitly distinguished it from the 92 TB occurrence corpus.
- Added cancellable downloads that retain partial data for immediate range-resume.
- Reduced retry lockout delays and increased transfer block size while throttling UI progress updates.

## 3.0.0rc1.post3 — Aperture V3.RC1F3

- Fixed pybioclip Tree-of-Life candidates being rejected when their external identifiers were not present in Aperture's local taxonomy.
- Tree-of-Life scores are retained as raw model scores rather than incorrectly marked as calibrated probabilities.
- Preserved complete upstream classifier rows in suggestion provenance for later GBIF/local-taxonomy resolution.
- Added installer-selected `DataRoot` storage for models, caches, logs, component databases, launcher state, taxonomy packages, maps, and update data.
- Redirected Hugging Face and Torch caches to the selected Aperture data disk.
