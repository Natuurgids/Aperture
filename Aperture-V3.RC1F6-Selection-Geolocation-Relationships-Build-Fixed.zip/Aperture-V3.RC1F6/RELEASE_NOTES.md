## Aperture V3.RC1F6 — 3.0.0rc1.post6

### NatureAI diagnostic logging

- Adds user-controlled diagnostic logging in **AI Resources → Diagnostics**.
- Logging can be enabled or disabled immediately without restarting Aperture.
- Supports Errors, Standard, and Detailed levels.
- Writes inference diagnostics to `<DataRoot>\logs\natureai\natureai-inference.jsonl`.
- Records run lifecycle, per-image failures, pipeline stage, model/provider identity, and exception details.
- Detailed mode also records tracebacks and sanitized classifier candidates.
- Adds bounded log rotation and a **Clear diagnostic logs** control.
- Keeps diagnostic settings under `<DataRoot>\config\diagnostics.json`.

### Retained fixes

- Retains external Tree-of-Life result persistence and selected-disk storage/legacy cleanup fixes from RC1F3–RC1F4.

## Aperture V3.RC1F3 — 3.0.0rc1.post3

- Fixed NatureAI Tree-of-Life results being discarded when external taxon identifiers were not already present in the Aperture taxonomy database.
- External classifier candidates are stored as reviewable labels with raw scores and complete upstream provenance.
- Added installer-selected `DataRoot` storage for models, caches, logs, component databases, taxonomy packages, maps, updates, and launcher state.
- Hugging Face, BioCLIP, and Torch caches now follow the selected Aperture data disk.
- Windows registry and Start Menu/Desktop shortcut metadata remain in Windows-managed per-user locations; these are small integration records rather than application data.
