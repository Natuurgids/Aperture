"""Import planning values and deterministic policy decisions."""
from __future__ import annotations
from dataclasses import dataclass
from enum import StrEnum
from pathlib import Path

class ImportStoragePolicy(StrEnum):
    MANAGED = "managed"
    REFERENCED = "referenced"
    HYBRID = "hybrid"

class DuplicatePolicy(StrEnum):
    SKIP = "skip"
    ADD_FILE_INSTANCE = "add_file_instance"

class SourceDisposition(StrEnum):
    KEEP = "keep"
    DELETE_AFTER_VERIFIED_COPY = "delete_after_verified_copy"

class ImportDecision(StrEnum):
    IMPORT_NEW_ASSET = "import_new_asset"
    ATTACH_TO_EXISTING_ASSET = "attach_to_existing_asset"
    SKIP_EXACT_DUPLICATE = "skip_exact_duplicate"
    REJECT_SOURCE = "reject_source"

@dataclass(frozen=True, slots=True)
class SourceFile:
    path: Path
    size: int
    modified_at_us: int

@dataclass(frozen=True, slots=True)
class Fingerprint:
    sha256: str
    size: int
    fast_fingerprint: str

@dataclass(frozen=True, slots=True)
class ImportPlanItem:
    item_key: str
    source: SourceFile
    fingerprint: Fingerprint
    storage_policy: ImportStoragePolicy
    source_disposition: SourceDisposition
    decision: ImportDecision
    existing_asset_id: int | None = None
    planning_error_code: str | None = None
    planning_error_detail: str | None = None

@dataclass(frozen=True, slots=True)
class ImportPlan:
    public_id: str
    created_at_us: int
    duplicate_policy: DuplicatePolicy
    items: tuple[ImportPlanItem, ...]
    source_root: str | None = None
    source_volume_label: str | None = None
    source_volume_serial: str | None = None
    application_version: str | None = None

@dataclass(frozen=True, slots=True)
class ImportItemResult:
    item_key: str
    state: str
    asset_public_id: str | None = None
    file_public_id: str | None = None
    error_code: str | None = None
    source_path: str | None = None

@dataclass(frozen=True, slots=True)
class ImportSummary:
    total: int
    imported: int
    attached: int
    skipped: int
    failed: int
    results: tuple[ImportItemResult, ...]
