# Local AI and Resource Guide

Aperture uses the NatureAI_Next resource registry and package formats. Model, prompt, taxonomy, preprocessing, provider, and application identities are recorded with generated suggestions.

Before inference, confirm that a compatible signed model package, prompt set, and taxonomy resource are active. CUDA is preferred when available; CPU remains the safe fallback. Low-confidence or unknown outcomes are valid results and should not be forced into a taxon.

Photographs stay local. Resource downloads occur only after an explicit user action. Use Health Check to copy diagnostic information when seeking support.


## Interrupted BioCLIP downloads

A remote TLS connection can occasionally close early and report `UNEXPECTED_EOF_WHILE_READING`. Aperture retries the official checkpoint download a bounded number of times with increasing delays. When all attempts fail, retry later or select an already-downloaded local checkpoint file. The BioCLIP model and analysis workflow are otherwise unchanged.
