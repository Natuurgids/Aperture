"""Composition helpers for optional subsystem databases."""
from __future__ import annotations

from natureai_next import __version__
from natureai_next.bootstrap.paths import ApplicationPaths
from natureai_next.infrastructure.database.settings import SqliteSettings
from natureai_next.infrastructure.subsystems.maps import maps_descriptor
from natureai_next.infrastructure.subsystems.taxonomy import taxonomy_descriptor
from natureai_next.infrastructure.subsystems.registry import SubsystemDatabaseRegistry


def build_subsystem_registry(
    paths: ApplicationPaths,
    settings: SqliteSettings | None = None,
) -> SubsystemDatabaseRegistry:
    return SubsystemDatabaseRegistry(
        (
            maps_descriptor(paths.subsystem_databases_dir / "maps-offline.sqlite3"),
            taxonomy_descriptor(paths.subsystem_databases_dir / "taxonomy-reference.sqlite3"),
        ),
        __version__,
        settings,
    )
