"""Bounded cleanup for durable workflow history and temporary artifacts."""
from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path

from natureai_next.domain.workflows import RetentionPolicy
from natureai_next.infrastructure.database.connection import SqliteConnectionFactory

_DAY_US = 86_400_000_000


@dataclass(frozen=True, slots=True)
class CleanupReport:
    jobs_removed: int = 0
    events_removed: int = 0
    temporary_files_removed: int = 0
    temporary_bytes_removed: int = 0
    empty_directories_removed: int = 0


@dataclass(frozen=True, slots=True)
class CleanupPreview:
    jobs_eligible: int = 0
    events_eligible: int = 0
    temporary_files_eligible: int = 0
    temporary_bytes_eligible: int = 0
    orphan_temporary_files: tuple[Path, ...] = ()


class WorkflowCleanupService:
    def __init__(self, factory: SqliteConnectionFactory, temporary_roots: tuple[Path, ...] = ()) -> None:
        self.factory = factory
        self.temporary_roots = temporary_roots

    def preview(self, *, now_us: int, policy: RetentionPolicy) -> CleanupPreview:
        connection = self.factory.connect()
        try:
            job_ids = self._job_ids(connection, now_us, policy)
            event_ids = self._event_ids(connection, now_us, policy)
        finally:
            connection.close()
        file_paths, byte_count = self._eligible_files(now_us, policy)
        return CleanupPreview(len(job_ids), len(event_ids), len(file_paths), byte_count, file_paths)

    def cleanup(self, *, now_us: int, policy: RetentionPolicy, dry_run: bool = False) -> CleanupReport:
        connection = self.factory.connect()
        try:
            connection.execute("BEGIN IMMEDIATE")
            job_ids = self._job_ids(connection, now_us, policy)
            event_ids = self._event_ids(connection, now_us, policy)
            if not dry_run:
                if job_ids:
                    placeholders = ",".join("?" for _ in job_ids)
                    connection.execute(f"DELETE FROM jobs WHERE id IN ({placeholders})", job_ids)
                if event_ids:
                    placeholders = ",".join("?" for _ in event_ids)
                    connection.execute(f"DELETE FROM event_outbox WHERE id IN ({placeholders})", event_ids)
                connection.commit()
            else:
                connection.rollback()
        except Exception:
            connection.rollback()
            raise
        finally:
            connection.close()

        file_count, byte_count, directories = self._cleanup_files(now_us, policy, dry_run)
        return CleanupReport(len(job_ids), len(event_ids), file_count, byte_count, directories)

    @staticmethod
    def _job_ids(connection, now_us: int, policy: RetentionPolicy) -> tuple[int, ...]:
        thresholds = {
            "succeeded": now_us - policy.succeeded_job_days * _DAY_US,
            "failed": now_us - policy.failed_job_days * _DAY_US,
            "cancelled": now_us - policy.cancelled_job_days * _DAY_US,
        }
        rows = connection.execute(
            """SELECT id,job_type,state,completed_at_us,
                      ROW_NUMBER() OVER (PARTITION BY job_type ORDER BY completed_at_us DESC,id DESC) AS recency
               FROM jobs
               WHERE state IN ('succeeded','failed','cancelled') AND completed_at_us IS NOT NULL"""
        ).fetchall()
        return tuple(
            int(row["id"])
            for row in rows
            if row["recency"] > policy.keep_latest_jobs_per_type
            and int(row["completed_at_us"]) < thresholds[str(row["state"])]
        )

    @staticmethod
    def _event_ids(connection, now_us: int, policy: RetentionPolicy) -> tuple[int, ...]:
        threshold = now_us - policy.dispatched_event_days * _DAY_US
        rows = connection.execute(
            "SELECT id FROM event_outbox WHERE dispatch_state='dispatched' AND created_at_us<?",
            (threshold,),
        ).fetchall()
        return tuple(int(row["id"]) for row in rows)

    def _eligible_files(self, now_us: int, policy: RetentionPolicy) -> tuple[tuple[Path, ...], int]:
        threshold_seconds = (now_us - policy.temporary_file_days * _DAY_US) / 1_000_000
        paths: list[Path] = []
        total = 0
        for root in self.temporary_roots:
            if not root.exists():
                continue
            for path in root.rglob("*"):
                if path.is_symlink() or not path.is_file():
                    continue
                try:
                    stat = path.stat()
                except OSError:
                    continue
                if stat.st_mtime >= threshold_seconds:
                    continue
                paths.append(path)
                total += stat.st_size
        return tuple(paths), total

    def _cleanup_files(self, now_us: int, policy: RetentionPolicy, dry_run: bool) -> tuple[int, int, int]:
        paths, total = self._eligible_files(now_us, policy)
        if dry_run:
            return len(paths), total, 0
        removed = bytes_removed = 0
        touched_roots: set[Path] = set()
        for path in paths:
            try:
                size = path.stat().st_size
                path.unlink()
            except OSError:
                continue
            removed += 1
            bytes_removed += size
            touched_roots.add(path.parent)
        directories_removed = 0
        for root in self.temporary_roots:
            if not root.exists():
                continue
            directories = sorted((p for p in root.rglob("*") if p.is_dir()), key=lambda p: len(p.parts), reverse=True)
            for directory in directories:
                try:
                    directory.rmdir()
                except OSError:
                    continue
                directories_removed += 1
        return removed, bytes_removed, directories_removed
