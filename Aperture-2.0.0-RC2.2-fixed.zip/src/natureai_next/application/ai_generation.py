"""User-controlled local BioCLIP suggestion generation."""
from __future__ import annotations

import json
from collections.abc import Callable, Sequence
from dataclasses import dataclass
from pathlib import Path

from natureai_next import __version__
from natureai_next.application.ai_review import CosineCandidateRanker, SuggestionService
from natureai_next.application.asset_analysis import AssetAnalysisService, TaxonCandidateInput
from natureai_next.infrastructure.ai.openclip_provider import OpenClipExecutionProvider
from natureai_next.infrastructure.ai.preprocessing import BioClipImagePreprocessor
from natureai_next.infrastructure.database.ai import SqliteAIRepository
from natureai_next.infrastructure.database.ai_generation import SqliteTaxonomyEmbeddingStore
from natureai_next.infrastructure.database.connection import SqliteConnectionFactory
from natureai_next.domain.ai import AnalysisStatus


@dataclass(frozen=True, slots=True)
class ActiveAIContext:
    model_variant_id: int
    model_identity: str
    model_version: str
    variant_identity: str
    precision: str
    preprocessing_identity: str
    input_size: int
    artifact_path: Path
    prompt_set_public_id: str
    execution_provider: str
    device: str


@dataclass(frozen=True, slots=True)
class SuggestionGenerationResult:
    requested: int
    completed_assets: int
    failed: tuple[tuple[str, str], ...]
    suggestions_created: int


class SqliteSuggestionGenerationSource:
    """Reads generation prerequisites and immutable asset source paths."""

    def __init__(self, factory: SqliteConnectionFactory) -> None:
        self._factory = factory

    def active_context(self) -> ActiveAIContext:
        connection = self._factory.connect(read_only=True)
        try:
            row = connection.execute(
                """SELECT v.id,p.model_identity,p.semantic_version,v.variant_identity,
                          v.precision,v.preprocessing_identity,v.input_size,
                          p.install_path_token,v.artifact_relative_path,ps.public_id,
                          v.device_requirements_json
                   FROM model_packages p
                   JOIN model_variants v ON v.package_id=p.id
                   LEFT JOIN prompt_sets ps ON ps.model_family=p.model_family AND ps.active=1
                   WHERE p.active=1 AND v.active=1
                   ORDER BY COALESCE(p.activated_at_us,p.installed_at_us) DESC,v.id DESC
                   LIMIT 1"""
            ).fetchone()
            if row is None:
                raise RuntimeError("No active local BioCLIP model package is installed.")
            if row[9] is None:
                raise RuntimeError("No active prompt set is installed for the active model.")
            input_size = int(row[6] or 0)
            if input_size <= 0:
                raise RuntimeError("The active model variant has no valid input size.")
            relative = str(row[8] or "").strip()
            if not relative:
                raise RuntimeError("The active model variant has no artifact path.")
            artifact = Path(str(row[7])) / relative
            if not artifact.is_file():
                raise RuntimeError(f"The active model artifact is missing: {artifact}")
            requirements = json.loads(str(row[10] or "{}"))
            providers = tuple(str(value).casefold() for value in requirements.get("providers", ()))
            device = "cuda" if any("cuda" in value for value in providers) else "cpu"
            return ActiveAIContext(
                model_variant_id=int(row[0]),
                model_identity=str(row[1]),
                model_version=str(row[2]),
                variant_identity=str(row[3]),
                precision=str(row[4]),
                preprocessing_identity=str(row[5]),
                input_size=input_size,
                artifact_path=artifact,
                prompt_set_public_id=str(row[9]),
                execution_provider="openclip-local-v1",
                device=device,
            )
        finally:
            connection.close()

    def asset_paths(self, public_ids: Sequence[str]) -> tuple[tuple[str, Path], ...]:
        ordered = tuple(dict.fromkeys(str(value) for value in public_ids if str(value)))
        if not ordered:
            return ()
        placeholders = ",".join("?" for _ in ordered)
        connection = self._factory.connect(read_only=True)
        try:
            rows = connection.execute(
                f"""SELECT a.public_id,f.normalized_path
                    FROM assets a
                    JOIN file_instances f ON f.id=a.primary_file_instance_id
                    WHERE a.lifecycle_state='active' AND a.public_id IN ({placeholders})""",
                ordered,
            ).fetchall()
        finally:
            connection.close()
        by_id = {str(row[0]): Path(str(row[1])) for row in rows}
        return tuple((public_id, by_id[public_id]) for public_id in ordered if public_id in by_id)


class LocalSuggestionGenerationService:
    """Runs local model inference and persists auditable ranked evidence."""

    def __init__(
        self,
        *,
        source: SqliteSuggestionGenerationSource,
        ai_repository: SqliteAIRepository,
        taxonomy_embeddings: SqliteTaxonomyEmbeddingStore,
        suggestions: SuggestionService,
        id_factory: Callable[[], str],
        now_us: Callable[[], int],
        provider: OpenClipExecutionProvider | None = None,
        analyses: AssetAnalysisService | None = None,
    ) -> None:
        self._source = source
        self._ai_repository = ai_repository
        self._taxonomy_embeddings = taxonomy_embeddings
        self._suggestions = suggestions
        self._id_factory = id_factory
        self._now_us = now_us
        self._provider = provider or OpenClipExecutionProvider()
        self._analyses = analyses
        self._ranker = CosineCandidateRanker()

    def generate_selected(
        self,
        asset_public_ids: Sequence[str],
        *,
        limit: int = 10,
        cancellation_check: Callable[[], None] = lambda: None,
        progress: Callable[[int, int, str], None] = lambda _current, _total, _message: None,
    ) -> SuggestionGenerationResult:
        public_ids = tuple(dict.fromkeys(str(value) for value in asset_public_ids if str(value)))
        if not public_ids:
            raise ValueError("Select at least one Library photograph before generating suggestions.")
        if limit < 1 or limit > 50:
            raise ValueError("Suggestion limit must be between 1 and 50.")
        context = self._source.active_context()
        candidates = tuple(
            item for item in self._taxonomy_embeddings.candidates(
                model_variant_id=context.model_variant_id,
                preprocessing_identity=context.preprocessing_identity,
            )
            if not item[0].startswith("group:")
        )
        if not candidates:
            raise RuntimeError(
                "No taxonomy text embeddings exist for the active model and prompt set. "
                "Build taxonomy embeddings before generating suggestions."
            )
        assets = self._source.asset_paths(public_ids)
        missing = tuple(value for value in public_ids if value not in {item[0] for item in assets})
        failures: list[tuple[str, str]] = [(value, "Asset has no readable primary file.") for value in missing]
        run_id = self._ai_repository.begin_inference_run(
            public_id=self._id_factory(),
            model_variant_id=context.model_variant_id,
            execution_provider=f"{context.execution_provider}:{context.device}",
            precision=context.precision,
            application_version=__version__,
            requested_item_count=len(public_ids),
            parameters_json=json.dumps(
                {"scope": "selected", "limit": limit, "device": context.device},
                sort_keys=True,
            ),
        )
        completed = 0
        created = 0
        model: object | None = None
        try:
            model = self._provider.load(
                context.artifact_path, device=context.device, precision=context.precision
            )
            preprocessor = BioClipImagePreprocessor(
                context.input_size, context.preprocessing_identity
            )
            total = len(assets)
            progress(0, total, "Loading BioCLIP model")
            for index, (asset_public_id, path) in enumerate(assets, start=1):
                cancellation_check()
                analysis_public_id: str | None = None
                try:
                    if not path.is_file():
                        raise FileNotFoundError(path)
                    configuration = {
                        "limit": limit,
                        "variant_identity": context.variant_identity,
                        "preprocessing_identity": context.preprocessing_identity,
                        "execution_provider": context.execution_provider,
                        "device": context.device,
                        "precision": context.precision,
                        "prompt_set_public_id": context.prompt_set_public_id,
                    }
                    if self._analyses is not None:
                        analysis_public_id = self._analyses.start(
                            asset_public_id=asset_public_id,
                            engine_id="ai.bioclip",
                            engine_family="bioclip",
                            analysis_kind="taxon_classification",
                            model_name=context.model_identity,
                            model_version=context.model_version,
                            configuration=configuration,
                        )
                    image = preprocessor.prepare(path)
                    vectors = self._provider.embed_images(model, (image,))
                    if len(vectors) != 1:
                        raise RuntimeError("The model returned an unexpected image-vector count.")
                    ranked = self._ranker.rank(
                        vectors[0], candidates, region_code=None, limit=limit
                    )
                    if not ranked:
                        raise RuntimeError("No compatible taxonomy candidates were produced.")
                    created_ids = self._suggestions.create(
                        asset_public_id=asset_public_id,
                        inference_run_id=run_id,
                        suggestions=ranked,
                        prompt_set_id=context.prompt_set_public_id,
                        analysis_public_id=analysis_public_id,
                        provenance={
                            "application_version": __version__,
                            "model_identity": context.model_identity,
                            "model_version": context.model_version,
                            "variant_identity": context.variant_identity,
                            "preprocessing_identity": context.preprocessing_identity,
                            "execution_provider": context.execution_provider,
                            "device": context.device,
                            "precision": context.precision,
                            "analysis_public_id": analysis_public_id,
                        },
                        geographic_context={},
                        now_us=self._now_us(),
                        id_factory=self._id_factory,
                    )
                    if self._analyses is not None and analysis_public_id is not None:
                        self._analyses.complete(
                            analysis_public_id,
                            summary={
                                "candidate_count": len(ranked),
                                "suggestion_count": len(created_ids),
                                "top_label": ranked[0].label,
                                "top_score": ranked[0].calibrated_score,
                            },
                            candidates=tuple(
                                TaxonCandidateInput(
                                    label=item.label,
                                    rank=item.rank,
                                    raw_score=item.raw_score,
                                    calibrated_score=item.calibrated_score,
                                    confidence_band=item.confidence_band,
                                    local_taxon_public_id=item.taxon_public_id,
                                    taxonomic_level=item.taxonomic_level,
                                    provenance={"suggestion_public_id": suggestion_id},
                                )
                                for item, suggestion_id in zip(ranked, created_ids, strict=True)
                            ),
                        )
                    created += len(created_ids)
                    completed += 1
                except Exception as exc:
                    if self._analyses is not None and analysis_public_id is not None:
                        try:
                            self._analyses.complete(
                                analysis_public_id,
                                status=AnalysisStatus.FAILED,
                                summary={"error": str(exc)},
                            )
                        except Exception:
                            pass
                    failures.append((asset_public_id, str(exc)))
                progress(index, total, f"Processed {index} of {total}")
            self._ai_repository.finish_inference_run(
                run_id,
                completed=completed,
                failed=len(failures),
                retries=0,
                final_batch_size=1,
                error_text=None,
            )
            return SuggestionGenerationResult(len(public_ids), completed, tuple(failures), created)
        except Exception as exc:
            self._ai_repository.finish_inference_run(
                run_id,
                completed=completed,
                failed=max(1, len(public_ids) - completed),
                retries=0,
                final_batch_size=1,
                error_text=str(exc),
            )
            raise
        finally:
            if model is not None:
                self._provider.unload(model)
