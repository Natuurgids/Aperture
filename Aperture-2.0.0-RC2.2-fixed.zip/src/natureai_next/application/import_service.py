"""Production import planning and execution application service."""
from __future__ import annotations
import hashlib
import json
import os
from dataclasses import asdict
from pathlib import Path
from typing import Iterable
from natureai_next.domain.catalog import Asset, AssetLifecycle, AvailabilityState, FileInstance, FileRole, MediaType, StorageMode
from natureai_next.domain.importing import (DuplicatePolicy, Fingerprint, ImportDecision, ImportItemResult, ImportPlan, ImportPlanItem, ImportStoragePolicy, ImportSummary, SourceDisposition, SourceFile)
from natureai_next.ports.clock import Clock
from natureai_next.ports.identity import UuidGenerator
from natureai_next.ports.importing import CancelCheck, FileFingerprinter, ManagedFileStore, SourceScanner
from natureai_next.ports.media import ImageDecoder, MetadataReader
from natureai_next.infrastructure.database.unit_of_work import SqliteUnitOfWork
from natureai_next import __version__

class ImportService:
    def __init__(self, *, uow_factory, scanner: SourceScanner, fingerprinter: FileFingerprinter, managed_store: ManagedFileStore, decoder: ImageDecoder, metadata_reader: MetadataReader, clock: Clock, ids: UuidGenerator) -> None:
        self.uow_factory=uow_factory; self.scanner=scanner; self.fingerprinter=fingerprinter; self.managed_store=managed_store; self.decoder=decoder; self.metadata_reader=metadata_reader; self.clock=clock; self.ids=ids

    def plan(self, roots: Iterable[Path], *, storage_policy: ImportStoragePolicy, duplicate_policy: DuplicatePolicy, recursive: bool = True, source_disposition: SourceDisposition = SourceDisposition.KEEP, cancel: CancelCheck | None = None) -> ImportPlan:
        if storage_policy is ImportStoragePolicy.HYBRID and source_disposition is SourceDisposition.DELETE_AFTER_VERIFIED_COPY:
            raise ValueError("hybrid imports cannot delete their referenced source")
        root_paths = tuple(Path(root).expanduser().resolve() for root in roots)
        items: list[ImportPlanItem] = []
        for source in self.scanner.scan(root_paths, recursive=recursive, cancel=cancel):
            if cancel:
                cancel()
            item_key = hashlib.sha256(f"{source.path}\0{source.size}\0{source.modified_at_us}".encode()).hexdigest()
            fingerprint = Fingerprint("0" * 64, source.size, "unavailable")
            try:
                unsupported = _obvious_unsupported_format(source.path)
                if unsupported is not None:
                    raise UnsupportedImportFormatError(unsupported)
                fingerprint = self.fingerprinter.fingerprint(source.path, cancel=cancel)
                self.decoder.probe(source.path)
            except Exception as exc:
                code = _error_code(exc)
                items.append(
                    ImportPlanItem(
                        item_key, source, fingerprint, storage_policy, source_disposition,
                        ImportDecision.REJECT_SOURCE, None, code, str(exc)[:1000],
                    )
                )
                continue
            existing = self._find_existing(fingerprint.sha256)
            decision = ImportDecision.IMPORT_NEW_ASSET
            existing_asset_id = None
            if existing:
                existing_asset_id = existing[0]["asset_id"]
                normalized = _normalized_path(source.path)
                same_path = any(row["path_key"] == normalized[1] for row in existing)
                decision = ImportDecision.SKIP_EXACT_DUPLICATE if duplicate_policy is DuplicatePolicy.SKIP or same_path else ImportDecision.ATTACH_TO_EXISTING_ASSET
            items.append(ImportPlanItem(item_key, source, fingerprint, storage_policy, source_disposition, decision, existing_asset_id))
        source_root = _common_source_root(root_paths)
        volume_label, volume_serial = _source_volume_identity(source_root)
        plan = ImportPlan(str(self.ids.new_uuid()), _now_us(self.clock), duplicate_policy, tuple(items), str(source_root) if source_root else None, volume_label, volume_serial, __version__)
        self._persist_plan(plan)
        return plan

    def load_plan(self, public_id: str) -> ImportPlan:
        with self.uow_factory() as uow:
            assert uow.connection is not None
            header=uow.connection.execute("SELECT id,created_at_us,duplicate_policy,source_root,source_volume_label,source_volume_serial,application_version FROM import_plans WHERE public_id=?",(public_id,)).fetchone()
            if header is None: raise KeyError(public_id)
            rows=tuple(uow.connection.execute("SELECT * FROM import_plan_items WHERE plan_id=? ORDER BY id",(header["id"],)))
        items=tuple(ImportPlanItem(row["item_key"], SourceFile(Path(row["source_path"]),row["source_size"],row["source_modified_at_us"]), Fingerprint(row["sha256"],row["source_size"],row["fast_fingerprint"]), ImportStoragePolicy(row["storage_policy"]), SourceDisposition(row["source_disposition"]), ImportDecision(row["decision"]), row["existing_asset_id"], row["error_code"], _result_error_detail(row["result_json"])) for row in rows)
        return ImportPlan(public_id,header["created_at_us"],DuplicatePolicy(header["duplicate_policy"]),items,header["source_root"],header["source_volume_label"],header["source_volume_serial"],header["application_version"])

    def execute(self, plan: ImportPlan, *, cancel: CancelCheck | None = None) -> ImportSummary:
        results: list[ImportItemResult] = []
        self._set_plan_state(plan.public_id, "running")
        for item in plan.items:
            try:
                if cancel: cancel()
                if item.decision is ImportDecision.REJECT_SOURCE:
                    self._finish_item(plan.public_id,item,"failed",None,None,item.planning_error_code)
                    results.append(ImportItemResult(item.item_key,"failed",error_code=item.planning_error_code,source_path=str(item.source.path)))
                    continue
                if item.decision is ImportDecision.SKIP_EXACT_DUPLICATE:
                    self._finish_item(plan.public_id,item,"skipped",None,None,None)
                    results.append(ImportItemResult(item.item_key,"skipped",source_path=str(item.source.path))); continue
                result = self._execute_item(plan.public_id, item, cancel)
                results.append(result)
            except Exception as exc:
                code = type(exc).__name__.lower()
                self._finish_item(plan.public_id,item,"failed",None,None,code)
                results.append(ImportItemResult(item.item_key,"failed",error_code=code,source_path=str(item.source.path)))
        summary = ImportSummary(len(results),sum(r.state=="imported" for r in results),sum(r.state=="attached" for r in results),sum(r.state=="skipped" for r in results),sum(r.state=="failed" for r in results),tuple(results))
        state = "completed_with_errors" if summary.failed else "completed"
        self._complete_plan(plan.public_id,state,summary)
        return summary

    def _execute_item(self, plan_id: str, item: ImportPlanItem, cancel: CancelCheck | None) -> ImportItemResult:
        current = self.fingerprinter.fingerprint(item.source.path,cancel=cancel)
        if current.sha256 != item.fingerprint.sha256 or current.size != item.fingerprint.size:
            raise OSError("source changed after import planning")
        probe = self.decoder.probe(item.source.path)
        metadata = self.metadata_reader.read(item.source.path)
        path = item.source.path
        mode = StorageMode.REFERENCED
        if item.storage_policy in {ImportStoragePolicy.MANAGED, ImportStoragePolicy.HYBRID}:
            path = self.managed_store.place_verified(item.source.path,item.fingerprint.sha256,cancel=cancel)
            mode = StorageMode.MANAGED
        normalized,path_key = _normalized_path(path)
        now = _now_us(self.clock)
        with self.uow_factory() as uow:
            assert uow.connection is not None
            c=uow.connection
            row=c.execute("SELECT id,state FROM import_plan_items WHERE plan_id=(SELECT id FROM import_plans WHERE public_id=?) AND item_key=?",(plan_id,item.item_key)).fetchone()
            if row is None: raise RuntimeError("import plan item is not persisted")
            if row["state"] in {"succeeded","skipped"}:
                saved=c.execute("SELECT a.public_id asset_public_id,f.public_id file_public_id FROM import_plan_items i LEFT JOIN assets a ON a.id=i.asset_id LEFT JOIN file_instances f ON f.id=i.file_instance_id WHERE i.id=?",(row["id"],)).fetchone()
                return ImportItemResult(item.item_key,"skipped",saved["asset_public_id"],saved["file_public_id"],source_path=str(item.source.path))
            c.execute("UPDATE import_plan_items SET state='running',modified_at_us=? WHERE id=?",(now,row["id"]))
            asset_id=item.existing_asset_id
            result_state="attached"
            if item.decision is ImportDecision.IMPORT_NEW_ASSET:
                asset=uow.assets.add(Asset(str(self.ids.new_uuid()),MediaType.IMAGE,AssetLifecycle.ACTIVE,now,now))
                assert asset.id is not None; asset_id=asset.id; result_state="imported"
            if asset_id is None: raise RuntimeError("missing target asset")
            duplicate_path=c.execute("SELECT public_id,id FROM file_instances WHERE path_key=? AND availability_state!='missing'",(path_key,)).fetchone()
            if duplicate_path:
                c.execute("UPDATE import_plan_items SET state='skipped',file_instance_id=?,asset_id=?,modified_at_us=? WHERE id=?",(duplicate_path["id"],asset_id,now,row["id"]))
                uow.commit(); return ImportItemResult(item.item_key,"skipped",None,duplicate_path["public_id"],source_path=str(item.source.path))
            file=uow.files.add(FileInstance(str(self.ids.new_uuid()),asset_id,mode,FileRole.ORIGINAL,normalized,path_key,item.fingerprint.size,item.source.modified_at_us,item.fingerprint.sha256,AvailabilityState.AVAILABLE,probe.mime_type,probe.format_name,now,now))
            assert file.id is not None
            c.execute("UPDATE file_instances SET fast_fingerprint=?,import_source_path=?,verified_at_us=? WHERE id=?",(item.fingerprint.fast_fingerprint,str(item.source.path),now,file.id))
            if item.storage_policy is ImportStoragePolicy.HYBRID:
                source_normalized,source_key=_normalized_path(item.source.path)
                alternate=uow.files.add(FileInstance(str(self.ids.new_uuid()),asset_id,StorageMode.REFERENCED,FileRole.ALTERNATE,source_normalized,source_key,item.fingerprint.size,item.source.modified_at_us,item.fingerprint.sha256,AvailabilityState.AVAILABLE,probe.mime_type,probe.format_name,now,now))
                assert alternate.id is not None
                c.execute("UPDATE file_instances SET fast_fingerprint=?,import_source_path=?,verified_at_us=? WHERE id=?",(item.fingerprint.fast_fingerprint,str(item.source.path),now,alternate.id))
            payload=json.dumps(metadata.raw,sort_keys=True,default=str,separators=(",",":" )).encode()
            checksum=hashlib.sha256(payload).hexdigest()
            snap=c.execute("INSERT INTO metadata_snapshots(public_id,file_instance_id,encoding,payload,payload_checksum,created_at_us) VALUES(?,?,?,?,?,?)",(str(self.ids.new_uuid()),file.id,"json-utf8",payload,checksum,now)).lastrowid
            c.execute("INSERT OR REPLACE INTO image_properties(asset_id,file_instance_id,pixel_width,pixel_height,orientation,has_alpha,camera_make,camera_model,lens,metadata_snapshot_id) VALUES(?,?,?,?,?,?,?,?,?,?)",(asset_id,file.id,probe.pixel_width,probe.pixel_height,probe.orientation,0,_text(metadata.normalized.get("camera_make")),_text(metadata.normalized.get("camera_model")),_text(metadata.normalized.get("lens")),snap))
            c.execute("UPDATE assets SET primary_file_instance_id=COALESCE(primary_file_instance_id,?),capture_local_text=COALESCE(capture_local_text,?),modified_at_us=? WHERE id=?",(file.id,_text(metadata.normalized.get("capture_time_text")),now,asset_id))
            latitude, longitude, altitude, location_source = _metadata_location(metadata.normalized)
            if latitude is not None and longitude is not None:
                location_id = c.execute(
                    "INSERT INTO locations(public_id,latitude,longitude,altitude_m,source,confidence,created_at_us) VALUES(?,?,?,?,?,?,?)",
                    (str(self.ids.new_uuid()), latitude, longitude, altitude, location_source or "embedded_metadata", 1.0, now),
                ).lastrowid
                c.execute(
                    "INSERT OR IGNORE INTO asset_locations(asset_id,location_id,role,precedence) VALUES(?,?,'capture',100)",
                    (asset_id, location_id),
                )
            metadata_state = "succeeded" if metadata.raw else "not_available"
            c.execute("UPDATE import_plan_items SET state='succeeded',asset_id=?,file_instance_id=?,result_json=?,modified_at_us=?,capture_latitude=?,capture_longitude=?,capture_altitude_m=?,location_source=?,metadata_extraction_state=? WHERE id=?",(asset_id,file.id,json.dumps({"state":result_state}),now,latitude,longitude,altitude,location_source,metadata_state,row["id"]))
            asset_public=c.execute("SELECT public_id FROM assets WHERE id=?",(asset_id,)).fetchone()[0]
            uow.commit()
        if item.source_disposition is SourceDisposition.DELETE_AFTER_VERIFIED_COPY and mode is StorageMode.MANAGED:
            item.source.path.unlink(missing_ok=True)
        return ImportItemResult(item.item_key,result_state,asset_public,file.public_id,source_path=str(item.source.path))

    def _find_existing(self, sha256: str):
        with self.uow_factory() as uow:
            assert uow.connection is not None
            rows=tuple(uow.connection.execute("SELECT id,asset_id,path_key FROM file_instances WHERE sha256=? ORDER BY id",(sha256,)))
        return rows

    def _persist_plan(self, plan: ImportPlan) -> None:
        with self.uow_factory() as uow:
            assert uow.connection is not None; c=uow.connection
            plan_id=c.execute("INSERT INTO import_plans(public_id,schema_version,duplicate_policy,state,created_at_us,source_root,source_volume_label,source_volume_serial,application_version) VALUES(?,2,?,'planned',?,?,?,?,?)",(plan.public_id,plan.duplicate_policy,plan.created_at_us,plan.source_root,plan.source_volume_label,plan.source_volume_serial,plan.application_version)).lastrowid
            c.executemany("INSERT INTO import_plan_items(plan_id,item_key,source_path,source_size,source_modified_at_us,sha256,fast_fingerprint,storage_policy,source_disposition,decision,existing_asset_id,error_code,result_json,modified_at_us,original_filename,original_relative_path) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",[(plan_id,i.item_key,str(i.source.path),i.source.size,i.source.modified_at_us,i.fingerprint.sha256,i.fingerprint.fast_fingerprint,i.storage_policy,i.source_disposition,i.decision,i.existing_asset_id,i.planning_error_code,_planning_result_json(i),plan.created_at_us,i.source.path.name,_relative_source_path(i.source.path,plan.source_root)) for i in plan.items])
            uow.commit()

    def _set_plan_state(self, public_id: str, state: str) -> None:
        with self.uow_factory() as uow:
            assert uow.connection is not None; uow.connection.execute("UPDATE import_plans SET state=? WHERE public_id=? AND state IN ('planned','running')",(state,public_id)); uow.commit()

    def _finish_item(self, plan_id: str, item: ImportPlanItem, state: str, asset_id: int|None, file_id: int|None, error: str|None) -> None:
        with self.uow_factory() as uow:
            assert uow.connection is not None; uow.connection.execute("UPDATE import_plan_items SET state=?,asset_id=?,file_instance_id=?,error_code=?,modified_at_us=? WHERE plan_id=(SELECT id FROM import_plans WHERE public_id=?) AND item_key=?",(state,asset_id,file_id,error,_now_us(self.clock),plan_id,item.item_key)); uow.commit()

    def _complete_plan(self, public_id: str, state: str, summary: ImportSummary) -> None:
        data={"total":summary.total,"imported":summary.imported,"attached":summary.attached,"skipped":summary.skipped,"failed":summary.failed}
        with self.uow_factory() as uow:
            assert uow.connection is not None; uow.connection.execute("UPDATE import_plans SET state=?,completed_at_us=?,summary_json=? WHERE public_id=?",(state,_now_us(self.clock),json.dumps(data,sort_keys=True),public_id)); uow.commit()

def _now_us(clock: Clock) -> int: return int(clock.now_utc().timestamp()*1_000_000)
def _text(value: object) -> str|None: return None if value is None else str(value)
def _normalized_path(path: Path) -> tuple[str,str]:
    normalized=str(path.expanduser().resolve())
    return normalized,os.path.normcase(normalized).casefold()


def _error_code(exc: Exception) -> str:
    if isinstance(exc, UnsupportedImportFormatError):
        return "unsupported_format"
    name = type(exc).__name__
    chars: list[str] = []
    for index, char in enumerate(name):
        if char.isupper() and index:
            chars.append("_")
        chars.append(char.lower())
    return "".join(chars)

def _planning_result_json(item: ImportPlanItem) -> str | None:
    if item.planning_error_detail is None:
        return None
    return json.dumps({"planning_error_detail": item.planning_error_detail}, sort_keys=True)

def _result_error_detail(value: str | None) -> str | None:
    if not value:
        return None
    try:
        data = json.loads(value)
    except (TypeError, ValueError):
        return None
    detail = data.get("planning_error_detail") if isinstance(data, dict) else None
    return detail if isinstance(detail, str) else None


class UnsupportedImportFormatError(ValueError):
    """A recognized non-image container was included in an import source."""


def _obvious_unsupported_format(path: Path) -> str | None:
    try:
        with path.open("rb") as stream:
            header = stream.read(8)
    except OSError:
        return None
    if header.startswith((b"PK\x03\x04", b"PK\x05\x06", b"PK\x07\x08")):
        return "ZIP archives are not importable images"
    if header.startswith(b"%PDF-"):
        return "PDF documents are not importable images"
    return None


def _common_source_root(roots: tuple[Path, ...]) -> Path | None:
    if not roots:
        return None
    try:
        return Path(os.path.commonpath([str(path) for path in roots]))
    except ValueError:
        return None

def _source_volume_identity(root: Path | None) -> tuple[str | None, str | None]:
    if root is None:
        return None, None
    anchor = root.anchor or None
    try:
        serial = str(root.stat().st_dev)
    except OSError:
        serial = None
    return anchor, serial

def _relative_source_path(path: Path, source_root: str | None) -> str | None:
    if not source_root:
        return None
    try:
        return str(path.relative_to(Path(source_root)))
    except ValueError:
        return None

def _metadata_location(normalized: object) -> tuple[float | None, float | None, float | None, str | None]:
    if not hasattr(normalized, "get"):
        return None, None, None, None
    latitude = _float_or_none(normalized.get("capture_latitude"))
    longitude = _float_or_none(normalized.get("capture_longitude"))
    altitude = _float_or_none(normalized.get("capture_altitude_m"))
    return latitude, longitude, altitude, "embedded_metadata" if latitude is not None and longitude is not None else None

def _float_or_none(value: object) -> float | None:
    try:
        return None if value is None else float(value)
    except (TypeError, ValueError):
        return None
