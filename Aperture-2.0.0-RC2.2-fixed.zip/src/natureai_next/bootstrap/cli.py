"""Stable desktop launcher command-line boundary."""

from __future__ import annotations

import argparse
import logging
import time

from natureai_next.bootstrap.startup_timing import StartupTimeline
from pathlib import Path
from typing import Sequence

from natureai_next.bootstrap.container import build_foundation_container
from natureai_next.shared.errors import NatureAIError
from natureai_next.infrastructure.filesystem.library_lock import LibraryLockedError


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="natureai-next")
    parser.add_argument("--library", type=Path, help="Library to open")
    parser.add_argument("--config-root", type=Path, help="Configuration root override")
    parser.add_argument("--safe-mode", action="store_true", help="Disable third-party plugins")
    parser.add_argument("--diagnostics", action="store_true", help="Start in diagnostics mode")
    parser.add_argument("--no-update-check", action="store_true", help="Disable update checks for this session")
    parser.add_argument("--log-level", choices=("DEBUG", "INFO", "WARNING", "ERROR"))
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    started_at = time.perf_counter()
    startup = StartupTimeline(started_at=started_at)
    startup.mark("process-started")
    args = build_parser().parse_args(argv)
    overrides: dict[str, object] = {}
    if args.log_level:
        overrides["application"] = {"log_level": args.log_level}
    if args.no_update_check:
        application = dict(overrides.get("application", {}))
        application["update_check_policy"] = "disabled"
        overrides["application"] = application
    try:
        container = build_foundation_container(config_root=args.config_root, session_overrides=overrides)
    except NatureAIError as exc:
        print(exc.descriptor.summary)
        return 2
    startup.mark("foundation-ready")
    logging.getLogger("natureai_next.bootstrap").info(
        "Foundation initialized",
        extra={"context": {"safe_mode": args.safe_mode, "diagnostics": args.diagnostics, "elapsed_ms": round((time.perf_counter() - started_at) * 1000, 1)}},
    )
    if args.library is None:
        print(f"NatureAI Next ready at {container.paths.local_root}; provide --library to open the desktop")
        return 0
    from natureai_next.application.library_service import LibraryService
    service = LibraryService(container.clock, container.uuid_generator)
    try:
        opened_context = service.open(args.library)
    except LibraryLockedError as exc:
        owner = exc.owner
        detail = "Aperture is already open with this library."
        if owner is not None:
            detail += f"\n\nProcess ID: {owner.pid}\nComputer: {owner.host}"
        print(detail)
        return 3
    startup.mark("library-opened")
    logging.getLogger("natureai_next.bootstrap").info("Library opened", extra={"context": {"elapsed_ms": round((time.perf_counter() - started_at) * 1000, 1)}})
    with opened_context as opened:
        from natureai_next.application.backup import LibraryBackupService
        from natureai_next.application.health import LibraryHealthService
        from natureai_next.application.catalog_browsing import CatalogEditService, CatalogQueryService
        from natureai_next.application.catalog_maintenance import CatalogMaintenanceService
        from natureai_next.application.ai_generation import LocalSuggestionGenerationService, SqliteSuggestionGenerationSource
        from natureai_next.application.asset_analysis import AssetAnalysisService
        from natureai_next.application.ai_resources import LocalAIResourceService
        from natureai_next.application.ai_review import SuggestionService
        from natureai_next.application.import_service import ImportService
        from natureai_next.application.search import LibraryViewsService, QuickSearchService
        from natureai_next.application.regional import RegionalProfileService
        from natureai_next.application.regional_acquisition import RegionalKnowledgeAcquisitionService
        from natureai_next.application.observation_intelligence import ObservationIntelligenceService
        from natureai_next.application.ecology import EcologicalContextService
        from natureai_next.infrastructure.database.ai import SqliteAIRepository
        from natureai_next.infrastructure.database.ai_generation import SqliteTaxonomyEmbeddingStore
        from natureai_next.infrastructure.database.ai_review import SqliteSuggestionStore
        from natureai_next.infrastructure.database.analyses import SqliteAssetAnalysisRepository
        from natureai_next.infrastructure.database.catalog_gui import SqliteCatalogGuiAdapter
        from natureai_next.infrastructure.database.regional import SqliteRegionalProfileStore
        from natureai_next.infrastructure.database.observation_intelligence import SqliteObservationIntelligenceAdapter
        from natureai_next.infrastructure.database.ecology import SqliteEcologicalContextStore
        from natureai_next.infrastructure.database.search import (
            SqliteCollectionAdapter, SqliteSavedSearchAdapter, SqliteSearchAdapter,
        )
        from natureai_next.infrastructure.database.unit_of_work import SqliteUnitOfWork
        from natureai_next.infrastructure.filesystem.importing import (
            DirectorySourceScanner,
            ShardedManagedFileStore,
            StreamingFileFingerprinter,
        )
        from natureai_next.infrastructure.imaging.catalog_thumbnails import PillowCatalogThumbnailProvider
        from natureai_next.infrastructure.imaging.pillow_adapter import PillowImageDecoder
        from natureai_next.infrastructure.metadata.pillow_reader import PillowMetadataReader
        from natureai_next.ui.presentation.ai_review import AIReviewModel
        from natureai_next.ui.qt.ai_review import AIReviewWorkspace
        from natureai_next.ui.qt.application import run_desktop

        fingerprinter = StreamingFileFingerprinter()
        managed_store = ShardedManagedFileStore(opened.layout.managed_originals, fingerprinter)
        import_service = ImportService(
            uow_factory=lambda: SqliteUnitOfWork(opened.connection_factory),
            scanner=DirectorySourceScanner(),
            fingerprinter=fingerprinter,
            managed_store=managed_store,
            decoder=PillowImageDecoder(),
            metadata_reader=PillowMetadataReader(),
            clock=container.clock,
            ids=container.uuid_generator,
        )
        catalog_adapter = SqliteCatalogGuiAdapter(opened.connection_factory)
        catalog_service = CatalogQueryService(catalog_adapter)
        catalog_edit_service = CatalogEditService(catalog_adapter, container.clock)
        search_adapter = SqliteSearchAdapter(opened.connection_factory)
        search_service = QuickSearchService(search_adapter)
        views_service = LibraryViewsService(
            saved=SqliteSavedSearchAdapter(opened.connection_factory),
            collections=SqliteCollectionAdapter(opened.connection_factory),
            search=search_adapter,
            clock=container.clock,
            ids=container.uuid_generator,
        )
        thumbnail_service = PillowCatalogThumbnailProvider(
            thumbnail_root=opened.layout.thumbnails,
            preview_root=opened.layout.previews,
            library_root=opened.layout.root,
        )
        maintenance_service = CatalogMaintenanceService(
            uow_factory=lambda: SqliteUnitOfWork(opened.connection_factory),
            fingerprinter=fingerprinter,
            managed_store=managed_store,
            clock=container.clock,
            ids=container.uuid_generator,
            cache_roots=(opened.layout.thumbnails, opened.layout.previews, opened.layout.root),
        )
        suggestion_service = SuggestionService(SqliteSuggestionStore(opened.connection_factory))
        observation_intelligence_service = ObservationIntelligenceService(
            SqliteObservationIntelligenceAdapter(opened.connection_factory)
        )
        from natureai_next.application.knowledge_engine import KnowledgeEngine
        desktop_knowledge_engine = KnowledgeEngine(
            observations=observation_intelligence_service,
            analyses=SqliteAssetAnalysisRepository(opened.connection_factory),
        )
        ecology_service = EcologicalContextService(
            SqliteEcologicalContextStore(opened.connection_factory),
            now_us=lambda: int(container.clock.now_utc().timestamp() * 1_000_000),
        )
        resource_service = LocalAIResourceService(
            factory=opened.connection_factory,
            models_root=container.paths.models_dir,
            id_factory=lambda: str(container.uuid_generator.new_uuid()),
            now_us=lambda: int(container.clock.now_utc().timestamp() * 1_000_000),
        )
        regional_service = RegionalProfileService(
            SqliteRegionalProfileStore(opened.connection_factory),
            now_us=lambda: int(container.clock.now_utc().timestamp() * 1_000_000),
        )
        regional_workspace = Path("D:/NatureAI-Models") if Path("D:/NatureAI-Models").exists() else container.paths.models_dir.parent
        def install_regional_reference_taxonomy(package_path: Path, trusted_keys_path: Path) -> str:
            from natureai_next.application.ai_resources import load_trusted_key_file
            from natureai_next.application.reference_taxonomy import AuthoritativeTaxonomyImportService
            from natureai_next.infrastructure.subsystems.taxonomy import (
                TAXONOMY_SUBSYSTEM_KEY,
                TaxonomyReferenceCatalog,
            )
            from natureai_next.infrastructure.taxonomy.package import Ed25519TaxonomyPackageVerifier

            taxonomy_factory = container.subsystem_registry.activate(TAXONOMY_SUBSYSTEM_KEY)
            service = AuthoritativeTaxonomyImportService(
                Ed25519TaxonomyPackageVerifier(load_trusted_key_file(trusted_keys_path)),
                TaxonomyReferenceCatalog(taxonomy_factory),
            )
            return service.install(
                package_path,
                installed_at_us=int(container.clock.now_utc().timestamp() * 1_000_000),
                source_url="https://www.gbif.org/",
            )

        regional_acquisition_service = RegionalKnowledgeAcquisitionService(
            resource_service,
            workspace=regional_workspace,
            reference_installer=install_regional_reference_taxonomy,
        )
        generation_service = LocalSuggestionGenerationService(
            source=SqliteSuggestionGenerationSource(opened.connection_factory),
            ai_repository=SqliteAIRepository(opened.connection_factory),
            taxonomy_embeddings=SqliteTaxonomyEmbeddingStore(opened.connection_factory),
            suggestions=suggestion_service,
            id_factory=lambda: str(container.uuid_generator.new_uuid()),
            now_us=lambda: int(container.clock.now_utc().timestamp() * 1_000_000),
            analyses=AssetAnalysisService(SqliteAssetAnalysisRepository(opened.connection_factory)),
        )
        def map_workspace_factory():
            from natureai_next.application.knowledge_engine import KnowledgeEngine
            from natureai_next.application.map_workspace import OfflineMapWorkspaceService
            from natureai_next.infrastructure.database.spatial_intelligence import SqliteSpatialIntelligenceAdapter
            from natureai_next.infrastructure.subsystems.maps import MAPS_SUBSYSTEM_KEY
            from natureai_next.ui.qt.maps import OfflineMapWorkspace
            from natureai_next.application.temporal_map import TemporalMapService
            map_factory = container.subsystem_registry.activate(MAPS_SUBSYSTEM_KEY)
            knowledge_engine = KnowledgeEngine(spatial=SqliteSpatialIntelligenceAdapter(opened.connection_factory))
            return OfflineMapWorkspace(
                lambda: OfflineMapWorkspaceService(
                    map_factory=map_factory,
                    library_factory=opened.connection_factory,
                    knowledge_engine=knowledge_engine,
                ),
                lambda: TemporalMapService(opened.connection_factory),
            )

        def knowledge_center_workspace_factory():
            from natureai_next.application.knowledge_center import KnowledgeCenterService
            from natureai_next.infrastructure.subsystems.taxonomy import TAXONOMY_SUBSYSTEM_KEY, TaxonomyReferenceCatalog
            from natureai_next.ui.qt.knowledge_center import KnowledgeCenterWorkspace

            from natureai_next.application.knowledge_engine import KnowledgeEngine
            state: dict[str, object] = {}

            def service_factory() -> KnowledgeCenterService:
                service = state.get("service")
                if isinstance(service, KnowledgeCenterService):
                    return service
                taxonomy_factory = container.subsystem_registry.activate(TAXONOMY_SUBSYSTEM_KEY)
                catalog = TaxonomyReferenceCatalog(taxonomy_factory)
                service = KnowledgeCenterService(
                    catalog,
                    observation_intelligence_service,
                    library_public_id=opened.manifest.public_id,
                    links=catalog,
                )
                state["catalog"] = catalog
                state["service"] = service
                return service

            def knowledge_engine_factory() -> KnowledgeEngine:
                engine = state.get("engine")
                if isinstance(engine, KnowledgeEngine):
                    return engine
                service_factory()
                catalog = state["catalog"]
                engine = KnowledgeEngine(taxonomy=catalog, observations=observation_intelligence_service)
                state["engine"] = engine
                return engine

            return KnowledgeCenterWorkspace(service_factory, knowledge_engine_factory)

        def ai_review_workspace_factory(
            selected_asset_ids: object = lambda: (),
        ) -> AIReviewWorkspace:
            if not callable(selected_asset_ids):
                raise TypeError("selected asset provider must be callable")
            return AIReviewWorkspace(
                model=AIReviewModel(suggestion_service),
                service=suggestion_service,
                action_id_factory=lambda: str(container.uuid_generator.new_uuid()),
                now_us=lambda: int(container.clock.now_utc().timestamp() * 1_000_000),
                generation_service=generation_service,
                selected_asset_ids=selected_asset_ids,
                resource_service=resource_service,
                regional_service=regional_service,
                regional_acquisition_service=regional_acquisition_service,
                observation_service=observation_intelligence_service,
                knowledge_engine=desktop_knowledge_engine,
                ecology_service=ecology_service,
                thumbnail_service=thumbnail_service,
            )
        session_path = opened.layout.root / "session.json"
        startup.mark("desktop-services-composed")
        logging.getLogger("natureai_next.bootstrap").info("Desktop services composed", extra={"context": {"elapsed_ms": round((time.perf_counter() - started_at) * 1000, 1)}})
        return run_desktop(
            library_name=opened.manifest.display_name,
            session_path=session_path,
            import_service=import_service,
            catalog_service=catalog_service,
            thumbnail_service=thumbnail_service,
            catalog_edit_service=catalog_edit_service,
            search_service=search_service,
            views_service=views_service,
            maintenance_service=maintenance_service,
            ai_review_workspace_factory=ai_review_workspace_factory,
            backup_service=LibraryBackupService(opened.backup_database, library_name=opened.manifest.display_name),
            default_backup_directory=opened.layout.backups,
            map_workspace_factory=map_workspace_factory,
            knowledge_center_workspace_factory=knowledge_center_workspace_factory,
            health_service=LibraryHealthService(
                layout=opened.layout,
                connection_factory=opened.connection_factory,
                update_settings_path=session_path.parent / "update-settings.json",
            ),
            on_about_to_quit=opened.close,
            startup_timeline=startup,
        )
