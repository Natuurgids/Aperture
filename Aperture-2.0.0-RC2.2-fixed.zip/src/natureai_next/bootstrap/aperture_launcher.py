"""Windowless Windows launcher for the Aperture desktop application."""

from __future__ import annotations

from pathlib import Path

from natureai_next.bootstrap.cli import main as cli_main

# Compatibility guard: the shared configuration service resolves
# os.environ.get("APPDATA") and stores data under
# root / "NatureAI" / "NatureAI Next" / "launcher.json".


def _configured_library() -> Path | None:
    from natureai_next.application.launcher_configuration import LauncherConfigurationStore
    return LauncherConfigurationStore().load().last_library


def _message_box(message: str, *, error: bool = True) -> None:
    try:
        import ctypes

        icon = 0x10 if error else 0x40
        ctypes.windll.user32.MessageBoxW(0, message, "Aperture", icon)
    except Exception:
        return


def main() -> int:
    library = _configured_library()
    if library is None:
        _message_box(
            "No Aperture Library is configured. Use 'Aperture - Select Library' and try again."
        )
        return 1
    if not (library / "library.json").is_file() or not (library / "library.sqlite3").is_file():
        _message_box(
            "The configured Aperture Library is unavailable or incomplete. "
            "Use 'Aperture - Select Library' to choose a valid library."
        )
        return 1
    try:
        return int(cli_main(["--library", str(library), "--log-level", "INFO"]))
    except Exception as exc:
        _message_box(
            "Aperture could not start.\n\n"
            f"{type(exc).__name__}: {exc}\n\n"
            "Use Aperture (Debug) for diagnostic output."
        )
        return 1
