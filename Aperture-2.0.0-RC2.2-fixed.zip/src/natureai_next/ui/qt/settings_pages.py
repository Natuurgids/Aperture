"""In-window settings workspaces for AI and regional resources."""
from __future__ import annotations
from html import escape
from pathlib import Path

try:
    from PySide6.QtCore import Qt, Slot
    from PySide6.QtWidgets import QHBoxLayout, QLabel, QPushButton, QVBoxLayout, QWidget
except ImportError as exc:  # pragma: no cover
    raise RuntimeError("PySide6 is required") from exc


class AIResourcesWorkspace(QWidget):
    def __init__(self, *, resource_service, suggestion_service, regional_service, regional_acquisition_service, activity_open, parent=None):
        super().__init__(parent)
        self._resource_service=resource_service; self._suggestion_service=suggestion_service
        self._regional_service=regional_service; self._regional_acquisition_service=regional_acquisition_service
        self._activity_open=activity_open
        self._summary=QLabel(); self._summary.setWordWrap(True); self._summary.setTextFormat(Qt.TextFormat.RichText)
        quick=QPushButton("BioCLIP Quick Setup…"); quick.clicked.connect(self._quick_setup)
        regional=QPushButton("Regional Knowledge"); regional.clicked.connect(self.open_regional_setup)
        advanced=QPushButton("Advanced resource installation…"); advanced.clicked.connect(self.open_advanced_resources)
        activity=QPushButton("Open Activity Center"); activity.clicked.connect(activity_open)
        refresh=QPushButton("Refresh"); refresh.clicked.connect(self.refresh)
        buttons=QHBoxLayout()
        for b in (quick,regional,activity,advanced,refresh): buttons.addWidget(b)
        buttons.addStretch(1)
        layout=QVBoxLayout(self); layout.addWidget(QLabel("<h2>AI Resources</h2>")); layout.addWidget(self._summary); layout.addLayout(buttons); layout.addStretch(1)
        self.refresh()

    @Slot()
    def refresh(self):
        try:
            o=self._suggestion_service.overview()
            model="Not installed" if o.active_model_identity is None else f"{escape(o.active_model_identity)} {escape(o.active_model_version or '')}"
            variant=escape(o.active_variant_identity or "None")
            prompt=escape(o.active_prompt_set or "Not installed")
        except Exception as exc:
            model=f"Unavailable: {escape(str(exc))}"; variant="Unknown"; prompt="Unknown"
        region="Not configured"
        if self._regional_service is not None:
            try:
                p=self._regional_service.load(); countries=", ".join(getattr(c, "country_name", getattr(c, "country_code", str(c))) for c in p.countries) or "continent-wide"
                region=f"{escape(p.primary_continent_code or 'Global')} · {escape(countries)}"
            except Exception: pass
        self._summary.setText(f"<p><b>BioCLIP model:</b> {model}</p><p><b>Variant:</b> {variant}</p><p><b>Prompt set:</b> {prompt}</p><p><b>Regional profile:</b> {region}</p><p>Long-running downloads and embedding jobs are shown in Activity Center.</p>")

    def _quick_setup(self):
        if self._resource_service is None: return
        from natureai_next.application.ai_setup import BioCLIPQuickSetupService
        from natureai_next.ui.qt.ai_setup import BioCLIPSetupDialog
        BioCLIPSetupDialog(BioCLIPQuickSetupService(self._resource_service), self).exec(); self.refresh()
    def open_regional_setup(self):
        if self._regional_service is None: return
        from natureai_next.ui.qt.regional_setup import RegionalSetupDialog
        RegionalSetupDialog(self._regional_service,self,acquisition_service=self._regional_acquisition_service).exec(); self.refresh()
    def open_advanced_resources(self):
        if self._resource_service is None: return
        from natureai_next.ui.qt.ai_resources import AIResourcesDialog
        AIResourcesDialog(self._resource_service,self,regional_service=self._regional_service,regional_acquisition_service=self._regional_acquisition_service).exec(); self.refresh()


class RegionalKnowledgeWorkspace(QWidget):
    def __init__(self, *, regional_service, regional_acquisition_service, parent=None):
        super().__init__(parent); self._service=regional_service; self._acquisition=regional_acquisition_service
        self._summary=QLabel(); self._summary.setWordWrap(True)
        configure=QPushButton("Configure regional knowledge…"); configure.clicked.connect(self.configure)
        layout=QVBoxLayout(self); layout.addWidget(QLabel("<h2>Regional Knowledge</h2>")); layout.addWidget(self._summary); layout.addWidget(configure,0,Qt.AlignmentFlag.AlignLeft); layout.addStretch(1)
        self.refresh()
    @Slot()
    def refresh(self):
        try:
            p=self._service.load(); countries=", ".join(getattr(c, "country_name", getattr(c, "country_code", str(c))) for c in p.countries) or "No individual countries selected"
            langs=", ".join(p.preferred_languages)
            self._summary.setText(f"<p><b>Continent:</b> {escape(p.primary_continent_code or 'None')}</p><p><b>Countries:</b> {escape(countries)}</p><p><b>Languages:</b> {escape(langs)}</p><p><b>Rest-of-world fallback:</b> {'Enabled' if p.include_global_fallback else 'Disabled'}</p>")
        except Exception as exc: self._summary.setText(f"Regional profile unavailable: {escape(str(exc))}")
    def configure(self):
        from natureai_next.ui.qt.regional_setup import RegionalSetupDialog
        RegionalSetupDialog(self._service,self,acquisition_service=self._acquisition).exec(); self.refresh()


class OfflineMapsResourcesWorkspace(QWidget):
    """Navigation-page entry for offline map acquisition and installed coverage."""

    def __init__(self, *, open_manager, parent=None):
        super().__init__(parent)
        self._open_manager = open_manager
        self._summary = QLabel()
        self._summary.setWordWrap(True)
        self._summary.setText(
            "<p>Offline map coverage is optional and remains visible when the computer is offline.</p>"
            "<p>Select continent, country, and provider-defined province/state/region packages in the map setup. "
            "Installed maps can be enabled, disabled, updated, imported from .apkg, or removed to recover space.</p>"
        )
        manage = QPushButton("Open Offline Map Setup…")
        manage.clicked.connect(self._open_manager)
        layout = QVBoxLayout(self)
        layout.addWidget(QLabel("<h2>Offline Maps</h2>"))
        layout.addWidget(self._summary)
        layout.addWidget(manage, 0, Qt.AlignmentFlag.AlignLeft)
        layout.addStretch(1)


class TaxonomyResourcesWorkspace(QWidget):
    """Taxonomy resource acquisition page, separate from taxonomy browsing."""

    def __init__(self, *, configure_regional, open_advanced, parent=None):
        super().__init__(parent)
        self._configure_regional = configure_regional
        self._open_advanced = open_advanced
        summary = QLabel(
            "<p>Taxonomy resources provide scientific and common names for the Knowledge Center. "
            "Regional Knowledge installation also installs its verified taxonomy into the shared reference database.</p>"
            "<p>The page remains available offline. Existing datasets continue to work; online acquisition is simply unavailable.</p>"
        )
        summary.setWordWrap(True)
        regional = QPushButton("Select Regional Taxonomy…")
        regional.clicked.connect(self._configure_regional)
        advanced = QPushButton("Import Authoritative Taxonomy Package…")
        advanced.clicked.connect(self._open_advanced)
        buttons = QHBoxLayout()
        buttons.addWidget(regional)
        buttons.addWidget(advanced)
        buttons.addStretch(1)
        layout = QVBoxLayout(self)
        layout.addWidget(QLabel("<h2>Taxonomy Resources</h2>"))
        layout.addWidget(summary)
        layout.addLayout(buttons)
        layout.addStretch(1)
