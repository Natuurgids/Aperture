"""Qt library workspace backed by catalog query and thumbnail services."""
from __future__ import annotations

from pathlib import Path
from typing import Literal, Protocol
import json
import os
from datetime import datetime, timezone

from natureai_next.domain.search import StructuredAssetFilters
from natureai_next.ports.catalog_queries import AssetDetail, AssetPage, MetadataPatch

try:
    from PySide6.QtCore import QByteArray, QObject, QSize, Qt, QThread, QTimer, Signal, Slot
    from PySide6.QtGui import QIcon, QKeySequence, QPixmap, QShortcut
    from PySide6.QtWidgets import (
        QCheckBox,
        QComboBox,
        QDateEdit,
        QFormLayout,
        QGridLayout,
        QGroupBox,
        QHBoxLayout,
        QInputDialog,
        QLabel,
        QLineEdit,
        QListWidget,
        QListWidgetItem,
        QMessageBox,
        QPushButton,
        QSpinBox,
        QSplitter,
        QStyle,
        QTextEdit,
        QVBoxLayout,
        QWidget,
    )
except ImportError as exc:  # pragma: no cover
    raise RuntimeError("PySide6 is required; install natureai-next[gui]") from exc


class CatalogApplicationService(Protocol):
    def page(self, *, limit: int, after_id: int | None = None) -> AssetPage: ...
    def by_public_ids(self, public_ids: tuple[str, ...]) -> AssetPage: ...
    def detail(self, public_id: str) -> AssetDetail | None: ...


class CatalogEditApplicationService(Protocol):
    def update_with_tags(
        self,
        *,
        public_id: str,
        expected_revision: int,
        patch: MetadataPatch,
        tag_names: tuple[str, ...],
    ) -> object: ...


class CatalogThumbnailService(Protocol):
    def load(self, *, source_path: Path | None, cached_path: Path | None, max_size: int) -> bytes | None: ...




class CatalogMaintenanceApplicationService(Protocol):
    def trash(self, asset_public_id: str) -> bool: ...
    def restore(self, asset_public_id: str) -> bool: ...
    def removal_preview(self, asset_public_id: str) -> object: ...
    def permanently_delete(
        self,
        asset_public_id: str,
        *,
        observation_policy: Literal["block", "unlink", "delete"] = "block",
    ) -> object: ...

class QuickSearchApplicationService(Protocol):
    def page(
        self,
        *,
        text: str = "",
        filters: StructuredAssetFilters | None = None,
        limit: int,
        after_id: int | None = None,
    ) -> AssetPage: ...


class LibraryViewsApplicationService(Protocol):
    def save_current_search(self, *, name: str, text: str, filters: StructuredAssetFilters) -> object: ...
    def list_saved_searches(self) -> tuple[object, ...]: ...
    def delete_saved_search(self, public_id: str) -> None: ...
    def page_saved_search(self, *, public_id: str, limit: int, after_id: int | None = None) -> AssetPage: ...
    def create_manual_collection(self, *, name: str, description: str | None = None) -> None: ...
    def create_smart_collection(self, *, name: str, text: str, filters: StructuredAssetFilters, description: str | None = None) -> None: ...
    def add_assets_to_collection(self, *, collection_public_id: str, asset_public_ids: tuple[str, ...]) -> None: ...
    def remove_assets_from_collection(self, *, collection_public_id: str, asset_public_ids: tuple[str, ...]) -> None: ...
    def update_collection(self, *, public_id: str, name: str, description: str | None = None) -> None: ...
    def delete_collection(self, public_id: str) -> None: ...
    def list_collections(self) -> tuple[object, ...]: ...
    def page_collection(self, *, public_id: str, limit: int, after_id: int | None = None) -> AssetPage: ...


class _CatalogWorker(QObject):
    page_ready = Signal(object, bool, int)
    failed = Signal(str, int)

    def __init__(
        self,
        service: CatalogApplicationService,
        search: QuickSearchApplicationService,
        views: LibraryViewsApplicationService,
        *,
        search_text: str,
        filters: StructuredAssetFilters,
        after_id: int | None,
        append: bool,
        request_id: int,
        view_kind: str | None = None,
        view_public_id: str | None = None,
        import_public_ids: tuple[str, ...] = (),
    ) -> None:
        super().__init__()
        self._service = service
        self._search = search
        self._views = views
        self._search_text = search_text
        self._filters = filters
        self._after_id = after_id
        self._append = append
        self._request_id = request_id
        self._view_kind = view_kind
        self._view_public_id = view_public_id
        self._import_public_ids = import_public_ids

    @Slot()
    def run(self) -> None:
        try:
            if self._import_public_ids:
                page = self._service.by_public_ids(self._import_public_ids)
            elif self._view_kind == "saved" and self._view_public_id:
                page = self._views.page_saved_search(public_id=self._view_public_id, limit=500, after_id=self._after_id)
            elif self._view_kind == "collection" and self._view_public_id:
                page = self._views.page_collection(public_id=self._view_public_id, limit=500, after_id=self._after_id)
            elif self._search_text or not self._filters.is_empty():
                page = self._search.page(
                    text=self._search_text,
                    filters=self._filters,
                    limit=500,
                    after_id=self._after_id,
                )
            else:
                page = self._service.page(limit=500, after_id=self._after_id)
            self.page_ready.emit(page, self._append, self._request_id)
        except Exception as exc:
            self.failed.emit(f"{type(exc).__name__}: {exc}", self._request_id)


class _ViewsWorker(QObject):
    loaded = Signal(object, object)
    completed = Signal(str)
    failed = Signal(str)

    def __init__(self, service: LibraryViewsApplicationService, operation: str, **kwargs: object) -> None:
        super().__init__()
        self._service = service
        self._operation = operation
        self._kwargs = kwargs

    @Slot()
    def run(self) -> None:
        try:
            if self._operation == "load":
                self.loaded.emit(self._service.list_saved_searches(), self._service.list_collections())
            elif self._operation == "save_search":
                self._service.save_current_search(**self._kwargs)
                self.completed.emit("Saved search created")
            elif self._operation == "delete_search":
                self._service.delete_saved_search(str(self._kwargs["public_id"]))
                self.completed.emit("Saved search deleted")
            elif self._operation == "create_collection":
                self._service.create_manual_collection(**self._kwargs)
                self.completed.emit("Collection created")
            elif self._operation == "create_smart_collection":
                self._service.create_smart_collection(**self._kwargs)
                self.completed.emit("Smart collection created")
            elif self._operation == "add_assets":
                self._service.add_assets_to_collection(**self._kwargs)
                self.completed.emit("Assets added to collection")
            elif self._operation == "remove_assets":
                self._service.remove_assets_from_collection(**self._kwargs)
                self.completed.emit("Assets removed from collection")
            elif self._operation == "update_collection":
                self._service.update_collection(**self._kwargs)
                self.completed.emit("Collection updated")
            elif self._operation == "delete_collection":
                self._service.delete_collection(str(self._kwargs["public_id"]))
                self.completed.emit("Collection deleted")
            else:
                raise ValueError(f"unsupported views operation: {self._operation}")
        except Exception as exc:
            self.failed.emit(f"{type(exc).__name__}: {exc}")


class _MaintenanceWorker(QObject):
    completed = Signal(str, object)
    failed = Signal(str)

    def __init__(
        self,
        service: CatalogMaintenanceApplicationService,
        operation: str,
        asset_public_ids: tuple[str, ...],
        *,
        observation_policy: Literal["block", "unlink", "delete"] = "block",
    ) -> None:
        super().__init__()
        self._service = service
        self._operation = operation
        self._asset_public_ids = asset_public_ids
        self._observation_policy = observation_policy

    @Slot()
    def run(self) -> None:
        try:
            if self._operation == "trash":
                changed = sum(1 for public_id in self._asset_public_ids if self._service.trash(public_id))
                self.completed.emit("trash", changed)
                return
            if self._operation == "delete":
                results = tuple(
                    self._service.permanently_delete(
                        public_id, observation_policy=self._observation_policy
                    )
                    for public_id in self._asset_public_ids
                )
                self.completed.emit("delete", results)
                return
            raise ValueError(f"unsupported maintenance operation: {self._operation}")
        except Exception as exc:
            self.failed.emit(f"{type(exc).__name__}: {exc}")


class _DetailWorker(QObject):
    ready = Signal(str, object)
    failed = Signal(str)

    def __init__(self, service: CatalogApplicationService, public_id: str) -> None:
        super().__init__()
        self._service = service
        self._public_id = public_id

    @Slot()
    def run(self) -> None:
        try:
            self.ready.emit(self._public_id, self._service.detail(self._public_id))
        except Exception as exc:
            self.failed.emit(f"{type(exc).__name__}: {exc}")


class _PreviewWorker(QObject):
    ready = Signal(int, object)

    def __init__(
        self,
        service: CatalogThumbnailService,
        *,
        request_id: int,
        source: Path | None,
    ) -> None:
        super().__init__()
        self._service = service
        self._request_id = request_id
        self._source = source

    @Slot()
    def run(self) -> None:
        try:
            data = self._service.load(source_path=self._source, cached_path=None, max_size=1200)
        except Exception:
            data = None
        self.ready.emit(self._request_id, data)


class _ThumbnailWorker(QObject):
    ready = Signal(str, object)

    def __init__(self, service: CatalogThumbnailService, public_id: str, source: Path | None, cached: Path | None) -> None:
        super().__init__()
        self._service = service
        self._public_id = public_id
        self._source = source
        self._cached = cached

    @Slot()
    def run(self) -> None:
        try:
            data = self._service.load(source_path=self._source, cached_path=self._cached, max_size=192)
        except Exception:
            data = None
        self.ready.emit(self._public_id, data)


class _MetadataSaveWorker(QObject):
    saved = Signal(str)
    failed = Signal(str, str)

    def __init__(
        self,
        service: CatalogEditApplicationService,
        *,
        public_id: str,
        expected_revision: int,
        patch: MetadataPatch,
        tag_names: tuple[str, ...],
    ) -> None:
        super().__init__()
        self._service = service
        self._public_id = public_id
        self._expected_revision = expected_revision
        self._patch = patch
        self._tag_names = tag_names

    @Slot()
    def run(self) -> None:
        try:
            self._service.update_with_tags(
                public_id=self._public_id,
                expected_revision=self._expected_revision,
                patch=self._patch,
                tag_names=self._tag_names,
            )
        except Exception as exc:
            self.failed.emit(self._public_id, f"{type(exc).__name__}: {exc}")
            return
        self.saved.emit(self._public_id)


class LibraryWorkspace(QWidget):
    """Paged, non-blocking catalog browser with viewer launch integration."""

    viewer_requested = Signal(object, str)

    def __init__(
        self,
        catalog: CatalogApplicationService,
        thumbnails: CatalogThumbnailService,
        editor: CatalogEditApplicationService,
        search: QuickSearchApplicationService,
        views: LibraryViewsApplicationService,
        maintenance: CatalogMaintenanceApplicationService | None = None,
        parent: QWidget | None = None,
    ) -> None:
        super().__init__(parent)
        self._catalog = catalog
        self._thumbnails = thumbnails
        self._editor = editor
        self._search_service = search
        self._views_service = views
        self._maintenance_service = maintenance
        self._search_text = ""
        self._active_view_kind: str | None = None
        self._active_view_id: str | None = None
        self._active_view_name: str | None = None
        self._active_filters = StructuredAssetFilters()
        self._page_request_id = 0
        self._next_cursor: int | None = None
        self._threads: set[QThread] = set()
        self._workers: set[QObject] = set()
        self._items: dict[str, QListWidgetItem] = {}
        self._thumbnail_inputs: dict[str, tuple[Path | None, Path | None]] = {}
        self._failed_thumbnails: set[str] = set()
        self._thumbnail_queue: list[tuple[str, Path | None, Path | None]] = []
        self._thumbnail_active = 0
        self._thumbnail_limit = 8
        self._preview_request_id = 0
        self._selected_public_id: str | None = None
        self._detail: AssetDetail | None = None
        self._loading_editor = False
        self._metadata_dirty = False
        self._selection_guard = False
        self._import_public_ids: tuple[str, ...] = ()
        self._pending_import_sync: dict[str, object] | None = None

        self._count = QLabel("0 assets")
        self._view_selector = QComboBox()
        self._view_selector.addItem("All Library", "library")
        self._view_selector.setAccessibleName("Library view")
        self._view_selector.currentIndexChanged.connect(self._view_selection_changed)
        self._refresh = QPushButton("Refresh")
        self._refresh.clicked.connect(self.refresh)
        self._more = QPushButton("Load more")
        self._more.clicked.connect(self.load_more)
        self._more.setEnabled(False)
        self._retry_thumbnails = QPushButton("Retry failed thumbnails")
        self._retry_thumbnails.setEnabled(False)
        self._retry_thumbnails.clicked.connect(self.retry_failed_thumbnails)
        self._open_viewer = QPushButton("Open viewer")
        self._open_viewer.setEnabled(False)
        self._open_viewer.clicked.connect(self.open_selected_viewer)
        self._trash_selected = QPushButton("Move to Trash")
        self._trash_selected.setEnabled(False)
        self._trash_selected.clicked.connect(self.trash_selected_assets)
        self._delete_selected = QPushButton("Permanently delete…")
        self._delete_selected.setEnabled(False)
        self._delete_selected.clicked.connect(self.permanently_delete_selected_assets)
        if maintenance is None:
            self._trash_selected.hide()
            self._delete_selected.hide()
        header = QHBoxLayout()
        header.addWidget(self._count)
        header.addWidget(QLabel("View"))
        header.addWidget(self._view_selector)
        header.addStretch(1)
        header.addWidget(self._refresh)
        header.addWidget(self._retry_thumbnails)
        header.addWidget(self._trash_selected)
        header.addWidget(self._delete_selected)
        header.addWidget(self._open_viewer)
        header.addWidget(self._more)

        self._search_input = QLineEdit()
        self._search_input.setPlaceholderText("Search filename, title, caption, notes, or tags…")
        self._search_input.setClearButtonEnabled(True)
        self._search_input.returnPressed.connect(self._apply_search)
        self._search_timer = QTimer(self)
        self._search_timer.setSingleShot(True)
        self._search_timer.setInterval(300)
        self._search_timer.timeout.connect(self._apply_search)
        self._search_input.textChanged.connect(lambda _text: self._search_timer.start())
        search_row = QHBoxLayout()
        search_row.addWidget(QLabel("Quick search"))
        search_row.addWidget(self._search_input, 1)

        self._minimum_rating = QComboBox()
        self._minimum_rating.addItem("Any", None)
        for rating in range(1, 6):
            self._minimum_rating.addItem(f"{rating}+", rating)
        self._filter_color = QComboBox()
        self._filter_color.addItem("Any", None)
        for value in ("red", "yellow", "green", "blue", "purple"):
            self._filter_color.addItem(value.title(), value)
        self._filter_pick = QComboBox()
        self._filter_pick.addItem("Any", None)
        self._filter_pick.addItem("Pick", "pick")
        self._filter_pick.addItem("Reject", "reject")
        self._date_from_enabled = QCheckBox("From")
        self._date_from = QDateEdit()
        self._date_from.setCalendarPopup(True)
        self._date_from.setDisplayFormat("yyyy-MM-dd")
        self._date_from.setEnabled(False)
        self._date_to_enabled = QCheckBox("To")
        self._date_to = QDateEdit()
        self._date_to.setCalendarPopup(True)
        self._date_to.setDisplayFormat("yyyy-MM-dd")
        self._date_to.setEnabled(False)
        self._date_from_enabled.toggled.connect(self._date_from.setEnabled)
        self._date_to_enabled.toggled.connect(self._date_to.setEnabled)
        self._minimum_width = QSpinBox()
        self._minimum_width.setRange(0, 100000)
        self._minimum_width.setSpecialValueText("Any")
        self._minimum_width.setSuffix(" px")
        self._minimum_height = QSpinBox()
        self._minimum_height.setRange(0, 100000)
        self._minimum_height.setSpecialValueText("Any")
        self._minimum_height.setSuffix(" px")
        self._filter_tag = QLineEdit()
        self._filter_tag.setPlaceholderText("Exact tag")
        self._filter_taxonomy = QLineEdit()
        self._filter_taxonomy.setPlaceholderText("Scientific or common name")
        self._clear_filters = QPushButton("Clear filters")
        self._clear_filters.clicked.connect(self.clear_filters)

        filters_box = QGroupBox("Structured filters")
        filters_layout = QGridLayout(filters_box)
        filters_layout.addWidget(QLabel("Rating"), 0, 0)
        filters_layout.addWidget(self._minimum_rating, 0, 1)
        filters_layout.addWidget(QLabel("Color"), 0, 2)
        filters_layout.addWidget(self._filter_color, 0, 3)
        filters_layout.addWidget(QLabel("Pick"), 0, 4)
        filters_layout.addWidget(self._filter_pick, 0, 5)
        filters_layout.addWidget(self._date_from_enabled, 1, 0)
        filters_layout.addWidget(self._date_from, 1, 1)
        filters_layout.addWidget(self._date_to_enabled, 1, 2)
        filters_layout.addWidget(self._date_to, 1, 3)
        filters_layout.addWidget(QLabel("Width ≥"), 1, 4)
        filters_layout.addWidget(self._minimum_width, 1, 5)
        filters_layout.addWidget(QLabel("Height ≥"), 1, 6)
        filters_layout.addWidget(self._minimum_height, 1, 7)
        filters_layout.addWidget(QLabel("Tag"), 2, 0)
        filters_layout.addWidget(self._filter_tag, 2, 1, 1, 3)
        filters_layout.addWidget(QLabel("Taxonomy"), 2, 4)
        filters_layout.addWidget(self._filter_taxonomy, 2, 5, 1, 2)
        filters_layout.addWidget(self._clear_filters, 2, 7)

        for combo in (self._minimum_rating, self._filter_color, self._filter_pick):
            combo.currentIndexChanged.connect(lambda _index: self._search_timer.start())
        for spin in (self._minimum_width, self._minimum_height):
            spin.valueChanged.connect(lambda _value: self._search_timer.start())
        for edit in (self._filter_tag, self._filter_taxonomy):
            edit.textChanged.connect(lambda _text: self._search_timer.start())
            edit.returnPressed.connect(self._apply_search)
        for check in (self._date_from_enabled, self._date_to_enabled):
            check.toggled.connect(lambda _checked: self._search_timer.start())
        self._date_from.dateChanged.connect(lambda _date: self._search_timer.start())
        self._date_to.dateChanged.connect(lambda _date: self._search_timer.start())

        self._saved_searches = QComboBox()
        self._saved_searches.addItem("Saved searches…", None)
        self._open_saved_search = QPushButton("Open")
        self._open_saved_search.clicked.connect(self.open_saved_search)
        self._save_search = QPushButton("Save current search…")
        self._save_search.clicked.connect(self.save_current_search)
        self._delete_search = QPushButton("Delete")
        self._delete_search.clicked.connect(self.delete_saved_search)
        self._collection_records: tuple[object, ...] = ()
        self._collections = QComboBox()
        self._collections.addItem("Collections…", None)
        self._open_collection = QPushButton("Open")
        self._open_collection.clicked.connect(self.open_collection)
        self._new_collection = QPushButton("New collection…")
        self._new_collection.clicked.connect(self.create_collection)
        self._new_smart_collection = QPushButton("Save as smart…")
        self._new_smart_collection.clicked.connect(self.create_smart_collection)
        self._edit_collection = QPushButton("Edit…")
        self._edit_collection.clicked.connect(self.edit_collection)
        self._delete_collection = QPushButton("Delete")
        self._delete_collection.clicked.connect(self.delete_collection)
        self._add_to_collection = QPushButton("Add selected to…")
        self._add_to_collection.clicked.connect(self.add_selected_to_collection)
        self._remove_from_collection = QPushButton("Remove selected")
        self._remove_from_collection.clicked.connect(self.remove_selected_from_collection)
        self._active_view = QLabel("")
        self._clear_view = QPushButton("Return to Library")
        self._clear_view.setEnabled(False)
        self._clear_view.clicked.connect(self.clear_active_view)
        views_box = QGroupBox("Saved views and collections")
        views_layout = QGridLayout(views_box)
        views_layout.addWidget(self._saved_searches, 0, 0)
        views_layout.addWidget(self._open_saved_search, 0, 1)
        views_layout.addWidget(self._save_search, 0, 2)
        views_layout.addWidget(self._delete_search, 0, 3)
        views_layout.addWidget(self._collections, 1, 0)
        views_layout.addWidget(self._open_collection, 1, 1)
        views_layout.addWidget(self._new_collection, 1, 2)
        views_layout.addWidget(self._new_smart_collection, 1, 3)
        views_layout.addWidget(self._edit_collection, 2, 1)
        views_layout.addWidget(self._delete_collection, 2, 2)
        views_layout.addWidget(self._add_to_collection, 3, 1)
        views_layout.addWidget(self._remove_from_collection, 3, 2)
        views_layout.addWidget(self._active_view, 4, 0, 1, 3)
        views_layout.addWidget(self._clear_view, 4, 3)

        self._grid = QListWidget()
        self._grid.setViewMode(QListWidget.ViewMode.IconMode)
        self._grid.setResizeMode(QListWidget.ResizeMode.Adjust)
        self._grid.setMovement(QListWidget.Movement.Static)
        self._grid.setIconSize(QSize(192, 192))
        self._grid.setGridSize(QSize(220, 240))
        self._grid.setSelectionMode(QListWidget.SelectionMode.ExtendedSelection)
        self._grid.itemSelectionChanged.connect(self._selection_changed)
        self._grid.itemDoubleClicked.connect(lambda _item: self.open_selected_viewer())

        self._preview = QLabel("No selection")
        self._preview.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self._preview.setMinimumSize(QSize(280, 280))
        self._preview.setWordWrap(True)
        self._technical = QLabel("")
        self._technical.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        self._technical.setWordWrap(True)

        self._title = QLineEdit()
        self._caption = QTextEdit()
        self._caption.setMaximumHeight(90)
        self._notes = QTextEdit()
        self._notes.setMaximumHeight(90)
        self._rating = QSpinBox()
        self._rating.setRange(0, 5)
        self._rating.setSpecialValueText("Unrated")
        self._color = QComboBox()
        self._color.addItem("None", None)
        for value in ("red", "yellow", "green", "blue", "purple"):
            self._color.addItem(value.title(), value)
        self._pick = QComboBox()
        self._pick.addItem("None", None)
        self._pick.addItem("Pick", "pick")
        self._pick.addItem("Reject", "reject")
        self._tags = QLineEdit()
        self._tags.setPlaceholderText("Comma-separated tags")

        form = QFormLayout()
        form.addRow("Title", self._title)
        form.addRow("Caption", self._caption)
        form.addRow("Notes", self._notes)
        form.addRow("Rating", self._rating)
        form.addRow("Color", self._color)
        form.addRow("Pick state", self._pick)
        form.addRow("User tags", self._tags)

        self._save_metadata = QPushButton("Save")
        self._save_metadata.setEnabled(False)
        self._save_metadata.clicked.connect(self.save_metadata)
        self._discard_metadata = QPushButton("Discard")
        self._discard_metadata.setEnabled(False)
        self._discard_metadata.clicked.connect(self.discard_metadata)
        metadata_buttons = QHBoxLayout()
        metadata_buttons.addWidget(self._save_metadata)
        metadata_buttons.addWidget(self._discard_metadata)
        metadata_buttons.addStretch(1)

        for control in (self._title, self._tags):
            control.textChanged.connect(self._mark_metadata_dirty)
        for control in (self._caption, self._notes):
            control.textChanged.connect(self._mark_metadata_dirty)
        self._rating.valueChanged.connect(self._mark_metadata_dirty)
        self._color.currentIndexChanged.connect(self._mark_metadata_dirty)
        self._pick.currentIndexChanged.connect(self._mark_metadata_dirty)
        self._save_shortcut = QShortcut(QKeySequence.StandardKey.Save, self)
        self._save_shortcut.activated.connect(self.save_metadata)
        self._discard_shortcut = QShortcut(QKeySequence("Esc"), self)
        self._discard_shortcut.activated.connect(self.discard_metadata)

        right = QWidget()
        right_layout = QVBoxLayout(right)
        right_layout.addWidget(self._preview, 1)
        right_layout.addWidget(self._technical)
        right_layout.addLayout(form)
        right_layout.addLayout(metadata_buttons)

        splitter = QSplitter()
        splitter.addWidget(self._grid)
        splitter.addWidget(right)
        splitter.setStretchFactor(0, 4)
        splitter.setStretchFactor(1, 1)

        layout = QVBoxLayout(self)
        layout.addLayout(header)
        layout.addLayout(search_row)
        layout.addWidget(filters_box)
        layout.addWidget(views_box)
        layout.addWidget(splitter, 1)
        self.refresh_views()
        self.refresh()

    @Slot()
    def _apply_search(self) -> None:
        if self._active_view_kind is not None:
            self._set_active_view(None, None, None)
        text = " ".join(self._search_input.text().split())
        filters = self._current_filters()
        if text == self._search_text and filters == self._active_filters and self._grid.count() > 0:
            return
        self._search_text = text
        self._active_filters = filters
        self.refresh()

    def _run_views_operation(self, operation: str, **kwargs: object) -> None:
        thread = QThread(self)
        worker = _ViewsWorker(self._views_service, operation, **kwargs)
        worker.moveToThread(thread)
        thread.started.connect(worker.run)
        worker.loaded.connect(self._views_loaded)
        worker.completed.connect(self._views_completed)
        worker.failed.connect(self._views_failed)
        worker.loaded.connect(thread.quit)
        worker.completed.connect(thread.quit)
        worker.failed.connect(thread.quit)
        self._track(thread, worker)
        thread.start()

    @Slot()
    def refresh_views(self) -> None:
        self._run_views_operation("load")

    @Slot(object, object)
    def _views_loaded(self, saved: tuple[object, ...], collections: tuple[object, ...]) -> None:
        self._collection_records = tuple(collections)
        selected_saved = self._saved_searches.currentData()
        selected_collection = self._collections.currentData()
        self._saved_searches.clear()
        self._saved_searches.addItem("Saved searches…", None)
        for item in saved:
            self._saved_searches.addItem(str(getattr(item, "name")), str(getattr(item, "public_id")))
        self._collections.clear()
        self._collections.addItem("Collections…", None)
        for item in collections:
            kind = str(getattr(item, "collection_type"))
            count = getattr(item, "asset_count")
            suffix = "Smart" if kind == "smart" else str(count)
            label = f"{getattr(item, 'name')} ({suffix})"
            self._collections.addItem(label, str(getattr(item, "public_id")))
            index = self._collections.count() - 1
            self._collections.setItemData(index, item, Qt.ItemDataRole.UserRole + 1)
        for combo, value in ((self._saved_searches, selected_saved), (self._collections, selected_collection)):
            index = combo.findData(value)
            if index >= 0:
                combo.setCurrentIndex(index)

    @Slot(str)
    def _views_completed(self, message: str) -> None:
        self._active_view.setText(message)
        self.refresh_views()

    @Slot(str)
    def _views_failed(self, message: str) -> None:
        QMessageBox.critical(self, "Saved views", message)

    @Slot()
    def save_current_search(self) -> None:
        text = " ".join(self._search_input.text().split())
        filters = self._current_filters()
        if not text and filters.is_empty():
            QMessageBox.information(self, "Save search", "Enter search text or enable at least one filter first.")
            return
        name, accepted = QInputDialog.getText(self, "Save current search", "Name")
        if accepted and name.strip():
            self._run_views_operation("save_search", name=name, text=text, filters=filters)

    @Slot()
    def delete_saved_search(self) -> None:
        public_id = self._saved_searches.currentData()
        if not public_id:
            return
        if QMessageBox.question(self, "Delete saved search", "Delete the selected saved search?") == QMessageBox.StandardButton.Yes:
            self._run_views_operation("delete_search", public_id=str(public_id))
            if self._active_view_kind == "saved" and self._active_view_id == public_id:
                self.clear_active_view()

    @Slot()
    def open_saved_search(self) -> None:
        public_id = self._saved_searches.currentData()
        if public_id:
            self._set_active_view("saved", str(public_id), self._saved_searches.currentText())
            self.refresh()

    @Slot()
    def create_collection(self) -> None:
        name, accepted = QInputDialog.getText(self, "New collection", "Name")
        if accepted and name.strip():
            self._run_views_operation("create_collection", name=name, description=None)

    @Slot()
    def create_smart_collection(self) -> None:
        text = " ".join(self._search_input.text().split())
        filters = self._current_filters()
        if not text and filters.is_empty():
            QMessageBox.information(self, "Smart collection", "Enter search text or enable at least one filter first.")
            return
        name, accepted = QInputDialog.getText(self, "New smart collection", "Name")
        if accepted and name.strip():
            self._run_views_operation("create_smart_collection", name=name, text=text, filters=filters, description=None)

    @Slot()
    def edit_collection(self) -> None:
        public_id = self._collections.currentData()
        if not public_id:
            return
        item = self._collections.currentData(Qt.ItemDataRole.UserRole + 1)
        current_name = str(getattr(item, "name", self._collections.currentText().split(" (")[0]))
        current_description = str(getattr(item, "description", "") or "")
        name, accepted = QInputDialog.getText(self, "Edit collection", "Name", text=current_name)
        if not accepted or not name.strip():
            return
        description, accepted = QInputDialog.getMultiLineText(self, "Edit collection", "Description", current_description)
        if accepted:
            self._run_views_operation("update_collection", public_id=str(public_id), name=name, description=description)

    @Slot()
    def delete_collection(self) -> None:
        public_id = self._collections.currentData()
        if not public_id:
            return
        if QMessageBox.question(self, "Delete collection", "Delete the selected collection? Photographs are not deleted.") == QMessageBox.StandardButton.Yes:
            self._run_views_operation("delete_collection", public_id=str(public_id))
            if self._active_view_kind == "collection" and self._active_view_id == public_id:
                self.clear_active_view()

    @Slot()
    def remove_selected_from_collection(self) -> None:
        if self._active_view_kind != "collection" or not self._active_view_id:
            QMessageBox.information(self, "Collection", "Open a manual collection before removing members.")
            return
        item = self._collections.currentData(Qt.ItemDataRole.UserRole + 1)
        if item is not None and str(getattr(item, "collection_type", "manual")) == "smart":
            QMessageBox.information(self, "Collection", "Smart collection membership is defined by its saved query.")
            return
        selected = tuple(str(row.data(Qt.ItemDataRole.UserRole)) for row in self._grid.selectedItems())
        if not selected:
            QMessageBox.information(self, "Collection", "Select one or more assets first.")
            return
        self._run_views_operation("remove_assets", collection_public_id=self._active_view_id, asset_public_ids=selected)
        QTimer.singleShot(250, self.refresh)

    @Slot()
    def add_selected_to_collection(self) -> None:
        selected = tuple(str(item.data(Qt.ItemDataRole.UserRole)) for item in self._grid.selectedItems())
        if not selected:
            QMessageBox.information(self, "Collection", "Select one or more photographs first.")
            return
        manual = tuple(
            item for item in self._collection_records
            if str(getattr(item, "collection_type", "manual")) == "manual"
        )
        if not manual:
            QMessageBox.information(self, "Collection", "Create a manual collection first.")
            return
        labels = [str(getattr(item, "name")) for item in manual]
        current_id = self._collections.currentData()
        current_index = next(
            (index for index, item in enumerate(manual) if str(getattr(item, "public_id")) == str(current_id)),
            0,
        )
        label, accepted = QInputDialog.getItem(
            self,
            "Add photographs to collection",
            "Manual collection",
            labels,
            current_index,
            False,
        )
        if not accepted:
            return
        target = manual[labels.index(label)]
        public_id = str(getattr(target, "public_id"))
        self._run_views_operation("add_assets", collection_public_id=public_id, asset_public_ids=selected)

    @Slot()
    def focus_collections(self) -> None:
        self._collections.setFocus(Qt.FocusReason.ShortcutFocusReason)
        self._active_view.setText("Select a collection, then Open; or select photographs and use Add selected to…")

    @Slot()
    def open_collection(self) -> None:
        public_id = self._collections.currentData()
        if public_id:
            self._set_active_view("collection", str(public_id), self._collections.currentText())
            self.refresh()

    @Slot()
    def clear_active_view(self) -> None:
        self._import_public_ids = ()
        self._set_active_view(None, None, None)
        index = self._view_selector.findData("library")
        if index >= 0 and self._view_selector.currentIndex() != index:
            self._view_selector.blockSignals(True)
            self._view_selector.setCurrentIndex(index)
            self._view_selector.blockSignals(False)
        self.refresh()

    @Slot(int)
    def _view_selection_changed(self, _index: int) -> None:
        value = self._view_selector.currentData()
        if value == "latest-import" and self._import_public_ids:
            self._set_active_view("import", None, f"Latest import ({len(self._import_public_ids)})")
            self.refresh()
            return
        if value == "library" and self._active_view_kind == "import":
            self.clear_active_view()

    def _set_active_view(self, kind: str | None, public_id: str | None, name: str | None) -> None:
        self._active_view_kind = kind
        self._active_view_id = public_id
        self._active_view_name = name
        self._active_view.setText(f"Active view: {name}" if name else "")
        self._clear_view.setEnabled(kind is not None)

    def _current_filters(self) -> StructuredAssetFilters:
        return StructuredAssetFilters(
            minimum_rating=self._minimum_rating.currentData(),
            color_label=self._filter_color.currentData(),
            pick_state=self._filter_pick.currentData(),
            captured_from_date=(self._date_from.date().toString("yyyy-MM-dd") if self._date_from_enabled.isChecked() else None),
            captured_to_date=(self._date_to.date().toString("yyyy-MM-dd") if self._date_to_enabled.isChecked() else None),
            minimum_width=self._minimum_width.value() or None,
            minimum_height=self._minimum_height.value() or None,
            tag=self._filter_tag.text().strip() or None,
            taxonomy_name=self._filter_taxonomy.text().strip() or None,
        )

    @Slot()
    def clear_filters(self) -> None:
        self._minimum_rating.setCurrentIndex(0)
        self._filter_color.setCurrentIndex(0)
        self._filter_pick.setCurrentIndex(0)
        self._date_from_enabled.setChecked(False)
        self._date_to_enabled.setChecked(False)
        self._minimum_width.setValue(0)
        self._minimum_height.setValue(0)
        self._filter_tag.clear()
        self._filter_taxonomy.clear()
        self._apply_search()

    def show_imported(self, public_ids: tuple[str, ...], *, imported: int, failed: int) -> None:
        normalized_ids = tuple(dict.fromkeys(public_ids))
        if not normalized_ids:
            # A zero-import result must not create an implicit empty Latest import
            # view or replace the user's current catalog state.
            self._pending_import_sync = {
                "status": "import-completed",
                "imported": imported,
                "failed": failed,
                "requested_assets": 0,
            }
            self.clear_active_view()
            return
        self._import_public_ids = normalized_ids
        self._search_text = ""
        self._active_filters = StructuredAssetFilters()
        latest_index = self._view_selector.findData("latest-import")
        label = f"Latest import ({len(self._import_public_ids)})"
        if latest_index < 0:
            self._view_selector.addItem(label, "latest-import")
            latest_index = self._view_selector.findData("latest-import")
        else:
            self._view_selector.setItemText(latest_index, label)
        self._view_selector.blockSignals(True)
        self._view_selector.setCurrentIndex(latest_index)
        self._view_selector.blockSignals(False)
        self._set_active_view("import", None, label)
        self._pending_import_sync = {
            "status": "import-completed",
            "imported": imported,
            "failed": failed,
            "requested_assets": len(self._import_public_ids),
        }
        self.refresh()

    @Slot()
    def refresh(self) -> None:
        self._next_cursor = None
        self._page_request_id += 1
        self._request_page(after_id=None, append=False, request_id=self._page_request_id)

    @Slot()
    def load_more(self) -> None:
        if self._next_cursor is not None:
            self._request_page(after_id=self._next_cursor, append=True, request_id=self._page_request_id)

    def _request_page(self, *, after_id: int | None, append: bool, request_id: int) -> None:
        self._refresh.setEnabled(False)
        self._more.setEnabled(False)
        self._retry_thumbnails.setEnabled(False)
        self._count.setText("Loading…")
        thread = QThread(self)
        worker = _CatalogWorker(
            self._catalog,
            self._search_service,
            self._views_service,
            search_text=self._search_text,
            filters=self._active_filters,
            after_id=after_id,
            append=append,
            request_id=request_id,
            view_kind=self._active_view_kind,
            view_public_id=self._active_view_id,
            import_public_ids=self._import_public_ids,
        )
        worker.moveToThread(thread)
        thread.started.connect(worker.run)
        worker.page_ready.connect(self._page_ready)
        worker.failed.connect(self._page_failed)
        worker.page_ready.connect(thread.quit)
        worker.failed.connect(thread.quit)
        self._track(thread, worker)
        thread.start()

    @Slot(object, bool, int)
    def _page_ready(self, page: AssetPage, append: bool, request_id: int) -> None:
        if request_id != self._page_request_id:
            return
        if not append:
            self._grid.clear()
            self._items.clear()
            self._thumbnail_inputs.clear()
            self._failed_thumbnails.clear()
            self._thumbnail_queue.clear()
            self._retry_thumbnails.setEnabled(False)
        for row in page.rows:
            label = row.title or Path(row.primary_path).name if row.primary_path else row.public_id
            item = QListWidgetItem(label)
            item.setData(Qt.ItemDataRole.UserRole, row.public_id)
            item.setToolTip(row.primary_path or row.public_id)
            item.setIcon(self.style().standardIcon(QStyle.StandardPixmap.SP_FileIcon))
            item.setStatusTip("Thumbnail loading")
            self._grid.addItem(item)
            self._items[row.public_id] = item
            inputs = (
                Path(row.primary_path) if row.primary_path else None,
                Path(row.thumbnail_path) if row.thumbnail_path else None,
            )
            self._thumbnail_inputs[row.public_id] = inputs
            self._request_thumbnail(row.public_id, *inputs)
        self._next_cursor = page.next_cursor
        noun = "result" if self._active_view_kind or self._search_text or not self._active_filters.is_empty() else "asset"
        self._count.setText(f"{page.total_count} {noun}{'s' if page.total_count != 1 else ''}")
        self._refresh.setEnabled(True)
        self._more.setEnabled(self._next_cursor is not None)
        if not append and self._pending_import_sync is not None:
            payload = dict(self._pending_import_sync)
            payload.update({
                "created_at_utc": datetime.now(timezone.utc).isoformat(),
                "database_assets": page.total_count,
                "model_assets": self._grid.count(),
                "synchronized": self._grid.count() == len(self._import_public_ids),
            })
            log_dir = Path(os.environ.get("LOCALAPPDATA", Path.home())) / "Aperture" / "Logs"
            log_dir.mkdir(parents=True, exist_ok=True)
            with (log_dir / "import-sync.jsonl").open("a", encoding="utf-8") as handle:
                handle.write(json.dumps(payload, sort_keys=True) + "\n")
            self._pending_import_sync = None

    def _request_thumbnail(self, public_id: str, source: Path | None, cached: Path | None) -> None:
        self._thumbnail_queue.append((public_id, source, cached))
        self._drain_thumbnail_queue()

    def _drain_thumbnail_queue(self) -> None:
        while self._thumbnail_queue and self._thumbnail_active < self._thumbnail_limit:
            public_id, source, cached = self._thumbnail_queue.pop(0)
            if public_id not in self._items:
                continue
            thread = QThread(self)
            worker = _ThumbnailWorker(self._thumbnails, public_id, source, cached)
            worker.moveToThread(thread)
            thread.started.connect(worker.run)
            worker.ready.connect(self._thumbnail_ready)
            worker.ready.connect(thread.quit)
            self._thumbnail_active += 1
            self._track(thread, worker)
            thread.start()

    @Slot(str, object)
    def _thumbnail_ready(self, public_id: str, data: bytes | None) -> None:
        self._thumbnail_active = max(0, self._thumbnail_active - 1)
        self._drain_thumbnail_queue()
        item = self._items.get(public_id)
        if item is None:
            return
        if not data:
            self._failed_thumbnails.add(public_id)
            item.setIcon(self.style().standardIcon(QStyle.StandardPixmap.SP_MessageBoxWarning))
            item.setStatusTip("Thumbnail unavailable; select Retry failed thumbnails")
            item.setToolTip(f"{item.toolTip()}\nThumbnail unavailable")
            self._retry_thumbnails.setEnabled(True)
            return
        pixmap = QPixmap()
        if pixmap.loadFromData(QByteArray(data)):
            item.setIcon(QIcon(pixmap))
            item.setStatusTip("Thumbnail ready")
            self._failed_thumbnails.discard(public_id)
            self._retry_thumbnails.setEnabled(bool(self._failed_thumbnails))
        else:
            self._failed_thumbnails.add(public_id)
            item.setIcon(self.style().standardIcon(QStyle.StandardPixmap.SP_MessageBoxWarning))
            self._retry_thumbnails.setEnabled(True)

    @Slot()
    def retry_failed_thumbnails(self) -> None:
        failed = tuple(self._failed_thumbnails)
        self._failed_thumbnails.clear()
        self._retry_thumbnails.setEnabled(False)
        for public_id in failed:
            item = self._items.get(public_id)
            inputs = self._thumbnail_inputs.get(public_id)
            if item is None or inputs is None:
                continue
            item.setIcon(self.style().standardIcon(QStyle.StandardPixmap.SP_FileIcon))
            item.setStatusTip("Retrying thumbnail")
            self._request_thumbnail(public_id, *inputs)

    @Slot()
    def _selection_changed(self) -> None:
        if self._selection_guard:
            return
        selected = self._grid.selectedItems()
        self._open_viewer.setEnabled(bool(selected))
        maintenance_enabled = self._maintenance_service is not None and bool(selected)
        self._trash_selected.setEnabled(maintenance_enabled)
        self._delete_selected.setEnabled(maintenance_enabled)
        if not selected:
            if self._metadata_dirty and self._detail is not None:
                self._restore_selection(self._detail.public_id)
                return
            self._preview_request_id += 1
            self._selected_public_id = None
            self._preview.setText("No selection")
            self._preview.setPixmap(QPixmap())
            self._technical.clear()
            self._load_editor(None)
            return
        public_id = str(selected[0].data(Qt.ItemDataRole.UserRole))
        if self._metadata_dirty and self._detail is not None and public_id != self._detail.public_id:
            choice = QMessageBox.warning(
                self,
                "Unsaved metadata",
                "Save or discard the current metadata changes before selecting another asset.",
                QMessageBox.StandardButton.Save
                | QMessageBox.StandardButton.Discard
                | QMessageBox.StandardButton.Cancel,
                QMessageBox.StandardButton.Save,
            )
            if choice == QMessageBox.StandardButton.Save:
                self._restore_selection(self._detail.public_id)
                self.save_metadata()
                return
            if choice == QMessageBox.StandardButton.Cancel:
                self._restore_selection(self._detail.public_id)
                return
            self._set_metadata_dirty(False)
        self._preview_request_id += 1
        self._preview.setText("Loading preview…")
        self._preview.setPixmap(QPixmap())
        self._request_detail(public_id)

    def _restore_selection(self, public_id: str) -> None:
        item = self._items.get(public_id)
        if item is None:
            return
        self._selection_guard = True
        try:
            self._grid.clearSelection()
            item.setSelected(True)
            self._grid.setCurrentItem(item)
        finally:
            self._selection_guard = False

    @Slot(str, object)
    def _detail_ready(self, public_id: str, detail: AssetDetail | None) -> None:
        if public_id != self._selected_public_id:
            return
        if detail is None:
            self._technical.setText("Asset is no longer available.")
            self._load_editor(None)
            return
        dimensions = (
            f"{detail.pixel_width} × {detail.pixel_height}"
            if detail.pixel_width and detail.pixel_height
            else "Unknown dimensions"
        )
        tags = ", ".join(detail.tags) or "None"
        self._technical.setText(
            f"<b>{detail.title or 'Untitled'}</b><br>"
            f"{dimensions}<br>"
            f"Format: {detail.format_name or detail.mime_type or 'Unknown'}<br>"
            f"Rating: {detail.rating if detail.rating is not None else '—'}<br>"
            f"Tags: {tags}<br><br>"
            f"Original: {detail.primary_path or 'Unavailable'}"
        )
        self._load_editor(detail)
        item = self._items.get(public_id)
        if item is not None:
            item.setText(detail.title or (Path(detail.primary_path).name if detail.primary_path else public_id))
        request_id = self._preview_request_id
        thread = QThread(self)
        worker = _PreviewWorker(
            self._thumbnails,
            request_id=request_id,
            source=Path(detail.primary_path) if detail.primary_path else None,
        )
        worker.moveToThread(thread)
        thread.started.connect(worker.run)
        worker.ready.connect(self._preview_ready)
        worker.ready.connect(thread.quit)
        self._track(thread, worker)
        thread.start()

    @Slot(int, object)
    def _preview_ready(self, request_id: int, data: bytes | None) -> None:
        if request_id != self._preview_request_id:
            return
        if not data:
            self._preview.setText("Preview unavailable")
            return
        pixmap = QPixmap()
        if not pixmap.loadFromData(QByteArray(data)):
            self._preview.setText("Preview unavailable")
            return
        self._preview.setPixmap(
            pixmap.scaled(
                self._preview.size(),
                Qt.AspectRatioMode.KeepAspectRatio,
                Qt.TransformationMode.SmoothTransformation,
            )
        )

    def _load_editor(self, detail: AssetDetail | None) -> None:
        self._loading_editor = True
        self._detail = detail
        enabled = detail is not None
        for control in (self._title, self._caption, self._notes, self._rating, self._color, self._pick, self._tags):
            control.setEnabled(enabled)
        if detail is None:
            self._title.clear()
            self._caption.clear()
            self._notes.clear()
            self._rating.setValue(0)
            self._color.setCurrentIndex(0)
            self._pick.setCurrentIndex(0)
            self._tags.clear()
        else:
            self._title.setText(detail.title or "")
            self._caption.setPlainText(detail.caption or "")
            self._notes.setPlainText(detail.user_notes or "")
            self._rating.setValue(detail.rating or 0)
            self._set_combo_value(self._color, detail.color_label)
            self._set_combo_value(self._pick, detail.pick_state)
            self._tags.setText(", ".join(detail.tags))
        self._loading_editor = False
        self._set_metadata_dirty(False)

    @staticmethod
    def _set_combo_value(combo: QComboBox, value: str | None) -> None:
        index = combo.findData(value)
        combo.setCurrentIndex(index if index >= 0 else 0)

    @Slot()
    def _mark_metadata_dirty(self) -> None:
        if not self._loading_editor and self._detail is not None:
            self._set_metadata_dirty(True)

    def _set_metadata_dirty(self, dirty: bool) -> None:
        self._metadata_dirty = dirty
        self._save_metadata.setEnabled(dirty and self._detail is not None)
        self._discard_metadata.setEnabled(dirty and self._detail is not None)

    @Slot()
    def discard_metadata(self) -> None:
        if self._detail is not None and self._metadata_dirty:
            self._load_editor(self._detail)

    @Slot()
    def save_metadata(self) -> None:
        detail = self._detail
        if detail is None or not self._metadata_dirty:
            return
        title = self._title.text().strip() or None
        caption = self._caption.toPlainText().strip() or None
        notes = self._notes.toPlainText().strip() or None
        if title is not None and len(title) > 500:
            QMessageBox.warning(self, "Invalid metadata", "Title cannot exceed 500 characters.")
            return
        if caption is not None and len(caption) > 10000:
            QMessageBox.warning(self, "Invalid metadata", "Caption cannot exceed 10,000 characters.")
            return
        if notes is not None and len(notes) > 50000:
            QMessageBox.warning(self, "Invalid metadata", "Notes cannot exceed 50,000 characters.")
            return
        patch = MetadataPatch(
            title=title,
            caption=caption,
            user_notes=notes,
            rating=self._rating.value() or None,
            color_label=self._color.currentData(),
            pick_state=self._pick.currentData(),
        )
        tags = tuple(part.strip() for part in self._tags.text().split(",") if part.strip())
        self._save_metadata.setEnabled(False)
        self._discard_metadata.setEnabled(False)
        thread = QThread(self)
        worker = _MetadataSaveWorker(
            self._editor,
            public_id=detail.public_id,
            expected_revision=detail.revision,
            patch=patch,
            tag_names=tags,
        )
        worker.moveToThread(thread)
        thread.started.connect(worker.run)
        worker.saved.connect(self._metadata_saved)
        worker.failed.connect(self._metadata_save_failed)
        worker.saved.connect(thread.quit)
        worker.failed.connect(thread.quit)
        self._track(thread, worker)
        thread.start()

    @Slot(str)
    def _metadata_saved(self, public_id: str) -> None:
        if public_id != self._selected_public_id:
            return
        self._set_metadata_dirty(False)
        self._request_detail(public_id)

    @Slot(str, str)
    def _metadata_save_failed(self, public_id: str, message: str) -> None:
        if public_id == self._selected_public_id:
            self._save_metadata.setEnabled(True)
            self._discard_metadata.setEnabled(True)
        if "asset_revision_conflict" in message:
            QMessageBox.warning(
                self,
                "Metadata changed elsewhere",
                "This asset changed after it was loaded. The latest values will be reloaded.",
            )
            self._request_detail(public_id)
        else:
            QMessageBox.critical(self, "Could not save metadata", message)

    def _request_detail(self, public_id: str) -> None:
        self._preview_request_id += 1
        self._selected_public_id = public_id
        thread = QThread(self)
        worker = _DetailWorker(self._catalog, public_id)
        worker.moveToThread(thread)
        thread.started.connect(worker.run)
        worker.ready.connect(self._detail_ready)
        worker.failed.connect(self._failed)
        worker.ready.connect(thread.quit)
        worker.failed.connect(thread.quit)
        self._track(thread, worker)
        thread.start()

    @Slot()

    def _run_maintenance_operation(
        self,
        operation: str,
        asset_public_ids: tuple[str, ...],
        *,
        observation_policy: Literal["block", "unlink", "delete"] = "block",
    ) -> None:
        if self._maintenance_service is None:
            return
        self._trash_selected.setEnabled(False)
        self._delete_selected.setEnabled(False)
        thread = QThread(self)
        worker = _MaintenanceWorker(
            self._maintenance_service, operation, asset_public_ids, observation_policy=observation_policy
        )
        worker.moveToThread(thread)
        thread.started.connect(worker.run)
        worker.completed.connect(self._maintenance_completed)
        worker.failed.connect(self._maintenance_failed)
        worker.completed.connect(thread.quit)
        worker.failed.connect(thread.quit)
        self._track(thread, worker)
        thread.start()

    @Slot(str, object)
    def _maintenance_completed(self, operation: str, payload: object) -> None:
        if operation == "trash":
            changed = int(payload)
            self._count.setText(f"Moved {changed} photograph{'s' if changed != 1 else ''} to Trash")
        else:
            results = tuple(payload)
            deleted_files = sum(int(getattr(item, "deleted_files", 0)) for item in results)
            deleted_analyses = sum(int(getattr(item, "deleted_analyses", 0)) for item in results)
            QMessageBox.information(
                self,
                "Permanent deletion complete",
                f"Deleted {len(results)} photograph(s), {deleted_files} managed file(s), "
                f"and {deleted_analyses} analysis record(s).",
            )
        self.refresh()

    @Slot(str)
    def _maintenance_failed(self, message: str) -> None:
        QMessageBox.critical(self, "Photograph removal", message)
        self._selection_changed()

    @Slot()
    def trash_selected_assets(self) -> None:
        if self._maintenance_service is None:
            return
        selected = self.selected_asset_ids()
        if not selected:
            return
        count = len(selected)
        answer = QMessageBox.question(
            self,
            "Move photographs to Trash",
            f"Move {count} selected photograph{'s' if count != 1 else ''} to Trash?\n\n"
            "Files and analyses are retained and can be restored.",
        )
        if answer != QMessageBox.StandardButton.Yes:
            return
        self._run_maintenance_operation("trash", selected)

    def _removal_summary(self, previews: tuple[object, ...]) -> str:
        analyses = sum(int(getattr(item, "analysis_count", 0)) for item in previews)
        suggestions = sum(int(getattr(item, "suggestion_count", 0)) for item in previews)
        observations = sum(int(getattr(item, "observation_count", 0)) for item in previews)
        promotions = sum(int(getattr(item, "promotion_count", 0)) for item in previews)
        files = sum(len(getattr(item, "managed_files", ())) for item in previews)
        derivatives = sum(len(getattr(item, "derivative_files", ())) for item in previews)
        jobs = sum(int(getattr(item, "running_job_count", 0)) for item in previews)
        return (
            f"Photographs: {len(previews)}\n"
            f"Managed files: {files}\n"
            f"Thumbnails/previews: {derivatives}\n"
            f"AI analyses: {analyses}\n"
            f"AI suggestions: {suggestions}\n"
            f"Linked observations: {observations}\n"
            f"Analysis promotions: {promotions}\n"
            f"Running or queued jobs: {jobs}"
        )

    @Slot()
    def permanently_delete_selected_assets(self) -> None:
        if self._maintenance_service is None:
            return
        selected = self.selected_asset_ids()
        if not selected:
            return
        previews = tuple(self._maintenance_service.removal_preview(public_id) for public_id in selected)
        not_trashed = tuple(item for item in previews if str(getattr(item, "lifecycle_state", "")) != "trashed")
        if not_trashed:
            QMessageBox.information(
                self,
                "Permanent deletion",
                "Every photograph must be moved to Trash before permanent deletion. "
                f"{len(not_trashed)} selected item(s) are not in Trash.",
            )
            return
        dependencies = any(bool(getattr(item, "has_authoritative_dependencies", False)) for item in previews)
        policy: Literal["block", "unlink", "delete"] = "block"
        dialog = QMessageBox(self)
        dialog.setWindowTitle("Permanently delete photographs")
        dialog.setIcon(QMessageBox.Icon.Warning)
        dialog.setText("This permanently removes the selected photographs and their related analyses.")
        dialog.setInformativeText(self._removal_summary(previews))
        cancel = dialog.addButton(QMessageBox.StandardButton.Cancel)
        if dependencies:
            unlink = dialog.addButton("Delete photos, keep observations", QMessageBox.ButtonRole.DestructiveRole)
            delete_all = dialog.addButton("Delete photos and observations", QMessageBox.ButtonRole.DestructiveRole)
            dialog.setDefaultButton(cancel)
            dialog.exec()
            clicked = dialog.clickedButton()
            if clicked is unlink:
                policy = "unlink"
            elif clicked is delete_all:
                policy = "delete"
            else:
                return
        else:
            confirm = dialog.addButton("Permanently delete", QMessageBox.ButtonRole.DestructiveRole)
            dialog.setDefaultButton(cancel)
            dialog.exec()
            if dialog.clickedButton() is not confirm:
                return
        self._run_maintenance_operation("delete", selected, observation_policy=policy)

    def selected_asset_ids(self) -> tuple[str, ...]:
        """Return the current visible Library selection by stable public identity."""
        return tuple(
            str(item.data(Qt.ItemDataRole.UserRole))
            for item in self._grid.selectedItems()
        )

    def open_selected_viewer(self) -> None:
        selected = self._grid.selectedItems()
        if not selected:
            return
        public_id = str(selected[0].data(Qt.ItemDataRole.UserRole))
        ordered_ids = tuple(
            str(self._grid.item(index).data(Qt.ItemDataRole.UserRole))
            for index in range(self._grid.count())
        )
        self.viewer_requested.emit(ordered_ids, public_id)

    @Slot(str, int)
    def _page_failed(self, message: str, request_id: int) -> None:
        if request_id != self._page_request_id:
            return
        self._failed(message)

    @Slot(str)
    def _failed(self, message: str) -> None:
        self._count.setText(f"Catalog error: {message}")
        self._refresh.setEnabled(True)

    def _track(self, thread: QThread, worker: QObject) -> None:
        # Keep both Python wrappers alive until the Qt thread finishes.  Retaining
        # only the QThread is insufficient: PySide may garbage-collect a local
        # worker before the thread event loop invokes its slot, making Refresh
        # appear to do nothing without producing an error.
        self._threads.add(thread)
        self._workers.add(worker)

        def cleanup() -> None:
            self._workers.discard(worker)
            self._threads.discard(thread)

        thread.finished.connect(cleanup)
        thread.finished.connect(worker.deleteLater)
        thread.finished.connect(thread.deleteLater)
