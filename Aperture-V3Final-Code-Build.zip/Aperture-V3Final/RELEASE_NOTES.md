## Aperture V3Final — 3.0.0

### Production release

Aperture 3.0 promotes the validated V3 release-candidate line to production. The final build retains the proven NatureAI/BioCLIP correction that safely supplies writable output streams when Aperture runs as a windowless Windows GUI process. This prevents the Tree-of-Life classifier failure reported as `NoneType object has no attribute write`.

### Validated workflows

- Clean installation and selected-drive data-root configuration.
- Existing-library opening and new-library creation.
- Photograph import, browsing, and metadata persistence.
- NatureAI/BioCLIP model activation and Tree-of-Life inference.
- AI Review, suggestion acceptance, and persistence after restart.
- Backup, restore, uninstall, and legacy-data cleanup.
- Configurable NatureAI diagnostic logging with Errors, Standard, and Detailed levels.

### Storage and diagnostics

- Models, caches, logs, taxonomy packages, maps, updates, launcher state, and component data follow the configured Aperture data root.
- NatureAI diagnostics are controlled from AI Resources → Diagnostics and can be enabled or disabled without restarting.
- Inference diagnostics are written to `<DataRoot>\logs\natureai\natureai-inference.jsonl` when enabled.
- Diagnostic configuration is stored in `<DataRoot>\config\diagnostics.json`.

### Upgrade guidance

Install V3Final over the approved release candidate. Existing libraries and external GBIF databases are retained. After upgrade, verify the active model and prompt-set identity in AI Review and run one representative inference job before large batch processing.

---

## Aperture V3Final — 3.0.0

### NatureAI diagnostic logging

- Adds user-controlled diagnostic logging in **AI Resources → Diagnostics**.
- Logging can be enabled or disabled immediately without restarting Aperture.
- Supports Errors, Standard, and Detailed levels.
- Writes inference diagnostics to `<DataRoot>\logs\natureai\natureai-inference.jsonl`.
- Records run lifecycle, per-image failures, pipeline stage, model/provider identity, and exception details.
- Detailed mode also records tracebacks and sanitized classifier candidates.
- Adds bounded log rotation and a **Clear diagnostic logs** control.
- Keeps diagnostic settings under `<DataRoot>\config\diagnostics.json`.

### Retained fixes

- Retains external Tree-of-Life result persistence and selected-disk storage/legacy cleanup fixes from RC1F3–RC1F4.

## Aperture V3.RC1F3 — 3.0.0rc1.post3

- Fixed NatureAI Tree-of-Life results being discarded when external taxon identifiers were not already present in the Aperture taxonomy database.
- External classifier candidates are stored as reviewable labels with raw scores and complete upstream provenance.
- Added installer-selected `DataRoot` storage for models, caches, logs, component databases, taxonomy packages, maps, updates, and launcher state.
- Hugging Face, BioCLIP, and Torch caches now follow the selected Aperture data disk.
- Windows registry and Start Menu/Desktop shortcut metadata remain in Windows-managed per-user locations; these are small integration records rather than application data.
