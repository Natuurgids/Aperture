"""PySide6 AI Review workspace built on presentation and application services only."""
from __future__ import annotations

from collections.abc import Callable
from html import escape
from datetime import datetime, timezone
from pathlib import Path

from natureai_next.application.ai_generation import LocalSuggestionGenerationService, SuggestionGenerationResult
from natureai_next.application.components import ResourceComponentRegistry
from natureai_next.application.ai_resources import LocalAIResourceService
from natureai_next.application.ai_review import ReviewFilter, SuggestionService
from natureai_next.application.observation_intelligence import ObservationIntelligenceService
from natureai_next.application.knowledge_engine import KnowledgeEngine
from natureai_next.domain.ai import SuggestionDetail, SuggestionProjection
from natureai_next.ui.presentation.ai_review import AIReviewModel

try:
    from PySide6.QtCore import QObject, QThread, Qt, Signal, Slot
    from PySide6.QtGui import QKeySequence, QShortcut, QPixmap
    from PySide6.QtWidgets import (
        QCheckBox,
        QComboBox,
        QHBoxLayout,
        QLabel,
        QListWidget,
        QListWidgetItem,
        QMessageBox,
        QProgressBar,
        QPushButton,
        QSplitter,
        QTextBrowser,
        QVBoxLayout,
        QWidget,
        QSizePolicy,
    )
except ImportError as exc:  # pragma: no cover
    raise RuntimeError("PySide6 is required; install natureai-next[gui]") from exc


class _GenerationWorker(QObject):
    progress = Signal(int, int, str)
    succeeded = Signal(object)
    failed = Signal(str)
    finished = Signal()

    def __init__(self, service: LocalSuggestionGenerationService, asset_ids: tuple[str, ...]) -> None:
        super().__init__()
        self._service = service
        self._asset_ids = asset_ids
        self._cancelled = False

    @Slot()
    def run(self) -> None:
        try:
            result = self._service.generate_selected(
                self._asset_ids,
                cancellation_check=self._check_cancelled,
                progress=lambda current, total, message: self.progress.emit(current, total, message),
            )
            self.succeeded.emit(result)
        except Exception as exc:
            self.failed.emit(str(exc))
        finally:
            self.finished.emit()

    def cancel(self) -> None:
        self._cancelled = True

    def _check_cancelled(self) -> None:
        if self._cancelled:
            raise RuntimeError("BioCLIP generation was cancelled.")


class AIReviewWorkspace(QWidget):
    resources_requested = Signal()
    observation_requested = Signal(str)
    """Keyboard-first review surface with no database or filesystem dependencies."""

    def __init__(
        self,
        *,
        model: AIReviewModel,
        service: SuggestionService,
        action_id_factory: Callable[[], str],
        now_us: Callable[[], int],
        generation_service: LocalSuggestionGenerationService | None = None,
        selected_asset_ids: Callable[[], tuple[str, ...]] = lambda: (),
        resource_service: LocalAIResourceService | None = None,
        regional_service: object | None = None,
        regional_acquisition_service: object | None = None,
        observation_service: ObservationIntelligenceService | None = None,
        knowledge_engine: KnowledgeEngine | None = None,
        ecology_service: object | None = None,
        thumbnail_service: object | None = None,
        component_registry: ResourceComponentRegistry | None = None,
        parent: QWidget | None = None,
    ) -> None:
        super().__init__(parent)
        self._model = model
        self._service = service
        self._action_id_factory = action_id_factory
        self._now_us = now_us
        self._generation_service = generation_service
        self._selected_asset_ids = selected_asset_ids
        self._resource_service = resource_service
        self._regional_service = regional_service
        self._regional_acquisition_service = regional_acquisition_service
        self._observation_service = observation_service
        self._knowledge_engine = knowledge_engine
        self._ecology_service = ecology_service
        self._thumbnail_service = thumbnail_service
        self._components = component_registry or ResourceComponentRegistry()
        if regional_acquisition_service is not None:
            from natureai_next.ui.qt.activity import activity_center
            activity_center().register_recovery("regional-knowledge", regional_acquisition_service.recovery_operation)
        self._generation_thread: QThread | None = None
        self._generation_worker: _GenerationWorker | None = None
        self._items_by_id: dict[str, SuggestionProjection] = {}
        self._current_asset_public_id: str | None = None

        self._model_status = QLabel()
        self._model_status.setWordWrap(True)
        self._queue_status = QLabel()
        self._queue_status.setWordWrap(True)

        self._state_filter = QComboBox()
        self._state_filter.addItems(["pending", "deferred", "accepted", "rejected", "superseded"])
        self._state_filter.currentTextChanged.connect(self.refresh)
        self._confidence_filter = QComboBox()
        self._confidence_filter.addItems(["all", "high", "medium", "low", "unknown", "unclassified"])
        self._confidence_filter.currentTextChanged.connect(self.refresh)
        self._current_photo_only = QCheckBox("Current photograph only")
        self._current_photo_only.setToolTip("Show only taxonomy suggestions for the selected photograph.")
        self._current_photo_only.toggled.connect(self._photo_filter_toggled)

        self._list = QListWidget()
        self._list.setAlternatingRowColors(True)
        self._list.currentItemChanged.connect(self._selection_changed)
        self._detail = QTextBrowser()
        self._detail.setOpenExternalLinks(False)
        self._preview = QLabel("Select a suggestion to preview its photograph")
        self._preview.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self._preview.setMinimumSize(360, 260)
        self._preview.setMaximumHeight(420)
        self._preview.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        self._preview.setStyleSheet("QLabel { background: #202020; color: #c8c8c8; border: 1px solid #555; }")
        self._preview_meta = QLabel()
        self._preview_meta.setWordWrap(True)
        self._status = QLabel("Ready")
        self._shortcut_hint = QLabel("J/K navigate • A accept • Shift+Enter accept & continue • R reject • D defer • F1 help")
        self._shortcut_hint.setAccessibleName("AI Review keyboard shortcuts")
        self._shortcut_hint.setWordWrap(True)

        accept = QPushButton("Accept")
        accept_next = QPushButton("Accept && Next")
        accept_resolve = QPushButton("Accept && Reject Rest")
        reject_others = QPushButton("Reject Other Options")
        reject = QPushButton("Reject")
        defer = QPushButton("Defer")
        reverse = QPushButton("Reverse acceptance")
        refresh = QPushButton("Refresh")
        more = QPushButton("Load more")
        self._generate = QPushButton("Generate selected")
        self._resources = QPushButton("AI Resources")
        self._observation_history = QPushButton("Observation History")
        self._cancel_generation = QPushButton("Cancel generation")
        self._cancel_generation.setEnabled(False)
        self._progress = QProgressBar()
        self._progress.setVisible(False)
        accept.clicked.connect(lambda: self._apply("accept"))
        accept_next.clicked.connect(lambda: self._apply("accept_next"))
        accept_resolve.clicked.connect(self._accept_and_reject_rest)
        reject_others.clicked.connect(self._reject_other_options)
        reject.clicked.connect(lambda: self._apply("reject"))
        defer.clicked.connect(lambda: self._apply("defer"))
        reverse.clicked.connect(lambda: self._apply("reverse"))
        refresh.clicked.connect(self.refresh)
        more.clicked.connect(self.load_more)
        self._generate.clicked.connect(self.generate_selected)
        self._resources.clicked.connect(self.resources_requested.emit)
        self._observation_history.clicked.connect(self._open_observation_history)
        self._cancel_generation.clicked.connect(self.cancel_generation)
        self._generate.setEnabled(self._generation_service is not None)
        self._resources.setEnabled(self._resource_service is not None)

        filters = QHBoxLayout()
        filters.addWidget(QLabel("State"))
        filters.addWidget(self._state_filter)
        filters.addWidget(QLabel("Confidence"))
        filters.addWidget(self._confidence_filter)
        filters.addWidget(self._current_photo_only)
        filters.addStretch(1)
        filters.addWidget(refresh)

        detail_panel = QWidget()
        detail_layout = QVBoxLayout(detail_panel)
        detail_layout.setContentsMargins(0, 0, 0, 0)
        detail_layout.addWidget(self._preview, 2)
        detail_layout.addWidget(self._preview_meta)
        detail_layout.addWidget(self._detail, 3)
        splitter = QSplitter(Qt.Orientation.Horizontal)
        splitter.addWidget(self._list)
        splitter.addWidget(detail_panel)
        splitter.setStretchFactor(0, 1)
        splitter.setStretchFactor(1, 2)

        actions = QHBoxLayout()
        for button in (accept, accept_next, accept_resolve, reject_others, reject, defer, reverse, more, self._generate, self._cancel_generation, self._observation_history, self._resources):
            actions.addWidget(button)
        actions.addStretch(1)

        layout = QVBoxLayout(self)
        layout.addWidget(self._model_status)
        layout.addWidget(self._queue_status)
        layout.addLayout(filters)
        layout.addWidget(splitter, 1)
        layout.addLayout(actions)
        layout.addWidget(self._progress)
        layout.addWidget(self._status)
        layout.addWidget(self._shortcut_hint)

        accept.setToolTip("Accept suggestion (A)")
        accept_next.setToolTip("Accept suggestion and move to the next item (Shift+Enter)")
        reject.setToolTip("Reject suggestion (R)")
        defer.setToolTip("Defer suggestion (D)")
        reverse.setToolTip("Reverse acceptance (Ctrl+Z)")

        QShortcut(QKeySequence("A"), self, activated=lambda: self._apply("accept"))
        QShortcut(QKeySequence("Shift+Return"), self, activated=lambda: self._apply("accept_next"))
        QShortcut(QKeySequence("O"), self, activated=self._open_observation_history)
        QShortcut(QKeySequence("R"), self, activated=lambda: self._apply("reject"))
        QShortcut(QKeySequence("D"), self, activated=lambda: self._apply("defer"))
        QShortcut(QKeySequence("Ctrl+Z"), self, activated=lambda: self._apply("reverse"))
        QShortcut(QKeySequence(Qt.Key.Key_J), self, activated=self._select_next)
        QShortcut(QKeySequence(Qt.Key.Key_K), self, activated=self._select_previous)
        self.refresh()

    @property
    def observation_service(self) -> ObservationIntelligenceService | None:
        return self._observation_service

    @property
    def knowledge_engine(self) -> KnowledgeEngine | None:
        return self._knowledge_engine

    @property
    def thumbnail_service(self) -> object | None:
        return self._thumbnail_service

    @property
    def ecology_service(self) -> object | None:
        return self._ecology_service

    @property
    def resource_service(self) -> LocalAIResourceService | None:
        return self._resource_service

    @property
    def regional_service(self) -> object | None:
        return self._regional_service

    @property
    def regional_acquisition_service(self) -> object | None:
        return self._regional_acquisition_service

    @property
    def suggestion_service(self) -> SuggestionService:
        return self._service

    @property
    def generation_busy(self) -> bool:
        return self._generation_thread is not None and self._generation_thread.isRunning()

    @Slot()
    def generate_selected(self) -> None:
        if not self._components.enabled('bioclip'):
            QMessageBox.information(self, 'BioCLIP disabled', 'Enable BioCLIP / OpenCLIP under Settings → Resource Components first.')
            return
        if self._generation_service is None or self.generation_busy:
            return
        asset_ids = self._selected_asset_ids()
        if not asset_ids:
            QMessageBox.information(
                self,
                "BioCLIP suggestions",
                "Select one or more photographs in the Library, then return to AI Review.",
            )
            return
        thread = QThread(self)
        worker = _GenerationWorker(self._generation_service, asset_ids)
        worker.moveToThread(thread)
        thread.started.connect(worker.run)
        worker.progress.connect(self._generation_progress)
        worker.succeeded.connect(self._generation_succeeded)
        worker.failed.connect(self._generation_failed)
        worker.finished.connect(thread.quit)
        worker.finished.connect(worker.deleteLater)
        thread.finished.connect(thread.deleteLater)
        thread.finished.connect(self._generation_finished)
        self._generation_thread = thread
        self._generation_worker = worker
        self._generate.setEnabled(False)
        self._cancel_generation.setEnabled(True)
        self._progress.setVisible(True)
        self._progress.setRange(0, max(1, len(asset_ids)))
        self._progress.setValue(0)
        self._status.setText(f"Starting local BioCLIP inference for {len(asset_ids)} asset(s)…")
        thread.start()

    @Slot()
    def cancel_generation(self) -> None:
        if self._generation_worker is not None:
            self._generation_worker.cancel()
            self._status.setText("Cancellation requested…")
            self._cancel_generation.setEnabled(False)

    @Slot(int, int, str)
    def _generation_progress(self, current: int, total: int, message: str) -> None:
        self._progress.setRange(0, max(1, total))
        self._progress.setValue(current)
        self._status.setText(message)

    @Slot(object)
    def _generation_succeeded(self, result: object) -> None:
        if not isinstance(result, SuggestionGenerationResult):
            self._status.setText("BioCLIP generation returned an invalid result.")
            return
        self._status.setText(
            f"BioCLIP complete: {result.completed_assets}/{result.requested} assets, "
            f"{result.suggestions_created} suggestions, {len(result.failed)} failures."
        )
        self.refresh()

    @Slot(str)
    def _generation_failed(self, message: str) -> None:
        self._status.setText(message)
        QMessageBox.warning(self, "BioCLIP generation failed", message)
        self.refresh()

    @Slot()
    def _generation_finished(self) -> None:
        self._generation_thread = None
        self._generation_worker = None
        self._generate.setEnabled(self._components.enabled('bioclip') and self._generation_service is not None)
        self._cancel_generation.setEnabled(False)
        self._progress.setVisible(False)

    def refresh(self, *_args: object) -> None:
        enabled = self._components.enabled('bioclip')
        self._generate.setEnabled(enabled and self._generation_service is not None and not self.generation_busy)
        if not enabled:
            self._model_status.setText('<b>BioCLIP / OpenCLIP:</b> disabled under Settings → Resource Components. Installed models and prior results remain available.')
        try:
            overview = self._service.overview()
            if not enabled:
                pass
            elif overview.active_model_identity is None:
                self._model_status.setText(
                    "<b>BioCLIP model:</b> no active model package. "
                    "Install and activate a local model package before generating suggestions."
                )
            else:
                self._model_status.setText(
                    "<b>Active model:</b> "
                    f"{escape(overview.active_model_identity)} {escape(overview.active_model_version or '')} "
                    f"· {escape(overview.active_variant_identity or '')} "
                    f"· prompt set: {escape(overview.active_prompt_set or 'none')}"
                )
            counts = dict(overview.suggestion_counts)
            self._queue_status.setText(
                "<b>Review queues:</b> "
                + " · ".join(
                    f"{state} {counts.get(state, 0)}"
                    for state in ("pending", "deferred", "accepted", "rejected", "superseded")
                )
                + (
                    ""
                    if overview.latest_run_outcome is None
                    else f" · latest inference: {escape(overview.latest_run_outcome)} "
                    f"({overview.latest_run_completed} completed, {overview.latest_run_failed} failed)"
                )
            )
        except Exception as exc:
            self._model_status.setText(f"<b>AI status unavailable:</b> {escape(str(exc))}")
            self._queue_status.clear()

        confidence = self._confidence_filter.currentText()
        filter_value = ReviewFilter(
            state=self._state_filter.currentText(),
            confidence=() if confidence == "all" else (confidence,),
        )
        if self._current_photo_only.isChecked() and self._current_asset_public_id:
            state = self._model.refresh_asset(self._current_asset_public_id, filter_value)
        else:
            state = self._model.refresh(filter_value)
        self._render(state.items, replace=True)
        if state.error:
            self._status.setText(state.error)
        elif state.items:
            self._status.setText(f"{len(state.items)} suggestions shown")
        else:
            self._status.setText(
                f"No {self._state_filter.currentText()} suggestions match the current filter."
            )
            self._detail.setHtml(
                "<h3>No suggestions</h3>"
                "<p>BioCLIP evidence is stored separately from confirmed catalog taxonomy. "
                "Suggestions will appear here after a local inference run has completed.</p>"
            )

    def load_more(self) -> None:
        before = len(self._model.state.items)
        state = self._model.load_more()
        self._render(state.items[before:], replace=False)
        self._status.setText(state.error or f"{len(state.items)} suggestions shown")

    def _render(self, items: tuple[SuggestionProjection, ...], *, replace: bool) -> None:
        selected = self._selected_id()
        if replace:
            self._list.clear()
            self._items_by_id.clear()
        for projection in items:
            self._items_by_id[projection.public_id] = projection
            label = projection.candidate_label or "Unknown"
            score = projection.calibrated_score
            score_text = "—" if score is None else f"{score:.3f}"
            item = QListWidgetItem(
                f"#{projection.rank}  {label}  ·  {score_text}  ·  {projection.confidence_band.value}"
            )
            item.setData(Qt.ItemDataRole.UserRole, projection.public_id)
            item.setToolTip(f"Asset {projection.asset_public_id}")
            self._list.addItem(item)
            if projection.public_id == selected:
                self._list.setCurrentItem(item)
        if self._list.currentRow() < 0 and self._list.count():
            self._list.setCurrentRow(0)

    def _selection_changed(self, current: QListWidgetItem | None, _previous: QListWidgetItem | None) -> None:
        if current is None:
            return
        public_id = str(current.data(Qt.ItemDataRole.UserRole))
        projection = self._items_by_id.get(public_id)
        if projection is not None:
            self._current_asset_public_id = projection.asset_public_id
        self._model.select(public_id)
        try:
            region_code = None if self._regional_service is None else self._regional_service.primary_region_code()
            detail = self._service.detail(public_id, region_code=region_code)
            evidence = None if self._regional_service is None else self._regional_service.evidence_for_taxon(detail.suggestion.candidate_taxon_public_id)
            personal = (
                self._knowledge_engine.observation_context(detail.suggestion.candidate_taxon_public_id)
                if self._knowledge_engine is not None
                else (None if self._observation_service is None else self._observation_service.context_for_taxon(detail.suggestion.candidate_taxon_public_id))
            )
            ecology = None if self._ecology_service is None else self._ecology_service.for_taxon(detail.suggestion.candidate_taxon_public_id)
            self._load_preview(detail)
            enrichment = None if self._knowledge_engine is None else self._knowledge_engine.asset_enrichment(detail.suggestion.asset_public_id)
            self._detail.setHtml(self._detail_html(detail, evidence, personal, ecology) + self._enrichment_html(enrichment))
        except Exception as exc:
            self._detail.setPlainText(str(exc))

    def _load_preview(self, detail: SuggestionDetail) -> None:
        self._preview.clear()
        self._preview.setText("Loading photograph…")
        path = Path(detail.asset_primary_path) if detail.asset_primary_path else None
        cached = Path(detail.asset_thumbnail_path) if detail.asset_thumbnail_path else None
        data = None
        try:
            if self._thumbnail_service is not None:
                data = self._thumbnail_service.load(source_path=path, cached_path=cached, max_size=1200)
        except Exception:
            data = None
        pixmap = QPixmap()
        if data and pixmap.loadFromData(data):
            scaled = pixmap.scaled(self._preview.size(), Qt.AspectRatioMode.KeepAspectRatio, Qt.TransformationMode.SmoothTransformation)
            self._preview.setPixmap(scaled)
        else:
            self._preview.setText("Preview unavailable")
        filename = "—" if path is None else path.name
        captured = detail.asset_capture_local_text or ""
        if not captured and detail.asset_capture_time_utc_us is not None:
            captured = datetime.fromtimestamp(detail.asset_capture_time_utc_us / 1_000_000, tz=timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")
        self._preview_meta.setText(f"{filename}" + (f"  ·  Captured {captured}" if captured else ""))

    @staticmethod
    def _enrichment_html(dossier: object | None) -> str:
        if dossier is None:
            return ""
        analyses = tuple(getattr(dossier, "analyses", ()))
        candidates = tuple(getattr(dossier, "candidates", ()))
        engines = tuple(getattr(dossier, "engine_ids", ()))
        latest = getattr(dossier, "latest_completed_at_us", None)
        latest_text = AIReviewWorkspace._format_observation_time(latest)
        engine_text = ", ".join(engines) or "—"
        return (
            "<h3>Photo enrichment history</h3>"
            f"<p><b>{len(analyses)}</b> analysis run(s) · <b>{len(candidates)}</b> normalized candidate(s)<br>"
            f"Engines: {escape(engine_text)}<br>Latest completed: {escape(latest_text)}</p>"
        )

    @staticmethod
    def _format_observation_time(value: int | None) -> str:
        if value is None:
            return "—"
        return datetime.fromtimestamp(value / 1_000_000, tz=timezone.utc).strftime("%Y-%m-%d")

    @staticmethod
    def _why_html(detail: SuggestionDetail, evidence: object | None, personal: object | None, ecology: object | None) -> str:
        suggestion = detail.suggestion
        points: list[str] = []
        score = suggestion.calibrated_score if suggestion.calibrated_score is not None else suggestion.raw_score
        points.append(f"The local visual model ranked this candidate #{suggestion.rank} with a score of {score:.3f} ({suggestion.confidence_band.value}).")
        if evidence is not None and getattr(evidence, "label", None):
            points.append(f"Regional occurrence evidence: {getattr(evidence, 'label')}.")
        if ecology is not None:
            months = set(getattr(ecology, "seasonal_months", ()))
            capture_us = detail.asset_capture_time_utc_us
            if capture_us is not None and months:
                month = datetime.fromtimestamp(capture_us / 1_000_000, tz=timezone.utc).month
                points.append(f"The photograph was captured in month {month}; this month is {'inside' if month in months else 'outside'} the installed seasonal range.")
            habitats = tuple(getattr(ecology, "habitats", ()))
            if habitats:
                points.append("Known habitats in the installed context include " + ", ".join(habitats) + ".")
            status = getattr(ecology, "conservation_status", None)
            if status:
                points.append(f"Installed conservation context: {status}. This is informational and does not change identification confidence.")
        if personal is not None:
            count = int(getattr(personal, "confirmed_observations", 0))
            points.append("This would be your first confirmed observation." if count == 0 else f"You previously confirmed this taxon {count} time(s).")
        items = "".join(f"<li>{escape(point)}</li>" for point in points)
        return (
            "<h3>Why this suggestion?</h3><ul>" + items + "</ul>"
            "<p><i>Feature-level visual explanations (for example plumage, bill shape, or leaf structure) are not available from the installed BioCLIP package, so NatureAI does not invent them.</i></p>"
        )

    @staticmethod
    def _detail_html(detail: SuggestionDetail, evidence: object | None = None, personal: object | None = None, ecology: object | None = None) -> str:
        suggestion = detail.suggestion
        fields = (
            ("Asset", suggestion.asset_public_id),
            ("Title", detail.asset_title or ""),
            ("Candidate", detail.taxon_scientific_name or suggestion.candidate_label or "Unknown"),
            ("Rank", detail.taxon_rank or suggestion.taxonomic_level or ""),
            ("Confidence", suggestion.confidence_band.value),
            ("Raw score", f"{suggestion.raw_score:.6f}"),
            ("Calibrated score", "" if suggestion.calibrated_score is None else f"{suggestion.calibrated_score:.6f}"),
            ("Occurrence", detail.regional_occurrence_status or ""),
            ("Regional evidence", "" if evidence is None else getattr(evidence, "label", "")),
            ("Occurrence source", "" if evidence is None else (getattr(evidence, "source", None) or "")),
            ("Model", detail.model_variant_public_id),
            ("Preprocessing", detail.preprocessing_identity),
            ("Provider", detail.execution_provider),
            ("Precision", detail.precision or ""),
            ("Prompt set", " / ".join(filter(None, (detail.prompt_set_identity, detail.prompt_set_version)))),
            ("Inference run", detail.inference_run_public_id),
        )
        rows = "".join(
            f"<tr><th align='left'>{escape(name)}</th><td>{escape(str(value))}</td></tr>"
            for name, value in fields
        )
        personal_html = ""
        if personal is not None:
            count = int(getattr(personal, "confirmed_observations", 0))
            photos = int(getattr(personal, "evidence_photos", 0))
            countries = ", ".join(getattr(personal, "country_codes", ())) or "—"
            if count == 0:
                summary = "This would be your first confirmed observation."
            else:
                summary = f"Previously confirmed {count} time(s), supported by {photos} photograph(s)."
            first_date = AIReviewWorkspace._format_observation_time(getattr(personal, "first_observed_at_us", None))
            last_date = AIReviewWorkspace._format_observation_time(getattr(personal, "last_observed_at_us", None))
            personal_html = (
                "<h3>Personal observation context</h3>"
                f"<p><b>{escape(summary)}</b></p>"
                f"<p>First observed: {escape(first_date)}<br>Last observed: {escape(last_date)}<br>Countries: {escape(countries)}</p>"
            )
        ecology_html = ""
        if ecology is not None:
            months = ", ".join(str(x) for x in getattr(ecology, "seasonal_months", ())) or "—"
            habitats = ", ".join(getattr(ecology, "habitats", ())) or "—"
            source = " / ".join(filter(None, (getattr(ecology, "source_name", None), getattr(ecology, "source_version", None))))
            ecology_html = (
                "<h3>Conservation & ecological context</h3>"
                f"<p>Conservation status: <b>{escape(getattr(ecology, 'conservation_status', None) or '—')}</b><br>"
                f"Seasonal months: {escape(months)}<br>Migration: {escape(getattr(ecology, 'migration_status', None) or '—')}<br>"
                f"Habitats: {escape(habitats)}<br>Source: {escape(source or '—')}</p>"
            )
        why_html = AIReviewWorkspace._why_html(detail, evidence, personal, ecology)
        return (
            f"<table cellspacing='6'>{rows}</table>"
            + why_html + personal_html + ecology_html +
            "<h3>Evidence provenance</h3>"
            f"<pre>{escape(suggestion.provenance_json)}</pre>"
            "<p><b>Accepting a suggestion creates human-confirmed taxonomy metadata. "
            "Rejecting or deferring it changes only the AI review state.</b></p>"
        )

    @Slot(bool)
    def _photo_filter_toggled(self, checked: bool) -> None:
        if checked and self._current_asset_public_id is None:
            selected = self._selected_id()
            projection = None if selected is None else self._items_by_id.get(selected)
            if projection is not None:
                self._current_asset_public_id = projection.asset_public_id
        self.refresh()

    @Slot()
    def _accept_and_reject_rest(self) -> None:
        public_id = self._selected_id()
        if public_id is None:
            return
        projection = self._items_by_id.get(public_id)
        try:
            was_first = False
            if projection is not None and self._observation_service is not None:
                context = self._observation_service.context_for_taxon(projection.candidate_taxon_public_id)
                was_first = bool(context is not None and context.is_first_observation)
            result = self._service.accept_and_reject_others(
                public_id,
                action_id_factory=self._action_id_factory,
                now_us=self._now_us(),
            )
            rejected = max(0, len(result.reviewed) - 1)
            message = f"Accepted this taxonomy and rejected {rejected} other option(s) for the photograph."
            if was_first:
                message += "\n\nThis is your first confirmed observation of this taxon."
            QMessageBox.information(self, "Photograph taxonomy resolved", message)
            self.refresh()
        except Exception as exc:
            QMessageBox.critical(self, "AI Review", str(exc))

    @Slot()
    def _reject_other_options(self) -> None:
        public_id = self._selected_id()
        if public_id is None:
            return
        try:
            result = self._service.reject_other_suggestions(
                public_id,
                action_id_factory=self._action_id_factory,
                now_us=self._now_us(),
            )
            QMessageBox.information(
                self,
                "Other taxonomy options rejected",
                f"Rejected {len(result.reviewed)} remaining option(s) for this photograph.",
            )
            self.refresh()
        except Exception as exc:
            QMessageBox.critical(self, "AI Review", str(exc))

    @Slot()
    def _open_observation_history(self) -> None:
        public_id = self._selected_id()
        projection = None if public_id is None else self._items_by_id.get(public_id)
        if projection is not None and projection.candidate_taxon_public_id:
            self.observation_requested.emit(projection.candidate_taxon_public_id)

    def _apply(self, action: str) -> None:
        public_id = self._selected_id()
        if public_id is None:
            return
        try:
            kwargs = {"action_public_id": self._action_id_factory(), "now_us": self._now_us()}
            if action in {"accept", "accept_next"}:
                was_first = False
                projection = self._items_by_id.get(public_id)
                before = None
                if projection is not None and self._observation_service is not None:
                    before = self._observation_service.context_for_taxon(projection.candidate_taxon_public_id)
                    was_first = bool(before is not None and before.is_first_observation)
                self._service.accept(public_id, **kwargs)
                after = None
                if projection is not None and self._observation_service is not None:
                    after = self._observation_service.context_for_taxon(projection.candidate_taxon_public_id)
                if after is not None:
                    heading = "First observation" if was_first else "Observation updated"
                    text = (
                        ("This is your first confirmed observation of this taxon.\n\n" if was_first else "")
                        + f"Personal total: {after.confirmed_observations} observation(s)\n"
                        + f"Supporting photographs: {after.evidence_photos}\n"
                        + f"Countries: {', '.join(after.country_codes) or '—'}"
                    )
                    QMessageBox.information(self, heading, text)
                if action == "accept_next":
                    self.refresh()
                    self._select_next()
                    return
            elif action == "reject":
                self._service.reject(public_id, **kwargs)
            elif action == "defer":
                self._service.defer(public_id, **kwargs)
            elif action == "reverse":
                self._service.reverse_acceptance(public_id, **kwargs)
            else:
                raise ValueError(f"unsupported action: {action}")
            self.refresh()
        except Exception as exc:
            QMessageBox.critical(self, "AI Review", str(exc))

    def _selected_id(self) -> str | None:
        item = self._list.currentItem()
        return None if item is None else str(item.data(Qt.ItemDataRole.UserRole))

    def _select_next(self) -> None:
        if self._list.count():
            self._list.setCurrentRow(min(self._list.count() - 1, self._list.currentRow() + 1))

    def _select_previous(self) -> None:
        if self._list.count():
            self._list.setCurrentRow(max(0, self._list.currentRow() - 1))
