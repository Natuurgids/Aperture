Aperture V3Final

Release: V3Final
Version: 3.0.0
Engine: NatureAI with integrated BioCLIP Tree of Life

Aperture 3.0 is the production release validated through clean installation, existing-library opening, new-library creation, photograph import, NatureAI inference, AI Review acceptance, restart persistence, backup and restore, uninstall, and legacy cleanup.

Start with QUICKSTART_WINDOWS.md. A Full AI installation installs, validates, and activates the BioCLIP model, pybioclip runtime, TreeOfLifeClassifier, and matching Tree-of-Life resources as one NatureAI engine. GBIF remains an optional independent taxonomy and enrichment resource.

For existing installations, open Maintenance Center and run Repair Full AI / NatureAI Engine, then verify that AI Resources reports the Tree of Life classifier ready before analysing photographs.
