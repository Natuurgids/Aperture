# Aperture V3Final Release-Readiness QA

The production release was accepted after all critical end-to-end workflows passed on the Windows reference installation. Repeat this checklist for every redistributed installer or materially changed dependency set.

## Required acceptance workflows

1. Complete a clean installation and verify the selected application and data roots.
2. Open an existing library and create a new library.
3. Import representative photographs, including duplicates and one damaged file.
4. Run NatureAI/BioCLIP inference and confirm suggestions are produced.
5. Review and accept suggestions, restart Aperture, and verify persistence.
6. Create and verify a backup, restore it, and run a Health Center check.
7. Verify uninstall and the report-first legacy cleanup utility.
8. Toggle NatureAI diagnostic logging and verify the configured log path follows the data root.

## Accessibility and UI

- Complete primary workflows using keyboard only.
- Verify accessible names with Windows Narrator.
- Test 100%, 150%, and 200% display scaling.
- Confirm focus visibility, dialog ordering, and readable errors.

## Performance and soak

- Measure startup and first-page display with representative libraries.
- Run an extended browse/import/AI workload and observe memory and responsiveness.
- Record backup, restore, search, and update timings.
- Confirm background work can be cancelled or recovered at documented safe checkpoints.

Record hardware, data size, timings, failures, and deviations in `VALIDATION.md`.
