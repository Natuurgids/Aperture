# Aperture V3Final documentation

This documentation set describes Aperture 3.0.0 and the integrated NatureAI BioCLIP Tree-of-Life engine.

## Start here

- [Installation](getting-started/installation.md)
- [Quick start](getting-started/quick-start.md)
- [User guide](user-guide/README.md)
- [AI and resources](user-guide/ai-and-resources.md)
- [Troubleshooting](operations/troubleshooting.md)
- [Backup and recovery](operations/backup-recovery.md)
- [Maintenance Center](operations/maintenance-center.md)
- [Developer guide](developer/README.md)
- [Release process](developer/release-process.md)

## Release identity

The production release identity is **Aperture V3Final**, package version **3.0.0**. Confirm `VERSION`, `pyproject.toml`, package `__version__`, About/CLI identity, release notes, manifest, and archive name before distribution.

## Operations

- [Release-readiness QA](operations/release-readiness-qa.md)
- [Startup performance](operations/startup-performance.md)
- [Offline updates](operations/offline-updates.md)
- [Health Center](operations/health-center.md)
