"""Stable ports used by catalog presentation and editing services."""
from __future__ import annotations
from dataclasses import dataclass
from typing import Protocol

@dataclass(frozen=True, slots=True)
class AssetGridRow:
    public_id: str
    internal_id: int
    revision: int
    title: str | None
    rating: int | None
    color_label: str | None
    pick_state: str | None
    capture_time_utc_us: int | None
    primary_file_public_id: str | None
    primary_path: str | None
    thumbnail_path: str | None
    pixel_width: int | None
    pixel_height: int | None

@dataclass(frozen=True, slots=True)
class AssetDetail:
    public_id: str
    revision: int
    title: str | None
    caption: str | None
    user_notes: str | None
    rating: int | None
    color_label: str | None
    pick_state: str | None
    primary_path: str | None
    mime_type: str | None
    format_name: str | None
    pixel_width: int | None
    pixel_height: int | None
    tags: tuple[str, ...]

@dataclass(frozen=True, slots=True)
class AssetPage:
    rows: tuple[AssetGridRow, ...]
    next_cursor: int | None
    total_count: int

@dataclass(frozen=True, slots=True)
class MetadataPatch:
    title: str | None
    caption: str | None
    user_notes: str | None
    rating: int | None
    color_label: str | None
    pick_state: str | None

@dataclass(frozen=True, slots=True)
class MetadataChangeResult:
    public_id: str
    previous_revision: int
    new_revision: int
    before: MetadataPatch
    after: MetadataPatch

class CatalogReadPort(Protocol):
    def page_assets(self, *, limit: int, after_id: int | None = None) -> AssetPage: ...
    def page_assets_by_public_ids(self, public_ids: tuple[str, ...]) -> AssetPage: ...
    def get_asset_detail(self, public_id: str) -> AssetDetail | None: ...

class CatalogEditPort(Protocol):
    def update_metadata(self, *, public_id: str, expected_revision: int, patch: MetadataPatch, modified_at_us: int) -> MetadataChangeResult: ...
    def update_metadata_and_tags(
        self,
        *,
        public_id: str,
        expected_revision: int,
        patch: MetadataPatch,
        tag_names: tuple[str, ...],
        modified_at_us: int,
    ) -> MetadataChangeResult: ...
    def set_tags(self, *, public_ids: tuple[str, ...], tag_names: tuple[str, ...], modified_at_us: int) -> None: ...
