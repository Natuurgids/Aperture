"""Ports used by the import application service."""
from __future__ import annotations
from pathlib import Path
from typing import Callable, Iterable, Protocol
from natureai_next.domain.importing import Fingerprint, SourceFile

CancelCheck = Callable[[], None]

class SourceScanner(Protocol):
    def scan(self, roots: Iterable[Path], *, recursive: bool, cancel: CancelCheck | None = None) -> tuple[SourceFile, ...]: ...

class FileFingerprinter(Protocol):
    def fingerprint(self, path: Path, *, cancel: CancelCheck | None = None) -> Fingerprint: ...

class ManagedFileStore(Protocol):
    def place_verified(self, source: Path, sha256: str, *, cancel: CancelCheck | None = None) -> Path: ...
    def purge(self, path: Path) -> None: ...
