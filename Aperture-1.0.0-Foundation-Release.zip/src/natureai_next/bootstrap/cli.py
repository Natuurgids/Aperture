"""Stable desktop launcher command-line boundary."""

from __future__ import annotations

import argparse
import logging
import time

from natureai_next.bootstrap.startup_timing import StartupTimeline
from pathlib import Path
from typing import Sequence

from natureai_next.bootstrap.container import build_foundation_container
from natureai_next.shared.errors import NatureAIError
from natureai_next.infrastructure.filesystem.library_lock import LibraryLockedError


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="natureai-next")
    parser.add_argument("--library", type=Path, help="Library to open")
    parser.add_argument("--config-root", type=Path, help="Configuration root override")
    parser.add_argument("--safe-mode", action="store_true", help="Disable third-party plugins")
    parser.add_argument("--diagnostics", action="store_true", help="Start in diagnostics mode")
    parser.add_argument("--no-update-check", action="store_true", help="Disable update checks for this session")
    parser.add_argument("--log-level", choices=("DEBUG", "INFO", "WARNING", "ERROR"))
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    started_at = time.perf_counter()
    startup = StartupTimeline(started_at=started_at)
    startup.mark("process-started")
    args = build_parser().parse_args(argv)
    overrides: dict[str, object] = {}
    if args.log_level:
        overrides["application"] = {"log_level": args.log_level}
    if args.no_update_check:
        application = dict(overrides.get("application", {}))
        application["update_check_policy"] = "disabled"
        overrides["application"] = application
    try:
        container = build_foundation_container(config_root=args.config_root, session_overrides=overrides)
    except NatureAIError as exc:
        print(exc.descriptor.summary)
        return 2
    startup.mark("foundation-ready")
    logging.getLogger("natureai_next.bootstrap").info(
        "Foundation initialized",
        extra={"context": {"safe_mode": args.safe_mode, "diagnostics": args.diagnostics, "elapsed_ms": round((time.perf_counter() - started_at) * 1000, 1)}},
    )
    if args.library is None:
        print(f"NatureAI Next ready at {container.paths.local_root}; provide --library to open the desktop")
        return 0
    from natureai_next.application.library_service import LibraryService
    service = LibraryService(container.clock, container.uuid_generator)
    try:
        opened_context = service.open(args.library)
    except LibraryLockedError as exc:
        owner = exc.owner
        detail = "Aperture is already open with this library."
        if owner is not None:
            detail += f"\n\nProcess ID: {owner.pid}\nComputer: {owner.host}"
        print(detail)
        return 3
    startup.mark("library-opened")
    logging.getLogger("natureai_next.bootstrap").info("Library opened", extra={"context": {"elapsed_ms": round((time.perf_counter() - started_at) * 1000, 1)}})
    with opened_context as opened:
        from natureai_next.application.backup import LibraryBackupService
        from natureai_next.application.health import LibraryHealthService
        from natureai_next.application.catalog_browsing import CatalogEditService, CatalogQueryService
        from natureai_next.application.ai_generation import LocalSuggestionGenerationService, SqliteSuggestionGenerationSource
        from natureai_next.application.ai_resources import LocalAIResourceService
        from natureai_next.application.ai_review import SuggestionService
        from natureai_next.application.import_service import ImportService
        from natureai_next.application.search import LibraryViewsService, QuickSearchService
        from natureai_next.application.regional import RegionalProfileService
        from natureai_next.application.regional_acquisition import RegionalKnowledgeAcquisitionService
        from natureai_next.application.observation_intelligence import ObservationIntelligenceService
        from natureai_next.application.ecology import EcologicalContextService
        from natureai_next.infrastructure.database.ai import SqliteAIRepository
        from natureai_next.infrastructure.database.ai_generation import SqliteTaxonomyEmbeddingStore
        from natureai_next.infrastructure.database.ai_review import SqliteSuggestionStore
        from natureai_next.infrastructure.database.catalog_gui import SqliteCatalogGuiAdapter
        from natureai_next.infrastructure.database.regional import SqliteRegionalProfileStore
        from natureai_next.infrastructure.database.observation_intelligence import SqliteObservationIntelligenceAdapter
        from natureai_next.infrastructure.database.ecology import SqliteEcologicalContextStore
        from natureai_next.infrastructure.database.search import (
            SqliteCollectionAdapter, SqliteSavedSearchAdapter, SqliteSearchAdapter,
        )
        from natureai_next.infrastructure.database.unit_of_work import SqliteUnitOfWork
        from natureai_next.infrastructure.filesystem.importing import (
            DirectorySourceScanner,
            ShardedManagedFileStore,
            StreamingFileFingerprinter,
        )
        from natureai_next.infrastructure.imaging.catalog_thumbnails import PillowCatalogThumbnailProvider
        from natureai_next.infrastructure.imaging.pillow_adapter import PillowImageDecoder
        from natureai_next.infrastructure.metadata.pillow_reader import PillowMetadataReader
        from natureai_next.ui.presentation.ai_review import AIReviewModel
        from natureai_next.ui.qt.ai_review import AIReviewWorkspace
        from natureai_next.ui.qt.application import run_desktop

        fingerprinter = StreamingFileFingerprinter()
        import_service = ImportService(
            uow_factory=lambda: SqliteUnitOfWork(opened.connection_factory),
            scanner=DirectorySourceScanner(),
            fingerprinter=fingerprinter,
            managed_store=ShardedManagedFileStore(opened.layout.managed_originals, fingerprinter),
            decoder=PillowImageDecoder(),
            metadata_reader=PillowMetadataReader(),
            clock=container.clock,
            ids=container.uuid_generator,
        )
        catalog_adapter = SqliteCatalogGuiAdapter(opened.connection_factory)
        catalog_service = CatalogQueryService(catalog_adapter)
        catalog_edit_service = CatalogEditService(catalog_adapter, container.clock)
        search_adapter = SqliteSearchAdapter(opened.connection_factory)
        search_service = QuickSearchService(search_adapter)
        views_service = LibraryViewsService(
            saved=SqliteSavedSearchAdapter(opened.connection_factory),
            collections=SqliteCollectionAdapter(opened.connection_factory),
            search=search_adapter,
            clock=container.clock,
            ids=container.uuid_generator,
        )
        thumbnail_service = PillowCatalogThumbnailProvider(
            thumbnail_root=opened.layout.thumbnails,
            preview_root=opened.layout.previews,
            library_root=opened.layout.root,
        )
        suggestion_service = SuggestionService(SqliteSuggestionStore(opened.connection_factory))
        observation_intelligence_service = ObservationIntelligenceService(
            SqliteObservationIntelligenceAdapter(opened.connection_factory)
        )
        ecology_service = EcologicalContextService(
            SqliteEcologicalContextStore(opened.connection_factory),
            now_us=lambda: int(container.clock.now_utc().timestamp() * 1_000_000),
        )
        resource_service = LocalAIResourceService(
            factory=opened.connection_factory,
            models_root=container.paths.models_dir,
            id_factory=lambda: str(container.uuid_generator.new_uuid()),
            now_us=lambda: int(container.clock.now_utc().timestamp() * 1_000_000),
        )
        regional_service = RegionalProfileService(
            SqliteRegionalProfileStore(opened.connection_factory),
            now_us=lambda: int(container.clock.now_utc().timestamp() * 1_000_000),
        )
        regional_workspace = Path("D:/NatureAI-Models") if Path("D:/NatureAI-Models").exists() else container.paths.models_dir.parent
        regional_acquisition_service = RegionalKnowledgeAcquisitionService(
            resource_service, workspace=regional_workspace
        )
        generation_service = LocalSuggestionGenerationService(
            source=SqliteSuggestionGenerationSource(opened.connection_factory),
            ai_repository=SqliteAIRepository(opened.connection_factory),
            taxonomy_embeddings=SqliteTaxonomyEmbeddingStore(opened.connection_factory),
            suggestions=suggestion_service,
            id_factory=lambda: str(container.uuid_generator.new_uuid()),
            now_us=lambda: int(container.clock.now_utc().timestamp() * 1_000_000),
        )
        def ai_review_workspace_factory(
            selected_asset_ids: object = lambda: (),
        ) -> AIReviewWorkspace:
            if not callable(selected_asset_ids):
                raise TypeError("selected asset provider must be callable")
            return AIReviewWorkspace(
                model=AIReviewModel(suggestion_service),
                service=suggestion_service,
                action_id_factory=lambda: str(container.uuid_generator.new_uuid()),
                now_us=lambda: int(container.clock.now_utc().timestamp() * 1_000_000),
                generation_service=generation_service,
                selected_asset_ids=selected_asset_ids,
                resource_service=resource_service,
                regional_service=regional_service,
                regional_acquisition_service=regional_acquisition_service,
                observation_service=observation_intelligence_service,
                ecology_service=ecology_service,
                thumbnail_service=thumbnail_service,
            )
        session_path = opened.layout.root / "session.json"
        startup.mark("desktop-services-composed")
        logging.getLogger("natureai_next.bootstrap").info("Desktop services composed", extra={"context": {"elapsed_ms": round((time.perf_counter() - started_at) * 1000, 1)}})
        return run_desktop(
            library_name=opened.manifest.display_name,
            session_path=session_path,
            import_service=import_service,
            catalog_service=catalog_service,
            thumbnail_service=thumbnail_service,
            catalog_edit_service=catalog_edit_service,
            search_service=search_service,
            views_service=views_service,
            ai_review_workspace_factory=ai_review_workspace_factory,
            backup_service=LibraryBackupService(opened.backup_database, library_name=opened.manifest.display_name),
            default_backup_directory=opened.layout.backups,
            health_service=LibraryHealthService(
                layout=opened.layout,
                connection_factory=opened.connection_factory,
                update_settings_path=session_path.parent / "update-settings.json",
            ),
            on_about_to_quit=opened.close,
            startup_timeline=startup,
        )
