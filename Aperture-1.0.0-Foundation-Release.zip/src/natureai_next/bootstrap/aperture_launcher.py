"""Windowless Windows launcher for the Aperture desktop application."""

from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any

from natureai_next.bootstrap.cli import main as cli_main


def _configuration_path() -> Path:
    appdata = os.environ.get("APPDATA")
    root = Path(appdata) if appdata else Path.home() / "AppData" / "Roaming"
    return root / "NatureAI" / "NatureAI Next" / "launcher.json"


def _configured_library() -> Path | None:
    path = _configuration_path()
    try:
        payload: Any = json.loads(path.read_text(encoding="utf-8-sig"))
    except (OSError, ValueError, TypeError):
        return None
    if not isinstance(payload, dict):
        return None
    value = payload.get("last_library")
    if not isinstance(value, str) or not value.strip():
        return None
    return Path(value.strip())


def _message_box(message: str, *, error: bool = True) -> None:
    try:
        import ctypes

        icon = 0x10 if error else 0x40
        ctypes.windll.user32.MessageBoxW(0, message, "Aperture", icon)
    except Exception:
        return


def main() -> int:
    library = _configured_library()
    if library is None:
        _message_box(
            "No Aperture Library is configured. Use 'Aperture - Select Library' and try again."
        )
        return 1
    if not (library / "library.json").is_file() or not (library / "library.sqlite3").is_file():
        _message_box(
            "The configured Aperture Library is unavailable or incomplete. "
            "Use 'Aperture - Select Library' to choose a valid library."
        )
        return 1
    try:
        return int(cli_main(["--library", str(library), "--log-level", "INFO"]))
    except Exception as exc:
        _message_box(
            "Aperture could not start.\n\n"
            f"{type(exc).__name__}: {exc}\n\n"
            "Use Aperture (Debug) for diagnostic output."
        )
        return 1
