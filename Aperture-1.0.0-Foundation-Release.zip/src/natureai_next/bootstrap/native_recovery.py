"""Detached native library recovery helper. End users never invoke this directly."""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import shutil
import subprocess
import sys
import time
from pathlib import Path
from typing import Any, Sequence


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _wait_for_exit(pid: int, timeout_seconds: float = 120.0) -> None:
    deadline = time.monotonic() + timeout_seconds
    while time.monotonic() < deadline:
        try:
            os.kill(pid, 0)
        except OSError:
            return
        time.sleep(0.25)
    raise TimeoutError("Aperture did not close in time to restore the library")


def _write_status(request_path: Path, payload: dict[str, Any], status: str, detail: str = "") -> None:
    payload["status"] = status
    payload["detail"] = detail
    temp = request_path.with_suffix(request_path.suffix + ".tmp")
    temp.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    temp.replace(request_path)


def main(argv: Sequence[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="aperture-recovery")
    parser.add_argument("--request", required=True, type=Path)
    parser.add_argument("--parent-pid", required=True, type=int)
    parser.add_argument("--library", required=True, type=Path)
    args = parser.parse_args(argv)
    request_path = args.request.resolve()
    payload: dict[str, Any] = json.loads(request_path.read_text(encoding="utf-8"))
    if payload.get("format") != "natureai-next.pending-restore" or payload.get("format_version") != 1:
        raise ValueError("unsupported staged restore request")
    staged = Path(str(payload["staged_database"])).resolve()
    target = Path(str(payload["target_database"])).resolve()
    emergency = Path(str(payload["emergency_backup"])).resolve()
    if not staged.is_file() or _sha256(staged) != str(payload["sha256"]).casefold():
        raise ValueError("staged backup verification failed")
    if not emergency.is_file():
        raise FileNotFoundError("emergency pre-restore backup is missing")
    rollback = target.with_suffix(target.suffix + ".pre-restore-rollback")
    try:
        _write_status(request_path, payload, "waiting-for-exit")
        _wait_for_exit(args.parent_pid)
        _write_status(request_path, payload, "restoring")
        shutil.copy2(target, rollback)
        replacement = target.with_suffix(target.suffix + ".restore.tmp")
        shutil.copy2(staged, replacement)
        replacement.replace(target)
        _write_status(request_path, payload, "restored")
        subprocess.Popen(
            [sys.executable, "-m", "natureai_next.bootstrap.cli", "--library", str(args.library)],
            stdin=subprocess.DEVNULL,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            close_fds=True,
        )
        return 0
    except Exception as exc:
        if rollback.is_file():
            shutil.copy2(rollback, target)
        _write_status(request_path, payload, "failed", str(exc))
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
