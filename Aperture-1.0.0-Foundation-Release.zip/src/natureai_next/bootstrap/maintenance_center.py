"""Aperture Maintenance Center launcher with pre-GUI diagnostics."""
from __future__ import annotations

from datetime import datetime, timezone
import json
import os
from pathlib import Path
from typing import Sequence


def _bootstrap_log(status: str, detail: str = "") -> None:
    log_dir = Path(os.environ.get("LOCALAPPDATA", Path.home())) / "Aperture" / "Logs"
    try:
        log_dir.mkdir(parents=True, exist_ok=True)
        payload = {
            "created_at_utc": datetime.now(timezone.utc).isoformat(),
            "status": status,
            "detail": detail,
        }
        with (log_dir / "maintenance-bootstrap.jsonl").open("a", encoding="utf-8") as handle:
            handle.write(json.dumps(payload, sort_keys=True) + "\n")
    except OSError:
        pass


def main(argv: Sequence[str] | None = None) -> int:
    _bootstrap_log("process-started")
    try:
        from natureai_next.ui.qt.maintenance_center import main as qt_main
        _bootstrap_log("qt-imported")
        result = qt_main(argv)
        _bootstrap_log("process-exited", str(result))
        return result
    except BaseException as exc:
        _bootstrap_log("bootstrap-failed", f"{type(exc).__name__}: {exc}")
        raise


if __name__ == "__main__":
    raise SystemExit(main())
