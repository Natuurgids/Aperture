"""GUI-independent presentation models."""
