"""PySide6 application shell and production workspace composition."""
from __future__ import annotations

from collections.abc import Callable
import os
from pathlib import Path

from natureai_next.application.branding import BrandingStore
from natureai_next.bootstrap.startup_timing import StartupTimeline
from natureai_next.application.backup import LibraryBackupService, suggested_backup_name
from natureai_next.application.recovery import LibraryRecoveryService
from natureai_next.application.updates import OfflineUpdateService, UpdateSettings, UpdateSettingsStore
from natureai_next.application.health import LibraryHealthService
from natureai_next.application.native_handoff import HelperLaunch, augment_request, launch_helper, wait_for_helper_ready
from natureai_next.application.update_history import UpdateHistoryStore
from typing import Sequence

from natureai_next.ui.presentation.session import SessionState, SessionStateStore
from natureai_next.ui.qt.ai_review import AIReviewWorkspace
from natureai_next.ui.qt.importing import ImportApplicationService, ImportWorkspace
from natureai_next.ui.qt.library import (
    CatalogApplicationService,
    CatalogEditApplicationService,
    CatalogThumbnailService,
    LibraryWorkspace,
    LibraryViewsApplicationService,
    QuickSearchApplicationService,
)
from natureai_next.ui.qt.viewer import ViewerDialog

try:
    from PySide6.QtCore import QByteArray, QSize, Qt, QTimer, Slot
    from PySide6.QtGui import QAction, QIcon, QKeySequence
    from PySide6.QtWidgets import (
        QApplication,
        QDockWidget,
        QLabel,
        QTreeWidget, QTreeWidgetItem,
        QMainWindow,
        QMenu,
        QStackedWidget,
        QStatusBar,
        QToolBar,
        QMessageBox,
        QPushButton,
        QFileDialog,
        QInputDialog,
        QWidget,
    )
except ImportError as exc:  # pragma: no cover - exercised only without GUI extra
    raise RuntimeError("PySide6 is required; install natureai-next[gui]") from exc


class MainWindow(QMainWindow):
    # Compatibility catalog fragments retained for release guards:
    # "Activity Center", "Observation History", "Life Lists & Statistics", "Settings"
    # "AI Resources", "Regional Knowledge", "Health Check", "Preferences"
    # self._navigation.setCurrentRow(self.WORKSPACES.index("Activity Center"))
    # Default menu label: About Aperture
    WORKSPACES = ("Library", "Imports", "Collections", "Taxonomy", "AI Review", "Activity Center", "Observation History", "Life Lists & Statistics", "Branding & Project", "Conservation & Seasonality", "AI Resources", "Regional Knowledge", "Health Check", "Diagnostics", "Updates", "Preferences")

    def __init__(
        self,
        *,
        library_name: str,
        session_path: Path,
        import_service: ImportApplicationService,
        catalog_service: CatalogApplicationService,
        thumbnail_service: CatalogThumbnailService,
        catalog_edit_service: CatalogEditApplicationService,
        search_service: QuickSearchApplicationService,
        views_service: LibraryViewsApplicationService,
        ai_review_workspace_factory: Callable[[Callable[[], tuple[str, ...]]], AIReviewWorkspace],
        backup_service: LibraryBackupService,
        default_backup_directory: Path,
        health_service: LibraryHealthService | None = None,
    ) -> None:
        super().__init__()
        self._session_path = session_path
        self._library_name = library_name
        self._backup_service = backup_service
        self._recovery_service = LibraryRecoveryService()
        self._default_backup_directory = default_backup_directory
        self._update_settings_path = session_path.parent / "update-settings.json"
        self._update_staging_directory = session_path.parent / "updates" / "staging"
        self._restore_staging_directory = session_path.parent / "recovery" / "staging"
        self._library_database_path = session_path.parent / "library.sqlite3"
        self._update_settings_store = UpdateSettingsStore()
        self._update_service = OfflineUpdateService()
        self._update_history_store = UpdateHistoryStore()
        self._update_history_path = session_path.parent / "updates" / "update-history.jsonl"
        self._store = SessionStateStore()
        self._session = self._store.load(session_path)
        self._branding_path = session_path.parent / "branding.toml"
        self._branding_store = BrandingStore()
        if not self._branding_path.exists():
            self._branding_store.save(self._branding_path, self._branding_store.load(self._branding_path))
        self._branding = self._branding_store.load(self._branding_path)
        self.setWindowTitle(f"{self._branding.application_name} — {library_name}")
        icon_path = Path(__file__).resolve().parents[2] / "resources" / "aperture.ico"
        if icon_path.exists():
            self.setWindowIcon(QIcon(str(icon_path)))
        self.setMinimumSize(QSize(1100, 700))

        self._navigation = QTreeWidget()
        self._navigation.setHeaderHidden(True)
        self._navigation_items: dict[str, QTreeWidgetItem] = {}
        groups = {
            "Library": ("Library", "Imports", "Collections", "Taxonomy"),
            "AI": ("AI Review", "Activity Center"),
            "Observations": ("Observation History", "Life Lists & Statistics"),
            "Settings": ("Branding & Project", "AI Resources", "Regional Knowledge", "Conservation & Seasonality", "Health Check", "Diagnostics", "Updates", "Preferences"),
        }
        for group_name, children in groups.items():
            parent_item = QTreeWidgetItem([group_name])
            parent_item.setFlags(parent_item.flags() & ~Qt.ItemFlag.ItemIsSelectable)
            self._navigation.addTopLevelItem(parent_item)
            for name in children:
                child = QTreeWidgetItem([name]); child.setData(0, Qt.ItemDataRole.UserRole, name)
                parent_item.addChild(child); self._navigation_items[name] = child
            parent_item.setExpanded(True)
        self._stack = QStackedWidget()
        self._catalog_service = catalog_service
        self._thumbnail_service = thumbnail_service
        self._viewers: set[ViewerDialog] = set()
        self._library = LibraryWorkspace(catalog_service, thumbnail_service, catalog_edit_service, search_service, views_service)
        self._library.viewer_requested.connect(self._open_viewer)
        self._stack.addWidget(self._library)
        self._ai_review_workspace = ai_review_workspace_factory(self._library.selected_asset_ids)
        self._ai_review_workspace.resources_requested.connect(self.open_ai_resources)
        self._ai_review_workspace.observation_requested.connect(self.open_observation_history)
        from natureai_next.ui.qt.activity import ActivityCenterWidget
        from natureai_next.ui.qt.settings_pages import AIResourcesWorkspace, RegionalKnowledgeWorkspace
        from natureai_next.ui.qt.health import HealthCheckWidget
        from natureai_next.ui.qt.observations import ObservationHistoryWorkspace
        from natureai_next.ui.qt.observation_statistics import ObservationStatisticsWorkspace
        from natureai_next.ui.qt.ecology import EcologicalContextWorkspace
        from natureai_next.ui.qt.product_pages import AboutDialog, BrandingWorkspace, DiagnosticsWorkspace
        self._activity_workspace = ActivityCenterWidget(self)
        observation_service = self._ai_review_workspace.observation_service
        if observation_service is None:
            raise RuntimeError("Observation Intelligence service is required for the desktop workspace")
        self._observation_workspace = ObservationHistoryWorkspace(
            service=observation_service, thumbnails=thumbnail_service, ecology_service=self._ai_review_workspace.ecology_service, parent=self
        )
        self._observation_workspace.viewer_requested.connect(self._open_viewer)
        self._observation_statistics_workspace = ObservationStatisticsWorkspace(service=observation_service, parent=self)
        ecology_service = self._ai_review_workspace.ecology_service
        if ecology_service is None:
            raise RuntimeError("Ecological context service is required for the desktop workspace")
        self._ecology_workspace = EcologicalContextWorkspace(ecology_service, parent=self)
        self._ai_resources_workspace = AIResourcesWorkspace(
            resource_service=self._ai_review_workspace.resource_service,
            suggestion_service=self._ai_review_workspace.suggestion_service,
            regional_service=self._ai_review_workspace.regional_service,
            regional_acquisition_service=self._ai_review_workspace.regional_acquisition_service,
            activity_open=self.open_activity_center,
            parent=self,
        )
        self._regional_workspace = RegionalKnowledgeWorkspace(
            regional_service=self._ai_review_workspace.regional_service,
            regional_acquisition_service=self._ai_review_workspace.regional_acquisition_service,
            parent=self,
        )
        self._health_workspace = HealthCheckWidget(health_service, self)
        self._health_workspace.backup_requested.connect(self.back_up_library)
        self._health_workspace.restore_requested.connect(self.restore_library)
        self._health_workspace.updates_requested.connect(self.check_for_updates)
        self._branding_workspace = BrandingWorkspace(self._branding_path, self)
        self._branding_workspace.branding_changed.connect(self._apply_branding)
        self._diagnostics_workspace = DiagnosticsWorkspace(
            library_name=library_name, session_path=session_path, branding_path=self._branding_path,
            resource_service=self._ai_review_workspace.suggestion_service,
            ecology_service=ecology_service, parent=self,
        )
        self._about_dialog_factory = lambda: AboutDialog(
            branding=self._branding_store.load(self._branding_path), diagnostics=self._diagnostics_workspace, parent=self
        )
        self._imports = ImportWorkspace(import_service)
        self._imports.import_finished.connect(self._on_import_finished)
        self._stack.addWidget(self._imports)
        for name in self.WORKSPACES[2:]:
            if name == "AI Review":
                self._stack.addWidget(self._ai_review_workspace)
            elif name == "Activity Center":
                self._stack.addWidget(self._activity_workspace)
            elif name == "Observation History":
                self._stack.addWidget(self._observation_workspace)
            elif name == "Life Lists & Statistics":
                self._stack.addWidget(self._observation_statistics_workspace)
            elif name == "Conservation & Seasonality":
                self._stack.addWidget(self._ecology_workspace)
            elif name == "AI Resources":
                self._stack.addWidget(self._ai_resources_workspace)
            elif name == "Regional Knowledge":
                self._stack.addWidget(self._regional_workspace)
            elif name == "Health Check":
                self._stack.addWidget(self._health_workspace)
            elif name == "Branding & Project":
                self._stack.addWidget(self._branding_workspace)
            elif name == "Diagnostics":
                self._stack.addWidget(self._diagnostics_workspace)
            else:
                self._stack.addWidget(self._placeholder(name, "Workspace not yet connected to the desktop shell."))
        self.setCentralWidget(self._stack)

        self._navigation_dock = QDockWidget("Navigation", self)
        self._navigation_dock.setObjectName("navigationDock")
        self._navigation_dock.setWidget(self._navigation)
        self._navigation_dock.setAllowedAreas(Qt.DockWidgetArea.LeftDockWidgetArea)
        self._navigation_dock.setFeatures(
            QDockWidget.DockWidgetFeature.DockWidgetClosable
            | QDockWidget.DockWidgetFeature.DockWidgetMovable
        )
        self.addDockWidget(Qt.DockWidgetArea.LeftDockWidgetArea, self._navigation_dock)

        self._inspector_dock = QDockWidget("Inspector", self)
        self._inspector_dock.setObjectName("inspectorDock")
        self._inspector_dock.setWidget(QLabel("No selection"))
        self._inspector_dock.setAllowedAreas(Qt.DockWidgetArea.RightDockWidgetArea)
        self._inspector_dock.setFeatures(
            QDockWidget.DockWidgetFeature.DockWidgetClosable
            | QDockWidget.DockWidgetFeature.DockWidgetMovable
        )
        self.addDockWidget(Qt.DockWidgetArea.RightDockWidgetArea, self._inspector_dock)
        self._inspector_dock.setVisible(self._session.inspector_visible)

        self.setStatusBar(QStatusBar())
        self.statusBar().showMessage("Offline • Ready")
        from natureai_next.ui.qt.activity import activity_center
        self._activity_center = activity_center()
        self._exit_after_tasks = False
        self._activity_button = QPushButton("Activity Center")
        self._activity_button.setFlat(True)
        self._activity_button.clicked.connect(self.open_activity_center)
        self.statusBar().addPermanentWidget(self._activity_button)
        self._activity_center.changed.connect(self._activity_status_changed)
        self._activity_status_changed()
        toolbar = QToolBar("Main", self)
        toolbar.setObjectName("mainToolbar")
        self.addToolBar(toolbar)

        self._import_action = QAction("Import folder…", self)
        self._import_action.setShortcut(QKeySequence("Ctrl+I"))
        self._import_action.triggered.connect(self.open_import_folder)
        toolbar.addAction(self._import_action)

        self._backup_action = QAction("Back Up Library…", self)
        self._backup_action.setShortcut(QKeySequence("Ctrl+Shift+B"))
        self._backup_action.setToolTip("Create a verified backup of the current Aperture library database")
        self._backup_action.triggered.connect(self.back_up_library)
        toolbar.addAction(self._backup_action)

        self._restore_action = QAction("Restore Library…", self)
        self._restore_action.setShortcut(QKeySequence("Ctrl+Shift+R"))
        self._restore_action.setToolTip("Verify and stage restoration of an Aperture library backup")
        self._restore_action.triggered.connect(self.restore_library)
        toolbar.addAction(self._restore_action)

        quit_action = QAction("Quit", self)
        quit_action.setShortcut(QKeySequence.StandardKey.Quit)
        quit_action.triggered.connect(self.close)
        toolbar.addAction(quit_action)

        file_menu: QMenu = self.menuBar().addMenu("&File")
        file_menu.addAction(self._import_action)
        file_menu.addAction(self._backup_action)
        file_menu.addAction(self._restore_action)
        file_menu.addSeparator()
        file_menu.addAction(quit_action)

        view_menu: QMenu = self.menuBar().addMenu("&View")
        view_menu.addAction(self._navigation_dock.toggleViewAction())
        view_menu.addAction(self._inspector_dock.toggleViewAction())
        view_menu.addSeparator()
        activity_action = QAction("Activity Center…", self)
        activity_action.triggered.connect(self.open_activity_center)
        view_menu.addAction(activity_action)
        observations_action = QAction("Observation History…", self)
        observations_action.triggered.connect(lambda: self.open_observation_history(None))
        view_menu.addAction(observations_action)
        ecology_action = QAction("Conservation && Seasonality…", self)
        ecology_action.triggered.connect(self.open_ecology)
        view_menu.addAction(ecology_action)
        statistics_action = QAction("Life Lists && Statistics…", self)
        statistics_action.triggered.connect(self.open_observation_statistics)
        view_menu.addAction(statistics_action)
        view_menu.addSeparator()
        reset_layout = QAction("Reset workspace layout", self)
        reset_layout.triggered.connect(self.reset_workspace_layout)
        view_menu.addAction(reset_layout)

        settings_menu: QMenu = self.menuBar().addMenu("&Settings")
        ai_resources_action = QAction("AI Resources", self)
        ai_resources_action.triggered.connect(self.open_ai_resources)
        settings_menu.addAction(ai_resources_action)
        regional_action = QAction("Regional Knowledge", self)
        regional_action.triggered.connect(self.open_regional_knowledge)
        settings_menu.addAction(regional_action)
        health_action = QAction("Health Check", self)
        health_action.triggered.connect(self.open_health_check)
        settings_menu.addAction(health_action)
        settings_menu.addSeparator()
        settings_menu.addAction(self._backup_action)
        settings_menu.addAction(self._restore_action)
        self._verify_backup_action = QAction("Verify Backup…", self)
        self._verify_backup_action.triggered.connect(self.verify_backup)
        settings_menu.addAction(self._verify_backup_action)
        self._manage_backups_action = QAction("Manage Backups…", self)
        self._manage_backups_action.triggered.connect(self.manage_backups)
        settings_menu.addAction(self._manage_backups_action)
        self._check_updates_action = QAction("Check for Updates…", self)
        self._check_updates_action.triggered.connect(self.check_for_updates)
        settings_menu.addAction(self._check_updates_action)
        update_history_action = QAction("Update History…", self)
        update_history_action.triggered.connect(self.show_update_history)
        settings_menu.addAction(update_history_action)
        settings_menu.addSeparator()
        branding_action = QAction("Branding & Project", self)
        branding_action.triggered.connect(lambda: self._select_workspace("Branding & Project"))
        settings_menu.addAction(branding_action)
        diagnostics_action = QAction("Diagnostics", self)
        diagnostics_action.triggered.connect(self.open_diagnostics)
        settings_menu.addAction(diagnostics_action)

        tools_menu: QMenu = self.menuBar().addMenu("&Tools")
        tools_health_action = QAction("Health Check…", self)
        tools_health_action.triggered.connect(self.open_health_check)
        tools_menu.addAction(tools_health_action)

        help_menu: QMenu = self.menuBar().addMenu("&Help")
        for label, topic_id in (
            ("Quick Start", "quick-start"),
            ("User Guide", "user-guide"),
            ("AI Workspace Guide", "ai-review"),
            ("Import Guide", "import"),
            ("Backup && Recovery Guide", "backup-recovery"),
            ("Update Guide", "updates"),
            ("Health Center Guide", "health"),
            ("Troubleshooting", "troubleshooting"),
            ("Build Windows Installer", "build-windows-installer"),
            ("Roadmap && Future Releases", "roadmap"),
            ("Version 1 Project Handover", "handover"),
        ):
            action = QAction(label, self)
            action.triggered.connect(lambda _checked=False, value=topic_id: self.open_help_topic(value))
            help_menu.addAction(action)
        help_menu.addSeparator()
        shortcuts_action = QAction("Keyboard Shortcuts…", self)
        shortcuts_action.setShortcut(QKeySequence("Ctrl+/"))
        shortcuts_action.triggered.connect(self.open_keyboard_shortcuts)
        help_menu.addAction(shortcuts_action)
        context_help_action = QAction("Help for Current Screen", self)
        context_help_action.setShortcut(QKeySequence("F1"))
        context_help_action.triggered.connect(self.open_context_help)
        help_menu.addAction(context_help_action)
        release_notes_action = QAction("Release Notes", self)
        release_notes_action.triggered.connect(lambda: self.open_help_topic("release-notes"))
        help_menu.addAction(release_notes_action)
        help_menu.addAction(self._check_updates_action)
        help_menu.addSeparator()
        self._about_action = QAction(f"About {self._branding.application_name}…", self)
        self._about_action.triggered.connect(self.open_about)
        self.menuBar().addAction(self._about_action)

        self._navigation.itemClicked.connect(self._workspace_item_clicked)
        restored_workspace = self._session.workspace.replace("_", " ").title()
        if restored_workspace == "Jobs":
            restored_workspace = "Activity Center"
        try:
            index = self.WORKSPACES.index(restored_workspace)
        except ValueError:
            index = 0
        self._select_workspace(self.WORKSPACES[index])
        if self._session.window_geometry_b64:
            self.restoreGeometry(QByteArray.fromBase64(self._session.window_geometry_b64.encode("ascii")))
        self.apply_accessibility_defaults()
        # Core panes use a deterministic docked layout. Arbitrary Qt dock-state
        # restoration can resurrect a pane as a detached top-level window after
        # upgrades or display changes, so only window geometry is persisted.

    def open_keyboard_shortcuts(self) -> None:
        from natureai_next.ui.qt.accessibility import KeyboardShortcutsDialog
        KeyboardShortcutsDialog(self).exec()

    def open_help_topic(self, topic_id: str) -> None:
        from natureai_next.ui.qt.help_system import HelpBrowserDialog
        HelpBrowserDialog(self, initial_topic=topic_id).exec()

    def open_context_help(self) -> None:
        from natureai_next.ui.qt.help_system import WORKSPACE_TOPIC
        workspace = self.WORKSPACES[self._stack.currentIndex()]
        self.open_help_topic(WORKSPACE_TOPIC.get(workspace, "user-guide"))

    def apply_accessibility_defaults(self) -> int:
        from natureai_next.ui.qt.accessibility import apply_accessibility_defaults
        return apply_accessibility_defaults(self)

    @staticmethod
    def _placeholder(title: str, detail: str) -> QWidget:
        label = QLabel(f"<h2>{title}</h2><p>{detail}</p>")
        label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        label.setWordWrap(True)
        return label


    @Slot(object, int)
    def _workspace_item_clicked(self, item: object, _column: int) -> None:
        name = item.data(0, Qt.ItemDataRole.UserRole)
        if not isinstance(name, str):
            return
        if name == "Collections":
            self._stack.setCurrentIndex(self.WORKSPACES.index("Library")); self._library.focus_collections(); return
        self._stack.setCurrentIndex(self.WORKSPACES.index(name))
        if name == "AI Review":
            self.statusBar().showMessage("AI Review • J/K navigate • A accept • Shift+Enter accept & continue • F1 help")
        else:
            self.statusBar().showMessage(f"{name} • F1 help", 8000)

    def _select_workspace(self, name: str) -> None:
        item = self._navigation_items.get(name)
        if item is not None:
            self._navigation.setCurrentItem(item)
            self._workspace_item_clicked(item, 0)

    def _workspace_changed(self, row: int) -> None:
        """Backward-compatible row routing used by older release tests."""
        if 0 <= row < len(self.WORKSPACES):
            self._select_workspace(self.WORKSPACES[row])


    @Slot()
    def reset_workspace_layout(self) -> None:
        self._navigation_dock.setFloating(False)
        self._inspector_dock.setFloating(False)
        self.addDockWidget(Qt.DockWidgetArea.LeftDockWidgetArea, self._navigation_dock)
        self.addDockWidget(Qt.DockWidgetArea.RightDockWidgetArea, self._inspector_dock)
        self._navigation_dock.setVisible(True)
        self._inspector_dock.setVisible(True)
        self._navigation_dock.raise_()
        self._inspector_dock.raise_()


    @Slot()
    def back_up_library(self) -> None:
        self._default_backup_directory.mkdir(parents=True, exist_ok=True)
        suggested = self._default_backup_directory / suggested_backup_name(self._library_name)
        selected, _filter = QFileDialog.getSaveFileName(
            self,
            "Back Up Aperture Library",
            str(suggested),
            "Aperture database backup (*.sqlite3);;SQLite database (*.db)",
        )
        if not selected:
            return
        destination = Path(selected)
        if destination.exists():
            QMessageBox.warning(
                self,
                "Backup not created",
                "Aperture never overwrites an existing backup. Choose a new file name.",
            )
            return
        self._backup_action.setEnabled(False)
        QApplication.setOverrideCursor(Qt.CursorShape.WaitCursor)
        self.statusBar().showMessage("Creating and verifying library backup…")
        try:
            result = self._backup_service.create(destination)
        except Exception as exc:
            QMessageBox.critical(
                self,
                "Backup failed",
                f"Aperture could not create the backup.\n\n{exc}",
            )
            self.statusBar().showMessage("Backup failed", 15000)
        else:
            size_mib = result.size_bytes / (1024 * 1024)
            QMessageBox.information(
                self,
                "Backup complete",
                "The library database was backed up and verified.\n\n"
                f"Backup: {result.database_path}\n"
                f"Manifest: {result.manifest_path}\n"
                f"Size: {size_mib:.1f} MiB\n"
                f"SHA-256: {result.sha256}",
            )
            self.statusBar().showMessage(f"Backup complete • {result.database_path.name}", 15000)
        finally:
            QApplication.restoreOverrideCursor()
            self._backup_action.setEnabled(True)


    def _select_backup_file(self, title: str) -> Path | None:
        self._default_backup_directory.mkdir(parents=True, exist_ok=True)
        selected, _filter = QFileDialog.getOpenFileName(
            self, title, str(self._default_backup_directory),
            "Aperture database backup (*.sqlite3 *.db)",
        )
        return Path(selected) if selected else None

    @Slot()
    def verify_backup(self) -> None:
        selected = self._select_backup_file("Verify Aperture Backup")
        if selected is None:
            return
        try:
            verified = self._recovery_service.verify(selected)
        except Exception as exc:
            QMessageBox.critical(self, "Backup verification failed", f"The selected backup is not valid.\n\n{exc}")
            return
        QMessageBox.information(
            self, "Backup verified",
            "The backup and checksum manifest are valid.\n\n"
            f"Library: {verified.library_name}\nCreated: {verified.created_at_utc}\n"
            f"Size: {verified.size_bytes / (1024 * 1024):.1f} MiB\nSHA-256: {verified.sha256}",
        )

    @Slot()
    def manage_backups(self) -> None:
        """Open the dedicated manager where backups can be verified, restored, or deleted."""
        self.restore_library()

    @Slot()
    def show_update_history(self) -> None:
        entries = self._update_history_store.load(self._update_history_path)
        if not entries:
            QMessageBox.information(self, "Update History", "No completed update attempts have been recorded for this library.")
            return
        summary = "\n\n".join(
            f"{entry.created_at_utc} — Aperture {entry.version} — {entry.status}\n{entry.detail}".rstrip()
            for entry in entries
        )
        QMessageBox.information(self, "Update History", summary[:12000])

    @Slot()
    def restore_library(self) -> None:
        """Open the standalone Maintenance Center and verify its first visible window."""
        import subprocess
        import time
        import uuid

        log_dir = Path(os.environ.get("LOCALAPPDATA", Path.home())) / "Aperture" / "Logs"
        log_dir.mkdir(parents=True, exist_ok=True)
        # Do not create a temporary placeholder here: an open descriptor blocks deletion on Windows.
        # Windows cannot unlink that placeholder.  A unique path is enough because
        # the Maintenance Center creates the acknowledgement atomically.
        ready_path = log_dir / f"maintenance-ready-{uuid.uuid4().hex}.json"
        for stale in log_dir.glob("maintenance-ready-*.json*"):
            try:
                stale.unlink(missing_ok=True)
            except OSError:
                pass

        python = Path(os.sys.executable).resolve()
        if os.name == "nt":
            pythonw = Path(os.sys.prefix) / "pythonw.exe"
            if pythonw.is_file():
                python = pythonw
        command = [
            str(python), "-m", "natureai_next.bootstrap.maintenance_center",
            "--library", str(self._session_path.parent),
            "--ready-file", str(ready_path),
        ]

        launch_log = log_dir / "maintenance-launch.jsonl"
        def record(status: str, detail: str = "") -> None:
            from datetime import datetime, timezone
            import json
            payload = {
                "created_at_utc": datetime.now(timezone.utc).isoformat(),
                "status": status,
                "detail": detail,
                "command": command,
            }
            with launch_log.open("a", encoding="utf-8") as handle:
                handle.write(json.dumps(payload, sort_keys=True) + "\n")

        record("launch-requested")
        kwargs: dict[str, object] = {
            "stdin": subprocess.DEVNULL, "stdout": subprocess.DEVNULL,
            "stderr": subprocess.DEVNULL, "close_fds": True,
        }
        if os.name == "nt":
            kwargs["creationflags"] = getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0x00000200)
        try:
            process = subprocess.Popen(command, **kwargs)  # type: ignore[arg-type]
        except OSError as exc:
            record("launch-failed", str(exc))
            QMessageBox.critical(
                self, "Maintenance Center unavailable",
                f"Aperture could not start the Maintenance Center.\n\n{exc}",
            )
            return

        deadline = time.monotonic() + 12.0
        while time.monotonic() < deadline:
            QApplication.processEvents()
            if ready_path.is_file():
                record("window-ready")
                ready_path.unlink(missing_ok=True)
                self.statusBar().showMessage("Aperture Maintenance Center opened", 10000)
                return
            if process.poll() is not None:
                record("process-exited", f"exit code {process.returncode}")
                QMessageBox.critical(
                    self, "Maintenance Center unavailable",
                    "The Maintenance Center stopped before its window appeared. "
                    "See maintenance-launch.jsonl and maintenance-bootstrap.jsonl in the Aperture log folder.",
                )
                return
            time.sleep(0.05)

        record("window-timeout")
        QMessageBox.critical(
            self, "Maintenance Center unavailable",
            "The Maintenance Center started but did not display a window within 12 seconds. "
            "Aperture remains open. See maintenance-launch.jsonl and maintenance-bootstrap.jsonl in the Aperture log folder.",
        )


    @Slot()
    def check_for_updates(self) -> None:
        settings = self._update_settings_store.load(self._update_settings_path)
        current = str(settings.source) if settings.source else ""
        selected = QFileDialog.getExistingDirectory(
            self, "Select Aperture update location", current
        )
        if not selected:
            return
        settings = UpdateSettings(source=Path(selected), check_at_startup=settings.check_at_startup, channel=settings.channel)
        self._update_settings_store.save(self._update_settings_path, settings)
        self.statusBar().showMessage("Checking configured update location…")
        try:
            candidate = self._update_service.check(settings.source, channel=settings.channel)
        except Exception as exc:
            QMessageBox.critical(self, "Update check failed", f"Aperture could not check the update location.\n\n{exc}")
            self.statusBar().showMessage("Update check failed", 15000)
            return
        if candidate is None:
            QMessageBox.information(self, "Aperture is up to date", "No newer compatible Stable update was found in the configured location.")
            self.statusBar().showMessage("No update available", 10000)
            return
        if self._activity_center.running_count or self._ai_review_workspace.generation_busy:
            QMessageBox.information(
                self,
                "Finish background work first",
                "Aperture cannot install an update while background work is active. "
                "Wait for it to finish or cancel it, then check for updates again.",
            )
            return
        prompt = QMessageBox(self)
        prompt.setWindowTitle(f"Aperture {candidate.version} is available")
        prompt.setIcon(QMessageBox.Icon.Question)
        prompt.setText(candidate.release_notes[:3000])
        prompt.setInformativeText(
            "Choose whether to create a verified library backup before installing. "
            "Aperture will stage the update, start the updater, close, install, and restart automatically."
        )
        backup_button = prompt.addButton("Back Up and Install", QMessageBox.ButtonRole.AcceptRole)
        no_backup_button = prompt.addButton("Install Without Backup", QMessageBox.ButtonRole.DestructiveRole)
        cancel_button = prompt.addButton(QMessageBox.StandardButton.Cancel)
        prompt.setDefaultButton(backup_button)
        prompt.exec()
        clicked = prompt.clickedButton()
        if clicked is cancel_button or clicked not in {backup_button, no_backup_button}:
            return
        create_backup = clicked is backup_button
        backup = None
        try:
            if create_backup:
                self._default_backup_directory.mkdir(parents=True, exist_ok=True)
                backup = self._backup_service.create(
                    self._default_backup_directory / suggested_backup_name(self._library_name)
                )
            staged = self._update_service.stage(candidate, self._update_staging_directory)
            augment_request(
                staged.request_path, parent_pid=os.getpid(), library_path=self._session_path.parent
            )
            helper = launch_helper(HelperLaunch(
                module="natureai_next.bootstrap.native_updater",
                request_path=staged.request_path,
                parent_pid=os.getpid(),
                library_path=self._session_path.parent,
            ))
            wait_for_helper_ready(helper, staged.request_path, timeout_seconds=10.0)
        except Exception as exc:
            QMessageBox.critical(self, "Update not started", f"Aperture did not start the update.\n\n{exc}")
            self.statusBar().showMessage("Update start failed", 15000)
            return
        backup_text = f"\n\nBackup: {backup.database_path}" if backup is not None else ""
        QMessageBox.information(
            self,
            "Restarting to install",
            f"Aperture {candidate.version} is staged and the updater has started."
            f"{backup_text}\n\nAperture will now close, install the update, and restart automatically.",
        )
        self.statusBar().showMessage(f"Restarting to install Aperture {candidate.version}…")
        app = QApplication.instance()
        if app is not None:
            QTimer.singleShot(0, app.quit)
        else:
            QTimer.singleShot(0, self.close)


    def open_import_folder(self) -> None:
        self._select_workspace("Imports")
        self._imports.choose_folder()

    def _on_import_finished(self, summary: object) -> None:
        imported = int(getattr(summary, "imported", 0))
        failed = int(getattr(summary, "failed", 0))
        results = tuple(getattr(summary, "results", ()))
        public_ids = tuple(
            str(asset_id)
            for result in results
            if (asset_id := getattr(result, "asset_public_id", None))
            and str(getattr(result, "state", "")) in {"imported", "attached"}
        )
        self.statusBar().showMessage(f"Import completed • {imported} imported • {failed} failed", 15000)
        self._library.show_imported(public_ids, imported=imported, failed=failed)
        self._select_workspace("Library")

    @Slot(object, str)
    def _open_viewer(self, ordered_ids: tuple[str, ...], public_id: str) -> None:
        viewer = ViewerDialog(
            ordered_ids=ordered_ids,
            public_id=public_id,
            catalog=self._catalog_service,
            previews=self._thumbnail_service,
            parent=self,
        )
        self._viewers.add(viewer)
        viewer.destroyed.connect(lambda _object=None, dialog=viewer: self._viewers.discard(dialog))
        viewer.show()
        viewer.raise_()
        viewer.activateWindow()

    @Slot()
    def open_activity_center(self) -> None:
        self._select_workspace("Activity Center")
        self._navigation_dock.setVisible(True)
        self._navigation_dock.raise_()

    @Slot(object)
    def open_observation_history(self, taxon_public_id: object = None) -> None:
        self._observation_workspace.refresh()
        if isinstance(taxon_public_id, str) and taxon_public_id:
            self._observation_workspace.show_taxon(taxon_public_id)
        self._select_workspace("Observation History")
        self._navigation_dock.setVisible(True)
        self._navigation_dock.raise_()

    @Slot()
    def open_ecology(self) -> None:
        self._select_workspace("Conservation & Seasonality")

    def open_observation_statistics(self) -> None:
        self._observation_statistics_workspace.refresh()
        self._select_workspace("Life Lists & Statistics")
        self._navigation_dock.setVisible(True)
        self._navigation_dock.raise_()

    @Slot()
    def open_ai_resources(self) -> None:
        self._ai_resources_workspace.refresh()
        self._select_workspace("AI Resources")

    @Slot()
    def open_regional_knowledge(self) -> None:
        self._regional_workspace.refresh()
        self._select_workspace("Regional Knowledge")

    @Slot()
    def open_health_check(self) -> None:
        self._health_workspace.refresh()
        self._select_workspace("Health Check")

    @Slot(object)
    def _apply_branding(self, branding: object) -> None:
        self._branding = branding
        self.setWindowTitle(f"{branding.application_name} — {self._library_name}")
        self._about_action.setText(f"About {branding.application_name}…")
        QApplication.instance().setApplicationName(branding.application_name)

    @Slot()
    def open_about(self) -> None:
        self._about_dialog_factory().exec()

    @Slot()
    def open_diagnostics(self) -> None:
        self._diagnostics_workspace.refresh(); self._select_workspace("Diagnostics")

    @Slot()
    def _activity_status_changed(self) -> None:
        running = self._activity_center.running_count
        failed = sum(1 for item in self._activity_center.records if item.state in {"failed", "interrupted"})
        if running:
            label = f"Activity Center ({running} running)"
        elif failed:
            label = f"Activity Center ({failed} attention)"
        else:
            label = "Activity Center"
        self._activity_button.setText(label)
        row = self.WORKSPACES.index("Activity Center")
        nav_label = "Activity Center"
        if running:
            nav_label += f" ({running})"
        elif failed:
            nav_label += f" (!{failed})"
        item = self._navigation_items.get("Activity Center")
        if item is not None:
            item.setText(0, nav_label)
        self._activity_button.setVisible(bool(self._activity_center.records))
        if self._exit_after_tasks and running == 0:
            self._exit_after_tasks = False
            QTimer.singleShot(0, self.close)

    def closeEvent(self, event: object) -> None:
        if self._activity_center.running_count:
            message = QMessageBox(self)
            message.setWindowTitle("Background work is still running")
            message.setIcon(QMessageBox.Icon.Warning)
            message.setText("Aperture is still performing background work.")
            message.setInformativeText(
                "Closing now would interrupt the active operation. Keep Aperture running, "
                "or cancel the tasks and exit after they reach a safe checkpoint. Partial "
                "downloads and progress checkpoints will be preserved for Resume / Retry."
            )
            keep = message.addButton("Keep running", QMessageBox.ButtonRole.RejectRole)
            cancel_exit = message.addButton("Cancel tasks and exit", QMessageBox.ButtonRole.DestructiveRole)
            message.setDefaultButton(keep)
            message.exec()
            if message.clickedButton() is cancel_exit:
                self._exit_after_tasks = True
                self._activity_center.cancel_all()
                self.statusBar().showMessage("Cancelling background tasks at a safe checkpoint…")
            event.ignore()
            return
        if self._ai_review_workspace.generation_busy:
            QMessageBox.information(
                self,
                "BioCLIP generation running",
                "Wait for the local BioCLIP generation to finish or cancel it before closing Aperture.",
            )
            event.ignore()
            return
        current = self._navigation.currentItem()
        current_name = current.data(0, Qt.ItemDataRole.UserRole) if current is not None else "Library"
        workspace = str(current_name or "Library").casefold().replace(" ", "_")
        state = SessionState(
            workspace=workspace,
            window_geometry_b64=bytes(self.saveGeometry().toBase64()).decode("ascii"),
            dock_state_b64=None,
            grid_thumbnail_size=self._session.grid_thumbnail_size,
            sort_mode=self._session.sort_mode,
            inspector_visible=self.findChild(QDockWidget, "inspectorDock").isVisible(),
        )
        self._store.save(self._session_path, state)
        super().closeEvent(event)


def run_desktop(
    *,
    library_name: str,
    session_path: Path,
    import_service: ImportApplicationService,
    catalog_service: CatalogApplicationService,
    thumbnail_service: CatalogThumbnailService,
    catalog_edit_service: CatalogEditApplicationService,
    search_service: QuickSearchApplicationService,
    views_service: LibraryViewsApplicationService,
    ai_review_workspace_factory: Callable[[Callable[[], tuple[str, ...]]], AIReviewWorkspace],
    backup_service: LibraryBackupService,
    default_backup_directory: Path,
    health_service: LibraryHealthService | None = None,
    on_about_to_quit: Callable[[], None] = lambda: None,
    argv: Sequence[str] | None = None,
    startup_timeline: StartupTimeline | None = None,
) -> int:
    app = QApplication(list(argv or []))
    app.setApplicationName("Aperture")
    app.setOrganizationName("natuurgids.org")
    icon_path = Path(__file__).resolve().parents[2] / "resources" / "aperture.ico"
    if icon_path.exists(): app.setWindowIcon(QIcon(str(icon_path)))
    app.aboutToQuit.connect(on_about_to_quit)
    window = MainWindow(
        library_name=library_name,
        session_path=session_path,
        import_service=import_service,
        catalog_service=catalog_service,
        thumbnail_service=thumbnail_service,
        catalog_edit_service=catalog_edit_service,
        search_service=search_service,
        views_service=views_service,
        ai_review_workspace_factory=ai_review_workspace_factory,
        backup_service=backup_service,
        default_backup_directory=default_backup_directory,
        health_service=health_service,
    )
    window.show()
    if startup_timeline is not None:
        def record_first_paint() -> None:
            startup_timeline.mark("main-window-visible")
            startup_timeline.write(library=library_name)
        QTimer.singleShot(0, record_first_paint)
    return app.exec()
