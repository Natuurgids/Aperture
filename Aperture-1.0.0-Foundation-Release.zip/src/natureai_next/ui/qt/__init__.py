"""Qt widget implementation."""
