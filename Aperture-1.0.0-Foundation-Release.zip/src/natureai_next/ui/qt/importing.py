"""Qt import workspace backed by the production import application service."""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Protocol

from natureai_next.domain.importing import DuplicatePolicy, ImportStoragePolicy, ImportSummary

try:
    from PySide6.QtCore import QObject, QThread, Signal, Slot
    from PySide6.QtWidgets import (
        QCheckBox,
        QComboBox,
        QFileDialog,
        QFormLayout,
        QHBoxLayout,
        QLabel,
        QLineEdit,
        QMessageBox,
        QPlainTextEdit,
        QPushButton,
        QVBoxLayout,
        QWidget,
    )
except ImportError as exc:  # pragma: no cover - optional GUI dependency
    raise RuntimeError("PySide6 is required; install natureai-next[gui]") from exc


class ImportApplicationService(Protocol):
    def plan(
        self,
        roots: tuple[Path, ...],
        *,
        storage_policy: ImportStoragePolicy,
        duplicate_policy: DuplicatePolicy,
        recursive: bool = True,
    ): ...

    def execute(self, plan) -> ImportSummary: ...


@dataclass(frozen=True, slots=True)
class ImportRequest:
    source: Path
    storage_policy: ImportStoragePolicy
    duplicate_policy: DuplicatePolicy
    recursive: bool


class _ImportWorker(QObject):
    completed = Signal(object)
    failed = Signal(str)
    status = Signal(str)

    def __init__(self, service: ImportApplicationService, request: ImportRequest) -> None:
        super().__init__()
        self._service = service
        self._request = request

    @Slot()
    def run(self) -> None:
        try:
            self.status.emit("Scanning, probing and hashing source files…")
            plan = self._service.plan(
                (self._request.source,),
                storage_policy=self._request.storage_policy,
                duplicate_policy=self._request.duplicate_policy,
                recursive=self._request.recursive,
            )
            self.status.emit(f"Importing {len(plan.items)} planned file(s)…")
            self.completed.emit(self._service.execute(plan))
        except Exception as exc:  # the application service records per-item failures
            self.failed.emit(f"{type(exc).__name__}: {exc}")


class ImportWorkspace(QWidget):
    """Folder import UI that delegates all catalog changes to ImportService."""

    import_finished = Signal(object)

    def __init__(self, service: ImportApplicationService, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self._service = service
        self._thread: QThread | None = None
        self._worker: _ImportWorker | None = None

        self._source = QLineEdit()
        self._source.setReadOnly(True)
        browse = QPushButton("Choose folder…")
        browse.clicked.connect(self.choose_folder)
        source_row = QHBoxLayout()
        source_row.addWidget(self._source, 1)
        source_row.addWidget(browse)

        self._storage = QComboBox()
        self._storage.addItem("Managed copy", ImportStoragePolicy.MANAGED)
        self._storage.addItem("Reference files in place", ImportStoragePolicy.REFERENCED)
        self._storage.addItem("Managed copy + source reference", ImportStoragePolicy.HYBRID)

        self._duplicates = QComboBox()
        self._duplicates.addItem("Skip exact duplicates", DuplicatePolicy.SKIP)
        self._duplicates.addItem("Attach duplicate path to existing asset", DuplicatePolicy.ADD_FILE_INSTANCE)

        self._recursive = QCheckBox("Include subfolders")
        self._recursive.setChecked(True)

        form = QFormLayout()
        form.addRow("Source folder", source_row)
        form.addRow("Storage", self._storage)
        form.addRow("Duplicates", self._duplicates)
        form.addRow("", self._recursive)

        self._start = QPushButton("Start import")
        self._start.setEnabled(False)
        self._start.clicked.connect(self.start_import)
        self._status = QLabel("Choose a folder containing test photographs.")
        self._details = QPlainTextEdit()
        self._details.setReadOnly(True)

        layout = QVBoxLayout(self)
        layout.addLayout(form)
        layout.addWidget(self._start)
        layout.addWidget(self._status)
        layout.addWidget(self._details, 1)

    @Slot()
    def choose_folder(self) -> None:
        selected = QFileDialog.getExistingDirectory(self, "Choose image folder", self._source.text())
        if selected:
            self.set_source(Path(selected))

    def set_source(self, source: Path) -> None:
        self._source.setText(str(source))
        self._start.setEnabled(source.is_dir() and self._thread is None)

    @Slot()
    def start_import(self) -> None:
        source = Path(self._source.text())
        if not source.is_dir():
            QMessageBox.warning(self, "Import", "Choose an existing source folder first.")
            return
        request = ImportRequest(
            source=source,
            storage_policy=self._storage.currentData(),
            duplicate_policy=self._duplicates.currentData(),
            recursive=self._recursive.isChecked(),
        )
        self._set_busy(True)
        self._details.clear()
        thread = QThread(self)
        worker = _ImportWorker(self._service, request)
        worker.moveToThread(thread)
        thread.started.connect(worker.run)
        worker.status.connect(self._status.setText)
        worker.completed.connect(self._on_completed)
        worker.failed.connect(self._on_failed)
        worker.completed.connect(thread.quit)
        worker.failed.connect(thread.quit)
        thread.finished.connect(self._on_thread_finished)
        thread.finished.connect(worker.deleteLater)
        self._thread = thread
        self._worker = worker
        thread.start()

    @Slot(object)
    def _on_completed(self, summary: ImportSummary) -> None:
        self._status.setText(
            f"Completed: {summary.imported} imported, {summary.attached} attached, "
            f"{summary.skipped} skipped, {summary.failed} failed."
        )
        lines = [
            f"Total: {summary.total}",
            f"Imported: {summary.imported}",
            f"Attached: {summary.attached}",
            f"Skipped: {summary.skipped}",
            f"Failed: {summary.failed}",
        ]
        for result in summary.results:
            if result.state == "failed":
                lines.append(f"FAILED {result.source_path or result.item_key}: {result.error_code or 'unknown error'}")
        self._details.setPlainText("\n".join(lines))
        self.import_finished.emit(summary)

    @Slot(str)
    def _on_failed(self, message: str) -> None:
        self._status.setText("Import planning failed.")
        self._details.setPlainText(message)
        QMessageBox.critical(self, "Import failed", message)

    @Slot()
    def _on_thread_finished(self) -> None:
        self._thread = None
        self._worker = None
        self._set_busy(False)

    def _set_busy(self, busy: bool) -> None:
        self._start.setEnabled(not busy and Path(self._source.text()).is_dir())
        self._storage.setEnabled(not busy)
        self._duplicates.setEnabled(not busy)
        self._recursive.setEnabled(not busy)
