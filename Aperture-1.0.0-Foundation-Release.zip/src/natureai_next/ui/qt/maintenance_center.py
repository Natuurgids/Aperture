"""Standalone Aperture Maintenance Center desktop application."""
from __future__ import annotations

import ctypes
from datetime import datetime, timezone
import json
import os
import shutil
import sqlite3
import subprocess
import sys
import time
from pathlib import Path
from typing import Any, Sequence

from natureai_next.application.backup import LibraryBackupService, suggested_backup_name
from natureai_next.application.recovery import LibraryRecoveryService
from natureai_next.bootstrap.container import build_foundation_container
from natureai_next.application.library_service import LibraryService
from natureai_next.bootstrap.startup_timing import latest_startup_summary
from natureai_next.infrastructure.database.restore import validate_database_and_close, replace_database_with_retry

try:
    from PySide6.QtCore import Qt, QTimer
    from PySide6.QtGui import QGuiApplication, QIcon
    from PySide6.QtWidgets import (
        QApplication, QFileDialog, QLabel, QMainWindow, QMessageBox,
        QPushButton, QTableWidget, QTableWidgetItem, QHBoxLayout, QVBoxLayout, QWidget, QGroupBox, QFormLayout, QProgressBar,
    )
except ImportError as exc:  # pragma: no cover
    raise RuntimeError("PySide6 is required; install natureai-next[gui]") from exc


def _last_library() -> Path | None:
    path = Path(os.environ.get("APPDATA", Path.home())) / "NatureAI" / "NatureAI Next" / "launcher.json"
    try:
        value = json.loads(path.read_text(encoding="utf-8")).get("last_library")
    except (OSError, ValueError, TypeError):
        return None
    return Path(str(value)) if value else None


def _request_aperture_close(timeout: float = 20.0) -> bool:
    """Ask running Aperture windows to close cleanly; never terminate them forcibly."""
    if os.name != "nt":
        return True
    user32 = ctypes.windll.user32
    kernel32 = ctypes.windll.kernel32
    current_pid = os.getpid()
    pids: set[int] = set()
    EnumWindowsProc = ctypes.WINFUNCTYPE(ctypes.c_bool, ctypes.c_void_p, ctypes.c_void_p)

    def callback(hwnd: int, _lparam: int) -> bool:
        pid = ctypes.c_ulong()
        user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
        if pid.value and pid.value != current_pid:
            length = user32.GetWindowTextLengthW(hwnd)
            title = ctypes.create_unicode_buffer(length + 1)
            user32.GetWindowTextW(hwnd, title, length + 1)
            if title.value.startswith("Aperture —") or title.value == "Aperture":
                pids.add(int(pid.value))
                user32.PostMessageW(hwnd, 0x0010, 0, 0)  # WM_CLOSE
        return True

    user32.EnumWindows(EnumWindowsProc(callback), 0)
    deadline = time.monotonic() + timeout
    while pids and time.monotonic() < deadline:
        remaining: set[int] = set()
        for pid in pids:
            handle = kernel32.OpenProcess(0x1000, False, pid)
            if handle:
                kernel32.CloseHandle(handle)
                remaining.add(pid)
        pids = remaining
        if pids:
            time.sleep(0.25)
    return not pids




def _wait_for_library_unlock(library: Path, timeout: float = 10.0) -> bool:
    """Wait for clean lock release; remove only a demonstrably stale local lock."""
    from natureai_next.infrastructure.filesystem.library_lock import _process_is_alive, _read_owner
    lock_path = library / ".natureai-next.lock"
    deadline = time.monotonic() + timeout
    while lock_path.exists() and time.monotonic() < deadline:
        owner = _read_owner(lock_path)
        if owner is not None and not _process_is_alive(owner.pid):
            try:
                lock_path.unlink()
            except FileNotFoundError:
                pass
            except OSError:
                return False
            return True
        time.sleep(0.2)
    return not lock_path.exists()



def _append_restore_log(library: Path, status: str, detail: str = "", **extra: Any) -> None:
    log_dir = Path(os.environ.get("LOCALAPPDATA", Path.home())) / "Aperture" / "Logs"
    log_dir.mkdir(parents=True, exist_ok=True)
    payload: dict[str, Any] = {
        "created_at_utc": datetime.now(timezone.utc).isoformat(),
        "library": str(library.resolve()),
        "status": status,
        "detail": detail,
    }
    payload.update(extra)
    with (log_dir / "restore-history.jsonl").open("a", encoding="utf-8") as handle:
        handle.write(json.dumps(payload, sort_keys=True) + "\n")


def _create_emergency_backup(library: Path) -> object:
    """Create and verify a SQLite online backup without acquiring the library lock."""
    source = (library / "library.sqlite3").resolve()
    if not source.is_file():
        raise FileNotFoundError(f"library database not found: {source}")
    backup_dir = library / "backups"
    backup_dir.mkdir(parents=True, exist_ok=True)
    try:
        manifest = json.loads((library / "library.json").read_text(encoding="utf-8-sig"))
        library_name = str(manifest.get("display_name") or manifest.get("library_name") or library.name)
    except (OSError, ValueError, TypeError):
        library_name = library.name

    def backup_database(destination: Path) -> Path:
        source_connection: sqlite3.Connection | None = None
        destination_connection: sqlite3.Connection | None = None
        cursor: sqlite3.Cursor | None = None
        try:
            source_connection = sqlite3.connect(
                f"file:{source.as_posix()}?mode=ro", uri=True
            )
            destination_connection = sqlite3.connect(str(destination))
            source_connection.backup(destination_connection)
            cursor = destination_connection.cursor()
            result = cursor.execute("PRAGMA integrity_check").fetchone()
            if result is None or str(result[0]).casefold() != "ok":
                raise RuntimeError(f"Emergency backup integrity check failed: {result}")
        finally:
            if cursor is not None:
                cursor.close()
            if destination_connection is not None:
                destination_connection.close()
            if source_connection is not None:
                source_connection.close()
        return destination

    result = LibraryBackupService(backup_database, library_name=library_name).create(
        backup_dir / suggested_backup_name(f"{library_name}-pre-restore")
    )
    LibraryRecoveryService().verify(result.database_path)
    return result

def _launch_aperture(library: Path) -> None:
    scripts_dir = Path(sys.prefix) / ("Scripts" if os.name == "nt" else "bin")
    executable = scripts_dir / ("natureai-next.exe" if os.name == "nt" else "natureai-next")
    command = [str(executable if executable.is_file() else sys.executable)]
    if not executable.is_file():
        command += ["-m", "natureai_next.bootstrap.cli"]
    command += ["--library", str(library)]
    subprocess.Popen(command, stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL,
                     stderr=subprocess.DEVNULL, close_fds=True)


class MaintenanceCenterWindow(QMainWindow):
    def __init__(self, library: Path) -> None:
        super().__init__()
        self.library = library.resolve()
        self.recovery = LibraryRecoveryService()
        self.setWindowTitle("Aperture Maintenance Center")
        icon = Path(__file__).resolve().parents[2] / "resources" / "aperture.ico"
        if icon.exists():
            self.setWindowIcon(QIcon(str(icon)))
        panel = QWidget(); layout = QVBoxLayout(panel)
        title = QLabel("<h2>Aperture Maintenance Center</h2>")
        detail = QLabel(f"Library: {self.library}<br><br>Manage verified backups, restore operations, operational locations, and maintenance history. Aperture libraries and photographs are never removed by routine maintenance actions.")
        detail.setWordWrap(True)
        layout.addWidget(title); layout.addWidget(detail)
        self.status_label = QLabel("Ready")
        self.status_label.setAccessibleName("Maintenance Center status")
        layout.addWidget(self.status_label)
        self.progress = QProgressBar()
        self.progress.setRange(0, 0)
        self.progress.setVisible(False)
        self.progress.setAccessibleName("Maintenance operation progress")
        layout.addWidget(self.progress)

        paths_group = QGroupBox("Operational locations")
        paths_form = QFormLayout(paths_group)
        self._path_values: dict[str, Path] = {
            "Library root": self.library,
            "SQLite database": self.library / "library.sqlite3",
            "Library manifest": self.library / "library.json",
            "Backups": self.library / "backups",
            "Cache": self.library / "cache",
            "Temporary files": self.library / "temp",
            "Application logs": Path(os.environ.get("LOCALAPPDATA", Path.home())) / "Aperture" / "Logs",
        }
        for label, path in self._path_values.items():
            row = QHBoxLayout()
            value = QLabel(str(path))
            value.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse | Qt.TextInteractionFlag.TextSelectableByKeyboard)
            value.setAccessibleName(f"{label} path")
            copy_button = QPushButton("Copy Path")
            copy_button.clicked.connect(lambda _checked=False, p=path: QGuiApplication.clipboard().setText(str(p)))
            open_button = QPushButton("Open Folder")
            open_button.clicked.connect(lambda _checked=False, p=path: self._open_operational_path(p))
            row.addWidget(value, 1); row.addWidget(copy_button); row.addWidget(open_button)
            paths_form.addRow(label, row)
        layout.addWidget(paths_group)

        performance_group = QGroupBox("Startup performance")
        performance_form = QFormLayout(performance_group)
        latest = latest_startup_summary()
        if latest is None:
            startup_text = "No startup timing record is available yet."
        else:
            events = latest.get("events", [])
            visible = next((event for event in reversed(events) if event.get("stage") == "main-window-visible"), None)
            startup_text = (f"{visible.get('elapsed_ms')} ms to first visible window" if visible else "Startup record does not contain first-paint timing.")
        self.startup_summary_label = QLabel(startup_text)
        self.startup_summary_label.setAccessibleName("Latest Aperture startup timing")
        performance_form.addRow("Latest startup", self.startup_summary_label)
        open_startup_log = QPushButton("Open Startup Log")
        open_startup_log.clicked.connect(lambda: self._open_operational_path(self._path_values["Application logs"] / "startup-timing.jsonl"))
        performance_form.addRow("Diagnostics", open_startup_log)
        layout.addWidget(performance_group)

        self.backup_table = QTableWidget(0, 4)
        self.backup_table.setHorizontalHeaderLabels(["Created", "Library", "Size", "File"])
        self.backup_table.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)
        self.backup_table.setSelectionMode(QTableWidget.SelectionMode.SingleSelection)
        self.backup_table.setAccessibleName("Verified backup history")
        layout.addWidget(self.backup_table)
        actions = QHBoxLayout()
        self._action_buttons: list[QPushButton] = []
        for text, handler in (
            ("Back Up Library…", self.backup),
            ("Restore Selected", self.restore_selected),
            ("Verify Selected", self.verify_selected),
            ("Delete Selected", self.delete_selected),
            ("Open Backup Folder", self.open_folder),
        ):
            button = QPushButton(text); button.clicked.connect(handler); actions.addWidget(button); self._action_buttons.append(button)
        layout.addLayout(actions)
        self.setCentralWidget(panel); self.resize(980, 720)
        for button in self._action_buttons:
            button.setEnabled(False)
        QTimer.singleShot(0, self.refresh_backups)


    def _set_operation_status(self, text: str, *, busy: bool = True) -> None:
        self.status_label.setText(text)
        self.progress.setVisible(busy)
        for button in self._action_buttons:
            button.setEnabled(not busy)
        QApplication.processEvents()


    def _open_operational_path(self, path: Path) -> None:
        target = path if path.is_dir() else path.parent
        target.mkdir(parents=True, exist_ok=True)
        if os.name == "nt":
            os.startfile(target)  # type: ignore[attr-defined]

    def refresh_backups(self) -> None:
        self.status_label.setText("Refreshing verified backup history…")
        self.progress.setVisible(True)
        backups = self.recovery.list_backups(self.library / "backups")
        self.backup_table.setRowCount(len(backups))
        for row, backup in enumerate(backups):
            values = (
                backup.created_at_utc.replace("T", " ").replace("+00:00", " UTC"),
                backup.library_name,
                f"{backup.size_bytes / (1024 * 1024):.1f} MB",
                backup.database_path.name,
            )
            for column, value in enumerate(values):
                item = QTableWidgetItem(value)
                item.setData(Qt.ItemDataRole.UserRole, str(backup.database_path))
                self.backup_table.setItem(row, column, item)
        self.backup_table.resizeColumnsToContents()
        self.status_label.setText(f"Ready — {len(backups)} verified backup(s) found")
        self.progress.setVisible(False)
        for button in self._action_buttons:
            button.setEnabled(True)

    def _selected_backup_path(self) -> Path | None:
        row = self.backup_table.currentRow()
        if row < 0:
            QMessageBox.information(self, "Select a backup", "Select a verified backup from the list first.")
            return None
        item = self.backup_table.item(row, 0)
        return Path(str(item.data(Qt.ItemDataRole.UserRole))) if item is not None else None

    def verify_selected(self) -> None:
        selected = self._selected_backup_path()
        if selected is not None:
            self._verify_path(selected)

    def restore_selected(self) -> None:
        selected = self._selected_backup_path()
        if selected is not None:
            self._restore_path(selected)

    def delete_selected(self) -> None:
        selected = self._selected_backup_path()
        if selected is None:
            return
        answer = QMessageBox.warning(
            self, "Delete backup",
            f"Delete this verified backup and its manifest?\n\n{selected.name}",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.Cancel,
            QMessageBox.StandardButton.Cancel,
        )
        if answer != QMessageBox.StandardButton.Yes:
            return
        selected.unlink(missing_ok=True)
        selected.with_suffix(selected.suffix + ".manifest.json").unlink(missing_ok=True)
        self.refresh_backups()

    def _library_service(self) -> LibraryService:
        container = build_foundation_container()
        return LibraryService(container.clock, container.uuid_generator)

    def backup(self) -> None:
        default = self.library / "backups" / suggested_backup_name(self.library.name)
        selected, _ = QFileDialog.getSaveFileName(self, "Back Up Aperture Library", str(default), "SQLite backup (*.sqlite3)")
        if not selected:
            return
        try:
            with self._library_service().open(self.library) as opened:
                result = LibraryBackupService(opened.backup_database, library_name=opened.manifest.display_name).create(Path(selected))
        except Exception as exc:
            QMessageBox.critical(self, "Backup failed", str(exc)); return
        QMessageBox.information(self, "Backup complete", f"Backup verified and saved:\n{result.database_path}\n\nSHA-256: {result.sha256}")
        self.refresh_backups()

    def verify(self) -> None:
        selected, _ = QFileDialog.getOpenFileName(self, "Verify Aperture Backup", str(self.library / "backups"), "SQLite backup (*.sqlite3 *.db)")
        if selected:
            self._verify_path(Path(selected))

    def _verify_path(self, selected: Path) -> None:
        try:
            item = self.recovery.verify(selected)
        except Exception as exc:
            QMessageBox.critical(self, "Backup invalid", str(exc)); return
        QMessageBox.information(self, "Backup verified", f"Library: {item.library_name}\nCreated: {item.created_at_utc}\nSHA-256: {item.sha256}")

    def restore(self) -> None:
        selected, _ = QFileDialog.getOpenFileName(self, "Restore Aperture Library", str(self.library / "backups"), "SQLite backup (*.sqlite3 *.db)")
        if selected:
            self._restore_path(Path(selected))

    def _restore_path(self, selected: Path) -> None:
        try:
            verified = self.recovery.verify(selected)
        except Exception as exc:
            QMessageBox.critical(self, "Restore unavailable", str(exc)); return

        prompt = QMessageBox(self)
        prompt.setIcon(QMessageBox.Icon.Warning)
        prompt.setWindowTitle("Restore Aperture library")
        prompt.setText(
            "Aperture will close while the selected database is restored. "
            "The Maintenance Center will remain visible and show progress. "
            "After validation, Aperture will restart automatically."
        )
        prompt.setInformativeText(
            f"Restore backup: {verified.database_path.name}\nCreated: {verified.created_at_utc}"
        )
        backup_button = prompt.addButton("Back Up and Restore", QMessageBox.ButtonRole.AcceptRole)
        no_backup_button = prompt.addButton("Restore Without Backup", QMessageBox.ButtonRole.DestructiveRole)
        cancel_button = prompt.addButton(QMessageBox.StandardButton.Cancel)
        prompt.setDefaultButton(backup_button)
        prompt.exec()
        clicked = prompt.clickedButton()
        if clicked is cancel_button or clicked not in (backup_button, no_backup_button):
            return
        create_emergency_backup = clicked is backup_button

        emergency = None
        target = self.library / "library.sqlite3"
        rollback = target.with_suffix(target.suffix + ".pre-restore-rollback")
        temp = target.with_suffix(target.suffix + ".restore.tmp")
        _append_restore_log(self.library, "started", backup=str(verified.database_path), emergency_backup=create_emergency_backup)
        try:
            self.show(); self.raise_(); self.activateWindow()
            if create_emergency_backup:
                self._set_operation_status("Creating and verifying the emergency backup…")
                emergency = _create_emergency_backup(self.library)
                _append_restore_log(self.library, "emergency-backup-created", path=str(emergency.database_path))

            self._set_operation_status("Closing Aperture safely before restore…")
            if not _request_aperture_close():
                raise RuntimeError("Aperture did not close. Save your work, close Aperture, and try again.")

            self._set_operation_status("Waiting for the library lock to be released…")
            if not _wait_for_library_unlock(self.library):
                raise RuntimeError("Aperture closed, but the library lock was not released safely.")

            self._set_operation_status("Restoring the selected database…")
            shutil.copy2(target, rollback)
            shutil.copy2(verified.database_path, temp)
            # Runs PRAGMA integrity_check and PRAGMA foreign_key_check, then closes every SQLite handle.
            validate_database_and_close(temp)
            _append_restore_log(
                self.library, "validated-and-closed", database=str(temp)
            )
            replace_database_with_retry(
                temp,
                target,
                retry_logger=lambda attempt, exc: _append_restore_log(
                    self.library,
                    "replace-retry",
                    str(exc),
                    attempt=attempt,
                    source=str(temp),
                    target=str(target),
                ),
            )
            _append_restore_log(self.library, "restored", restored_database=str(verified.database_path))
        except Exception as exc:
            if rollback.is_file():
                shutil.copy2(rollback, target)
            _append_restore_log(self.library, "failed", str(exc))
            self._set_operation_status("Restore failed", busy=False)
            QMessageBox.critical(self, "Restore failed", f"The previous database was preserved or restored.\n\n{exc}")
            return
        finally:
            temp.unlink(missing_ok=True)

        self._set_operation_status("Restore complete. Restarting Aperture…")
        detail = "The database was restored and validated successfully."
        if emergency is not None:
            detail += f"\n\nEmergency backup: {emergency.database_path}"
        detail += "\n\nAperture will now restart."
        QMessageBox.information(self, "Restore complete", detail)
        _launch_aperture(self.library)
        QTimer.singleShot(1500, self.close)

    def open_folder(self) -> None:
        folder = self.library / "backups"; folder.mkdir(parents=True, exist_ok=True)
        if os.name == "nt":
            os.startfile(folder)  # type: ignore[attr-defined]


def main(argv: Sequence[str] | None = None) -> int:
    import argparse
    parser = argparse.ArgumentParser(prog="aperture-maintenance-center")
    parser.add_argument("--library", type=Path)
    parser.add_argument("--ready-file", type=Path)
    args = parser.parse_args(argv)
    library = args.library or _last_library()
    if library is None:
        app = QApplication.instance() or QApplication([])
        QMessageBox.critical(None, "Library required", "Open Aperture once or provide --library to select a library.")
        return 2
    app = QApplication.instance() or QApplication([])
    window = MaintenanceCenterWindow(library)
    window.show()
    window.raise_()
    window.activateWindow()
    app.processEvents()
    if args.ready_file is not None:
        args.ready_file.parent.mkdir(parents=True, exist_ok=True)
        temp = args.ready_file.with_suffix(args.ready_file.suffix + ".tmp")
        temp.write_text(
            json.dumps({"status": "window-ready", "pid": os.getpid()}, sort_keys=True) + "\n",
            encoding="utf-8",
        )
        temp.replace(args.ready_file)
    return app.exec()
