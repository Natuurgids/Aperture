"""Guided BioCLIP setup wizard with no hand-edited manifests."""
from __future__ import annotations

import os
from pathlib import Path

from natureai_next.application.ai_setup import (
    BioCLIPQuickSetupService,
    BioCLIPSetupRequest,
    BioCLIPSetupResult,
)

try:
    from PySide6.QtCore import QObject, QThread, Signal, Slot
    from PySide6.QtWidgets import (
        QCheckBox,
        QDialog,
        QFileDialog,
        QFormLayout,
        QHBoxLayout,
        QLabel,
        QLineEdit,
        QMessageBox,
        QProgressBar,
        QPushButton,
        QVBoxLayout,
        QWidget,
    )
except ImportError as exc:  # pragma: no cover
    raise RuntimeError("PySide6 is required") from exc


class _SetupWorker(QObject):
    progress = Signal(int, int, str)
    succeeded = Signal(object)
    failed = Signal(str)
    finished = Signal()

    def __init__(self, service: BioCLIPQuickSetupService, request: BioCLIPSetupRequest) -> None:
        super().__init__()
        self._service = service
        self._request = request

    @Slot()
    def run(self) -> None:
        try:
            result = self._service.run(
                self._request,
                progress=lambda current, total, message: self.progress.emit(
                    current, total, message
                ),
            )
            self.succeeded.emit(result)
        except Exception as exc:
            self.failed.emit(str(exc))
        finally:
            self.finished.emit()


class BioCLIPSetupDialog(QDialog):
    """Downloads or imports BioCLIP, signs it locally, installs it, and optionally imports CSV taxonomy."""

    def __init__(self, service: BioCLIPQuickSetupService, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self._service = service
        self._thread: QThread | None = None
        self._worker: _SetupWorker | None = None
        self.setWindowTitle("BioCLIP Quick Setup")
        self.setMinimumWidth(760)

        intro = QLabel(
            "This wizard creates every NatureAI package and manifest automatically. "
            "You may download the official Imageomics BioCLIP checkpoint or select a checkpoint "
            "already stored on this computer. An optional taxonomy CSV can contain columns "
            "scientific_name, common_name, rank, source_taxon_id, kingdom, major_group, "
            "language_tag, and region_code."
        )
        intro.setWordWrap(True)

        default_root = Path("D:/NatureAI-Models") if os.name == "nt" else Path.home() / "NatureAI-Models"
        self._workspace = QLineEdit(str(default_root))
        self._checkpoint = QLineEdit()
        self._taxonomy = QLineEdit()
        self._download = QCheckBox("Download the official Imageomics BioCLIP checkpoint")
        self._consent = QCheckBox(
            "I understand the checkpoint is obtained from Imageomics/Hugging Face under its upstream license."
        )
        self._download.toggled.connect(self._download_changed)

        form = QFormLayout()
        form.addRow("Resource workspace", self._folder_row(self._workspace))
        form.addRow("Existing checkpoint (optional)", self._file_row(
            self._checkpoint, "Model files (*.bin *.pt *.pth);;All files (*)"
        ))
        form.addRow("Taxonomy CSV (optional)", self._file_row(
            self._taxonomy, "CSV files (*.csv)"
        ))

        self._start = QPushButton("Build, install and activate resources")
        self._close = QPushButton("Close")
        self._start.clicked.connect(self._begin)
        self._close.clicked.connect(self.accept)
        buttons = QHBoxLayout()
        buttons.addWidget(self._start)
        buttons.addStretch(1)
        buttons.addWidget(self._close)

        self._progress = QProgressBar()
        self._progress.setRange(0, 7)
        self._progress.setValue(0)
        self._status = QLabel("Ready")
        self._status.setWordWrap(True)

        layout = QVBoxLayout(self)
        layout.addWidget(intro)
        layout.addLayout(form)
        layout.addWidget(self._download)
        layout.addWidget(self._consent)
        layout.addWidget(self._progress)
        layout.addWidget(self._status)
        layout.addLayout(buttons)
        self._download_changed(False)

    def _folder_row(self, field: QLineEdit) -> QWidget:
        host = QWidget(self)
        layout = QHBoxLayout(host)
        layout.setContentsMargins(0, 0, 0, 0)
        button = QPushButton("Browse…")
        button.clicked.connect(lambda: self._pick_folder(field))
        layout.addWidget(field, 1)
        layout.addWidget(button)
        return host

    def _file_row(self, field: QLineEdit, pattern: str) -> QWidget:
        host = QWidget(self)
        layout = QHBoxLayout(host)
        layout.setContentsMargins(0, 0, 0, 0)
        button = QPushButton("Browse…")
        button.clicked.connect(lambda: self._pick_file(field, pattern))
        layout.addWidget(field, 1)
        layout.addWidget(button)
        return host

    def _pick_folder(self, field: QLineEdit) -> None:
        value = QFileDialog.getExistingDirectory(self, "Select resource workspace", field.text())
        if value:
            field.setText(value)

    def _pick_file(self, field: QLineEdit, pattern: str) -> None:
        value, _ = QFileDialog.getOpenFileName(self, "Select local file", "", pattern)
        if value:
            field.setText(value)

    @Slot(bool)
    def _download_changed(self, enabled: bool) -> None:
        self._consent.setEnabled(enabled)
        if not enabled:
            self._consent.setChecked(False)

    @Slot()
    def _begin(self) -> None:
        if self._thread is not None:
            return
        if self._download.isChecked() and not self._consent.isChecked():
            QMessageBox.warning(self, "BioCLIP Quick Setup", "Confirm the upstream download notice first.")
            return
        checkpoint_text = self._checkpoint.text().strip()
        taxonomy_text = self._taxonomy.text().strip()
        request = BioCLIPSetupRequest(
            workspace=Path(self._workspace.text().strip()),
            checkpoint=Path(checkpoint_text) if checkpoint_text else None,
            download_official_checkpoint=self._download.isChecked(),
            taxonomy_csv=Path(taxonomy_text) if taxonomy_text else None,
        )
        thread = QThread(self)
        worker = _SetupWorker(self._service, request)
        worker.moveToThread(thread)
        thread.started.connect(worker.run)
        worker.progress.connect(self._on_progress)
        worker.succeeded.connect(self._on_success)
        worker.failed.connect(self._on_failure)
        worker.finished.connect(thread.quit)
        worker.finished.connect(worker.deleteLater)
        thread.finished.connect(thread.deleteLater)
        thread.finished.connect(self._finished)
        self._thread = thread
        self._worker = worker
        self._start.setEnabled(False)
        self._close.setEnabled(False)
        self._status.setText("Starting BioCLIP setup…")
        thread.start()

    @Slot(int, int, str)
    def _on_progress(self, current: int, total: int, message: str) -> None:
        self._progress.setRange(0, total)
        self._progress.setValue(current)
        self._status.setText(message)

    @Slot(object)
    def _on_success(self, result: object) -> None:
        if not isinstance(result, BioCLIPSetupResult):
            self._on_failure("The setup service returned an invalid result.")
            return
        details = [
            f"Model installed: {result.model_public_id}",
            f"Package: {result.model_package}",
            f"Trusted keys: {result.trusted_keys}",
        ]
        if result.taxonomy_source_public_id:
            details.append(f"Taxonomy installed: {result.taxonomy_source_public_id}")
        if result.prompt_public_id:
            details.append(f"Prompt set installed: {result.prompt_public_id}")
        if result.embedding_counts:
            details.append(
                f"Taxonomy embeddings: {result.embedding_counts[1]} written from "
                f"{result.embedding_counts[0]} labels"
            )
        self._status.setText("Setup completed successfully.")
        QMessageBox.information(self, "BioCLIP Quick Setup", "\n".join(details))

    @Slot(str)
    def _on_failure(self, message: str) -> None:
        self._status.setText(message)
        QMessageBox.warning(self, "BioCLIP Quick Setup", message)

    @Slot()
    def _finished(self) -> None:
        self._thread = None
        self._worker = None
        self._start.setEnabled(True)
        self._close.setEnabled(True)

    def reject(self) -> None:
        if self._thread is not None:
            QMessageBox.information(self, "BioCLIP Quick Setup", "Wait for the current setup step to finish.")
            return
        super().reject()
