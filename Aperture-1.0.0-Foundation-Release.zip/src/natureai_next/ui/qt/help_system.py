"""Integrated, offline help and shortcut discovery for Aperture."""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

try:
    from PySide6.QtCore import Qt
    from PySide6.QtWidgets import (
        QDialog,
        QHBoxLayout,
        QLabel,
        QLineEdit,
        QListWidget,
        QListWidgetItem,
        QPushButton,
        QTextBrowser,
        QVBoxLayout,
        QWidget,
    )
except ImportError as exc:  # pragma: no cover
    raise RuntimeError("PySide6 is required") from exc


@dataclass(frozen=True, slots=True)
class HelpTopic:
    topic_id: str
    title: str
    relative_path: str
    workspace: str | None = None


HELP_TOPICS = (
    HelpTopic("quick-start", "Quick Start", "getting-started/quick-start.md", "Library"),
    HelpTopic("user-guide", "User Guide", "user-guide/README.md", "Library"),
    HelpTopic("keyboard", "Keyboard Shortcuts", "accessibility/ACCESSIBILITY_AND_KEYBOARD.md"),
    HelpTopic("ai-review", "AI Review Workspace", "user-guide/ai-and-resources.md", "AI Review"),
    HelpTopic("import", "Import Guide", "user-guide/import-export.md", "Imports"),
    HelpTopic("backup-recovery", "Backup & Recovery", "operations/backup-recovery.md", "Health Check"),
    HelpTopic("maintenance-center", "Maintenance Center", "operations/maintenance-center.md", "Settings"),
    HelpTopic("updates", "Offline Updates", "operations/offline-updates.md", "Updates"),
    HelpTopic("health", "Health Center", "operations/health-center.md", "Health Check"),
    HelpTopic("troubleshooting", "Troubleshooting", "operations/troubleshooting.md", "Diagnostics"),
    HelpTopic("build-windows-installer", "Build Windows Installer", "developer/build-windows-installer.md"),
    HelpTopic("roadmap", "Roadmap & Future Releases", "user-guide/roadmap.md"),
    HelpTopic("handover", "Version 1 Project Handover", "PROJECT_HANDOVER.md"),
    HelpTopic("version2-charter", "Version 2 Development Charter", "VERSION2_DEVELOPMENT_CHARTER.md"),
    HelpTopic("release-notes", "Release Notes", "../RELEASE_NOTES.md"),
)

WORKSPACE_TOPIC = {topic.workspace: topic.topic_id for topic in HELP_TOPICS if topic.workspace}


def documentation_root() -> Path:
    """Resolve bundled docs in source and installed-release layouts."""
    package_help = Path(__file__).resolve().parents[2] / "resources" / "help"
    candidates = (
        package_help,
        Path(__file__).resolve().parents[4] / "docs",
        Path(__file__).resolve().parents[3] / "docs",
        Path.cwd() / "docs",
    )
    for candidate in candidates:
        if candidate.is_dir():
            return candidate
    return candidates[0]


def topic_by_id(topic_id: str) -> HelpTopic:
    for topic in HELP_TOPICS:
        if topic.topic_id == topic_id:
            return topic
    raise KeyError(topic_id)


def topic_text(topic: HelpTopic) -> str:
    path = (documentation_root() / topic.relative_path).resolve()
    try:
        return path.read_text(encoding="utf-8")
    except OSError:
        return f"# {topic.title}\n\nThis help topic is unavailable in the current installation.\n\nExpected file: `{path}`"


class HelpBrowserDialog(QDialog):
    """Searchable browser for documentation shipped with Aperture."""

    def __init__(self, parent: QWidget | None = None, *, initial_topic: str = "quick-start") -> None:
        super().__init__(parent)
        self.setWindowTitle("Aperture Help")
        self.resize(980, 680)
        self._search = QLineEdit(self)
        self._search.setPlaceholderText("Search help topics")
        self._search.setAccessibleName("Search Aperture help")
        self._topics = QListWidget(self)
        self._topics.setAccessibleName("Help topics")
        self._browser = QTextBrowser(self)
        self._browser.setAccessibleName("Help article")
        self._browser.setOpenExternalLinks(False)
        for topic in HELP_TOPICS:
            item = QListWidgetItem(topic.title)
            item.setData(Qt.ItemDataRole.UserRole, topic.topic_id)
            self._topics.addItem(item)
        self._search.textChanged.connect(self._filter)
        self._topics.currentItemChanged.connect(self._show_current)
        close = QPushButton("Close", self)
        close.clicked.connect(self.accept)
        left = QVBoxLayout()
        left.addWidget(QLabel("Contents"))
        left.addWidget(self._search)
        left.addWidget(self._topics, 1)
        body = QHBoxLayout()
        body.addLayout(left, 1)
        body.addWidget(self._browser, 3)
        layout = QVBoxLayout(self)
        layout.addLayout(body, 1)
        layout.addWidget(close, alignment=Qt.AlignmentFlag.AlignRight)
        self.open_topic(initial_topic)

    def _filter(self, text: str) -> None:
        needle = text.casefold().strip()
        for row in range(self._topics.count()):
            item = self._topics.item(row)
            topic = topic_by_id(str(item.data(Qt.ItemDataRole.UserRole)))
            haystack = f"{topic.title}\n{topic_text(topic)}".casefold()
            item.setHidden(bool(needle) and needle not in haystack)

    def _show_current(self, current: QListWidgetItem | None, _previous: QListWidgetItem | None) -> None:
        if current is None:
            return
        topic = topic_by_id(str(current.data(Qt.ItemDataRole.UserRole)))
        self._browser.setMarkdown(topic_text(topic))

    def open_topic(self, topic_id: str) -> None:
        for row in range(self._topics.count()):
            item = self._topics.item(row)
            if item.data(Qt.ItemDataRole.UserRole) == topic_id:
                item.setHidden(False)
                self._topics.setCurrentItem(item)
                return
        self._topics.setCurrentRow(0)
