"""Aperture product identity, About and diagnostics UI.

Default footer: Powered by NatureAI_Next.
"""
from __future__ import annotations

import platform
import sys
import webbrowser
from dataclasses import replace
from html import escape
from pathlib import Path

from natureai_next import __version__
from natureai_next.application.branding import BrandingSettings, BrandingStore

try:
    from PySide6 import __version__ as pyside_version
    from PySide6.QtCore import Qt, Signal, Slot
    from PySide6.QtGui import QGuiApplication
    from PySide6.QtWidgets import (
        QDialog, QDialogButtonBox, QFormLayout, QHBoxLayout, QLabel, QLineEdit,
        QMessageBox, QPushButton, QPlainTextEdit, QVBoxLayout, QWidget,
    )
except ImportError as exc:  # pragma: no cover
    raise RuntimeError("PySide6 is required") from exc


class BrandingWorkspace(QWidget):
    branding_changed = Signal(object)

    def __init__(self, path: Path, parent=None):
        super().__init__(parent)
        self._path = path
        self._store = BrandingStore()
        self._fields = {name: QLineEdit() for name in BrandingSettings.__dataclass_fields__}
        form = QFormLayout()
        labels = {
            "application_name": "Application name",
            "powered_by": "Powered by",
            "organization_name": "Organization",
            "project_website": "Project website",
            "donation_label": "Donation label",
            "donation_url": "Donation URL",
        }
        for key, widget in self._fields.items():
            form.addRow(labels[key], widget)
        save = QPushButton("Save")
        save.clicked.connect(self.save)
        reset = QPushButton("Reset to project defaults")
        reset.clicked.connect(self.reset_defaults)
        buttons = QHBoxLayout(); buttons.addWidget(save); buttons.addWidget(reset); buttons.addStretch(1)
        note = QLabel("These user-facing values are editable for open-source forks. NatureAI_Next technical identifiers remain unchanged.")
        note.setWordWrap(True)
        layout = QVBoxLayout(self)
        layout.addWidget(QLabel("<h2>Branding & Project</h2>")); layout.addWidget(note); layout.addLayout(form); layout.addLayout(buttons); layout.addStretch(1)
        self.refresh()

    @property
    def settings(self) -> BrandingSettings:
        return self._store.load(self._path)

    def refresh(self) -> None:
        settings = self.settings
        for key, widget in self._fields.items():
            widget.setText(getattr(settings, key))

    @Slot()
    def save(self) -> None:
        try:
            settings = BrandingSettings(**{key: widget.text().strip() for key, widget in self._fields.items()})
            self._store.save(self._path, settings)
        except Exception as exc:
            QMessageBox.warning(self, "Branding settings", str(exc)); return
        self.branding_changed.emit(settings)
        QMessageBox.information(self, "Branding settings", "Branding settings saved.")

    @Slot()
    def reset_defaults(self) -> None:
        defaults = BrandingSettings()
        self._store.save(self._path, defaults)
        self.refresh(); self.branding_changed.emit(defaults)


class DiagnosticsWorkspace(QWidget):
    def __init__(self, *, library_name: str, session_path: Path, branding_path: Path, resource_service=None, ecology_service=None, parent=None):
        super().__init__(parent)
        self._library_name = library_name; self._session_path = session_path; self._branding_path = branding_path
        self._resource_service = resource_service; self._ecology_service = ecology_service
        self._text = QPlainTextEdit(); self._text.setReadOnly(True)
        copy = QPushButton("Copy system information"); copy.clicked.connect(self.copy_information)
        refresh = QPushButton("Refresh"); refresh.clicked.connect(self.refresh)
        row = QHBoxLayout(); row.addWidget(copy); row.addWidget(refresh); row.addStretch(1)
        layout = QVBoxLayout(self); layout.addWidget(QLabel("<h2>Diagnostics</h2>")); layout.addWidget(self._text); layout.addLayout(row)
        self.refresh()

    def information(self) -> str:
        branding = BrandingStore().load(self._branding_path)
        lines = [
            f"{branding.application_name} {__version__}", f"Powered by {branding.powered_by} {__version__}",
            f"Library: {self._library_name}", f"Session path: {self._session_path}",
            f"Python: {platform.python_version()}", f"PySide6 / Qt: {pyside_version}",
            f"Operating system: {platform.platform()}",
        ]
        try:
            import torch
            lines.extend([f"PyTorch: {torch.__version__}", f"CUDA available: {torch.cuda.is_available()}"])
            if torch.cuda.is_available(): lines.append(f"CUDA device: {torch.cuda.get_device_name(0)}")
        except Exception:
            lines.append("PyTorch: not available")
        if self._resource_service is not None:
            try:
                overview = self._resource_service.overview()
                lines.extend([
                    f"Active model: {overview.active_model_identity or 'None'} {overview.active_model_version or ''}".rstrip(),
                    f"Active prompt set: {overview.active_prompt_set or 'None'}",
                ])
            except Exception as exc: lines.append(f"AI resources: unavailable ({exc})")
        return "\n".join(lines)

    @Slot()
    def refresh(self) -> None:
        self._text.setPlainText(self.information())

    @Slot()
    def copy_information(self) -> None:
        QGuiApplication.clipboard().setText(self.information())


class AboutDialog(QDialog):
    def __init__(self, *, branding: BrandingSettings, diagnostics: DiagnosticsWorkspace, parent=None):
        super().__init__(parent)
        self.setWindowTitle(f"About {branding.application_name}")
        self.resize(680, 620)
        title = QLabel(f"<h1>{escape(branding.application_name)}</h1><p><b>Version {escape(__version__)}</b></p><p>Powered by {escape(branding.powered_by)} {escape(__version__)}</p>")
        title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        body = QLabel(
            f"<h3>Project</h3><p>Created by ChatGPT working together with {escape(branding.organization_name)}.</p>"
            "<h3>Core technologies</h3><p>NatureAI_Next, BioCLIP, OpenCLIP, PyTorch, PySide6 / Qt, SQLite and Python.</p>"
            "<h3>Licenses and attribution</h3><p>Installed model, taxonomy and ecological resources retain their own versions, licenses and attribution. Review the shipped license documentation and package manifests before redistribution.</p>"
        )
        body.setWordWrap(True); body.setOpenExternalLinks(False)
        website = QPushButton("Project website"); website.clicked.connect(lambda: self._open_url(branding.project_website))
        donation = QPushButton(branding.donation_label or "Support project"); donation.clicked.connect(lambda: self._open_url(branding.donation_url))
        donation.setVisible(bool(branding.donation_url))
        copy = QPushButton("Copy system information"); copy.clicked.connect(diagnostics.copy_information)
        row = QHBoxLayout(); row.addWidget(website); row.addWidget(donation); row.addWidget(copy); row.addStretch(1)
        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Close); buttons.rejected.connect(self.reject)
        layout = QVBoxLayout(self); layout.addWidget(title); layout.addWidget(body); layout.addLayout(row); layout.addStretch(1); layout.addWidget(buttons)

    def _open_url(self, url: str) -> None:
        if url: webbrowser.open(url)
