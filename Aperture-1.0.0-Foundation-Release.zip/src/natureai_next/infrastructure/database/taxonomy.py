"""SQLite taxonomy, observation, ROI, and user-taxon adapters."""
from __future__ import annotations
import json,sqlite3,uuid
from dataclasses import asdict
from typing import Any
from natureai_next.domain.taxonomy import ObservationDraft,ObservationView,RegionOfInterestDraft,TaxonPage,TaxonSummary,TaxonomyPackageData
from natureai_next.infrastructure.database.connection import SqliteConnectionFactory
from natureai_next.infrastructure.database.unit_of_work import SqliteUnitOfWork


def _public_taxon_id(source_name:str,source_taxon_id:str)->str:
    return str(uuid.uuid5(uuid.NAMESPACE_URL,f"natureai-next:taxonomy:{source_name}:{source_taxon_id}"))

def _validate_graph(package:TaxonomyPackageData)->None:
    by_id={x.source_taxon_id:x for x in package.taxa}
    if len(by_id)!=len(package.taxa):raise ValueError("duplicate source taxon identifier")
    for item in package.taxa:
        if item.parent_source_taxon_id and item.parent_source_taxon_id not in by_id:raise ValueError(f"missing parent taxon: {item.parent_source_taxon_id}")
        if item.accepted_source_taxon_id and item.accepted_source_taxon_id not in by_id:raise ValueError(f"missing accepted taxon: {item.accepted_source_taxon_id}")
        if item.accepted_source_taxon_id and by_id[item.accepted_source_taxon_id].status.value!="accepted":raise ValueError("synonym target must be accepted")
    state:dict[str,int]={}
    def visit(identifier:str)->None:
        value=state.get(identifier,0)
        if value==1:raise ValueError("taxonomy hierarchy contains a cycle")
        if value==2:return
        state[identifier]=1;parent=by_id[identifier].parent_source_taxon_id
        if parent:visit(parent)
        state[identifier]=2
    for identifier in by_id:visit(identifier)

class SqliteTaxonomyAdapter:
    def __init__(self,factory:SqliteConnectionFactory)->None:self._factory=factory
    def install(self,package:TaxonomyPackageData,*,now_us:int)->str:
        _validate_graph(package)
        taxon_ids={x.source_taxon_id:_public_taxon_id(package.source_name,x.source_taxon_id) for x in package.taxa}
        license_json=json.dumps(asdict(package.license),sort_keys=True,separators=(",",":"))
        manifest_json=json.dumps({"package_id":package.package_id,"minimum_app_version":package.minimum_app_version},sort_keys=True,separators=(",",":"))
        with SqliteUnitOfWork(self._factory) as u:
            c=u.connection;assert c is not None
            existing=c.execute("SELECT public_id,package_checksum FROM taxonomy_sources WHERE package_id=?",(package.package_id,)).fetchone()
            if existing:
                if existing['package_checksum']!=package.checksum:raise ValueError("installed taxonomy package identity has a different checksum")
                return str(existing['public_id'])
            source_public_id=str(uuid.uuid5(uuid.NAMESPACE_URL,f"natureai-next:taxonomy-source:{package.source_name}:{package.source_version}"))
            c.execute("UPDATE taxonomy_sources SET active=0 WHERE name=?",(package.source_name,))
            c.execute("INSERT INTO taxonomy_sources(public_id,name,source_version,package_checksum,license_json,installed_at_us,activated_at_us,active,package_id,attribution_text,manifest_json) VALUES(?,?,?,?,?,?,?,?,?,?,?)",(source_public_id,package.source_name,package.source_version,package.checksum,license_json,now_us,now_us,1,package.package_id,package.attribution_text,manifest_json))
            source_id=int(c.execute("SELECT last_insert_rowid()").fetchone()[0])
            for item in package.taxa:
                c.execute("INSERT INTO taxa(source_id,source_taxon_id,public_id,scientific_name,authorship,rank,status,kingdom,major_group,extinct) VALUES(?,?,?,?,?,?,?,?,?,?)",(source_id,item.source_taxon_id,taxon_ids[item.source_taxon_id],item.scientific_name,item.authorship,item.rank,item.status.value,item.kingdom,item.major_group,int(item.extinct)))
            db_ids={r['source_taxon_id']:int(r['id']) for r in c.execute("SELECT id,source_taxon_id FROM taxa WHERE source_id=?",(source_id,))}
            for item in package.taxa:
                c.execute("UPDATE taxa SET parent_taxon_id=?,accepted_taxon_id=? WHERE id=?",(db_ids.get(item.parent_source_taxon_id),db_ids.get(item.accepted_source_taxon_id),db_ids[item.source_taxon_id]))
            for item in package.names:
                if item.source_taxon_id not in db_ids:raise ValueError("name references unknown taxon")
                c.execute("INSERT INTO taxon_names(taxon_id,language_tag,region_code,name,name_type,preferred,source) VALUES(?,?,?,?,?,?,?)",(db_ids[item.source_taxon_id],item.language_tag,item.region_code.upper() if item.region_code else None,item.name,item.name_type,int(item.preferred),item.source))
            for item in package.regions:
                if item.source_taxon_id not in db_ids:raise ValueError("region references unknown taxon")
                c.execute("INSERT INTO taxon_regions(taxon_id,region_code,occurrence_status,source) VALUES(?,?,?,?)",(db_ids[item.source_taxon_id],item.region_code,item.occurrence_status,item.source))
            c.execute("INSERT INTO taxon_closure(ancestor_taxon_id,descendant_taxon_id,depth) SELECT id,id,0 FROM taxa WHERE source_id=?",(source_id,))
            c.execute("WITH RECURSIVE lineage(ancestor,descendant,depth) AS (SELECT parent_taxon_id,id,1 FROM taxa WHERE source_id=? AND parent_taxon_id IS NOT NULL UNION ALL SELECT t.parent_taxon_id,l.descendant,l.depth+1 FROM lineage l JOIN taxa t ON t.id=l.ancestor WHERE t.parent_taxon_id IS NOT NULL) INSERT INTO taxon_closure SELECT ancestor,descendant,depth FROM lineage",(source_id,))
            c.execute("UPDATE user_taxa SET mapped_taxon_id=(SELECT n.id FROM taxa n JOIN taxa old ON old.id=user_taxa.mapped_taxon_id WHERE n.source_taxon_id=old.source_taxon_id AND n.source_id=? LIMIT 1) WHERE mapped_taxon_id IN (SELECT id FROM taxa WHERE source_id IN (SELECT id FROM taxonomy_sources WHERE name=? AND id!=?))",(source_id,package.source_name,source_id))
            c.execute("UPDATE library_info SET active_taxonomy_release_ids_json=? WHERE id=1",(json.dumps([source_public_id]),))
            u.commit();return source_public_id
    def active_sources(self)->tuple[dict[str,object],...]:
        c=self._factory.connect()
        try:return tuple(dict(r) for r in c.execute("SELECT public_id,name,source_version,package_checksum,license_json,attribution_text,activated_at_us FROM taxonomy_sources WHERE active=1 ORDER BY name"))
        finally:c.close()
    def _summary(self,r:sqlite3.Row)->TaxonSummary:return TaxonSummary(r['public_id'],r['source_taxon_id'],r['scientific_name'],r['authorship'],r['rank'],r['status'],r['parent_public_id'],r['accepted_public_id'],r['preferred_name'],r['occurrence_status'])
    def _base_sql(self)->str:return """SELECT t.public_id,t.source_taxon_id,t.scientific_name,t.authorship,t.rank,t.status,p.public_id parent_public_id,a.public_id accepted_public_id,(SELECT n.name FROM taxon_names n WHERE n.taxon_id=t.id AND (? IS NULL OR n.language_tag=?) AND (? IS NULL OR n.region_code IS NULL OR n.region_code=?) ORDER BY n.preferred DESC,n.region_code IS NOT NULL DESC,n.id LIMIT 1) preferred_name,(SELECT tr.occurrence_status FROM taxon_regions tr WHERE tr.taxon_id=t.id AND tr.region_code=? LIMIT 1) occurrence_status FROM taxa t JOIN taxonomy_sources s ON s.id=t.source_id LEFT JOIN taxa p ON p.id=t.parent_taxon_id LEFT JOIN taxa a ON a.id=t.accepted_taxon_id WHERE s.active=1"""
    def search(self,text:str,*,language_tag:str|None=None,region_code:str|None=None,limit:int=50)->tuple[TaxonSummary,...]:
        if not text.strip():return ()
        c=self._factory.connect();q=f"%{text.strip()}%";region=region_code.upper() if region_code else None
        try:
            sql=self._base_sql()+" AND (t.scientific_name LIKE ? OR EXISTS(SELECT 1 FROM taxon_names x WHERE x.taxon_id=t.id AND x.name LIKE ?)) AND (? IS NULL OR EXISTS(SELECT 1 FROM taxon_regions rr WHERE rr.taxon_id=t.id AND rr.region_code=?)) ORDER BY CASE WHEN lower(t.scientific_name)=lower(?) THEN 0 ELSE 1 END,t.scientific_name LIMIT ?"
            rows=c.execute(sql,(language_tag,language_tag,region,region,region,q,q,region,region,text.strip(),min(max(limit,1),500))).fetchall();return tuple(self._summary(r) for r in rows)
        finally:c.close()
    def children(self,parent_public_id:str|None,*,region_code:str|None=None,language_tag:str|None=None,after_name:str|None=None,limit:int=200)->TaxonPage:
        c=self._factory.connect();region=region_code.upper() if region_code else None;limit=min(max(limit,1),500)
        try:
            sql=self._base_sql()+" AND ((? IS NULL AND t.parent_taxon_id IS NULL) OR p.public_id=?) AND (? IS NULL OR t.scientific_name>?) AND (? IS NULL OR EXISTS(SELECT 1 FROM taxon_regions rr WHERE rr.taxon_id=t.id AND rr.region_code=?)) ORDER BY t.scientific_name,t.id LIMIT ?"
            rows=c.execute(sql,(language_tag,language_tag,region,region,region,parent_public_id,parent_public_id,after_name,after_name,region,region,limit+1)).fetchall();items=tuple(self._summary(r) for r in rows[:limit]);return TaxonPage(items,items[-1].scientific_name if len(rows)>limit and items else None)
        finally:c.close()
    def detail(self,public_id:str,*,language_tag:str|None=None,region_code:str|None=None)->TaxonSummary:
        c=self._factory.connect();region=region_code.upper() if region_code else None
        try:
            r=c.execute(self._base_sql()+" AND t.public_id=?",(language_tag,language_tag,region,region,region,public_id)).fetchone()
            if r is None:raise KeyError(public_id)
            return self._summary(r)
        finally:c.close()
    def verify_closure(self,source_public_id:str)->tuple[int,int]:
        c=self._factory.connect()
        try:
            expected=int(c.execute("WITH RECURSIVE x(a,d) AS (SELECT id,id FROM taxa WHERE source_id=(SELECT id FROM taxonomy_sources WHERE public_id=?) UNION ALL SELECT t.parent_taxon_id,x.d FROM x JOIN taxa t ON t.id=x.a WHERE t.parent_taxon_id IS NOT NULL) SELECT COUNT(*) FROM x",(source_public_id,)).fetchone()[0]);actual=int(c.execute("SELECT COUNT(*) FROM taxon_closure tc JOIN taxa t ON t.id=tc.descendant_taxon_id WHERE t.source_id=(SELECT id FROM taxonomy_sources WHERE public_id=?)",(source_public_id,)).fetchone()[0]);return expected,actual
        finally:c.close()
    def rebuild_closure(self,source_public_id:str)->None:
        with SqliteUnitOfWork(self._factory) as u:
            c=u.connection;assert c is not None;sid=c.execute("SELECT id FROM taxonomy_sources WHERE public_id=?",(source_public_id,)).fetchone()
            if sid is None:raise KeyError(source_public_id)
            source_id=int(sid[0]);c.execute("DELETE FROM taxon_closure WHERE descendant_taxon_id IN (SELECT id FROM taxa WHERE source_id=?)",(source_id,));c.execute("INSERT INTO taxon_closure SELECT id,id,0 FROM taxa WHERE source_id=?",(source_id,));c.execute("WITH RECURSIVE lineage(ancestor,descendant,depth) AS (SELECT parent_taxon_id,id,1 FROM taxa WHERE source_id=? AND parent_taxon_id IS NOT NULL UNION ALL SELECT t.parent_taxon_id,l.descendant,l.depth+1 FROM lineage l JOIN taxa t ON t.id=l.ancestor WHERE t.parent_taxon_id IS NOT NULL) INSERT INTO taxon_closure SELECT ancestor,descendant,depth FROM lineage",(source_id,));u.commit()

class SqliteObservationAdapter:
    def __init__(self,factory:SqliteConnectionFactory)->None:self._factory=factory
    def _view(self,c:sqlite3.Connection,public_id:str)->ObservationView:
        r=c.execute("""SELECT o.public_id,a.public_id asset_public_id,o.revision,o.observation_type,o.confirmation_state,t.public_id taxon_public_id,u.public_id user_taxon_public_id,COALESCE(t.scientific_name,u.display_name) display_name,o.life_stage,o.sex,o.count,o.behavior,o.notes,roi.public_id roi_public_id FROM observations o JOIN assets a ON a.id=o.asset_id LEFT JOIN taxa t ON t.id=o.taxon_id LEFT JOIN user_taxa u ON u.id=o.user_taxon_id LEFT JOIN regions_of_interest roi ON roi.id=o.region_of_interest_id WHERE o.public_id=?""",(public_id,)).fetchone()
        if r is None:raise KeyError(public_id)
        return ObservationView(**dict(r))
    def create(self,*,public_id:str,asset_public_id:str,draft:ObservationDraft,now_us:int,source:str="user")->ObservationView:
        draft.validate()
        with SqliteUnitOfWork(self._factory) as u:
            c=u.connection;assert c is not None
            c.execute("""INSERT INTO observations(public_id,asset_id,taxon_id,user_taxon_id,observation_type,life_stage,sex,count,behavior,notes,confirmation_state,source,region_of_interest_id,created_at_us,modified_at_us,revision) SELECT ?,a.id,t.id,ut.id,?,?,?,?,?,?,?,?,roi.id,?,?,1 FROM assets a LEFT JOIN taxa t ON t.public_id=? LEFT JOIN user_taxa ut ON ut.public_id=? LEFT JOIN regions_of_interest roi ON roi.public_id=? WHERE a.public_id=?""",(public_id,draft.observation_type.value,draft.life_stage,draft.sex,draft.count,draft.behavior,draft.notes,draft.confirmation_state.value,source,now_us,now_us,draft.taxon_public_id,draft.user_taxon_public_id,draft.roi_public_id,asset_public_id))
            if c.execute("SELECT changes()").fetchone()[0]!=1:raise KeyError(asset_public_id)
            oid=int(c.execute("SELECT id FROM observations WHERE public_id=?",(public_id,)).fetchone()[0]);snapshot=json.dumps(asdict(draft),default=str,sort_keys=True,separators=(",",":"));c.execute("INSERT INTO observation_revisions(observation_id,revision,snapshot_json,changed_at_us) VALUES(?,?,?,?)",(oid,1,snapshot,now_us));view=self._view(c,public_id);u.commit();return view
    def update(self,*,public_id:str,expected_revision:int,draft:ObservationDraft,now_us:int)->ObservationView:
        draft.validate()
        with SqliteUnitOfWork(self._factory) as u:
            c=u.connection;assert c is not None
            c.execute("""UPDATE observations SET taxon_id=(SELECT id FROM taxa WHERE public_id=?),user_taxon_id=(SELECT id FROM user_taxa WHERE public_id=?),observation_type=?,life_stage=?,sex=?,count=?,behavior=?,notes=?,confirmation_state=?,region_of_interest_id=(SELECT id FROM regions_of_interest WHERE public_id=?),modified_at_us=?,revision=revision+1 WHERE public_id=? AND revision=?""",(draft.taxon_public_id,draft.user_taxon_public_id,draft.observation_type.value,draft.life_stage,draft.sex,draft.count,draft.behavior,draft.notes,draft.confirmation_state.value,draft.roi_public_id,now_us,public_id,expected_revision))
            if c.execute("SELECT changes()").fetchone()[0]!=1:raise RuntimeError("observation revision conflict")
            row=c.execute("SELECT id,revision FROM observations WHERE public_id=?",(public_id,)).fetchone();snapshot=json.dumps(asdict(draft),default=str,sort_keys=True,separators=(",",":"));c.execute("INSERT INTO observation_revisions VALUES(NULL,?,?,?,?)",(row['id'],row['revision'],snapshot,now_us));view=self._view(c,public_id);u.commit();return view
    def list_for_asset(self,asset_public_id:str)->tuple[ObservationView,...]:
        c=self._factory.connect()
        try:
            ids=[r[0] for r in c.execute("SELECT o.public_id FROM observations o JOIN assets a ON a.id=o.asset_id WHERE a.public_id=? ORDER BY o.created_at_us,o.id",(asset_public_id,))];return tuple(self._view(c,x) for x in ids)
        finally:c.close()
    def create_roi(self,*,public_id:str,asset_public_id:str,draft:RegionOfInterestDraft,now_us:int)->str:
        draft.validate();payload=json.dumps(draft.coordinates,sort_keys=True,separators=(",",":"))
        with SqliteUnitOfWork(self._factory) as u:
            c=u.connection;assert c is not None;c.execute("INSERT INTO regions_of_interest(public_id,asset_id,shape_type,coordinates_json,label,created_source,created_at_us,modified_at_us) SELECT ?,id,?,?,?,?,?,? FROM assets WHERE public_id=?",(public_id,draft.shape_type,payload,draft.label,'user',now_us,now_us,asset_public_id));
            if c.execute("SELECT changes()").fetchone()[0]!=1:raise KeyError(asset_public_id)
            u.commit();return public_id

class SqliteUserTaxonAdapter:
    def __init__(self,factory:SqliteConnectionFactory)->None:self._factory=factory
    def create(self,*,public_id:str,display_name:str,scientific_name:str|None,rank:str|None,now_us:int)->None:
        with SqliteUnitOfWork(self._factory) as u:
            assert u.connection is not None;u.connection.execute("INSERT INTO user_taxa(public_id,scientific_name,display_name,rank,created_at_us,modified_at_us) VALUES(?,?,?,?,?,?)",(public_id,scientific_name,display_name,rank,now_us,now_us));u.commit()
    def map_to_taxon(self,*,user_taxon_public_id:str,taxon_public_id:str|None,now_us:int)->None:
        with SqliteUnitOfWork(self._factory) as u:
            c=u.connection;assert c is not None;c.execute("UPDATE user_taxa SET mapped_taxon_id=(SELECT id FROM taxa WHERE public_id=?),modified_at_us=? WHERE public_id=?",(taxon_public_id,now_us,user_taxon_public_id));
            if c.execute("SELECT changes()").fetchone()[0]!=1:raise KeyError(user_taxon_public_id)
            u.commit()
