"""Explicit SQLite unit of work with serialized writes."""
from __future__ import annotations
import sqlite3, threading
from types import TracebackType
from natureai_next.infrastructure.database.connection import SqliteConnectionFactory
from natureai_next.infrastructure.database.repositories import SqliteAssetRepository,SqliteAuditRepository,SqliteCollectionRepository,SqliteFileInstanceRepository,SqliteJobRepository,SqliteOutboxRepository,SqliteTagRepository

class SqliteUnitOfWork:
    _write_lock=threading.RLock()
    def __init__(self,factory:SqliteConnectionFactory)->None:self.factory=factory; self.connection:sqlite3.Connection|None=None
    def __enter__(self)->"SqliteUnitOfWork":
        self._write_lock.acquire()
        try:
            self.connection=self.factory.connect(); self.connection.execute("BEGIN IMMEDIATE")
            c=self.connection; self.assets=SqliteAssetRepository(c); self.files=SqliteFileInstanceRepository(c); self.tags=SqliteTagRepository(c); self.collections=SqliteCollectionRepository(c); self.jobs=SqliteJobRepository(c); self.outbox=SqliteOutboxRepository(c); self.audit=SqliteAuditRepository(c); return self
        except Exception:self._write_lock.release(); raise
    def commit(self)->None:
        if self.connection is None: raise RuntimeError("unit of work is not active")
        self.connection.execute("COMMIT")
    def rollback(self)->None:
        if self.connection is not None and self.connection.in_transaction:self.connection.execute("ROLLBACK")
    def __exit__(self,exc_type:type[BaseException]|None,exc:BaseException|None,traceback:TracebackType|None)->None:
        try:
            if self.connection is not None:
                if exc_type is not None:self.rollback()
                elif self.connection.in_transaction:self.rollback()
                self.connection.close()
        finally:self.connection=None; self._write_lock.release()
