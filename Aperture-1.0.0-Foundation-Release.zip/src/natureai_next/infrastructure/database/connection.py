"""Thread-confined SQLite connection factory."""
from __future__ import annotations
import sqlite3
from pathlib import Path
from natureai_next.infrastructure.database.settings import SqliteSettings

class SqliteConnectionFactory:
    def __init__(self, database_path: Path, settings: SqliteSettings | None = None) -> None:
        self.database_path = database_path
        self.settings = settings or SqliteSettings()
    def connect(self, *, read_only: bool = False) -> sqlite3.Connection:
        if read_only:
            connection = sqlite3.connect(f"file:{self.database_path.as_posix()}?mode=ro", uri=True, isolation_level=None, check_same_thread=True)
        else:
            self.database_path.parent.mkdir(parents=True, exist_ok=True)
            connection = sqlite3.connect(self.database_path, isolation_level=None, check_same_thread=True)
        connection.row_factory = sqlite3.Row
        connection.execute("PRAGMA foreign_keys=ON")
        connection.execute(f"PRAGMA busy_timeout={self.settings.busy_timeout_ms}")
        connection.execute("PRAGMA temp_store=MEMORY")
        connection.execute(f"PRAGMA cache_size={-self.settings.cache_size_kib}")
        connection.execute(f"PRAGMA mmap_size={self.settings.mmap_size_bytes}")
        if not read_only:
            connection.execute("PRAGMA journal_mode=WAL")
            connection.execute(f"PRAGMA synchronous={self.settings.synchronous}")
        return connection
