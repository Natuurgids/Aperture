"""Database integrity maintenance primitives."""
from __future__ import annotations
from dataclasses import dataclass
from natureai_next.infrastructure.database.connection import SqliteConnectionFactory
@dataclass(frozen=True,slots=True)
class IntegrityReport:
    quick_check:tuple[str,...]; foreign_key_violations:tuple[tuple[object,...],...]
    @property
    def healthy(self)->bool:return self.quick_check==("ok",) and not self.foreign_key_violations

def check_integrity(factory:SqliteConnectionFactory,*,full:bool=False)->IntegrityReport:
    c=factory.connect(read_only=True)
    try:
        pragma="integrity_check" if full else "quick_check"
        checks=tuple(str(r[0]) for r in c.execute(f"PRAGMA {pragma}")); fk=tuple(tuple(r) for r in c.execute("PRAGMA foreign_key_check")); return IntegrityReport(checks,fk)
    finally:c.close()
