"""Core database migrations."""
from natureai_next.infrastructure.database.migrations.core import MigrationError, MigrationRunner
from natureai_next.infrastructure.database.migrations.v001_initial import MIGRATION as V001
from natureai_next.infrastructure.database.migrations.v002_jobs_media import MIGRATION as V002
from natureai_next.infrastructure.database.migrations.v003_import_catalog import MIGRATION as V003
from natureai_next.infrastructure.database.migrations.v004_search_collections_geo import MIGRATION as V004
from natureai_next.infrastructure.database.migrations.v005_taxonomy import MIGRATION as V005
from natureai_next.infrastructure.database.migrations.v006_ai_foundation import MIGRATION as V006
from natureai_next.infrastructure.database.migrations.v007_ai_runtime import MIGRATION as V007
from natureai_next.infrastructure.database.migrations.v008_ai_review import MIGRATION as V008
from natureai_next.infrastructure.database.migrations.v009_ai_generation import MIGRATION as V009
from natureai_next.infrastructure.database.migrations.v010_taxonomy_embedding_lifecycle import MIGRATION as V010
from natureai_next.infrastructure.database.migrations.v011_resumable_exports import MIGRATION as V011
from natureai_next.infrastructure.database.migrations.v012_resumable_derivative_exports import MIGRATION as V012
from natureai_next.infrastructure.database.migrations.v013_regional_knowledge import MIGRATION as V013
from natureai_next.infrastructure.database.migrations.v014_observation_intelligence import MIGRATION as V014
from natureai_next.infrastructure.database.migrations.v015_ecological_context import MIGRATION as V015

CORE_MIGRATIONS = (V001, V002, V003, V004, V005, V006, V007, V008, V009, V010, V011, V012, V013, V014, V015)
__all__ = ["CORE_MIGRATIONS", "MigrationError", "MigrationRunner"]
