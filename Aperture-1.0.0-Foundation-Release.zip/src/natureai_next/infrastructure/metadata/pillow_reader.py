"""Bounded normalized metadata extraction using Pillow."""
from __future__ import annotations

from pathlib import Path
from PIL import ExifTags, Image, UnidentifiedImageError
from natureai_next.ports.media import MetadataResult


class PillowMetadataReader:
    def __init__(self, *, max_entries: int = 512, max_text_length: int = 4096) -> None:
        self.max_entries = max_entries
        self.max_text_length = max_text_length

    def read(self, path: Path) -> MetadataResult:
        try:
            with Image.open(path) as image:
                raw: dict[str, object] = {}
                warnings: list[str] = []
                for index, (tag_id, value) in enumerate(image.getexif().items()):
                    if index >= self.max_entries:
                        warnings.append("metadata_entry_limit_reached")
                        break
                    name = ExifTags.TAGS.get(tag_id, str(tag_id))
                    raw[name] = self._safe_value(value)
                normalized = {
                    "pixel_width": image.width,
                    "pixel_height": image.height,
                    "format_name": image.format,
                    "orientation": raw.get("Orientation"),
                    "camera_make": raw.get("Make"),
                    "camera_model": raw.get("Model"),
                    "lens": raw.get("LensModel"),
                    "capture_time_text": raw.get("DateTimeOriginal") or raw.get("DateTime"),
                }
                return MetadataResult(normalized, raw, tuple(warnings))
        except (OSError, UnidentifiedImageError, ValueError) as exc:
            raise ValueError(f"cannot read image metadata: {path}") from exc

    def _safe_value(self, value: object) -> object:
        if isinstance(value, bytes):
            return value[: self.max_text_length].hex()
        text = str(value)
        return text if len(text) <= self.max_text_length else text[: self.max_text_length]
