"""Bounded source scanning, streaming fingerprints and immutable managed originals."""
from __future__ import annotations
import hashlib
import os
from contextlib import suppress
from pathlib import Path
from tempfile import NamedTemporaryFile
from typing import Iterable
from natureai_next.domain.importing import Fingerprint, SourceFile
from natureai_next.ports.importing import CancelCheck

class DirectorySourceScanner:
    def __init__(self, *, max_files: int = 1_000_000) -> None:
        self.max_files = max_files

    def scan(self, roots: Iterable[Path], *, recursive: bool, cancel: CancelCheck | None = None) -> tuple[SourceFile, ...]:
        found: list[SourceFile] = []
        for root in roots:
            root = root.expanduser().resolve()
            candidates = root.rglob("*") if recursive and root.is_dir() else (root.iterdir() if root.is_dir() else (root,))
            for path in candidates:
                if cancel: cancel()
                if not path.is_file() or path.is_symlink():
                    continue
                stat = path.stat()
                found.append(SourceFile(path.resolve(), stat.st_size, stat.st_mtime_ns // 1000))
                if len(found) > self.max_files:
                    raise ValueError("source scan exceeded configured file limit")
        found.sort(key=lambda item: os.path.normcase(str(item.path)))
        return tuple(found)

class StreamingFileFingerprinter:
    def __init__(self, *, chunk_size: int = 4 * 1024 * 1024, fast_window: int = 64 * 1024) -> None:
        self.chunk_size = chunk_size
        self.fast_window = fast_window

    def fingerprint(self, path: Path, *, cancel: CancelCheck | None = None) -> Fingerprint:
        stat_before = path.stat()
        digest = hashlib.sha256()
        with path.open("rb") as stream:
            while chunk := stream.read(self.chunk_size):
                if cancel: cancel()
                digest.update(chunk)
        stat_after = path.stat()
        if (stat_before.st_size, stat_before.st_mtime_ns) != (stat_after.st_size, stat_after.st_mtime_ns):
            raise OSError(f"source changed while hashing: {path}")
        fast = self._fast(path, stat_after.st_size)
        return Fingerprint(digest.hexdigest(), stat_after.st_size, fast)

    def _fast(self, path: Path, size: int) -> str:
        digest = hashlib.blake2b(digest_size=16)
        digest.update(size.to_bytes(8, "big"))
        with path.open("rb") as stream:
            digest.update(stream.read(self.fast_window))
            if size > self.fast_window:
                stream.seek(max(0, size - self.fast_window))
                digest.update(stream.read(self.fast_window))
        return digest.hexdigest()

class ShardedManagedFileStore:
    def __init__(self, root: Path, fingerprinter: StreamingFileFingerprinter) -> None:
        self.root = root
        self.fingerprinter = fingerprinter

    def path_for(self, sha256: str, suffix: str) -> Path:
        safe_suffix = suffix.lower() if suffix and len(suffix) <= 16 else ""
        return self.root / sha256[:2] / sha256[2:4] / f"{sha256}{safe_suffix}"

    def place_verified(self, source: Path, sha256: str, *, cancel: CancelCheck | None = None) -> Path:
        destination = self.path_for(sha256, source.suffix)
        destination.parent.mkdir(parents=True, exist_ok=True)
        if destination.exists():
            if self.fingerprinter.fingerprint(destination, cancel=cancel).sha256 != sha256:
                raise OSError(f"managed original checksum conflict: {destination}")
            return destination
        with NamedTemporaryFile(dir=destination.parent, prefix=f".{destination.name}.", suffix=".partial", delete=False) as temp:
            temp_path = Path(temp.name)
            with source.open("rb") as input_stream:
                while chunk := input_stream.read(self.fingerprinter.chunk_size):
                    if cancel: cancel()
                    temp.write(chunk)
            temp.flush()
            os.fsync(temp.fileno())
        try:
            if self.fingerprinter.fingerprint(temp_path, cancel=cancel).sha256 != sha256:
                raise OSError("managed copy verification failed")
            os.replace(temp_path, destination)
            with suppress(OSError):
                destination.chmod(0o444)
            return destination
        finally:
            temp_path.unlink(missing_ok=True)

    def purge(self, path: Path) -> None:
        with suppress(OSError):
            path.chmod(0o666)
        path.unlink(missing_ok=True)
