"""Exclusive library writer lock with safe stale-owner recovery."""
from __future__ import annotations

import json
import os
import socket
import time
import ctypes
import atexit
from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True, slots=True)
class LockOwner:
    pid: int
    host: str
    created_at_us: int


class LibraryLockedError(RuntimeError):
    def __init__(self, path: Path, owner: LockOwner | None = None) -> None:
        self.path = path
        self.owner = owner
        detail = f"library is already locked: {path}"
        if owner is not None:
            detail += f" (pid={owner.pid}, host={owner.host})"
        super().__init__(detail)


def _read_owner(path: Path) -> LockOwner | None:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
        return LockOwner(
            pid=int(value["pid"]),
            host=str(value["host"]),
            created_at_us=int(value["created_at_us"]),
        )
    except (OSError, ValueError, TypeError, KeyError, json.JSONDecodeError):
        return None


def _process_is_alive(pid: int) -> bool:
    if pid <= 0:
        return False
    if pid == os.getpid():
        return True
    if os.name == "nt":
        process_query_limited_information = 0x1000
        still_active = 259
        handle = ctypes.windll.kernel32.OpenProcess(
            process_query_limited_information, False, pid
        )
        if not handle:
            return False
        try:
            exit_code = ctypes.c_ulong()
            if not ctypes.windll.kernel32.GetExitCodeProcess(handle, ctypes.byref(exit_code)):
                return False
            return exit_code.value == still_active
        finally:
            ctypes.windll.kernel32.CloseHandle(handle)
    try:
        os.kill(pid, 0)
    except ProcessLookupError:
        return False
    except PermissionError:
        return True
    except OSError:
        return False
    return True


class LibraryLock:
    def __init__(self, path: Path) -> None:
        self.path = path
        self._held = False

    def acquire(self) -> None:
        payload = json.dumps(
            {"pid": os.getpid(), "host": socket.gethostname(), "created_at_us": time.time_ns() // 1000},
            separators=(",", ":"),
            sort_keys=True,
        )
        for _attempt in range(2):
            try:
                fd = os.open(self.path, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
            except FileExistsError as exc:
                owner = _read_owner(self.path)
                if recover_stale_library_lock(self.path):
                    continue
                raise LibraryLockedError(self.path, owner) from exc
            try:
                os.write(fd, payload.encode("utf-8"))
                os.fsync(fd)
            finally:
                os.close(fd)
            self._held = True
            atexit.register(self.release)
            return
        raise LibraryLockedError(self.path, _read_owner(self.path))

    def release(self) -> None:
        if self._held:
            self.path.unlink(missing_ok=True)
            self._held = False
            try:
                atexit.unregister(self.release)
            except Exception:
                pass

    def __enter__(self) -> "LibraryLock":
        self.acquire()
        return self

    def __exit__(self, *_: object) -> None:
        self.release()


def recover_stale_library_lock(path: Path) -> bool:
    """Remove *path* only when it belongs to a dead process on this host.

    Returns ``True`` when the lock is absent or was safely removed.  A live,
    remote, or unreadable owner is never disturbed.
    """
    if not path.exists():
        return True
    owner = _read_owner(path)
    if owner is None:
        return False
    if owner.host.casefold() != socket.gethostname().casefold():
        return False
    if _process_is_alive(owner.pid):
        return False
    try:
        path.unlink()
    except FileNotFoundError:
        return True
    except OSError:
        return False
    return True
