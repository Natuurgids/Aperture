"""Guided, local-first BioCLIP resource setup without hand-edited manifests."""
from __future__ import annotations

import base64
import csv
import hashlib
import json
import shutil
import tempfile
import urllib.request
from dataclasses import dataclass
from pathlib import Path
from typing import Callable

from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey

from natureai_next import __version__
from natureai_next.application.ai_resources import LocalAIResourceService
from natureai_next.domain.taxonomy import LicenseMetadata
from natureai_next.infrastructure.ai.package import build_model_package
from natureai_next.infrastructure.taxonomy.package import build_taxonomy_package

BIOCLIP_CHECKPOINT_URL = (
    "https://huggingface.co/imageomics/bioclip/resolve/main/"
    "open_clip_pytorch_model.bin?download=true"
)
BIOCLIP_ATTRIBUTION = (
    "BioCLIP by Samuel Stevens et al., Imageomics Institute; trained with "
    "TreeOfLife-10M and OpenCLIP. DOI: 10.57967/hf/1511."
)


@dataclass(frozen=True, slots=True)
class BioCLIPSetupRequest:
    workspace: Path
    checkpoint: Path | None = None
    download_official_checkpoint: bool = False
    taxonomy_csv: Path | None = None
    key_id: str = "natureai-local"


@dataclass(frozen=True, slots=True)
class BioCLIPSetupResult:
    model_package: Path
    model_public_id: str
    trusted_keys: Path
    taxonomy_package: Path | None = None
    taxonomy_source_public_id: str | None = None
    prompt_manifest: Path | None = None
    prompt_public_id: str | None = None
    embedding_counts: tuple[int, int] | None = None


class BioCLIPQuickSetupService:
    """Builds, signs, installs and activates local BioCLIP resources."""

    def __init__(self, resources: LocalAIResourceService) -> None:
        self._resources = resources

    def run(
        self,
        request: BioCLIPSetupRequest,
        *,
        progress: Callable[[int, int, str], None] | None = None,
    ) -> BioCLIPSetupResult:
        report = progress or (lambda _current, _total, _message: None)
        root = request.workspace.expanduser().resolve()
        signing = root / "signing"
        source_model = root / "source" / "model"
        packages = root / "packages"
        prompts = root / "prompts"
        for directory in (signing, source_model, packages, prompts):
            directory.mkdir(parents=True, exist_ok=True)

        private_key_path = signing / f"{request.key_id}-private.pem"
        trusted_keys_path = signing / f"{request.key_id}-trusted.json"
        report(1, 7, "Preparing local signing identity…")
        private_key = self._ensure_signing_identity(
            request.key_id, private_key_path, trusted_keys_path
        )

        checkpoint = request.checkpoint
        if request.download_official_checkpoint:
            checkpoint = source_model / "open_clip_pytorch_model.bin"
            if not checkpoint.is_file():
                report(2, 7, "Downloading the official BioCLIP checkpoint…")
                self._download(BIOCLIP_CHECKPOINT_URL, checkpoint)
        if checkpoint is None or not checkpoint.is_file():
            raise FileNotFoundError(
                "Select a BioCLIP checkpoint or enable official checkpoint download."
            )

        report(3, 7, "Building and signing the BioCLIP model package…")
        checksum = self._sha256_file(checkpoint)
        model_package = packages / "natureai-local-bioclip-1.zip"
        build_model_package(
            model_package,
            private_key=private_key,
            manifest={
                "package_id": "natureai-local-bioclip-1",
                "model_identity": "imageomics-bioclip-vit-b-16",
                "semantic_version": "1.0.0",
                "model_family": "bioclip",
                "upstream_source": (
                    "https://huggingface.co/imageomics/bioclip ; "
                    f"DOI 10.57967/hf/1511 ; SHA256 {checksum}"
                ),
                "license_name": "MIT",
                "attribution_text": BIOCLIP_ATTRIBUTION,
                "minimum_application_version": __version__,
                "signing_key_id": request.key_id,
                "variants": [
                    {
                        "identity": "cuda-fp16",
                        "runtime": "torch",
                        "precision": "fp16",
                        "providers": ["cuda"],
                        "preprocessing_identity": "imageomics-bioclip-openclip-vit-b-16-v1",
                        "embedding_dimension": 512,
                        "input_size": 224,
                        "normalized_output": True,
                        "artifact_path": "open_clip_pytorch_model.bin",
                    }
                ],
            },
            artifacts={"open_clip_pytorch_model.bin": checkpoint.read_bytes()},
        )
        report(4, 7, "Verifying, installing and activating the model…")
        model_public_id = self._resources.install_model(model_package, trusted_keys_path)

        taxonomy_package: Path | None = None
        taxonomy_source_id: str | None = None
        prompt_manifest: Path | None = None
        prompt_public_id: str | None = None
        embedding_counts: tuple[int, int] | None = None
        if request.taxonomy_csv is not None:
            report(5, 7, "Converting the taxonomy CSV into a signed package…")
            taxa, names, prompt_rows = self._load_taxonomy_csv(request.taxonomy_csv)
            taxonomy_package = packages / "natureai-local-taxonomy-1.zip"
            build_taxonomy_package(
                taxonomy_package,
                private_key=private_key,
                key_id=request.key_id,
                package_id="natureai-local-taxonomy-1",
                source_name="natureai-local-taxonomy",
                source_version="1.0.0",
                minimum_app_version=__version__,
                license_metadata=LicenseMetadata(
                    "User supplied local taxonomy",
                    None,
                    "Locally supplied by the NatureAI user.",
                    False,
                ),
                taxa=taxa,
                names=names,
                attribution_text="Locally supplied by the NatureAI user.",
            )
            taxonomy_source_id = self._resources.install_taxonomy(
                taxonomy_package, trusted_keys_path
            )
            report(6, 7, "Creating and activating taxonomy prompts…")
            prompt_manifest = prompts / "natureai-local-taxonomy-prompts.json"
            prompt_manifest.write_text(
                json.dumps(
                    {
                        "schema_version": 1,
                        "identity": "natureai-local-taxonomy-prompts",
                        "semantic_version": "1.0.0",
                        "model_family": "bioclip",
                        "minimum_application_version": __version__,
                        "prompts": prompt_rows,
                    },
                    indent=2,
                    ensure_ascii=False,
                ) + "\n",
                encoding="utf-8",
            )
            prompt_public_id = self._resources.install_prompt_set(
                prompt_manifest, model_family="bioclip"
            )
            report(7, 7, "Building taxonomy text embeddings…")
            embedding_counts = self._resources.build_taxonomy_embeddings()
        else:
            report(7, 7, "Model setup completed. Add a taxonomy CSV when ready.")

        return BioCLIPSetupResult(
            model_package=model_package,
            model_public_id=model_public_id,
            trusted_keys=trusted_keys_path,
            taxonomy_package=taxonomy_package,
            taxonomy_source_public_id=taxonomy_source_id,
            prompt_manifest=prompt_manifest,
            prompt_public_id=prompt_public_id,
            embedding_counts=embedding_counts,
        )

    @staticmethod
    def _ensure_signing_identity(
        key_id: str, private_path: Path, trusted_path: Path
    ) -> Ed25519PrivateKey:
        if private_path.is_file() and trusted_path.is_file():
            return serialization.load_pem_private_key(private_path.read_bytes(), password=None)
        if private_path.exists() or trusted_path.exists():
            raise RuntimeError("The signing identity is incomplete; restore or remove both key files.")
        key = Ed25519PrivateKey.generate()
        private_path.write_bytes(
            key.private_bytes(
                serialization.Encoding.PEM,
                serialization.PrivateFormat.PKCS8,
                serialization.NoEncryption(),
            )
        )
        public_raw = key.public_key().public_bytes(
            serialization.Encoding.Raw, serialization.PublicFormat.Raw
        )
        trusted_path.write_text(
            json.dumps({key_id: base64.b64encode(public_raw).decode("ascii")}, indent=2) + "\n",
            encoding="utf-8",
        )
        return key

    @staticmethod
    def _download(url: str, destination: Path) -> None:
        destination.parent.mkdir(parents=True, exist_ok=True)
        with tempfile.NamedTemporaryFile(delete=False, dir=destination.parent) as handle:
            temp = Path(handle.name)
        try:
            with urllib.request.urlopen(url, timeout=60) as response, temp.open("wb") as target:
                shutil.copyfileobj(response, target, length=1024 * 1024)
            if temp.stat().st_size < 100_000_000:
                raise RuntimeError("Downloaded BioCLIP checkpoint is unexpectedly small.")
            temp.replace(destination)
        finally:
            temp.unlink(missing_ok=True)

    @staticmethod
    def _sha256_file(path: Path) -> str:
        digest = hashlib.sha256()
        with path.open("rb") as handle:
            for block in iter(lambda: handle.read(1024 * 1024), b""):
                digest.update(block)
        return digest.hexdigest()

    @staticmethod
    def _load_taxonomy_csv(path: Path) -> tuple[list[dict[str, object]], list[dict[str, object]], list[dict[str, object]]]:
        if not path.is_file():
            raise FileNotFoundError(path)
        taxa: list[dict[str, object]] = []
        names: list[dict[str, object]] = []
        prompts: list[dict[str, object]] = []
        with path.open("r", encoding="utf-8-sig", newline="") as handle:
            reader = csv.DictReader(handle)
            required = {"scientific_name"}
            if not reader.fieldnames or not required.issubset(reader.fieldnames):
                raise ValueError("Taxonomy CSV requires a scientific_name column.")
            for index, row in enumerate(reader, 1):
                scientific = (row.get("scientific_name") or "").strip()
                if not scientific:
                    continue
                source_id = (row.get("source_taxon_id") or f"local-{index}").strip()
                common = (row.get("common_name") or "").strip()
                rank = (row.get("rank") or "species").strip()
                taxa.append({
                    "source_taxon_id": source_id,
                    "scientific_name": scientific,
                    "rank": rank,
                    "status": "accepted",
                    "parent_source_taxon_id": None,
                    "accepted_source_taxon_id": None,
                    "authorship": None,
                    "kingdom": (row.get("kingdom") or None),
                    "major_group": (row.get("major_group") or None),
                    "extinct": False,
                })
                if common:
                    names.append({
                        "source_taxon_id": source_id,
                        "name": common,
                        "name_type": "vernacular",
                        "source": "local-csv",
                        "language_tag": (row.get("language_tag") or "en"),
                        "region_code": (row.get("region_code") or None),
                        "preferred": True,
                    })
                label = common or scientific
                prompts.append({
                    "label": f"{label} [{source_id}]",
                    "text": f"a wildlife photograph of {common + ', ' if common else ''}{scientific}",
                    "taxon_public_id": None,
                    "broad_group": (row.get("major_group") or "organism"),
                })
        if not taxa:
            raise ValueError("Taxonomy CSV contains no usable records.")
        # taxon_public_id is resolved after package installation by the embedding label source;
        # broad-group prompts make the manifest valid while installed taxonomy names supply taxa.
        return taxa, names, prompts
