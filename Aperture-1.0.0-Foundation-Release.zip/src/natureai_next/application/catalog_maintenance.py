"""Missing-file, relinking, trash and recoverable purge services."""
from __future__ import annotations
import json
import os
from pathlib import Path
from natureai_next.ports.clock import Clock
from natureai_next.ports.identity import UuidGenerator
from natureai_next.ports.importing import FileFingerprinter, ManagedFileStore

def _now_us(clock: Clock)->int:return int(clock.now_utc().timestamp()*1_000_000)
def _path(path:Path)->tuple[str,str]:
    value=str(path.expanduser().resolve()); return value,os.path.normcase(value).casefold()

class CatalogMaintenanceService:
    def __init__(self, *, uow_factory, fingerprinter: FileFingerprinter, managed_store: ManagedFileStore, clock: Clock, ids: UuidGenerator) -> None:
        self.uow_factory=uow_factory; self.fingerprinter=fingerprinter; self.managed_store=managed_store; self.clock=clock; self.ids=ids

    def refresh_availability(self) -> int:
        changed=0; now=_now_us(self.clock)
        with self.uow_factory() as uow:
            assert uow.connection is not None; c=uow.connection
            for row in c.execute("SELECT id,normalized_path,availability_state FROM file_instances WHERE storage_mode IN ('managed','referenced')"):
                target="available" if Path(row["normalized_path"]).is_file() else "missing"
                if target != row["availability_state"]:
                    c.execute("UPDATE file_instances SET availability_state=?,modified_at_us=? WHERE id=?",(target,now,row["id"])); changed+=1
            uow.commit()
        return changed

    def relink(self, file_public_id: str, candidate: Path) -> None:
        fingerprint=self.fingerprinter.fingerprint(candidate); normalized,key=_path(candidate); now=_now_us(self.clock)
        with self.uow_factory() as uow:
            assert uow.connection is not None; c=uow.connection
            row=c.execute("SELECT sha256 FROM file_instances WHERE public_id=?",(file_public_id,)).fetchone()
            if row is None: raise KeyError(file_public_id)
            if row["sha256"] and row["sha256"] != fingerprint.sha256: raise ValueError("relink candidate checksum does not match original")
            c.execute("UPDATE file_instances SET normalized_path=?,path_key=?,file_size=?,modified_at_observed_us=?,sha256=?,fast_fingerprint=?,availability_state='available',verified_at_us=?,modified_at_us=? WHERE public_id=?",(normalized,key,fingerprint.size,candidate.stat().st_mtime_ns//1000,fingerprint.sha256,fingerprint.fast_fingerprint,now,now,file_public_id)); uow.commit()

    def trash(self, asset_public_id: str) -> bool:
        with self.uow_factory() as uow:
            assert uow.connection is not None
            cur=uow.connection.execute("UPDATE assets SET lifecycle_state='trashed',modified_at_us=?,revision=revision+1 WHERE public_id=? AND lifecycle_state='active'",(_now_us(self.clock),asset_public_id)); uow.commit(); return cur.rowcount==1

    def restore(self, asset_public_id: str) -> bool:
        with self.uow_factory() as uow:
            assert uow.connection is not None
            cur=uow.connection.execute("UPDATE assets SET lifecycle_state='active',modified_at_us=?,revision=revision+1 WHERE public_id=? AND lifecycle_state='trashed'",(_now_us(self.clock),asset_public_id)); uow.commit(); return cur.rowcount==1

    def purge(self, asset_public_id: str) -> bool:
        now=_now_us(self.clock)
        with self.uow_factory() as uow:
            assert uow.connection is not None; c=uow.connection
            asset=c.execute("SELECT id FROM assets WHERE public_id=? AND lifecycle_state='trashed'",(asset_public_id,)).fetchone()
            if asset is None:return False
            paths=[r[0] for r in c.execute("SELECT normalized_path FROM file_instances WHERE asset_id=? AND storage_mode='managed'",(asset["id"],))]
            intent=str(self.ids.new_uuid())
            c.execute("INSERT INTO purge_intents(public_id,asset_id,managed_paths_json,state,created_at_us,modified_at_us) VALUES(?,?,?,'pending',?,?)",(intent,asset["id"],json.dumps(paths),now,now)); uow.commit()
        try:
            for value in paths:self.managed_store.purge(Path(value))
            with self.uow_factory() as uow:
                assert uow.connection is not None; c=uow.connection
                c.execute("UPDATE purge_intents SET state='files_deleted',modified_at_us=? WHERE public_id=?",(_now_us(self.clock),intent))
                c.execute("UPDATE assets SET lifecycle_state='purged',modified_at_us=?,revision=revision+1 WHERE id=?",(_now_us(self.clock),asset["id"]))
                c.execute("UPDATE purge_intents SET state='completed',modified_at_us=? WHERE public_id=?",(_now_us(self.clock),intent)); uow.commit()
            return True
        except Exception as exc:
            with self.uow_factory() as uow:
                assert uow.connection is not None; uow.connection.execute("UPDATE purge_intents SET state='failed',error_text=?,modified_at_us=? WHERE public_id=?",(str(exc),_now_us(self.clock),intent)); uow.commit()
            raise
