"""Verified backup inspection and safe restore staging."""
from __future__ import annotations

import hashlib
import json
import shutil
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path


@dataclass(frozen=True, slots=True)
class VerifiedBackup:
    database_path: Path
    manifest_path: Path
    library_name: str
    created_at_utc: str
    size_bytes: int
    sha256: str


@dataclass(frozen=True, slots=True)
class StagedRestore:
    staged_database: Path
    staged_manifest: Path
    request_path: Path
    emergency_backup: Path


class LibraryRecoveryService:
    """Verify NatureAI_Next backup manifests and stage restart-safe restores."""

    def verify(self, database_path: Path) -> VerifiedBackup:
        database_path = database_path.expanduser().resolve()
        if not database_path.is_file():
            raise FileNotFoundError(database_path)
        manifest_path = database_path.with_suffix(database_path.suffix + ".manifest.json")
        if not manifest_path.is_file():
            raise FileNotFoundError(f"backup manifest not found: {manifest_path}")
        payload = json.loads(manifest_path.read_text(encoding="utf-8"))
        if payload.get("format") != "natureai-next.database-backup" or payload.get("format_version") != 1:
            raise ValueError("unsupported backup manifest format")
        if payload.get("database_file") != database_path.name:
            raise ValueError("backup manifest names a different database file")
        size = database_path.stat().st_size
        if payload.get("size_bytes") != size:
            raise ValueError("backup size does not match its manifest")
        digest = hashlib.sha256()
        with database_path.open("rb") as handle:
            for chunk in iter(lambda: handle.read(1024 * 1024), b""):
                digest.update(chunk)
        actual = digest.hexdigest()
        if payload.get("sha256") != actual:
            raise ValueError("backup checksum does not match its manifest")
        return VerifiedBackup(
            database_path=database_path,
            manifest_path=manifest_path,
            library_name=str(payload.get("library_name", "Aperture Library")),
            created_at_utc=str(payload.get("created_at_utc", "")),
            size_bytes=size,
            sha256=actual,
        )

    def list_backups(self, directory: Path) -> tuple[VerifiedBackup, ...]:
        directory = directory.expanduser().resolve()
        if not directory.exists():
            return ()
        results: list[VerifiedBackup] = []
        for candidate in sorted(directory.glob("*.sqlite3"), key=lambda p: p.stat().st_mtime, reverse=True):
            try:
                results.append(self.verify(candidate))
            except (OSError, ValueError, json.JSONDecodeError):
                continue
        return tuple(results)

    def stage_restore(
        self,
        backup: VerifiedBackup,
        *,
        staging_directory: Path,
        current_database: Path,
        emergency_backup: Path,
    ) -> StagedRestore:
        staging_directory = staging_directory.expanduser().resolve()
        current_database = current_database.expanduser().resolve()
        emergency_backup = emergency_backup.expanduser().resolve()
        self.verify(backup.database_path)
        if not current_database.is_file():
            raise FileNotFoundError(f"current library database not found: {current_database}")
        if not emergency_backup.is_file():
            raise FileNotFoundError(f"emergency backup not found: {emergency_backup}")
        staging_directory.mkdir(parents=True, exist_ok=True)
        staged_database = staging_directory / "restore.sqlite3"
        staged_manifest = staging_directory / "restore.sqlite3.manifest.json"
        temp_database = staged_database.with_suffix(".sqlite3.tmp")
        temp_manifest = staged_manifest.with_suffix(staged_manifest.suffix + ".tmp")
        shutil.copy2(backup.database_path, temp_database)
        staged_payload = json.loads(backup.manifest_path.read_text(encoding="utf-8"))
        staged_payload["database_file"] = staged_database.name
        temp_manifest.write_text(json.dumps(staged_payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")
        temp_database.replace(staged_database)
        temp_manifest.replace(staged_manifest)
        staged_verified = self.verify(staged_database)
        request_path = staging_directory / "pending-restore.json"
        request = {
            "format": "natureai-next.pending-restore",
            "format_version": 1,
            "created_at_utc": datetime.now(timezone.utc).isoformat(),
            "target_database": str(current_database),
            "staged_database": str(staged_verified.database_path),
            "sha256": staged_verified.sha256,
            "emergency_backup": str(emergency_backup),
        }
        temp_request = request_path.with_suffix(".json.tmp")
        temp_request.write_text(json.dumps(request, indent=2, sort_keys=True) + "\n", encoding="utf-8")
        temp_request.replace(request_path)
        return StagedRestore(staged_database, staged_manifest, request_path, emergency_backup)
