"""NatureAI Next package."""
