"""Automatic acquisition and installation of regional GBIF taxonomy evidence."""
from __future__ import annotations

import hashlib
import json
import urllib.parse
import urllib.request
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Callable, Iterable

from cryptography.hazmat.primitives import serialization

from natureai_next import __version__
from natureai_next.application.ai_resources import LocalAIResourceService
from natureai_next.application.ai_setup import BioCLIPQuickSetupService
from natureai_next.domain.regional import RegionalCountry, RegionalProfile
from natureai_next.domain.taxonomy import LicenseMetadata
from natureai_next.infrastructure.taxonomy.package import build_taxonomy_package

_GBIF_API = "https://api.gbif.org/v1"
_CONTINENT_NAMES = {
    "AF": "AFRICA", "AS": "ASIA", "EU": "EUROPE", "NA": "NORTH_AMERICA",
    "SA": "SOUTH_AMERICA", "OC": "OCEANIA", "AN": "ANTARCTICA",
}


@dataclass(frozen=True, slots=True)
class RegionalAcquisitionResult:
    package_path: Path
    taxonomy_source_public_id: str
    prompt_manifest: Path
    prompt_public_id: str
    embedding_counts: tuple[int, int] | None
    taxa_count: int
    region_record_count: int


class GbifRegionalClient:
    """Small anonymous GBIF client using occurrence facets and species records."""

    def __init__(self, *, base_url: str = _GBIF_API, timeout: int = 60, facet_page: int = 1000) -> None:
        self._base_url = base_url.rstrip("/")
        self._timeout = timeout
        self._facet_page = facet_page

    def species_keys(self, *, country: str | None = None, continent: str | None = None, maximum: int = 20000) -> tuple[int, ...]:
        result: list[int] = []
        offset = 0
        while len(result) < maximum:
            params: dict[str, object] = {
                "limit": 0, "facet": "speciesKey", "facetLimit": min(self._facet_page, maximum-len(result)),
                "facetOffset": offset, "hasCoordinate": "true",
            }
            if country: params["country"] = country
            if continent: params["continent"] = continent
            payload = self._json("/occurrence/search", params)
            facets = payload.get("facets", []) if isinstance(payload, dict) else []
            counts = facets[0].get("counts", []) if facets and isinstance(facets[0], dict) else []
            page: list[int] = []
            for item in counts:
                try: page.append(int(item["name"]))
                except (KeyError, TypeError, ValueError): continue
            result.extend(page)
            if len(page) < int(params["facetLimit"]): break
            offset += len(page)
        return tuple(dict.fromkeys(result[:maximum]))

    def species(self, key: int) -> dict[str, object]:
        value = self._json(f"/species/{key}", {})
        if not isinstance(value, dict): raise ValueError(f"GBIF species {key} returned invalid data")
        return value

    def _json(self, path: str, params: dict[str, object]) -> object:
        query = urllib.parse.urlencode(params)
        request = urllib.request.Request(
            f"{self._base_url}{path}" + (f"?{query}" if query else ""),
            headers={"Accept": "application/json", "User-Agent": f"NatureAI-Next/{__version__}"},
        )
        with urllib.request.urlopen(request, timeout=self._timeout) as response:
            return json.load(response)


class RegionalKnowledgeAcquisitionService:
    """Downloads, signs, installs and activates a regional GBIF knowledge package."""

    def __init__(self, resources: LocalAIResourceService, *, workspace: Path, client: GbifRegionalClient | None = None) -> None:
        self._resources = resources
        self._workspace = workspace
        self._client = client or GbifRegionalClient()

    def _job_root(self, profile: RegionalProfile) -> Path:
        code = "-".join([profile.primary_continent_code or "global", *(c.country_code for c in profile.countries)])
        return self._workspace.expanduser().resolve() / "activity" / f"regional-{code.casefold()}"

    @staticmethod
    def profile_payload(profile: RegionalProfile) -> dict[str, object]:
        return {
            "primary_continent_code": profile.primary_continent_code,
            "countries": [asdict(item) for item in profile.countries],
            "include_global_fallback": profile.include_global_fallback,
            "preferred_languages": list(profile.preferred_languages),
        }

    @staticmethod
    def profile_from_payload(payload: dict[str, object]) -> RegionalProfile:
        countries = tuple(RegionalCountry(**item) for item in payload.get("countries", []) if isinstance(item, dict))
        return RegionalProfile(
            payload.get("primary_continent_code") if isinstance(payload.get("primary_continent_code"), str) else None,
            countries,
            bool(payload.get("include_global_fallback", True)),
            tuple(str(x) for x in payload.get("preferred_languages", ("en", "scientific"))),
        )

    def recovery_operation(self, payload: dict[str, object]) -> Callable[..., RegionalAcquisitionResult]:
        profile = self.profile_from_payload(payload)
        return lambda progress, cancelled: self.acquire(profile, progress=progress, cancelled=cancelled)

    def acquire(
        self,
        profile: RegionalProfile,
        *,
        progress: Callable[[int, int, str], None] | None = None,
        cancelled: Callable[[], bool] | None = None,
    ) -> RegionalAcquisitionResult:
        report = progress or (lambda _current, _total, _message: None)
        is_cancelled = cancelled or (lambda: False)
        def check_cancelled() -> None:
            if is_cancelled():
                raise InterruptedError("Cancelled by user")
        job_root = self._job_root(profile)
        job_root.mkdir(parents=True, exist_ok=True)
        state_path = job_root / "state.json"
        def checkpoint(stage: str, **extra: object) -> None:
            value = {"stage": stage, "profile": self.profile_payload(profile), **extra}
            temp = state_path.with_suffix(".tmp")
            temp.write_text(json.dumps(value, indent=2, sort_keys=True), encoding="utf-8")
            temp.replace(state_path)
        checkpoint("started")
        if not profile.primary_continent_code and not profile.countries:
            raise ValueError("Save a continent or country profile before downloading regional knowledge.")
        root = self._workspace.expanduser().resolve()
        signing = root / "signing"; packages = root / "packages"; prompts = root / "prompts"
        for folder in (signing, packages, prompts): folder.mkdir(parents=True, exist_ok=True)
        key_id = "natureai-local"
        private_path = signing / f"{key_id}-private.pem"; trusted_path = signing / f"{key_id}-trusted.json"
        private_key = BioCLIPQuickSetupService._ensure_signing_identity(key_id, private_path, trusted_path)

        scopes: list[tuple[str, str]] = []
        for country in profile.countries: scopes.append((country.country_code, country.country_code))
        if profile.primary_continent_code:
            scopes.append((profile.primary_continent_code, _CONTINENT_NAMES[profile.primary_continent_code]))
        report(1, 5, "Finding taxa recorded in the selected region…")
        keys_path = job_root / "region-keys.json"
        keys_by_region: dict[str, tuple[int, ...]] = {}
        if keys_path.is_file():
            loaded = json.loads(keys_path.read_text(encoding="utf-8"))
            keys_by_region = {str(code): tuple(int(x) for x in values) for code, values in loaded.items()}
        else:
            for region_code, api_value in scopes:
                check_cancelled()
                keys_by_region[region_code] = self._client.species_keys(
                    country=api_value if len(region_code)==2 and region_code not in _CONTINENT_NAMES else None,
                    continent=api_value if region_code in _CONTINENT_NAMES else None,
                )
            keys_path.write_text(json.dumps({k:list(v) for k,v in keys_by_region.items()}, indent=2), encoding="utf-8")
        all_keys: dict[int, None] = {}
        for keys in keys_by_region.values(): all_keys.update((key, None) for key in keys)
        if not all_keys: raise RuntimeError("GBIF returned no species for the selected regional profile.")
        checkpoint("region-keys-complete", taxa_total=len(all_keys))

        report(2, 5, f"Downloading taxonomy details for {len(all_keys):,} taxa…")
        detail_dir = job_root / "species"; detail_dir.mkdir(exist_ok=True)
        taxa: list[dict[str, object]] = []; names: list[dict[str, object]] = []
        valid_keys: set[int] = set()
        for index, key in enumerate(all_keys, start=1):
            check_cancelled()
            detail_path = detail_dir / f"{key}.json"
            if detail_path.is_file():
                item = json.loads(detail_path.read_text(encoding="utf-8"))
            else:
                item = self._client.species(key)
                temp = detail_path.with_suffix(".tmp")
                temp.write_text(json.dumps(item, ensure_ascii=False), encoding="utf-8")
                temp.replace(detail_path)
            if index == 1 or index % 25 == 0 or index == len(all_keys):
                report(index, len(all_keys), f"Downloading taxonomy details: {index:,} of {len(all_keys):,}")
                checkpoint("taxonomy-details", completed=index, total=len(all_keys))
            scientific = str(item.get("scientificName") or item.get("canonicalName") or "").strip()
            rank = str(item.get("rank") or "SPECIES").casefold()
            if not scientific or rank not in {"species", "subspecies", "variety", "form"}: continue
            source_id = str(key); valid_keys.add(key)
            status_text = str(item.get("taxonomicStatus") or "ACCEPTED").upper()
            status = "accepted" if status_text in {"ACCEPTED", "DOUBTFUL"} else "unresolved"
            taxa.append({
                "source_taxon_id": source_id, "scientific_name": scientific, "rank": rank,
                "status": status, "authorship": item.get("authorship"), "kingdom": item.get("kingdom"),
                "major_group": item.get("phylum") or item.get("class"), "extinct": bool(item.get("extinct", False)),
            })
            names.append({"source_taxon_id": source_id, "name": scientific, "name_type": "scientific", "source": "GBIF Backbone Taxonomy", "language_tag": "scientific", "preferred": True})
            vernacular = str(item.get("vernacularName") or "").strip()
            if vernacular:
                names.append({"source_taxon_id": source_id, "name": vernacular, "name_type": "vernacular", "source": "GBIF Backbone Taxonomy", "language_tag": "en", "preferred": True})
        regions: list[dict[str, object]] = []
        for region_code, keys in keys_by_region.items():
            for key in keys:
                if key in valid_keys:
                    regions.append({"source_taxon_id": str(key), "region_code": region_code, "occurrence_status": "recorded", "source": "GBIF occurrence search"})

        check_cancelled()
        checkpoint("taxonomy-details-complete", taxa_count=len(taxa), region_count=len(regions))
        report(3, 5, "Building and signing the regional taxonomy package…")
        profile_code = "-".join([profile.primary_continent_code or "global", *(c.country_code for c in profile.countries)])
        snapshot_hash = hashlib.sha256(json.dumps({"taxa": taxa, "regions": regions}, sort_keys=True, ensure_ascii=False).encode("utf-8")).hexdigest()[:12]
        package_identity = f"natureai-gbif-{profile_code.casefold()}-{snapshot_hash}"
        package_path = packages / f"{package_identity}.zip"
        build_taxonomy_package(
            package_path, private_key=private_key, key_id=key_id,
            package_id=package_identity, source_name="GBIF regional occurrence and backbone taxonomy",
            source_version=f"api-snapshot-{snapshot_hash}", minimum_app_version=__version__,
            license_metadata=LicenseMetadata("CC BY 4.0", "https://creativecommons.org/licenses/by/4.0/", "GBIF.org occurrence data and GBIF Backbone Taxonomy; accessed by NatureAI Next.", True),
            taxa=taxa, names=names, regions=regions,
            attribution_text="GBIF.org occurrence data and GBIF Backbone Taxonomy. Individual occurrence datasets may require additional attribution; see GBIF.org.",
        )
        checkpoint("package-built", package_path=str(package_path))
        check_cancelled()
        report(4, 5, "Installing taxonomy and generating prompts…")
        source_id = self._resources.install_taxonomy(package_path, trusted_path)
        prompt_path = prompts / f"natureai-gbif-{profile_code.casefold()}-prompts.json"
        prompt_rows = [{"label": f"{t['scientific_name']} [{t['source_taxon_id']}]", "text": f"a wildlife photograph of {t['scientific_name']}", "taxon_public_id": None, "broad_group": t.get("major_group") or "organism"} for t in taxa]
        prompt_path.write_text(json.dumps({"schema_version":1,"identity":f"natureai-gbif-{profile_code.casefold()}-prompts","semantic_version":"1.0.0","model_family":"bioclip","minimum_application_version":__version__,"prompts":prompt_rows}, indent=2, ensure_ascii=False)+"\n", encoding="utf-8")
        prompt_id = self._resources.install_prompt_set(prompt_path, model_family="bioclip")
        checkpoint("resources-installed", taxonomy_source_public_id=source_id, prompt_public_id=prompt_id)
        check_cancelled()
        report(5, 5, "Building regional taxonomy embeddings…")
        try: embedding_counts = self._resources.build_taxonomy_embeddings()
        except RuntimeError: embedding_counts = None
        result = RegionalAcquisitionResult(package_path, source_id, prompt_path, prompt_id, embedding_counts, len(taxa), len(regions))
        checkpoint("completed", result=str(result))
        return result
