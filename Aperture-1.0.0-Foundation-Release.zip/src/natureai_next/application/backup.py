"""User-facing verified library database backup orchestration."""
from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Callable


@dataclass(frozen=True, slots=True)
class BackupResult:
    database_path: Path
    manifest_path: Path
    size_bytes: int
    sha256: str
    created_at_utc: str


class LibraryBackupService:
    """Create a verified database snapshot and a portable checksum manifest."""

    def __init__(self, backup_database: Callable[[Path], Path], *, library_name: str) -> None:
        self._backup_database = backup_database
        self._library_name = library_name

    def create(self, destination: Path) -> BackupResult:
        destination = destination.expanduser().resolve()
        if destination.exists():
            raise FileExistsError(f"backup already exists: {destination}")
        if destination.suffix.casefold() not in {".sqlite3", ".db"}:
            destination = destination.with_suffix(".sqlite3")
        destination.parent.mkdir(parents=True, exist_ok=True)
        created = self._backup_database(destination)
        digest = hashlib.sha256()
        with created.open("rb") as handle:
            for chunk in iter(lambda: handle.read(1024 * 1024), b""):
                digest.update(chunk)
        created_at = datetime.now(timezone.utc).isoformat()
        manifest = created.with_suffix(created.suffix + ".manifest.json")
        payload = {
            "format": "natureai-next.database-backup",
            "format_version": 1,
            "library_name": self._library_name,
            "created_at_utc": created_at,
            "database_file": created.name,
            "size_bytes": created.stat().st_size,
            "sha256": digest.hexdigest(),
        }
        temp = manifest.with_suffix(manifest.suffix + ".tmp")
        temp.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")
        temp.replace(manifest)
        return BackupResult(
            database_path=created,
            manifest_path=manifest,
            size_bytes=payload["size_bytes"],
            sha256=payload["sha256"],
            created_at_utc=created_at,
        )


def suggested_backup_name(library_name: str) -> str:
    safe = "".join(character if character.isalnum() or character in "-_" else "-" for character in library_name)
    safe = safe.strip("-") or "Aperture-Library"
    stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    return f"{safe}-{stamp}.sqlite3"
