"""Application services for paged catalog reads and metadata commands."""
from __future__ import annotations
from dataclasses import dataclass
from natureai_next.ports.catalog_queries import AssetDetail, AssetPage, CatalogEditPort, CatalogReadPort, MetadataChangeResult, MetadataPatch
from natureai_next.ports.clock import Clock

class CatalogQueryService:
    def __init__(self, reader: CatalogReadPort) -> None: self._reader = reader
    def page(self, *, limit: int, after_id: int | None = None) -> AssetPage:
        if not 1 <= limit <= 500: raise ValueError("page limit must be between 1 and 500")
        return self._reader.page_assets(limit=limit, after_id=after_id)
    def by_public_ids(self, public_ids: tuple[str, ...]) -> AssetPage:
        return self._reader.page_assets_by_public_ids(public_ids)
    def detail(self, public_id: str) -> AssetDetail | None: return self._reader.get_asset_detail(public_id)

@dataclass(frozen=True, slots=True)
class UndoableMetadataCommand:
    change: MetadataChangeResult

class CatalogEditService:
    def __init__(self, editor: CatalogEditPort, clock: Clock) -> None: self._editor, self._clock = editor, clock

    @staticmethod
    def _clean_tags(tag_names: tuple[str, ...]) -> tuple[str, ...]:
        unique: dict[str, str] = {}
        for raw_name in tag_names:
            name = raw_name.strip()
            if name:
                unique.setdefault(name.casefold(), name)
        return tuple(sorted(unique.values(), key=str.casefold))
    def update(self, *, public_id: str, expected_revision: int, patch: MetadataPatch) -> UndoableMetadataCommand:
        now = int(self._clock.now_utc().timestamp() * 1_000_000)
        return UndoableMetadataCommand(self._editor.update_metadata(public_id=public_id, expected_revision=expected_revision, patch=patch, modified_at_us=now))
    def update_with_tags(
        self,
        *,
        public_id: str,
        expected_revision: int,
        patch: MetadataPatch,
        tag_names: tuple[str, ...],
    ) -> UndoableMetadataCommand:
        clean = self._clean_tags(tag_names)
        now = int(self._clock.now_utc().timestamp() * 1_000_000)
        return UndoableMetadataCommand(
            self._editor.update_metadata_and_tags(
                public_id=public_id,
                expected_revision=expected_revision,
                patch=patch,
                tag_names=clean,
                modified_at_us=now,
            )
        )

    def apply_tags(self, *, public_ids: tuple[str, ...], tag_names: tuple[str, ...]) -> None:
        clean = self._clean_tags(tag_names)
        now = int(self._clock.now_utc().timestamp() * 1_000_000)
        self._editor.set_tags(public_ids=public_ids, tag_names=clean, modified_at_us=now)
