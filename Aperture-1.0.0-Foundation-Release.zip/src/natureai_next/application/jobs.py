"""Application-facing durable job commands and queries."""
from __future__ import annotations

import json
from dataclasses import dataclass
from natureai_next.domain.jobs import JobRecord, JobState, ResourceClass
from natureai_next.infrastructure.database.connection import SqliteConnectionFactory
from natureai_next.infrastructure.database.unit_of_work import SqliteUnitOfWork
from natureai_next.ports.clock import Clock
from natureai_next.ports.identity import UuidGenerator


@dataclass(frozen=True, slots=True)
class SubmitJob:
    job_type: str
    payload: dict[str, object]
    resource_class: ResourceClass
    priority: int = 0
    payload_version: int = 1
    idempotency_key: str | None = None
    parent_job_id: int | None = None
    dependency_job_id: int | None = None


class JobService:
    def __init__(self, factory: SqliteConnectionFactory, clock: Clock, ids: UuidGenerator) -> None:
        self.factory, self.clock, self.ids = factory, clock, ids

    def submit(self, command: SubmitJob) -> JobRecord:
        now = self._now()
        record = JobRecord(str(self.ids.new_uuid()),command.job_type,command.payload_version,json.dumps(command.payload,sort_keys=True,separators=(",", ":")),JobState.QUEUED,command.priority,command.resource_class,now,now,command.idempotency_key,command.parent_job_id,command.dependency_job_id)
        with SqliteUnitOfWork(self.factory) as uow:
            if command.idempotency_key:
                row = uow.connection.execute("SELECT public_id FROM jobs WHERE idempotency_key=?", (command.idempotency_key,)).fetchone()
                if row is not None:
                    existing = uow.jobs.get(row[0]); uow.commit();
                    if existing is None: raise RuntimeError("idempotent job disappeared")
                    return existing
            created = uow.jobs.add(record); uow.commit(); return created

    def cancel(self, public_id: str) -> bool:
        with SqliteUnitOfWork(self.factory) as uow:
            changed=uow.jobs.request_cancel(public_id,self._now());uow.commit();return changed

    def pause(self, public_id: str) -> bool:
        with SqliteUnitOfWork(self.factory) as uow:
            changed=uow.jobs.request_pause(public_id,self._now());uow.commit();return changed

    def resume(self, public_id: str) -> bool:
        with SqliteUnitOfWork(self.factory) as uow:
            changed=uow.jobs.resume(public_id,self._now());uow.commit();return changed

    def recent(self, limit: int = 100) -> tuple[JobRecord, ...]:
        connection=self.factory.connect(read_only=True)
        try:
            from natureai_next.infrastructure.database.repositories import SqliteJobRepository
            return SqliteJobRepository(connection).list_recent(limit)
        finally: connection.close()

    def _now(self) -> int:
        return int(self.clock.now_utc().timestamp()*1_000_000)
