"""Local AI resource installation and taxonomy embedding preparation."""
from __future__ import annotations

import base64
import json
from pathlib import Path
from typing import Callable

from natureai_next.application.ai_review import PromptSetService, TaxonomyTextEmbeddingService
from natureai_next.domain.ai import TaxonomyTextLabel
from natureai_next.infrastructure.ai.openclip_provider import OpenClipExecutionProvider
from natureai_next.infrastructure.ai.package import ModelPackageInstaller, ModelPackageVerifier
from natureai_next.infrastructure.ai.prompts import load_prompt_set, prompt_set_checksum, validate_prompt_set
from natureai_next.infrastructure.database.ai_generation import (
    SqliteTaxonomyEmbeddingRefreshPlanSource,
    SqliteTaxonomyEmbeddingStore,
    SqliteTaxonomyLabelSource,
)
from natureai_next.infrastructure.database.ai_review import SqlitePromptSetStore
from natureai_next.infrastructure.database.connection import SqliteConnectionFactory
from natureai_next.infrastructure.database.taxonomy import SqliteTaxonomyAdapter
from natureai_next.infrastructure.taxonomy.package import Ed25519TaxonomyPackageVerifier


def load_trusted_key_file(path: Path) -> dict[str, bytes]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict) or not value:
        raise ValueError("trusted key file must be a non-empty JSON object")
    result: dict[str, bytes] = {}
    for key_id, encoded in value.items():
        if not isinstance(key_id, str) or not key_id.strip() or not isinstance(encoded, str):
            raise ValueError("trusted key entries must map key identifiers to base64 strings")
        raw = base64.b64decode(encoded, validate=True)
        if len(raw) != 32:
            raise ValueError(f"Ed25519 public key {key_id!r} must contain 32 bytes")
        result[key_id] = raw
    return result


class LocalAIResourceService:
    """Installs signed local resources and builds compatible taxonomy embeddings."""

    def __init__(
        self,
        *,
        factory: SqliteConnectionFactory,
        models_root: Path,
        id_factory: Callable[[], str],
        now_us: Callable[[], int],
    ) -> None:
        self._factory = factory
        self._models_root = models_root
        self._id_factory = id_factory
        self._now_us = now_us

    def install_model(self, package_path: Path, trusted_keys_path: Path) -> str:
        verifier = ModelPackageVerifier(load_trusted_key_file(trusted_keys_path))
        return ModelPackageInstaller(self._factory, self._models_root, verifier).install(
            package_path, activate=True
        )

    def install_prompt_set(
        self,
        manifest_path: Path,
        *,
        model_family: str | None = None,
    ) -> str:
        record = PromptSetService(
            SqlitePromptSetStore(self._factory),
            loader=load_prompt_set,
            checksum=prompt_set_checksum,
            validator=validate_prompt_set,
        ).install(
            manifest_path,
            public_id=self._id_factory(),
            now_us=self._now_us(),
            activate=True,
            model_family=model_family,
        )
        return record.public_id

    def install_taxonomy(self, package_path: Path, trusted_keys_path: Path) -> str:
        package = Ed25519TaxonomyPackageVerifier(
            load_trusted_key_file(trusted_keys_path)
        ).verify(package_path)
        return SqliteTaxonomyAdapter(self._factory).install(package, now_us=self._now_us())

    def build_taxonomy_embeddings(self) -> tuple[int, int]:
        plans = SqliteTaxonomyEmbeddingRefreshPlanSource(self._factory).active_plans()
        if not plans:
            raise RuntimeError("No active model variant is available.")
        provider = OpenClipExecutionProvider()
        total_labels = 0
        total_written = 0
        for plan in plans:
            connection = self._factory.connect(read_only=True)
            try:
                row = connection.execute(
                    """SELECT p.install_path_token,v.artifact_relative_path,v.precision,
                              v.device_requirements_json
                       FROM model_variants v JOIN model_packages p ON p.id=v.package_id
                       WHERE v.id=?""",
                    (plan.model_variant_id,),
                ).fetchone()
            finally:
                connection.close()
            if row is None:
                continue
            requirements = json.loads(str(row[3] or "{}"))
            providers = tuple(str(x).casefold() for x in requirements.get("providers", ()))
            device = "cuda" if any("cuda" in x for x in providers) else "cpu"
            artifact = Path(str(row[0])) / str(row[1])
            handle = provider.load(artifact, device=device, precision=str(row[2]))
            try:
                service = TaxonomyTextEmbeddingService(
                    labels=SqliteTaxonomyLabelSource(self._factory),
                    store=SqliteTaxonomyEmbeddingStore(self._factory),
                    embed_text=lambda texts, h=handle: provider.embed_text(h, texts),
                    public_id_factory=lambda _label: self._id_factory(),
                )
                result = service.rebuild(
                    model_variant_id=plan.model_variant_id,
                    preprocessing_identity=plan.preprocessing_identity,
                    prompt_set_public_id=plan.prompt_set_public_id,
                    now_us=self._now_us(),
                )
                total_labels += result.labels_seen
                total_written += result.embeddings_written
            finally:
                provider.unload(handle)
        return total_labels, total_written
