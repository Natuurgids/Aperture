"""Library lifecycle contracts and immutable layout."""
from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path

@dataclass(frozen=True,slots=True)
class LibraryLayout:
    root:Path; database:Path; manifest:Path; managed_originals:Path; sidecars:Path; thumbnails:Path; previews:Path; vector_indexes:Path; backups:Path; temp:Path; lock_file:Path
    @classmethod
    def at(cls,root:Path)->"LibraryLayout":
        resolved=root.expanduser().resolve()
        return cls(resolved,resolved/"library.sqlite3",resolved/"library.json",resolved/"originals",resolved/"sidecars",resolved/"cache"/"thumbnails",resolved/"cache"/"previews",resolved/"indexes"/"vectors",resolved/"backups",resolved/"temp",resolved/".natureai-next.lock")
    def create_directories(self)->None:
        for path in (self.root,self.managed_originals,self.sidecars,self.thumbnails,self.previews,self.vector_indexes,self.backups,self.temp):path.mkdir(parents=True,exist_ok=True)
