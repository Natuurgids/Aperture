"""Configurable user-facing product identity for open-source distributions."""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from urllib.parse import urlparse
import tomllib

from natureai_next.infrastructure.filesystem.atomic import atomic_write_bytes
from natureai_next.infrastructure.filesystem.toml_codec import dumps_toml


@dataclass(frozen=True, slots=True)
class BrandingSettings:
    application_name: str = "Aperture"
    powered_by: str = "NatureAI_Next"
    organization_name: str = "natuurgids.org"
    project_website: str = "https://natuurgids.org"
    donation_label: str = "Support Aperture"
    donation_url: str = "https://natuurgids.org"

    def validate(self) -> None:
        if not self.application_name.strip():
            raise ValueError("Application name must not be blank")
        if not self.powered_by.strip():
            raise ValueError("Powered-by text must not be blank")
        for label, value in (("Project website", self.project_website), ("Donation URL", self.donation_url)):
            if value and urlparse(value).scheme.casefold() not in {"http", "https"}:
                raise ValueError(f"{label} must use http or https")


class BrandingStore:
    def load(self, path: Path) -> BrandingSettings:
        if not path.exists():
            return BrandingSettings()
        with path.open("rb") as stream:
            document = tomllib.load(stream)
        values = document.get("branding", {})
        if not isinstance(values, dict):
            values = {}
        defaults = BrandingSettings()
        settings = BrandingSettings(**{
            field: str(values.get(field, getattr(defaults, field)))
            for field in defaults.__dataclass_fields__
        })
        settings.validate()
        return settings

    def save(self, path: Path, settings: BrandingSettings) -> None:
        settings.validate()
        payload = {"branding": {
            "application_name": settings.application_name,
            "powered_by": settings.powered_by,
            "organization_name": settings.organization_name,
            "project_website": settings.project_website,
            "donation_label": settings.donation_label,
            "donation_url": settings.donation_url,
        }}
        atomic_write_bytes(path, dumps_toml(payload).encode("utf-8"))
