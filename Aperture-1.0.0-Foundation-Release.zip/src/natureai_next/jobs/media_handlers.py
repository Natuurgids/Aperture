"""Persistent media-pipeline job handlers."""
from __future__ import annotations

import json
from pathlib import Path
from natureai_next.infrastructure.imaging.cache import DerivativeCache, DerivativeSpec
from natureai_next.ports.jobs import JobExecutionContext
from natureai_next.ports.media import MetadataReader


class GenerateDerivativeHandler:
    job_type = "media.generate_derivative"
    resource_class = "io"
    def __init__(self, cache: DerivativeCache) -> None: self.cache = cache
    def execute(self, context: JobExecutionContext) -> dict[str, object]:
        payload=json.loads(context.job.payload_json);context.cancellation.raise_if_cancelled()
        source=Path(payload["source"]);spec=DerivativeSpec(payload["kind"],int(payload["max_width"]),int(payload["max_height"]),int(payload.get("quality",85)))
        context.report_progress(0,1,"file","Rendering derivative")
        output,manifest=self.cache.get_or_create(source,spec,payload.get("source_sha256"))
        context.report_progress(1,1,"file","Derivative ready")
        return {"path":str(output),"cache_key":manifest.cache_key,"width":manifest.pixel_width,"height":manifest.pixel_height}


class ExtractMetadataHandler:
    job_type = "media.extract_metadata"
    resource_class = "io"
    def __init__(self, reader: MetadataReader) -> None: self.reader=reader
    def execute(self, context: JobExecutionContext) -> dict[str, object]:
        payload=json.loads(context.job.payload_json);context.cancellation.raise_if_cancelled();result=self.reader.read(Path(payload["source"]))
        return {"normalized":dict(result.normalized),"raw":dict(result.raw),"warnings":list(result.warnings)}
