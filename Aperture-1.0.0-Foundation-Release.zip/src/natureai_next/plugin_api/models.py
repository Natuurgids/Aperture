"""Immutable public plugin data contracts."""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import StrEnum
from pathlib import Path
from typing import Mapping


class PluginCapability(StrEnum):
    FILESYSTEM_PLUGIN_DATA = "filesystem.plugin_data"
    FILESYSTEM_EXPORT = "filesystem.export"
    FILESYSTEM_ASSET_READ = "filesystem.asset_read"
    UI_CONTRIBUTION = "ui.contribution"
    MODEL_LOADING = "ai.model_loading"
    TAXONOMY_INSTALLATION = "taxonomy.installation"
    DATABASE_STORAGE = "database.plugin_storage"
    RESTRICTED_UPDATE_TRANSPORT = "network.restricted_update_transport"


@dataclass(frozen=True, slots=True)
class PluginManifest:
    plugin_id: str
    display_name: str
    version: str
    provider: str
    description: str
    license: str
    plugin_api_specifier: str
    minimum_application_version: str
    capabilities: frozenset[PluginCapability]
    entry_point: str
    homepage: str | None = None
    support: str | None = None
    publisher_identity: str | None = None


@dataclass(frozen=True, slots=True)
class MetadataField:
    name: str
    value: str | int | float | bool
    source: str


@dataclass(frozen=True, slots=True)
class MetadataReadResult:
    fields: tuple[MetadataField, ...]
    warnings: tuple[str, ...]
    raw_fields: Mapping[str, str] = field(default_factory=dict)
    reader_version: str = "1"


@dataclass(frozen=True, slots=True)
class PluginPaths:
    package_resources: Path
    global_data: Path
    library_data: Path | None
