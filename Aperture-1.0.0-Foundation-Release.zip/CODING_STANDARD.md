# NatureAI Next — Coding Standard

**Status:** Approved design baseline  
**Document version:** 0.1

## 1. Scope

This standard applies to all production Python, tests, build scripts, database migrations, plugin API code, and PySide6 UI code in NatureAI Next.

The goals are correctness, stable architecture, maintainability, predictable performance, and safe offline behavior.

## 2. Language and tooling baseline

- Python 3.11 only until the project formally changes the baseline.
- Source layout under `src/`.
- `pyproject.toml` is the primary project configuration.
- Code formatting and linting use a single automated toolchain selected during Milestone 1.
- Static typing is mandatory for production code.
- Type checking runs in strict mode for core domain, application, ports, and plugin API packages; infrastructure exceptions require documented justification.
- Tests use pytest or the approved equivalent.
- Qt-specific tests use a maintained PySide6-compatible test adapter.

Exact tool versions are pinned in environment/lock files and updated deliberately.

## 3. Architecture enforcement

Allowed dependency direction:

```text
shared <- domain <- ports/application <- infrastructure/ui/plugins/bootstrap
```

More precisely:

- `domain` may depend only on standard library and approved dependency-free `shared` modules.
- `ports` may depend on domain and shared types.
- `application` may depend on domain, ports, and shared.
- `infrastructure` implements ports and may use external libraries.
- `ui` depends on application-facing services and presentation models, not infrastructure implementations.
- `bootstrap` may depend on all modules solely to compose them.
- plugin implementations depend only on the public plugin API and their own dependencies.

Import cycles are prohibited. Import-lint rules are part of CI.

## 4. Code organization

- One module has one coherent responsibility.
- Avoid files above approximately 500 logical lines; larger files require a cohesion review, not mechanical splitting.
- Public interfaces are placed near their domain and re-exported intentionally.
- No wildcard imports.
- No runtime path manipulation.
- No side-effectful work at module import time beyond constants and lightweight registration declarations.
- Global mutable singletons are prohibited except immutable registries created in the composition root.

## 5. Naming

- Packages/modules/functions/variables: `snake_case`.
- Classes/protocols/exceptions: `PascalCase`.
- Constants: `UPPER_SNAKE_CASE`.
- Private implementation names begin with `_`.
- Stable command, event, error, and plugin IDs use lowercase dotted namespaces.
- Database names use lowercase `snake_case`.
- Boolean names read as predicates: `is_available`, `has_embedding`, `should_retry`.
- Avoid unexplained abbreviations.

## 6. Types and data models

- Every public function and method has complete parameter and return annotations.
- Prefer immutable dataclasses for commands, events, value objects, and results.
- Use enums for closed domain states; serialized enums must handle unknown future values at compatibility boundaries.
- Use `Protocol` for structural ports where appropriate.
- Avoid `Any`; isolate unavoidable dynamic library boundaries and validate immediately.
- Do not pass unstructured dictionaries across stable boundaries when a typed model is appropriate.
- Use `pathlib.Path` internally for filesystem paths, converted at serialization boundaries.
- Use timezone-aware UTC instants and explicit local-time value objects.

## 7. Functions and control flow

- Functions should express one level of abstraction.
- Prefer early validation and clear guard clauses.
- Avoid boolean-flag functions that perform unrelated modes; use distinct commands or strategy objects.
- Avoid hidden I/O in properties.
- Iteration over potentially large data sets must be streamed or paged.
- Never use an unbounded list where the data size may scale with the library.
- Public methods document transactional, threading, and I/O behavior when non-obvious.

## 8. Error handling

- Do not catch `Exception` unless at a process, job, plugin, or UI boundary where it is logged and converted.
- Never use bare `except`.
- Expected failures use typed exceptions or result objects with stable error codes.
- Preserve exception chaining with `raise ... from ...`.
- Do not expose raw tracebacks to ordinary users.
- Cancellation is distinct from failure.
- Retry only failures classified as transient and only with bounded policy.
- Logging an exception does not by itself constitute handling it.

## 9. Logging

Structured logs include:

- timestamp;
- severity;
- subsystem;
- correlation ID;
- job ID where applicable;
- plugin ID/version where applicable;
- stable error code;
- sanitized context.

Rules:

- no image content or embedding vectors in logs;
- no secrets;
- avoid full user paths at normal levels where a path token or filename is enough;
- no duplicate logging at every layer;
- performance-sensitive loops use aggregated metrics, not per-item info logs.

## 10. Database coding rules

- SQL exists only in database infrastructure and migration modules.
- Use parameterized SQL exclusively.
- Application services own transaction boundaries through unit of work.
- Repositories do not call commit independently.
- No transaction remains open during filesystem copying, hashing, decoding, or inference.
- Every foreign key has an explicit delete policy.
- Every schema change has a migration and migration test.
- Large queries use keyset pagination.
- Performance-sensitive queries require query-plan tests or benchmark evidence.
- Database row models are not domain entities unless explicitly mapped.

## 11. Filesystem rules

- Original files are opened read-only.
- Writes use temporary files in the destination filesystem, flush, optional fsync according to durability class, then atomic replace where supported.
- Path comparisons use normalized Windows-aware keys while preserving display form.
- Never assume case sensitivity.
- Handle long paths through supported Windows APIs and packaging settings.
- Validate user-controlled export templates and paths.
- File deletion follows recorded intent and recovery rules.

## 12. Concurrency and threading

- Qt widgets and GUI objects are UI-thread only.
- Database connections are thread-confined.
- Torch model instances are owned by the AI worker/provider coordinator unless documented safe otherwise.
- Shared mutable state requires an explicit owner and synchronization strategy.
- Prefer message passing and immutable values.
- Every long-running operation supports progress and cancellation where meaningful.
- Do not block the UI thread with `sleep`, file I/O, database calls, futures waiting, or inference.
- Async, thread, and process boundaries must be visible in function or class documentation.

## 13. PySide6 rules

- Use Qt model/view for large collections.
- Do not create one widget per thumbnail.
- Signals carry stable IDs or immutable data, not repositories or database rows tied to a connection.
- Disconnect or lifetime-guard long-lived signal connections.
- Use parent ownership consistently for QObjects.
- Business logic belongs in application services or view models, not widget event handlers.
- UI text is translatable.
- Colors and spacing come from the design system or palette, not feature-local literals.

## 14. AI coding rules

- Model-specific code remains in provider adapters.
- Preprocessing is versioned and tested.
- Application boundaries do not expose Torch tensors.
- Inference runs record model, preprocessing, provider, precision, and parameters.
- Batch size is bounded and adaptive only through documented policy.
- CUDA out-of-memory errors trigger controlled cleanup and bounded retry.
- Raw model scores are not labeled probabilities without calibration.
- AI results never directly mutate confirmed metadata.

## 15. Plugin coding rules

Core code exposed to plugins must be in the public plugin API package. Internal symbols are not compatibility promises.

Plugin handlers:

- are idempotent for event delivery;
- use namespaced IDs;
- use approved storage services;
- do not modify originals;
- do not access core tables directly;
- submit long work through jobs;
- declare capabilities accurately.

## 16. Security and offline rules

- No general network library use outside update infrastructure and approved restricted update adapters.
- A CI/static check scans for unauthorized network imports in production packages.
- Downloaded packages require checksum verification and appropriate signature verification.
- External processes use argument arrays, never shell-concatenated user input.
- Deserialize only validated formats; arbitrary pickle loading is prohibited for untrusted artifacts.
- Model loading policy must account for unsafe serialization formats and trusted package sources.

## 17. Documentation

- Public APIs have docstrings describing purpose, parameters, return value, errors, thread behavior, and transactional behavior where relevant.
- Comments explain why, not restate what.
- Architectural decisions belong in the source-of-truth documents before code.
- User-visible behavior changes update documentation in the same change.
- No stale TODO markers in production code. Deferred work belongs in tracked planning with no incomplete code path.

## 18. Testing standard

Every module must compile. Tests are proportional to risk.

Required categories:

- domain and application unit tests;
- port/adapter contract tests;
- database migration tests;
- filesystem failure tests;
- job cancellation/recovery tests;
- plugin compatibility tests;
- AI regression and tolerance tests;
- GUI view-model tests;
- performance tests for hot paths.

Tests must be deterministic. Time, UUIDs, filesystem, and provider selection are injected where determinism matters.

Do not use real network access in tests except isolated update-transport tests against a local controlled server.

## 19. Performance standard

- Measure before optimizing, but design hot paths for scale from the beginning.
- Avoid N+1 database queries.
- Avoid repeated image decode and model preprocessing.
- Use bounded caches with metrics.
- Batch database and inference work.
- Use memory-mapped or streaming techniques only behind clear adapters and benchmarks.
- Performance regressions beyond agreed thresholds fail the relevant benchmark gate.

## 20. Dependencies

A new dependency requires review of:

- license;
- maintenance health;
- Windows and Python 3.11 support;
- offline packaging;
- binary size;
- startup impact;
- security history;
- API stability;
- replacement cost.

Prefer well-maintained focused dependencies. Do not reimplement complex standard functionality merely to avoid a justified dependency.

## 21. Git and change quality

- Changes are cohesive and reviewable.
- Commit messages describe intent.
- Generated files are clearly identified.
- Database migrations are never rewritten after release.
- Public API changes include compatibility notes.
- Refactoring is separated from behavior changes where practical.
- No drive-by architectural refactors without an approved design update.

## 22. Definition of acceptable production code

Production code is acceptable only when it:

- implements the complete approved behavior;
- has no placeholder or silent fallback that hides missing functionality;
- preserves documented invariants;
- is typed and test-covered according to risk;
- handles expected failure modes;
- is observable and cancellable where applicable;
- does not introduce unauthorized network access;
- performs acceptably at intended scale;
- keeps stable APIs coherent.
