## AI Review single-photograph workflow (0.15.2)

AI Review includes a **Current photograph only** toggle. **Accept & Reject Rest** accepts the selected taxonomy and rejects every remaining pending/deferred alternative for that photograph. **Reject Other Options** can be used after a normal acceptance.

# NatureAI Next — GUI Design

**Status:** Approved design baseline  
**Document version:** 0.1

## 1. GUI goals

The PySide6 interface must feel like a native, high-performance Windows desktop application for large photo libraries. It must remain responsive during import, indexing, thumbnail generation, and AI inference.

The GUI is a presentation layer. It consumes application services and observable read models; it does not contain persistence, filesystem, or inference logic.

## 2. Interaction principles

- Preserve context and selection during background refreshes.
- Prefer non-modal workflows; reserve modal dialogs for destructive confirmation and short configuration tasks.
- Support keyboard-first operation for rating, tagging, navigation, and review.
- Show progress without blocking unrelated work.
- Use optimistic visual updates only when rollback is defined.
- Expose AI provenance and uncertainty.
- Never hide failures; summarize them with actionable detail.
- Scale correctly on high-DPI displays and multi-monitor setups.

## 3. Application shell

The main window contains:

1. **Title and command area** — current library, global commands, search entry, activity indicator.
2. **Navigation rail** — Library, Imports, Collections, Taxonomy, AI Review, Jobs, and Settings.
3. **Workspace area** — central routed content.
4. **Inspector panel** — contextual metadata and actions.
5. **Status bar** — selection count, result count, active sort/filter, background status, and offline/update state.

Panels may be resized and selected panels may be hidden. Layout is persisted per library and validated against current screen geometry at startup.

## 4. Workspaces

### 4.1 Library workspace

Primary photo management view:

- virtualized thumbnail grid;
- optional compact list view;
- filter bar;
- sort controls;
- saved-search access;
- breadcrumb/context header;
- multi-selection;
- inspector integration.

Visible thumbnails load asynchronously. The view requests bounded pages through a query service using keyset pagination.

### 4.2 Viewer workspace

Single-image and comparison viewing:

- fit, 100%, and custom zoom;
- pan and smooth zoom;
- orientation-correct display;
- optional before/alternate comparison;
- metadata overlay;
- region-of-interest drawing and editing;
- next/previous navigation respecting current result order.

Full-resolution decoding is tiled or bounded where image size requires it. Viewer transitions never block on AI work.

### 4.3 Import workspace

Import flow:

1. choose sources and storage policy;
2. scan and summarize candidates;
3. review duplicate and conflict policy;
4. start resumable import job;
5. inspect successes, skips, and failures.

The import plan is saved before execution. Closing the window does not cancel the job unless explicitly requested.

### 4.4 AI Review workspace

- queue grouped by suggestion type and model;
- image/crop preview;
- ranked candidates;
- taxonomy context;
- score type and provenance;
- accept, reject, defer, and choose-other actions;
- batch review with safeguards;
- keyboard shortcuts;
- filters for model, group, score band, and status.

Batch acceptance requires consistent target fields and displays the number of affected assets.

### 4.5 Taxonomy workspace

- hierarchy browser;
- scientific and vernacular name search;
- synonyms and accepted-name relationships;
- regional status;
- source and release metadata;
- linked asset counts;
- user taxa and mapping tools.

Taxonomy browsing uses lazy child loading and cached read models.

### 4.6 Collections workspace

- manual collections;
- smart collections defined by the visual query builder;
- collection hierarchy or grouping;
- drag/drop manual membership;
- saved sort and view state.

### 4.7 Jobs workspace

- active, queued, completed, and failed jobs;
- progress and throughput;
- pause/cancel/retry where supported;
- per-item failure drill-down;
- technical details copy/export;
- resource use summary.

### 4.8 Settings workspace

Separates:

- application settings;
- library settings;
- AI and model settings;
- storage and cache settings;
- plugin management;
- update settings;
- diagnostics.

Changes show whether they apply immediately, require model reload, require library reopen, or require application restart.

## 5. Inspector design

Inspector sections:

- file and capture information;
- rating, pick state, and color label;
- title, caption, and notes;
- tags;
- observations and taxonomy;
- location;
- AI suggestions and provenance;
- history/audit summary.

Sections are collapsible. Multi-selection displays common values, mixed-state indicators, and batch-edit semantics.

Edits use a draft buffer. Committing creates one application command; cancelling restores the persisted state. Autosave may be used only for low-risk scalar fields and must preserve undo grouping.

## 6. Search UX

### 6.1 Global search

The search entry supports plain text and recognized field syntax. Suggestions are generated locally from tags, taxa, places, and saved searches.

### 6.2 Visual query builder

Users can build nested AND/OR/NOT groups using supported fields. The UI serializes the versioned query AST defined in `DATABASE.md`.

### 6.3 Similarity search

Accessible from an asset, crop, text prompt, or selection. The UI clearly displays the active model and allows structured filters to refine results.

## 7. View-model architecture

Presentation logic uses view models or presenters with:

- immutable state snapshots;
- explicit commands;
- loading, empty, success, partial-failure, and failure states;
- cancellation of obsolete requests;
- selection identity based on asset public IDs;
- no direct SQL or model-provider calls.

Qt models implement incremental loading and role-based data access. Large result sets are not materialized as Python object graphs.

## 8. Threading rules

- All QWidget and Qt GUI object access occurs on the UI thread.
- Application work executes through services and job dispatchers.
- Results return via queued signals or a dedicated UI dispatcher.
- Signal payloads use immutable IDs and data objects, not live database connections or Torch tensors.
- Obsolete request results are discarded using request generations or cancellation tokens.

## 9. Thumbnail grid performance

- Virtualized item creation; no QWidget per thumbnail.
- Size-tiered cached thumbnails.
- Priority queue based on viewport proximity.
- Request coalescing for duplicate thumbnail keys.
- Memory cache bounded by bytes.
- Disk cache keyed by source content hash, renderer version, orientation, and requested tier.
- Placeholder rendering uses lightweight native painting.
- Rapid scrolling cancels or deprioritizes distant work.

## 10. Commands, shortcuts, and undo

Central command registry provides:

- stable command IDs;
- labels and icons;
- enabled/checked state;
- default shortcuts;
- menu, toolbar, context menu, and command-palette integration;
- plugin command registration.

Metadata edits that can be safely reversed participate in an application-level undo stack. Undo stores semantic inverse commands or audit-based patches, not widget snapshots. File imports, model installation, taxonomy activation, purge, and exports are not assumed undoable; they use explicit recovery or confirmation flows.

## 11. Dialog and notification policy

- Toasts for transient success and non-critical information.
- Inline banners for workspace-scoped warnings.
- Job center for long operations.
- Modal confirmation only for destructive or security-sensitive actions.
- Error dialogs include a stable error code and “copy technical details” option.
- Repeated errors are grouped to avoid notification storms.

## 12. Accessibility

- Logical tab order.
- Accessible names, descriptions, and states.
- Keyboard alternatives for drag/drop.
- No meaning conveyed by color alone.
- Minimum practical hit targets.
- Respect Windows text scaling and contrast settings where Qt supports them.
- Screen-reader testing for primary workflows before stable release.

## 13. Localization

All UI strings use translation catalogs. Dates, numbers, units, and plural forms use locale-aware formatting. Scientific names preserve canonical formatting independent of locale.

No concatenated translatable sentence fragments are allowed.

## 14. Visual design system

A small internal design system defines:

- spacing scale;
- typography roles;
- icon sizes;
- elevation/border usage;
- semantic states;
- focus indicators;
- thumbnail selection and rating overlays.

The application supports system-aware light and dark themes. Theme resources are centralized; feature widgets do not hard-code colors.

## 15. Window and session state

Persisted state includes:

- window geometry and state;
- panel sizes and visibility;
- active workspace;
- library view mode and thumbnail size;
- last non-sensitive search context;
- column widths;
- optional viewer zoom policy.

State is schema-versioned and sanitized when monitors or DPI change.

## 16. GUI testing

- view-model unit tests;
- Qt model contract tests;
- keyboard navigation tests;
- high-DPI layout smoke tests;
- selection preservation tests;
- stale async result tests;
- thumbnail scrolling benchmarks;
- screenshot-based visual regression for controlled components where stable;
- end-to-end workflow tests late in the roadmap.

## 17. GUI decisions

### GUI-001: Model/view grid, not widget-per-item

Required for 100,000-asset scalability.

### GUI-002: Job center instead of blocking progress dialogs

Allows continued work and durable progress.

### GUI-003: Draft-and-commit inspector edits

Creates predictable transactions and undo behavior.

### GUI-004: Central command registry

Keeps shortcuts, menus, context actions, and plugins consistent.

### GUI-005: AI review is a dedicated workflow

Prevents suggestions from being mistaken for confirmed metadata.

## Persistent catalog derivatives — 0.11.0

Library grid thumbnails and larger catalog previews are rendered asynchronously and cached in separate library directories. Grid items display a standard file placeholder while work is pending, a warning icon when rendering fails, and support explicit retry. Widgets never open database connections and never write cache files directly.

## Implemented full-image viewer (0.11.3)

The Library workspace opens a modeless viewer from an explicit button or tile double-click. The viewer receives only catalog and preview service ports. Catalog detail and preview bytes are loaded on retained worker threads, and request generations reject stale results during rapid navigation. `QGraphicsView` provides bounded cursor-anchored zoom and drag panning. Fit, actual-size, First/Last, Previous/Next, mouse, and keyboard controls are available. The ordering is the bounded set currently materialized in the Library workspace; loading additional catalog pages expands that ordering.

## Library quick search — 0.11.5

The Library header contains a clearable quick-search field. Input is debounced for 300 ms and Enter can submit immediately. Search runs on a worker thread and displays a result count. Empty input restores normal Library paging. Requests carry monotonically increasing identities so an older result cannot replace a newer query. Filtered rows retain thumbnails, metadata editing, selection, and Viewer launch behavior.


## Structured Library filters — 0.11.6

The Library workspace exposes a structured-filter panel for minimum rating, color label, pick state, inclusive capture-date bounds, minimum pixel dimensions, exact tags, and confirmed taxonomy names. Filters and Quick Search are combined by the application search service into one validated structured query and execute on retained worker threads. The Qt layer never compiles SQL. Clearing filters restores ordinary catalog paging without changing source files or catalog metadata.

## Capture-date filtering — 0.11.7

The Library From/To controls submit inclusive ISO calendar dates. They match either authoritative UTC capture timestamps or normalized EXIF local capture-date text.

## Saved searches and collections

The Library workspace provides a Saved views and collections panel. Users can save the active Quick Search and structured filters, reopen or delete saved searches, create manual collections, add the current multi-selection, open collections as live Library views, and return to the full Library. All persistence operations execute off the Qt UI thread.

## Collection management (0.12.1)
The Library workspace distinguishes manual and smart collections. Users can create smart collections from the current query, rename collections, edit descriptions, delete collections, and remove selected members from manual collections.


## Core pane docking policy (0.12.9)

Navigation and Inspector are deterministic core panes. Navigation is docked left and Inspector right. They may be hidden and restored through the View menu, but are not floatable top-level windows. Qt dock-state blobs are not persisted; window geometry, workspace, inspector visibility, sorting, and thumbnail size remain session settings.

## AI Review desktop workspace (0.13.0)

The Navigation rail's AI Review entry opens the production review queue. The workspace contains model and prompt status, queue counts, review-state and confidence filters, bounded Load more paging, suggestion details, provenance, and Accept/Reject/Defer/Reverse actions. Keyboard commands remain A, R, D, Ctrl+Z, J, and K. AI evidence is never presented as confirmed metadata until accepted.


## AI Review generation controls (0.13.2)

AI Review provides **Generate selected**, progress, and cancellation controls. Selection originates in the Library workspace and is passed by stable asset public ID. Generation runs outside the Qt UI thread. NatureAI blocks application shutdown while generation is active to protect Qt object ownership and inference-run integrity.

## AI resources dialog

AI Review exposes **Manage local AI resources…**. The dialog selects local package files, validates trusted Ed25519 public keys, installs and activates resources, and explicitly builds taxonomy text embeddings. Operations display actionable errors and never download data automatically.

## Regional knowledge setup
Open AI Review → Manage local AI resources → Regional knowledge setup. Select a continent, optional countries, preferred languages, and whether worldwide fallback remains enabled.

## Regional knowledge acquisition
The Regional Knowledge dialog provides **Save and download regional knowledge**. Progress covers discovery, taxonomy retrieval, package signing/install, prompts, and embeddings. Paths and trusted keys are derived from the configured NatureAI model workspace.


## Observation History workspace (0.15.3)
The Observation History workspace groups confirmed species, chronological observations, and all linked evidence photographs. Evidence thumbnails open in the standard Viewer. AI Review can navigate directly to the selected taxon.


## Life Lists & Statistics

The Observation Intelligence area includes a projection-based dashboard with personal species totals, observation and evidence counts, country coverage, first observations for the current year, biological-group life lists, and the most frequently observed species. All values are derived from confirmed observations and update without a separate synchronization step.

## Conservation & Seasonality workspace

The workspace imports a source-attributed ecological-context CSV. Matching scientific names update local taxon context; unknown names are skipped. AI Review displays the installed context in a separate evidence section.
