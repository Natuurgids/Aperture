# NatureAI Next — Database Design

**Status:** Approved design baseline  
**Document version:** 0.1

## 1. Database role

SQLite is the authoritative store for catalog metadata, taxonomy references, AI provenance, user actions, job state, and cache manifests. Original photographs and large derivatives remain on the filesystem.

The schema is designed for at least 100,000 assets and should remain viable at 1,000,000 assets on the reference workstation without a fundamental redesign.

## 2. SQLite configuration

Each library uses one `library.sqlite3` database.

Required connection configuration:

- WAL journal mode;
- foreign keys enabled;
- busy timeout configured;
- synchronous mode `NORMAL` by default, configurable to `FULL` for maximum durability;
- temp storage in memory when safe;
- application-controlled page cache;
- explicit transactions;
- periodic passive checkpoints and controlled truncate checkpoints during maintenance.

Connections are thread-confined. A connection factory creates read-only or read-write connections according to use case.

## 3. Identity strategy

Most persisted entities use:

- `id INTEGER PRIMARY KEY` as an efficient internal key;
- `public_id TEXT NOT NULL UNIQUE` containing a locally generated UUID for stable external references.

Internal foreign keys use integer IDs. Public APIs, plugin events, exports, and logs use public IDs unless a contract explicitly states otherwise.

Content hashes use lowercase hexadecimal SHA-256. Fast preliminary fingerprints may assist import planning but never replace the canonical hash for duplicate identity.

## 4. Time representation

- Absolute timestamps are stored as integer microseconds since Unix epoch UTC.
- Capture time includes source timezone information and certainty fields.
- User-entered local times without a known timezone preserve the local wall time separately.
- Dates with incomplete precision are represented by explicit precision, not guessed values.

## 5. Schema migration

- Migrations are numbered, immutable, and applied in order.
- Each migration runs inside a transaction when SQLite permits.
- Destructive or long-running migrations create a verified pre-migration backup.
- The database records schema version, application version, start/end time, and migration checksum.
- Production downgrade migrations are not supported. Recovery uses a backup and compatible application version.
- Plugin schema changes use plugin-owned namespaced migrations and may not alter core tables.

## 6. Core schema groups

The following table definitions are logical contracts. Exact DDL may add indexes, checks, generated columns, and SQLite compatibility details without changing semantics.

### 6.1 Library and schema metadata

#### `library_info`

Single-row logical record:

- library public UUID;
- creation timestamp;
- current schema version;
- minimum compatible application version;
- display name;
- default locale;
- active taxonomy release IDs;
- integrity state.

#### `schema_migrations`

- migration number;
- name;
- checksum;
- applied timestamp;
- application version;
- execution duration.

### 6.2 Assets and files

#### `assets`

- internal and public identity;
- media type;
- lifecycle state (`active`, `trashed`, `purged`);
- primary file instance ID;
- capture time normalized fields;
- rating;
- color label;
- pick state;
- title;
- caption;
- user notes;
- created and modified timestamps;
- optimistic revision number.

#### `file_instances`

- asset ID;
- storage mode (`managed`, `referenced`, `derivative`);
- role (`original`, `alternate`, `sidecar`, `preview`, `thumbnail`, `export`);
- normalized path and case-folded path key;
- file size;
- modified time observed;
- canonical SHA-256;
- optional fast fingerprint;
- availability state;
- MIME type and format;
- import source path;
- verification timestamp;
- created and modified timestamps.

A unique constraint prevents duplicate active path keys. Hash indexes support duplicate lookup.

#### `image_properties`

One-to-one with an asset or file instance as defined by importer policy:

- pixel width and height;
- orientation;
- bit depth;
- color space;
- alpha presence;
- camera make and model;
- lens;
- exposure fields;
- original metadata snapshot reference.

#### `metadata_snapshots`

Stores compressed, size-bounded original metadata payloads or normalized key/value representations. Binary payload size limits prevent database abuse.

### 6.3 Tags and collections

#### `tags`

- public identity;
- canonical normalized name;
- display name;
- optional parent tag;
- optional color;
- created timestamp.

Tag name uniqueness is case-insensitive within a parent.

#### `asset_tags`

Many-to-many relation with source (`user`, `import`, `plugin`) and created timestamp.

#### `collections`

- identity;
- type (`manual`, `smart`);
- name and description;
- smart-query JSON and query schema version;
- sort mode;
- timestamps.

#### `collection_assets`

Manual membership with stable position key and added timestamp.

### 6.4 Geography

#### `locations`

Reusable place records:

- point latitude/longitude;
- optional altitude and accuracy;
- country code;
- administrative areas;
- locality;
- place name;
- source and confidence;
- optional geometry reference for future polygon support.

Coordinates are validated by checks. Geographic search uses an SQLite RTree virtual table keyed to location IDs for bounding-box queries.

#### `asset_locations`

Links an asset to a location with role (`capture`, `subject`, `user_defined`) and precedence.

### 6.5 Taxonomy

#### `taxonomy_sources`

- source identity and name;
- source version;
- package checksum;
- license metadata;
- installation and activation timestamps;
- active flag.

#### `taxa`

- source ID;
- source taxon identifier;
- stable concept public ID;
- scientific name;
- authorship;
- rank;
- parent taxon ID;
- accepted taxon ID for synonyms;
- status;
- kingdom and major group denormalizations for filtering;
- extinction flag where supplied.

The source identifier is unique within a taxonomy source. Hierarchy traversal uses parent indexes and a closure table.

#### `taxon_closure`

- ancestor taxon ID;
- descendant taxon ID;
- depth.

Rebuilt transactionally when a taxonomy package is activated.

#### `taxon_names`

- taxon ID;
- language tag;
- region code;
- name;
- name type;
- preferred flag;
- source.

#### `taxon_regions`

- taxon ID;
- region code or geographic unit;
- occurrence status;
- source.

#### `user_taxa`

Separate namespace for provisional or custom concepts. User taxa can later be mapped to an imported taxon without rewriting observation history.

### 6.6 Observations and annotations

#### `observations`

- identity;
- asset ID;
- confirmed taxon ID or user taxon ID, mutually constrained;
- observation type (`organism`, `habitat`, `landscape`, `unknown`);
- life stage, sex, count, behavior, and notes where applicable;
- confirmation state;
- source (`user`, `import`, `plugin`);
- region-of-interest ID;
- timestamps;
- revision.

An asset may contain multiple observations.

#### `regions_of_interest`

- asset ID;
- shape type;
- normalized coordinates encoded as validated JSON or dedicated columns;
- label;
- created source;
- timestamps.

Coordinates are normalized to the orientation-corrected image coordinate system.

### 6.7 AI models and inference

#### `model_packages`

- model identity and semantic version;
- model family;
- artifact checksum;
- manifest JSON;
- license metadata;
- install path token;
- installation state;
- installed timestamp.

#### `model_variants`

- package ID;
- variant identity;
- runtime (`torch`, `onnx`);
- precision;
- device requirements;
- preprocessing identity;
- embedding dimension;
- active flag.

#### `inference_runs`

- job ID;
- model variant ID;
- execution provider;
- parameter JSON;
- application version;
- started/completed timestamps;
- outcome and error code.

#### `embeddings`

- asset ID;
- model variant ID;
- preprocessing identity;
- crop/region ID if applicable;
- vector dimension;
- scalar type;
- normalized flag;
- compressed vector blob;
- vector checksum;
- created timestamp.

A unique constraint prevents duplicate current embeddings for the same asset/region/model/preprocessing combination.

#### `ai_suggestions`

- asset or observation target;
- inference run ID;
- suggestion type;
- candidate taxon or label;
- raw score;
- rank;
- optional calibrated score and calibration identity;
- explanation/provenance JSON;
- review state (`pending`, `accepted`, `rejected`, `superseded`);
- reviewed timestamp and user action reference.

Accepted suggestions create or update user-owned domain records through application services; the suggestion row remains as provenance.

### 6.8 Search

#### `asset_search_fts`

FTS5 virtual table containing normalized searchable text derived from:

- title, caption, and notes;
- tags;
- scientific and common names;
- place names;
- selected imported metadata.

Updates occur through outbox handlers, not ad hoc widget logic. A rebuild command verifies parity.

#### Saved query representation

Smart collection and saved-search queries are JSON abstract syntax trees with an explicit schema version. The query compiler permits only documented fields and operators.

### 6.9 Jobs and events

#### `jobs`

- public identity;
- type and payload version;
- payload JSON;
- state;
- priority;
- resource class;
- idempotency key;
- parent/dependency fields;
- progress current/total/unit/message;
- attempt count and retry time;
- timestamps;
- error code and diagnostic reference;
- result JSON.

#### `job_items`

Optional per-item state for large batch jobs, allowing isolated retries without enormous job payloads.

#### `event_outbox`

- event public ID;
- event type and schema version;
- aggregate public ID;
- payload JSON;
- created timestamp;
- dispatch state and attempt count.

#### `audit_log`

Records material user-visible changes:

- action identity;
- actor (`user`, `system`, plugin ID);
- action type;
- target identity;
- before/after summary or patch;
- timestamp;
- correlation ID.

Sensitive raw file metadata is not duplicated unnecessarily.

### 6.10 Plugins

#### `installed_plugins`

- plugin ID and version;
- manifest checksum;
- enabled state;
- compatibility status;
- granted capabilities;
- install timestamp;
- last load result.

#### Plugin-owned tables

Plugin tables must begin with `plugin_<normalized_plugin_id>__`. Plugins use core-provided migration services and cannot alter core tables or triggers.

## 7. Index strategy

Required relational indexes include:

- asset lifecycle, capture time, rating, and modified time;
- file path key, hash, and availability;
- observation asset and taxon;
- taxonomy parent, accepted-name, rank, and source identifier;
- tag normalized name;
- job state/priority/retry time;
- outbox dispatch state;
- embedding model and asset uniqueness.

Composite index order is determined from measured query plans. Every non-trivial query added to a performance-sensitive path must include an `EXPLAIN QUERY PLAN` test or benchmark evidence.

## 8. Vector index

Embedding blobs in SQLite are authoritative. Approximate nearest-neighbor indexes are stored under `indexes/vectors/` and are rebuildable.

Initial index adapter:

- HNSW-based local index where packaging is stable;
- one index per model variant and preprocessing identity;
- mapping between HNSW labels and asset/region IDs persisted in SQLite;
- atomic index generation followed by manifest swap;
- checksum and row-count validation at open;
- exact chunked NumPy fallback when the index is missing or invalid.

The fallback guarantees correctness, although it may be slower.

## 9. Concurrency and transactions

- UI reads use short-lived snapshots.
- Application commands use explicit unit-of-work transactions.
- Long filesystem or AI operations never hold a database transaction open.
- Jobs use prepare/execute/commit phases: reserve work, perform external work, then commit results.
- Optimistic revisions detect conflicting metadata edits.
- Bulk writes use bounded batches, normally 100–1,000 rows depending on payload size.

## 10. Deletion and retention

- Removing an asset initially moves it to application trash.
- Purge is explicit and records an audit event.
- Managed originals are deleted only during purge and only after database intent is durably recorded.
- Referenced originals are never deleted by catalog purge unless a separately designed feature is approved.
- Dependent derived artifacts are deleted asynchronously and remain rebuildable.

## 11. Backup and restore

A consistent backup includes:

1. SQLite online backup output;
2. `library.json`;
3. managed originals and application-owned sidecars;
4. optional derivatives and indexes, clearly marked as rebuildable;
5. taxonomy and model manifests sufficient to identify dependencies.

Backup validation checks database integrity, manifest checksums, and expected file counts. Restore never overwrites an existing library without explicit confirmation outside the design scope of automated operations.

## 12. Integrity maintenance

Maintenance commands include:

- SQLite quick and full integrity checks;
- foreign key checks;
- orphan file and derivative detection;
- hash verification sampling or full verification;
- FTS parity rebuild;
- taxonomy closure verification;
- vector index manifest verification;
- vacuum and analyze under controlled conditions.

## 13. Database decisions

### DB-001: Integer internal keys plus UUID public IDs

Balances SQLite performance with stable external identity.

### DB-002: Original and derived binaries outside SQLite

Avoids database bloat and simplifies media streaming and recovery.

### DB-003: AI suggestions are immutable provenance records

Review changes status and creates user domain data; it does not erase inference history.

### DB-004: Embeddings authoritative in SQLite, ANN index rebuildable

Prevents an opaque external index from becoming the only copy of model output.

### DB-005: Versioned query AST

Prevents saved searches from depending on schema-specific SQL.

## Resumable export journal (migration 011)

`export_plans` is the durable header for restart-safe export execution. It stores the immutable canonical plan JSON, destination, lifecycle state, completion metadata, manifest identity, and bounded terminal error text. Reusing a public plan identity with different canonical content is rejected.

`export_plan_items` stores deterministic output assignments and source identity before copying begins. Each row records source path, authoritative size and optional SHA-256, relative output path, stable item order, attempt count, lifecycle state, verified output size and SHA-256, and bounded error text. The unique plan/path constraint prevents two assets from publishing the same output name.

Only short state transitions use SQLite write transactions. File copying and hashing occur outside database transactions. On worker interruption, `running` items are reset to `pending`. A resumed execution validates every `succeeded` output by size and SHA-256; valid outputs are skipped and invalid outputs are returned to the retry path. Failed items are retried only on a subsequent explicit execution. The final manifest is produced only when every item is verified as succeeded.

## Migration 012 — resumable derivative exports

Migration 012 rebuilds the Milestone 10 export journal tables to widen `export_kind` from original-only plans to `original_files` and `derivatives` while preserving all existing plan and item rows. Derivative item rows add an immutable JSON metadata snapshot, rendered pixel dimensions, XMP path, XMP size, and XMP checksum. The rebuild is required because SQLite cannot alter an existing `CHECK` constraint in place.

## Migration 013 — regional knowledge
Adds `regional_profiles` and `regional_profile_countries`. Occurrence facts continue to live in `taxon_regions`; the profile only stores user priorities and display preferences.

## Migration 014: Observation Intelligence

`observation_assets` links one or more assets to a stable observation. Existing `observations.asset_id` remains as the legacy primary asset for compatibility; migration 014 backfills the join table and adds confirmed-taxon indexes.

## Migration 015 — Ecological context

`ecological_context` stores optional conservation status, seasonal months, migration status, habitats, and source attribution for installed taxa. The table is additive and does not alter taxonomy or observation records.
