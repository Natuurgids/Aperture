# Aperture Help System

Aperture includes its guides inside the desktop application. Open the **Help** menu to access Quick Start, the User Guide, AI Workspace Guide, Import Guide, Backup & Recovery, Updates, Health Center, Troubleshooting, release notes, Roadmap & Future Releases, and the keyboard shortcut reference.

## Context help

Press `F1` on any main screen. Aperture opens the most relevant bundled topic for that workspace. In AI Review, `F1` opens the AI guide; in Updates it opens the offline-update guide; in Health Check it opens the Health Center guide.

## Search

The Help browser searches topic titles and bundled Markdown content locally. No network connection is used.

## Keyboard shortcut reference

Press `Ctrl+/` or choose **Help → Keyboard Shortcuts…**. Shortcuts are grouped by screen, including the AI Review `J`/`K` navigation and `Shift+Enter` accept-and-continue command.


## Roadmap

Choose **Help → Roadmap & Future Releases** to review the approved Version 2–5 direction, intentional Version 1 limitations, and long-term library-compatibility principles. The roadmap is directional and does not promise delivery dates.
