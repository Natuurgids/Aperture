from pathlib import Path
from natureai_next.infrastructure.database.connection import SqliteConnectionFactory
from natureai_next.infrastructure.database.migrations import CORE_MIGRATIONS
from natureai_next.infrastructure.database.migrations.core import MigrationRunner


def test_ai_generation_schema_is_applied(tmp_path: Path):
    connection = SqliteConnectionFactory(tmp_path / 'library.sqlite3').connect()
    try:
        assert MigrationRunner(CORE_MIGRATIONS, '0.9.2').apply(connection) == len(CORE_MIGRATIONS)
        names = {row[0] for row in connection.execute("SELECT name FROM sqlite_master WHERE type='table'")}
        assert {'taxonomy_text_embeddings', 'near_duplicate_groups', 'near_duplicate_group_members'} <= names
        columns = {row[1] for row in connection.execute("PRAGMA table_info(taxonomy_text_embeddings)")}
        assert {'generation_identity', 'taxonomy_source_ids_json'} <= columns
    finally:
        connection.close()
