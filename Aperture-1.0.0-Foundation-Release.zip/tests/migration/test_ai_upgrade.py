from pathlib import Path
from natureai_next.infrastructure.database.connection import SqliteConnectionFactory
from natureai_next.infrastructure.database.migrations import CORE_MIGRATIONS
from natureai_next.infrastructure.database.migrations.core import MigrationRunner


def test_ai_migration_adds_provenance_and_index_tables(tmp_path:Path)->None:
    c=SqliteConnectionFactory(tmp_path/'upgrade.sqlite3').connect();MigrationRunner(CORE_MIGRATIONS[:-1],'0.7.0').apply(c);MigrationRunner(CORE_MIGRATIONS,'0.8.0').apply(c)
    assert c.execute("SELECT COUNT(*) FROM schema_migrations").fetchone()[0]==len(CORE_MIGRATIONS)
    columns={row[1] for row in c.execute('PRAGMA table_info(embeddings)')};assert {'execution_provider','precision','application_version','validity_state'}<=columns
    assert c.execute("SELECT name FROM sqlite_master WHERE name='vector_index_generations'").fetchone() is not None;c.close()
