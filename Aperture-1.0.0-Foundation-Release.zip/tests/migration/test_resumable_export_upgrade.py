from pathlib import Path

from natureai_next.infrastructure.database.connection import SqliteConnectionFactory
from natureai_next.infrastructure.database.migrations import CORE_MIGRATIONS, MigrationRunner


def test_resumable_export_schema_is_applied(tmp_path: Path) -> None:
    connection = SqliteConnectionFactory(tmp_path / "library.sqlite3").connect()
    try:
        assert MigrationRunner(CORE_MIGRATIONS, "0.10.2").apply(connection) == len(CORE_MIGRATIONS)
        tables = {row[0] for row in connection.execute("SELECT name FROM sqlite_master WHERE type='table'")}
        assert {"export_plans", "export_plan_items"} <= tables
        columns = {row[1] for row in connection.execute("PRAGMA table_info(export_plan_items)")}
        assert {"relative_output_path", "attempt_count", "output_sha256", "error_text"} <= columns
    finally:
        connection.close()
