from pathlib import Path

from natureai_next.infrastructure.database.connection import SqliteConnectionFactory
from natureai_next.infrastructure.database.migrations import CORE_MIGRATIONS, MigrationRunner


def test_resumable_derivative_export_columns_are_applied(tmp_path: Path) -> None:
    connection = SqliteConnectionFactory(tmp_path / "library.sqlite3").connect()
    try:
        assert MigrationRunner(CORE_MIGRATIONS, "0.10.4").apply(connection) == len(CORE_MIGRATIONS)
        columns = {row[1] for row in connection.execute("PRAGMA table_info(export_plan_items)")}
        assert {
            "item_json",
            "output_pixel_width",
            "output_pixel_height",
            "xmp_relative_path",
            "xmp_size_bytes",
            "xmp_sha256",
        } <= columns
    finally:
        connection.close()
