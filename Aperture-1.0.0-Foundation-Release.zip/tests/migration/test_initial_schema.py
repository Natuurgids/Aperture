from pathlib import Path
import sqlite3
import pytest
from natureai_next.infrastructure.database.connection import SqliteConnectionFactory
from natureai_next.infrastructure.database.migrations import CORE_MIGRATIONS,MigrationError,MigrationRunner

def test_initial_schema_and_checksums(tmp_path:Path)->None:
    c=SqliteConnectionFactory(tmp_path/'db.sqlite3').connect()
    try:
        assert MigrationRunner(CORE_MIGRATIONS,'0.1.0').apply(c)==len(CORE_MIGRATIONS)
        tables={r[0] for r in c.execute("SELECT name FROM sqlite_master WHERE type IN ('table','view')")}
        assert {'library_info','assets','file_instances','tags','collections','jobs','event_outbox','audit_log','location_rtree'}<=tables
        assert c.execute('PRAGMA foreign_keys').fetchone()[0]==1
        assert c.execute('PRAGMA journal_mode').fetchone()[0]=='wal'
    finally:c.close()

def test_changed_applied_migration_is_rejected(tmp_path:Path)->None:
    c=SqliteConnectionFactory(tmp_path/'db.sqlite3').connect()
    try:
        MigrationRunner(CORE_MIGRATIONS,'0.1.0').apply(c)
        c.execute("UPDATE schema_migrations SET checksum='bad' WHERE migration_number=1")
        with pytest.raises(MigrationError):MigrationRunner(CORE_MIGRATIONS,'0.1.0').apply(c)
    finally:c.close()
