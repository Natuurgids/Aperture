from pathlib import Path
from natureai_next.infrastructure.database.connection import SqliteConnectionFactory
from natureai_next.infrastructure.database.migrations import CORE_MIGRATIONS,MigrationRunner

def test_milestone_three_database_upgrades_with_import_tables(tmp_path:Path):
    connection=SqliteConnectionFactory(tmp_path/'upgrade.sqlite3').connect()
    try:
        MigrationRunner(CORE_MIGRATIONS[:2],'0.3.0').apply(connection)
        MigrationRunner(CORE_MIGRATIONS,'0.4.0').apply(connection)
        names={r[0] for r in connection.execute("SELECT name FROM sqlite_master WHERE type='table'")}
        assert {'import_plans','import_plan_items','purge_intents'} <= names
        assert connection.execute('SELECT count(*) FROM schema_migrations').fetchone()[0]==len(CORE_MIGRATIONS)
    finally:connection.close()
