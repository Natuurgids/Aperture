from pathlib import Path
from natureai_next.infrastructure.database.connection import SqliteConnectionFactory
from natureai_next.infrastructure.database.migrations import CORE_MIGRATIONS,MigrationRunner


def test_milestone_two_database_upgrades_in_place(tmp_path:Path)->None:
    connection=SqliteConnectionFactory(tmp_path/'upgrade.sqlite3').connect()
    try:
        MigrationRunner(CORE_MIGRATIONS[:1],'0.2.0').apply(connection)
        connection.execute("INSERT INTO jobs(public_id,job_type,payload_version,payload_json,state,priority,resource_class,created_at_us,modified_at_us) VALUES('j','x',1,'{}','queued',0,'io',1,1)")
        MigrationRunner(CORE_MIGRATIONS,'0.3.0').apply(connection)
        row=connection.execute("SELECT cancellation_requested,pause_requested FROM jobs WHERE public_id='j'").fetchone()
        assert tuple(row)==(0,0)
        assert connection.execute("SELECT count(*) FROM schema_migrations").fetchone()[0]==len(CORE_MIGRATIONS)
        assert connection.execute("SELECT name FROM sqlite_master WHERE name='derivative_cache_entries'").fetchone() is not None
    finally:connection.close()
