from pathlib import Path
from natureai_next.infrastructure.database.connection import SqliteConnectionFactory
from natureai_next.infrastructure.database.migrations import CORE_MIGRATIONS, MigrationRunner

def test_milestone_five_database_upgrades_with_search_schema(tmp_path:Path):
    c=SqliteConnectionFactory(tmp_path/'upgrade.sqlite3').connect()
    try:
        MigrationRunner(CORE_MIGRATIONS[:3],'0.5.0').apply(c)
        c.execute("INSERT INTO assets(public_id,media_type,lifecycle_state,title,created_at_us,modified_at_us) VALUES('a1','image','active','Grebe',1,1)");c.commit()
        MigrationRunner(CORE_MIGRATIONS,'0.6.0').apply(c)
        names={r[0] for r in c.execute("SELECT name FROM sqlite_master")}
        assert {'saved_searches','asset_search_fts'} <= names
        assert c.execute("SELECT title FROM asset_search_fts WHERE rowid=1").fetchone()[0]=='Grebe'
        assert c.execute('SELECT count(*) FROM schema_migrations').fetchone()[0]==len(CORE_MIGRATIONS)
    finally:c.close()
