from __future__ import annotations

import json
from pathlib import Path

from natureai_next.bootstrap.resource_cli import main


def test_key_generation_and_model_package_round_trip(tmp_path: Path, capsys) -> None:
    private_key = tmp_path / "private.pem"
    trusted = tmp_path / "trusted.json"
    assert main(["key-generate", "--key-id", "local", "--private-key", str(private_key), "--trusted-keys", str(trusted)]) == 0
    artifact = tmp_path / "checkpoint.pt"
    artifact.write_bytes(b"fixture")
    config = tmp_path / "model.json"
    config.write_text(json.dumps({
        "package_id": "fixture-model-1", "model_identity": "bioclip", "semantic_version": "1.0.0",
        "model_family": "bioclip", "upstream_source": "fixture", "license_name": "fixture",
        "attribution_text": "fixture", "minimum_application_version": "0.13.5", "signing_key_id": "local",
        "artifact_files": {"model.pt": "checkpoint.pt"},
        "variants": [{"identity": "cpu", "runtime": "torch", "precision": "fp32", "providers": ["cpu"],
            "preprocessing_identity": "prep", "embedding_dimension": 3, "input_size": 32,
            "normalized_output": True, "artifact_path": "model.pt"}],
    }), encoding="utf-8")
    package = tmp_path / "model.zip"
    assert main(["model-build", "--config", str(config), "--private-key", str(private_key), "--output", str(package)]) == 0
    assert main(["model-verify", str(package), "--trusted-keys", str(trusted)]) == 0
    output = capsys.readouterr().out
    assert '"ok": true' in output
    assert '"model_identity": "bioclip"' in output


def test_prompt_verify_rejects_wrong_model_family(tmp_path: Path, capsys) -> None:
    manifest = tmp_path / "prompts.json"
    manifest.write_text(json.dumps({
        "schema_version": 1, "identity": "fixture", "semantic_version": "1.0.0",
        "model_family": "bioclip", "minimum_application_version": "0.13.5",
        "prompts": [{"label": "bird", "text": "a bird", "taxon_public_id": "t1", "broad_group": None}],
    }), encoding="utf-8")
    assert main(["prompt-verify", str(manifest), "--model-family", "other"]) == 2
    assert "incompatible" in capsys.readouterr().out


def test_workspace_init_uses_absolute_resource_paths(tmp_path: Path, capsys) -> None:
    root = tmp_path / "NatureAI Models"
    assert main(["workspace-init", "--root", str(root), "--key-id", "local"]) == 0
    config = json.loads((root / "build" / "model-package.json").read_text(encoding="utf-8"))
    assert config["artifact_files"]["model.pt"] == str((root / "source" / "model" / "bioclip-checkpoint.pt").resolve())
    assert (root / "BUILD_COMMANDS.ps1").is_file()
    assert "workspace-init" not in (root / "BUILD_COMMANDS.ps1").read_text(encoding="utf-8")
    assert '"ok": true' in capsys.readouterr().out
