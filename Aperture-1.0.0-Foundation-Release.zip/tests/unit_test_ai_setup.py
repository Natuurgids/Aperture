from pathlib import Path

from natureai_next.application.ai_setup import BioCLIPQuickSetupService, BioCLIPSetupRequest


class _Resources:
    def __init__(self) -> None:
        self.installed = []

    def install_model(self, package: Path, trusted: Path) -> str:
        assert package.is_file()
        assert trusted.is_file()
        self.installed.append((package, trusted))
        return "model-public-id"


def test_quick_setup_builds_files_without_manual_manifests(tmp_path: Path) -> None:
    checkpoint = tmp_path / "checkpoint.bin"
    checkpoint.write_bytes(b"fixture model")
    resources = _Resources()
    service = BioCLIPQuickSetupService(resources)  # type: ignore[arg-type]
    result = service.run(BioCLIPSetupRequest(workspace=tmp_path / "workspace", checkpoint=checkpoint))
    assert result.model_public_id == "model-public-id"
    assert result.model_package.is_file()
    assert result.trusted_keys.is_file()
    assert (tmp_path / "workspace" / "signing" / "natureai-local-private.pem").is_file()
    assert len(resources.installed) == 1
