from pathlib import Path

from natureai_next.application.regional_acquisition import RegionalKnowledgeAcquisitionService
from natureai_next.domain.regional import RegionalCountry, RegionalProfile


class _Client:
    def species_keys(self, *, country=None, continent=None, maximum=20000):
        return (1, 2) if country == "NL" else (2, 3)
    def species(self, key):
        return {
            "key": key,
            "scientificName": f"Species {key}",
            "rank": "SPECIES",
            "taxonomicStatus": "ACCEPTED",
            "kingdom": "Animalia",
            "class": "Aves",
        }


class _Resources:
    def __init__(self): self.taxonomy=None; self.prompt=None
    def install_taxonomy(self, package_path, trusted_keys_path):
        assert package_path.is_file(); assert trusted_keys_path.is_file(); self.taxonomy=package_path
        return "taxonomy-source"
    def install_prompt_set(self, manifest_path, *, model_family=None):
        assert manifest_path.is_file(); assert model_family == "bioclip"; self.prompt=manifest_path
        return "prompt-set"
    def build_taxonomy_embeddings(self):
        raise RuntimeError("No active model variant is available.")


def test_regional_acquisition_builds_and_installs_signed_resources(tmp_path: Path):
    resources=_Resources()
    service=RegionalKnowledgeAcquisitionService(resources,workspace=tmp_path,client=_Client())
    profile=RegionalProfile("EU",(RegionalCountry("NL","EU","Netherlands",0),),True,("en","scientific"))
    result=service.acquire(profile)
    assert result.taxa_count == 3
    assert result.region_record_count == 4
    assert result.package_path.is_file()
    assert result.prompt_manifest.is_file()
    assert result.embedding_counts is None


class _CountingClient(_Client):
    def __init__(self):
        self.details = 0
    def species(self, key):
        self.details += 1
        return super().species(key)


def test_regional_acquisition_reuses_downloaded_taxonomy_details(tmp_path: Path):
    resources = _Resources()
    client = _CountingClient()
    service = RegionalKnowledgeAcquisitionService(resources, workspace=tmp_path, client=client)
    profile = RegionalProfile("EU", (RegionalCountry("NL", "EU", "Netherlands", 0),), True, ("en", "scientific"))
    first = service.acquire(profile)
    assert first.taxa_count == 3
    downloaded = client.details
    second = service.acquire(profile)
    assert second.taxa_count == 3
    assert client.details == downloaded
    state = service._job_root(profile) / "state.json"
    assert state.is_file()
    assert '"stage": "completed"' in state.read_text(encoding="utf-8")
