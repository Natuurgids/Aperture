from __future__ import annotations

import hashlib
from datetime import datetime, timezone
from pathlib import Path
from uuid import UUID

import pytest

from natureai_next.application.exporting import ResumableOriginalFileExportService
from natureai_next.application.library_service import LibraryService
from natureai_next.domain.catalog import Asset, AssetLifecycle, AvailabilityState, FileInstance, FileRole, MediaType, StorageMode
from natureai_next.domain.exporting import CollisionPolicy, ExportItemState, ExportSelection, OriginalFileExportPlan
from natureai_next.infrastructure.database.export_plans import SqliteResumableOriginalExportStore
from natureai_next.infrastructure.database.exporting import SqliteExportCatalogReader
from natureai_next.infrastructure.database.unit_of_work import SqliteUnitOfWork
from natureai_next.infrastructure.exporting.files import LocalOriginalFileExportWriter


class Clock:
    def now_utc(self) -> datetime:
        return datetime(2026, 7, 13, tzinfo=timezone.utc)


class Ids:
    value = 900

    def new_uuid(self) -> UUID:
        self.value += 1
        return UUID(int=self.value)


class CountingWriter(LocalOriginalFileExportWriter):
    def __init__(self) -> None:
        self.written: list[str] = []

    def write_item(self, **kwargs):  # type: ignore[no-untyped-def]
        item = kwargs["item"]
        self.written.append(item.asset_public_id)
        return super().write_item(**kwargs)


def _library(tmp_path: Path):
    opened = LibraryService(Clock(), Ids()).create(tmp_path / "Library", display_name="Exports")
    first = tmp_path / "first.jpg"
    second = tmp_path / "second.jpg"
    first.write_bytes(b"first-original")
    with SqliteUnitOfWork(opened.connection_factory) as uow:
        for index, (asset_id, file_id, source, payload) in enumerate(
            (("asset-1", "file-1", first, b"first-original"), ("asset-2", "file-2", second, b"second-original")),
            start=1,
        ):
            asset = uow.assets.add(Asset(asset_id, MediaType.IMAGE, AssetLifecycle.ACTIVE, index, index, title=f"Bird {index}"))
            file = uow.files.add(
                FileInstance(
                    file_id,
                    asset.id or 0,
                    StorageMode.REFERENCED,
                    FileRole.ORIGINAL,
                    str(source),
                    str(source).casefold(),
                    len(payload),
                    index,
                    hashlib.sha256(payload).hexdigest(),
                    AvailabilityState.AVAILABLE,
                    "image/jpeg",
                    "JPEG",
                    index,
                    index,
                )
            )
            assert uow.connection is not None
            uow.connection.execute("UPDATE assets SET primary_file_instance_id=? WHERE id=?", (file.id, asset.id))
        uow.commit()
    return opened, first, second


def test_resumable_export_retries_only_failed_items(tmp_path: Path) -> None:
    opened, _first, second = _library(tmp_path)
    now = iter(range(1_000, 2_000)).__next__
    writer = CountingWriter()
    store = SqliteResumableOriginalExportStore(opened.connection_factory)
    service = ResumableOriginalFileExportService(SqliteExportCatalogReader(opened.connection_factory), writer, store)
    plan = OriginalFileExportPlan(
        "resumable-1",
        tmp_path / "output",
        ExportSelection(include_all_active=True),
        naming_template="{asset_id}{original_ext}",
        collision_policy=CollisionPolicy.REPLACE,
        created_at_us=900,
    )
    try:
        with pytest.raises(RuntimeError, match="1 original export item"):
            service.execute(plan, now_us=now)
        assert writer.written == ["asset-1", "asset-2"]
        items = store.list_items(plan.public_id)
        assert [item.state for item in items] == [ExportItemState.SUCCEEDED, ExportItemState.FAILED]
        first_output = plan.destination_directory / "asset-1.jpg"
        first_mtime = first_output.stat().st_mtime_ns

        second.write_bytes(b"second-original")
        writer.written.clear()
        result = service.execute(plan, now_us=now)
        assert writer.written == ["asset-2"]
        assert result.asset_count == 2
        assert first_output.stat().st_mtime_ns == first_mtime
        assert all(item.state is ExportItemState.SUCCEEDED for item in store.list_items(plan.public_id))
        assert result.manifest_path is not None and result.manifest_path.is_file()
    finally:
        opened.close()


def test_invalid_completed_output_is_rebuilt_on_resume(tmp_path: Path) -> None:
    opened, _first, second = _library(tmp_path)
    second.write_bytes(b"second-original")
    now = iter(range(3_000, 4_000)).__next__
    writer = CountingWriter()
    store = SqliteResumableOriginalExportStore(opened.connection_factory)
    service = ResumableOriginalFileExportService(SqliteExportCatalogReader(opened.connection_factory), writer, store)
    plan = OriginalFileExportPlan(
        "resumable-2",
        tmp_path / "output",
        ExportSelection(include_all_active=True),
        naming_template="{asset_id}{original_ext}",
        collision_policy=CollisionPolicy.REPLACE,
        include_manifest=False,
    )
    try:
        service.execute(plan, now_us=now)
        (plan.destination_directory / "asset-1.jpg").write_bytes(b"corrupt")
        writer.written.clear()
        service.execute(plan, now_us=now)
        assert writer.written == ["asset-1"]
        assert (plan.destination_directory / "asset-1.jpg").read_bytes() == b"first-original"
    finally:
        opened.close()


def test_running_items_are_recovered_after_interruption(tmp_path: Path) -> None:
    opened, _first, second = _library(tmp_path)
    second.write_bytes(b"second-original")
    store = SqliteResumableOriginalExportStore(opened.connection_factory)
    writer = LocalOriginalFileExportWriter()
    plan = OriginalFileExportPlan("resumable-3", tmp_path / "output", ExportSelection(include_all_active=True))
    try:
        records = SqliteExportCatalogReader(opened.connection_factory).read_primary_files(None)
        store.prepare(plan=plan, items=writer.assign_items(plan=plan, records=records), now_us=1)
        claimed = store.claim_next_item(plan.public_id, 2)
        assert claimed is not None and claimed.state is ExportItemState.RUNNING
        assert store.recover_running_items(plan.public_id, 3) == 1
        assert store.list_items(plan.public_id)[0].state is ExportItemState.PENDING
    finally:
        opened.close()
