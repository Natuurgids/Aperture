from pathlib import Path
from natureai_next.domain.catalog import Asset,AssetLifecycle,AvailabilityState,Collection,FileInstance,FileRole,MediaType,StorageMode,Tag
from natureai_next.domain.events import AuditEntry,OutboxEvent
from natureai_next.domain.jobs import JobRecord,JobState
from natureai_next.infrastructure.database.connection import SqliteConnectionFactory
from natureai_next.infrastructure.database.migrations import CORE_MIGRATIONS,MigrationRunner
from natureai_next.infrastructure.database.unit_of_work import SqliteUnitOfWork

def test_repository_set_commits_atomically(tmp_path:Path)->None:
    f=SqliteConnectionFactory(tmp_path/'db.sqlite3');c=f.connect();MigrationRunner(CORE_MIGRATIONS,'0.1').apply(c);c.execute("INSERT INTO library_info VALUES(1,'lib',1,1,'0.1','x','en','[]','clean')");c.close()
    with SqliteUnitOfWork(f) as u:
        a=u.assets.add(Asset('a',MediaType.IMAGE,AssetLifecycle.ACTIVE,1,1))
        fi=u.files.add(FileInstance('f',a.id or 0,StorageMode.MANAGED,FileRole.ORIGINAL,'C:/a.jpg','c:/a.jpg',10,1,'a'*64,AvailabilityState.AVAILABLE,'image/jpeg','JPEG',1,1))
        tag=u.tags.add(Tag('t','bird','Bird',1));u.tags.attach(asset_id=a.id or 0,tag_id=tag.id or 0,source='user',created_at_us=1)
        coll=u.collections.add(Collection('c','manual','Favorites',None,None,None,'manual',1,1));u.collections.add_asset(collection_id=coll.id or 0,asset_id=a.id or 0,position_key='a',added_at_us=1)
        u.jobs.add(JobRecord('j','scan',1,'{}',JobState.QUEUED,0,'io',1,1))
        u.outbox.add(OutboxEvent('e','asset.created',1,'a','{}',1));u.audit.add(AuditEntry('au','user','asset.create','a',None,'{}',1,'corr'));u.commit()
    read=f.connect(read_only=True)
    try:
        assert read.execute('SELECT count(*) FROM assets').fetchone()[0]==1
        assert read.execute('SELECT count(*) FROM event_outbox').fetchone()[0]==1
        assert read.execute('SELECT count(*) FROM audit_log').fetchone()[0]==1
    finally:read.close()
