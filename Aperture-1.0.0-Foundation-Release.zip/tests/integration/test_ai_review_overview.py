from pathlib import Path

from natureai_next.application.ai_review import SuggestionService
from natureai_next.application.library_service import LibraryService
from natureai_next.infrastructure.database.ai_review import SqliteSuggestionStore
from natureai_next.infrastructure.diagnostics.system_services import SystemClock, SystemUuidGenerator


def test_ai_review_overview_reports_model_prompt_run_and_queue_counts(tmp_path: Path) -> None:
    opened = LibraryService(SystemClock(), SystemUuidGenerator()).create(
        tmp_path / "library", display_name="AI overview"
    )
    try:
        connection = opened.connection_factory.connect()
        connection.execute(
            "INSERT INTO assets(public_id,media_type,lifecycle_state,created_at_us,modified_at_us) "
            "VALUES('asset-1','image','active',1,1)"
        )
        connection.execute(
            "INSERT INTO model_packages(public_id,model_identity,semantic_version,model_family,"
            "artifact_checksum,manifest_json,license_json,install_path_token,installation_state,"
            "installed_at_us,activated_at_us,active) "
            "VALUES('pkg','bioclip','2.0.0','bioclip','x','{}','{}','models/pkg','installed',1,2,1)"
        )
        package_id = connection.execute("SELECT id FROM model_packages WHERE public_id='pkg'").fetchone()[0]
        connection.execute(
            "INSERT INTO model_variants(public_id,package_id,variant_identity,runtime,precision,"
            "device_requirements_json,preprocessing_identity,embedding_dimension,active) "
            "VALUES('variant',?,'vit-b-16','torch','fp16','{}','prep',512,1)",
            (package_id,),
        )
        variant_id = connection.execute("SELECT id FROM model_variants WHERE public_id='variant'").fetchone()[0]
        connection.execute(
            "INSERT INTO prompt_sets(public_id,identity,semantic_version,model_family,checksum,"
            "manifest_json,active,installed_at_us) "
            "VALUES('prompts','europe-wildlife','1.0.0','bioclip','xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx','{}',1,2)"
        )
        connection.execute(
            "INSERT INTO inference_runs(public_id,model_variant_id,execution_provider,parameter_json,"
            "application_version,started_at_us,outcome,precision,completed_item_count,failed_item_count) "
            "VALUES('run',?,'torch:cuda','{}','0.13.0',3,'completed_with_errors','fp16',9,1)",
            (variant_id,),
        )
        run_id = connection.execute("SELECT id FROM inference_runs WHERE public_id='run'").fetchone()[0]
        connection.execute(
            "INSERT INTO ai_suggestions(public_id,asset_id,inference_run_id,suggestion_type,candidate_label,"
            "raw_score,rank,score_type,confidence_band,geographic_context_json,provenance_json,review_state,created_at_us) "
            "VALUES('s1',1,?,'taxon','Robin',0.8,1,'cosine','high','{}','{}','pending',4)",
            (run_id,),
        )
        connection.commit()
        connection.close()

        overview = SuggestionService(SqliteSuggestionStore(opened.connection_factory)).overview()
        assert overview.active_model_identity == "bioclip"
        assert overview.active_model_version == "2.0.0"
        assert overview.active_variant_identity == "vit-b-16"
        assert overview.active_prompt_set == "europe-wildlife 1.0.0"
        assert overview.count("pending") == 1
        assert overview.latest_run_outcome == "completed_with_errors"
        assert overview.latest_run_completed == 9
        assert overview.latest_run_failed == 1
    finally:
        opened.close()
