import json,time
from datetime import datetime,timezone
from pathlib import Path
from uuid import uuid4
from natureai_next.application.jobs import JobService,SubmitJob
from natureai_next.application.library_service import LibraryService
from natureai_next.domain.jobs import JobRecord,JobState,ResourceClass
from natureai_next.infrastructure.database.unit_of_work import SqliteUnitOfWork
from natureai_next.jobs.engine import JobEngine

class Clock:
    def now_utc(self):return datetime.now(timezone.utc)
class Ids:
    def new_uuid(self):return uuid4()
class Handler:
    job_type='test.ok';resource_class='io'
    def execute(self,context):context.report_progress(1,1,'item','done');return {'ok':True}
class Failing:
    job_type='test.fail';resource_class='io'
    def execute(self,context):raise ValueError('bad item')

def setup(tmp_path:Path):
    opened=LibraryService(Clock(),Ids()).create(tmp_path/'lib',display_name='Jobs')
    return opened,JobService(opened.connection_factory,Clock(),Ids())

def test_job_claim_execute_and_idempotency(tmp_path:Path):
    opened,service=setup(tmp_path)
    try:
        cmd=SubmitJob('test.ok',{'x':1},ResourceClass.IO,idempotency_key='same')
        first=service.submit(cmd);assert service.submit(cmd).public_id==first.public_id
        engine=JobEngine(opened.connection_factory,[Handler()],io_workers=0,cpu_workers=0)
        assert engine.run_once(ResourceClass.IO)
        done=service.recent()[0]
        assert done.state==JobState.SUCCEEDED and done.progress_current==1 and json.loads(done.result_json)=={'ok':True}
    finally:opened.close()

def test_failure_is_per_job_and_next_job_runs(tmp_path:Path):
    opened,service=setup(tmp_path)
    try:
        failed=service.submit(SubmitJob('test.fail',{},ResourceClass.IO,priority=10));ok=service.submit(SubmitJob('test.ok',{},ResourceClass.IO))
        engine=JobEngine(opened.connection_factory,[Handler(),Failing()],io_workers=0,cpu_workers=0)
        assert engine.run_once(ResourceClass.IO);assert engine.run_once(ResourceClass.IO)
        states={j.public_id:j.state for j in service.recent()}
        assert states[failed.public_id]==JobState.FAILED and states[ok.public_id]==JobState.SUCCEEDED
    finally:opened.close()

def test_expired_running_job_recovers_and_requeues(tmp_path:Path):
    opened,service=setup(tmp_path)
    try:
        job=service.submit(SubmitJob('test.ok',{},ResourceClass.IO))
        with SqliteUnitOfWork(opened.connection_factory) as uow:
            claimed=uow.jobs.claim_next(resource_class='io',worker_id='dead',now_us=1,lease_until_us=2);uow.commit()
        engine=JobEngine(opened.connection_factory,[Handler()],io_workers=0,cpu_workers=0)
        assert engine.recover_interrupted()==1
        assert service.recent()[0].state==JobState.QUEUED
    finally:opened.close()

def test_pause_resume_cancel_commands(tmp_path:Path):
    opened,service=setup(tmp_path)
    try:
        job=service.submit(SubmitJob('test.ok',{},ResourceClass.IO));assert service.pause(job.public_id);assert service.recent()[0].state==JobState.PAUSED
        assert service.resume(job.public_id);assert service.cancel(job.public_id);assert service.recent()[0].state==JobState.CANCELLED
    finally:opened.close()
