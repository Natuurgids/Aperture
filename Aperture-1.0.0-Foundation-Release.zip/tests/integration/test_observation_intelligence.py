from pathlib import Path

from natureai_next.application.library_service import LibraryService
from natureai_next.application.observation_intelligence import ObservationIntelligenceService
from natureai_next.domain.ai import ConfidenceBand, SuggestionCandidate
from natureai_next.infrastructure.database.ai_review import SqliteSuggestionStore
from natureai_next.infrastructure.database.observation_intelligence import SqliteObservationIntelligenceAdapter
from natureai_next.infrastructure.diagnostics.system_services import SystemClock, SystemUuidGenerator


def _seed(opened):
    c = opened.connection_factory.connect()
    c.execute("INSERT INTO assets(public_id,media_type,lifecycle_state,created_at_us,modified_at_us) VALUES('asset-1','image','active',1,1)")
    c.execute("INSERT INTO assets(public_id,media_type,lifecycle_state,created_at_us,modified_at_us) VALUES('asset-2','image','active',2,2)")
    c.execute("INSERT INTO taxonomy_sources(public_id,name,source_version,package_checksum,license_json,installed_at_us,active,attribution_text,manifest_json) VALUES('source-1','Fixture','1.0','checksum','{}',1,1,'Fixture','{}')")
    sid = c.execute("SELECT id FROM taxonomy_sources WHERE public_id='source-1'").fetchone()[0]
    c.execute("INSERT INTO taxa(public_id,source_id,source_taxon_id,scientific_name,rank,status) VALUES('taxon-1',?,'1','Species one','species','accepted')", (sid,))
    c.execute("INSERT INTO model_packages(public_id,model_identity,semantic_version,model_family,artifact_checksum,manifest_json,license_json,install_path_token,installation_state,installed_at_us,active) VALUES('pkg','bioclip','1','bioclip','x','{}','{}','x','installed',1,1)")
    pid = c.execute("SELECT id FROM model_packages WHERE public_id='pkg'").fetchone()[0]
    c.execute("INSERT INTO model_variants(public_id,package_id,variant_identity,runtime,precision,device_requirements_json,preprocessing_identity,embedding_dimension,active) VALUES('variant',?,'v','torch','fp32','{}','prep',2,1)", (pid,))
    vid = c.execute("SELECT id FROM model_variants WHERE public_id='variant'").fetchone()[0]
    c.execute("INSERT INTO inference_runs(public_id,model_variant_id,execution_provider,parameter_json,application_version,started_at_us,outcome,precision) VALUES('run',?,'fake','{}','0.15',1,'succeeded','fp32')", (vid,))
    run = c.execute("SELECT id FROM inference_runs WHERE public_id='run'").fetchone()[0]
    c.commit(); c.close()
    return run


def test_acceptance_creates_observation_history_and_primary_evidence(tmp_path: Path):
    opened = LibraryService(SystemClock(), SystemUuidGenerator()).create(tmp_path / 'lib', display_name='Observations')
    try:
        run = _seed(opened)
        store = SqliteSuggestionStore(opened.connection_factory)
        service = ObservationIntelligenceService(SqliteObservationIntelligenceAdapter(opened.connection_factory))
        before = service.context_for_taxon('taxon-1')
        assert before is not None and before.is_first_observation
        store.create_suggestions(asset_public_id='asset-1', inference_run_id=run, suggestions=(SuggestionCandidate('taxon-1','Species one',.9,.9,1,ConfidenceBand.HIGH),), provenance={}, geographic_context={}, now_us=10, id_factory=lambda:'suggestion-1')
        store.review(suggestion_public_id='suggestion-1', action='accept', action_public_id='action-1', now_us=11)
        context = service.context_for_taxon('taxon-1')
        assert context is not None
        assert context.confirmed_observations == 1
        assert context.evidence_photos == 1
        record = service.inspect('obs-ai-action-1')
        assert record.asset_public_ids == ('asset-1',)
        assert record.scientific_name == 'Species one'
    finally:
        opened.close()


def test_multiple_photos_can_link_to_one_observation_without_duplicates(tmp_path: Path):
    opened = LibraryService(SystemClock(), SystemUuidGenerator()).create(tmp_path / 'lib', display_name='Observations')
    try:
        run = _seed(opened)
        store = SqliteSuggestionStore(opened.connection_factory)
        service = ObservationIntelligenceService(SqliteObservationIntelligenceAdapter(opened.connection_factory))
        store.create_suggestions(asset_public_id='asset-1', inference_run_id=run, suggestions=(SuggestionCandidate('taxon-1','Species one',.9,.9,1,ConfidenceBand.HIGH),), provenance={}, geographic_context={}, now_us=10, id_factory=lambda:'suggestion-1')
        store.review(suggestion_public_id='suggestion-1', action='accept', action_public_id='action-1', now_us=11)
        service.link_photo('obs-ai-action-1', 'asset-2', now_us=12)
        service.link_photo('obs-ai-action-1', 'asset-2', now_us=13)
        record = service.inspect('obs-ai-action-1')
        assert record.asset_public_ids == ('asset-1', 'asset-2')
        context = service.context_for_taxon('taxon-1')
        assert context is not None and context.confirmed_observations == 1 and context.evidence_photos == 2
    finally:
        opened.close()


def test_species_history_lists_timeline_and_evidence_photos(tmp_path: Path):
    opened = LibraryService(SystemClock(), SystemUuidGenerator()).create(tmp_path / 'lib', display_name='History')
    try:
        run = _seed(opened)
        store = SqliteSuggestionStore(opened.connection_factory)
        service = ObservationIntelligenceService(SqliteObservationIntelligenceAdapter(opened.connection_factory))
        store.create_suggestions(
            asset_public_id='asset-1', inference_run_id=run,
            suggestions=(SuggestionCandidate('taxon-1','Species one',.9,.9,1,ConfidenceBand.HIGH),),
            provenance={}, geographic_context={}, now_us=10, id_factory=lambda:'suggestion-history'
        )
        store.review(suggestion_public_id='suggestion-history', action='accept', action_public_id='action-history', now_us=11)
        service.link_photo('obs-ai-action-history', 'asset-2', now_us=12)
        summaries = service.list_species()
        assert len(summaries) == 1
        assert summaries[0].scientific_name == 'Species one'
        assert summaries[0].observation_count == 1
        assert summaries[0].evidence_photo_count == 2
        history = service.history_for_taxon('taxon-1')
        assert history.summary.taxon_public_id == 'taxon-1'
        assert len(history.timeline) == 1
        assert tuple(photo.asset_public_id for photo in history.timeline[0].photos) == ('asset-1', 'asset-2')
    finally:
        opened.close()


def test_species_history_returns_every_confirmed_observation_newest_first(tmp_path: Path):
    opened = LibraryService(SystemClock(), SystemUuidGenerator()).create(tmp_path / 'lib', display_name='Timeline')
    try:
        run = _seed(opened)
        store = SqliteSuggestionStore(opened.connection_factory)
        service = ObservationIntelligenceService(SqliteObservationIntelligenceAdapter(opened.connection_factory))
        store.create_suggestions(
            asset_public_id='asset-1', inference_run_id=run,
            suggestions=(SuggestionCandidate('taxon-1','Species one',.9,.9,1,ConfidenceBand.HIGH),),
            provenance={}, geographic_context={}, now_us=10, id_factory=lambda:'suggestion-timeline-1'
        )
        store.review(suggestion_public_id='suggestion-timeline-1', action='accept', action_public_id='action-timeline-1', now_us=11)
        store.create_suggestions(
            asset_public_id='asset-2', inference_run_id=run,
            suggestions=(SuggestionCandidate('taxon-1','Species one',.8,.8,1,ConfidenceBand.HIGH),),
            provenance={}, geographic_context={}, now_us=20, id_factory=lambda:'suggestion-timeline-2'
        )
        store.review(suggestion_public_id='suggestion-timeline-2', action='accept', action_public_id='action-timeline-2', now_us=21)
        history = service.history_for_taxon('taxon-1')
        assert len(history.timeline) == 2
        assert tuple(entry.observation_public_id for entry in history.timeline) == (
            'obs-ai-action-timeline-2', 'obs-ai-action-timeline-1'
        )
        assert all(entry.photos for entry in history.timeline)
    finally:
        opened.close()


def test_observation_statistics_are_projected_from_confirmed_history(tmp_path: Path):
    opened = LibraryService(SystemClock(), SystemUuidGenerator()).create(tmp_path / 'lib', display_name='Statistics')
    try:
        run = _seed(opened)
        store = SqliteSuggestionStore(opened.connection_factory)
        service = ObservationIntelligenceService(SqliteObservationIntelligenceAdapter(opened.connection_factory))
        store.create_suggestions(asset_public_id='asset-1', inference_run_id=run, suggestions=(SuggestionCandidate('taxon-1','Species one',.9,.9,1,ConfidenceBand.HIGH),), provenance={}, geographic_context={}, now_us=10, id_factory=lambda:'suggestion-stats-1')
        store.review(suggestion_public_id='suggestion-stats-1', action='accept', action_public_id='action-stats-1', now_us=11)
        store.create_suggestions(asset_public_id='asset-2', inference_run_id=run, suggestions=(SuggestionCandidate('taxon-1','Species one',.8,.8,1,ConfidenceBand.HIGH),), provenance={}, geographic_context={}, now_us=20, id_factory=lambda:'suggestion-stats-2')
        store.review(suggestion_public_id='suggestion-stats-2', action='accept', action_public_id='action-stats-2', now_us=21)
        stats = service.statistics(current_year=1970)
        assert stats.species_count == 1
        assert stats.observation_count == 2
        assert stats.evidence_photo_count == 2
        assert stats.first_observations_this_year == 1
        assert stats.life_list[0].species_count == 1
        assert stats.most_observed_species[0].scientific_name == 'Species one'
    finally:
        opened.close()
