from __future__ import annotations

from pathlib import Path

from natureai_next.bootstrap.container import build_foundation_container


def test_foundation_container_creates_required_paths(tmp_path: Path) -> None:
    container = build_foundation_container(config_root=tmp_path)
    assert container.paths.logs_dir.is_dir()
    assert container.paths.models_dir.is_dir()
    assert container.settings.settings.schema_version == 1
    assert container.clock.now_utc().tzinfo is not None
