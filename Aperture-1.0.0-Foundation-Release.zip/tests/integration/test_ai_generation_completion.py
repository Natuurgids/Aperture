from __future__ import annotations

from pathlib import Path

from natureai_next.application.ai_review import (
    CosineCandidateRanker,
    HierarchicalSuggestionGenerator,
    RegionalCandidateRanker,
    ReviewSessionService,
)
from natureai_next.application.library_service import LibraryService
from natureai_next.domain.ai import EmbeddingVector, TaxonomyTextEmbedding
from natureai_next.infrastructure.database.ai_generation import (
    SqliteNearDuplicateStore,
    SqliteReviewSessionStore,
    SqliteTaxonomyEmbeddingStore,
)
from natureai_next.infrastructure.diagnostics.system_services import SystemClock, SystemUuidGenerator


def _seed(opened):
    c = opened.connection_factory.connect()
    c.execute("INSERT INTO assets(public_id,media_type,lifecycle_state,created_at_us,modified_at_us) VALUES('a1','image','active',1,1)")
    c.execute("INSERT INTO assets(public_id,media_type,lifecycle_state,created_at_us,modified_at_us) VALUES('a2','image','active',1,1)")
    c.execute("INSERT INTO taxonomy_sources(public_id,name,source_version,package_checksum,license_json,installed_at_us,active,attribution_text,manifest_json) VALUES('s','Fixture','1','x','{}',1,1,'x','{}')")
    source_id = c.execute("SELECT id FROM taxonomy_sources WHERE public_id='s'").fetchone()[0]
    c.execute("INSERT INTO taxa(public_id,source_id,source_taxon_id,scientific_name,rank,status) VALUES('t1',?,'1','Taxon one','species','accepted')", (source_id,))
    c.execute("INSERT INTO taxa(public_id,source_id,source_taxon_id,scientific_name,rank,status) VALUES('t2',?,'2','Taxon two','species','accepted')", (source_id,))
    c.execute("INSERT INTO model_packages(public_id,model_identity,semantic_version,model_family,artifact_checksum,manifest_json,license_json,install_path_token,installation_state,installed_at_us,active) VALUES('p','bioclip','1','bioclip','x','{}','{}','x','installed',1,1)")
    package_id = c.execute("SELECT id FROM model_packages WHERE public_id='p'").fetchone()[0]
    c.execute("INSERT INTO model_variants(public_id,package_id,variant_identity,runtime,precision,device_requirements_json,preprocessing_identity,embedding_dimension,active) VALUES('v',?,'v','torch','fp32','{}','prep',2,1)", (package_id,))
    variant_id = c.execute("SELECT id FROM model_variants WHERE public_id='v'").fetchone()[0]
    c.commit(); c.close()
    return int(variant_id)


def test_taxonomy_embedding_generation_and_invalidation(tmp_path: Path):
    opened = LibraryService(SystemClock(), SystemUuidGenerator()).create(tmp_path / 'lib', display_name='AI generation')
    try:
        variant_id = _seed(opened)
        store = SqliteTaxonomyEmbeddingStore(opened.connection_factory)
        count = store.replace_generation(
            model_variant_id=variant_id,
            preprocessing_identity='prep',
            prompt_set_public_id=None,
            embeddings=(
                TaxonomyTextEmbedding('e1', 't1', None, 'scientific', 'Taxon one', None, None, EmbeddingVector((1.0, 0.0))),
                TaxonomyTextEmbedding('e2', 't2', None, 'scientific', 'Taxon two', None, None, EmbeddingVector((0.0, 1.0))),
                TaxonomyTextEmbedding('e3', None, 'plants', 'broad_group', 'plants', None, None, EmbeddingVector((1.0, 0.0))),
            ),
            now_us=10,
        )
        assert count == 3
        candidates = store.candidates(model_variant_id=variant_id, preprocessing_identity='prep')
        assert {item[0] for item in candidates} == {'t1', 't2', 'group:plants'}
        assert store.invalidate(model_variant_id=variant_id) == 3
        assert store.candidates(model_variant_id=variant_id, preprocessing_identity='prep') == ()
    finally:
        opened.close()


def test_near_duplicate_groups_and_review_session_round_trip(tmp_path: Path):
    opened = LibraryService(SystemClock(), SystemUuidGenerator()).create(tmp_path / 'lib', display_name='Review state')
    try:
        variant_id = _seed(opened)
        duplicates = SqliteNearDuplicateStore(opened.connection_factory)
        ids = iter(('g1',))
        assert duplicates.replace_groups(
            model_variant_id=variant_id,
            preprocessing_identity='prep',
            threshold=0.95,
            groups=((('a1', 1.0), ('a2', 0.97)),),
            group_id_factory=lambda: next(ids),
            now_us=20,
        ) == ('g1',)
        group = duplicates.page_groups()[0]
        assert [member.asset_public_id for member in group.members] == ['a1', 'a2']

        sessions = ReviewSessionService(SqliteReviewSessionStore(opened.connection_factory))
        sessions.save({'state': 'pending', 'selected': 'suggestion-7'}, public_id='session', now_us=30)
        assert sessions.load() == {'selected': 'suggestion-7', 'state': 'pending'}
    finally:
        opened.close()


def test_hierarchical_generation_stops_on_unknown_and_applies_region():
    base = CosineCandidateRanker(high=0.8, medium=0.5, low=0.2)
    generator = HierarchicalSuggestionGenerator(
        ranker=base,
        broad_group_candidates=lambda: (('plants', 'Plants', EmbeddingVector((1.0, 0.0))),),
        taxon_candidates=lambda group, region: (
            ('t1', 'Taxon one', EmbeddingVector((0.9, 0.1))),
            ('t2', 'Taxon two', EmbeddingVector((0.8, 0.2))),
        ),
        occurrence_resolver=lambda ids, region: {'t2': 'native', 't1': 'absent'},
        regional_ranker=RegionalCandidateRanker(base, native_boost=0.1, absent_penalty=0.2),
    )
    result = generator.generate(EmbeddingVector((1.0, 0.0)), region_code='NL', limit=2)
    assert result.broad_group is not None
    assert result.candidates[0].taxon_public_id == 't2'

    unknown = HierarchicalSuggestionGenerator(
        ranker=base,
        broad_group_candidates=lambda: (('plants', 'Plants', EmbeddingVector((0.0, 1.0))),),
        taxon_candidates=lambda group, region: (),
    ).generate(EmbeddingVector((1.0, 0.0)), region_code=None)
    assert unknown.candidates == ()
