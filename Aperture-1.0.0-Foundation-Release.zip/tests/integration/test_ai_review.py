from pathlib import Path
import itertools
import pytest
from natureai_next.application.library_service import LibraryService
from natureai_next.domain.ai import ConfidenceBand,SuggestionCandidate
from natureai_next.infrastructure.database.ai_review import SqliteSuggestionStore
from natureai_next.infrastructure.diagnostics.system_services import SystemClock,SystemUuidGenerator

def _seed(opened):
    c=opened.connection_factory.connect()
    c.execute("INSERT INTO assets(public_id,media_type,lifecycle_state,created_at_us,modified_at_us) VALUES('asset-1','image','active',1,1)")
    c.execute("INSERT INTO taxonomy_sources(public_id,name,source_version,package_checksum,license_json,installed_at_us,active,attribution_text,manifest_json) VALUES('source-1','Fixture','1.0','checksum','{}',1,1,'Fixture','{}')")
    sid=c.execute("SELECT id FROM taxonomy_sources WHERE public_id='source-1'").fetchone()[0]
    c.execute("INSERT INTO taxa(public_id,source_id,source_taxon_id,scientific_name,rank,status) VALUES('taxon-1',?,'1','Species one','species','accepted')",(sid,))
    c.execute("INSERT INTO model_packages(public_id,model_identity,semantic_version,model_family,artifact_checksum,manifest_json,license_json,install_path_token,installation_state,installed_at_us,active) VALUES('pkg','bioclip','1','bioclip','x','{}','{}','x','installed',1,1)")
    pid=c.execute("SELECT id FROM model_packages WHERE public_id='pkg'").fetchone()[0]
    c.execute("INSERT INTO model_variants(public_id,package_id,variant_identity,runtime,precision,device_requirements_json,preprocessing_identity,embedding_dimension,active) VALUES('variant',?,'v','torch','fp32','{}','prep',2,1)",(pid,))
    vid=c.execute("SELECT id FROM model_variants WHERE public_id='variant'").fetchone()[0]
    c.execute("INSERT INTO inference_runs(public_id,model_variant_id,execution_provider,parameter_json,application_version,started_at_us,outcome,precision) VALUES('run',?,'fake','{}','0.9',1,'succeeded','fp32')",(vid,))
    run=c.execute("SELECT id FROM inference_runs WHERE public_id='run'").fetchone()[0]
    c.commit();c.close();return run

def test_suggestion_review_accept_and_reverse(tmp_path:Path):
    opened=LibraryService(SystemClock(),SystemUuidGenerator()).create(tmp_path/'lib',display_name='Review')
    try:
        run=_seed(opened);store=SqliteSuggestionStore(opened.connection_factory);ids=iter(['suggestion-1'])
        created=store.create_suggestions(asset_public_id='asset-1',inference_run_id=run,suggestions=(SuggestionCandidate('taxon-1','Species one',.8,.8,1,ConfidenceBand.HIGH,'species'),),provenance={'model':'bioclip'},geographic_context={'region':'NL'},now_us=10,id_factory=lambda:next(ids))
        assert created==('suggestion-1',) and store.page(state='pending').items[0].candidate_taxon_public_id=='taxon-1'
        store.review(suggestion_public_id='suggestion-1',action='accept',action_public_id='action-1',now_us=11)
        assert store.page(state='accepted').items[0].public_id=='suggestion-1'
        store.reverse_acceptance(suggestion_public_id='suggestion-1',action_public_id='action-2',now_us=12)
        assert store.page(state='pending').items[0].public_id=='suggestion-1'
    finally:opened.close()

def test_acceptance_cannot_reverse_after_observation_edit(tmp_path:Path):
    opened=LibraryService(SystemClock(),SystemUuidGenerator()).create(tmp_path/'lib',display_name='Review')
    try:
        run=_seed(opened);store=SqliteSuggestionStore(opened.connection_factory)
        store.create_suggestions(asset_public_id='asset-1',inference_run_id=run,suggestions=(SuggestionCandidate('taxon-1','Species one',.8,.8,1,ConfidenceBand.HIGH),),provenance={},geographic_context={},now_us=10,id_factory=lambda:'suggestion-1')
        store.review(suggestion_public_id='suggestion-1',action='accept',action_public_id='action-1',now_us=11)
        c=opened.connection_factory.connect();c.execute("UPDATE observations SET revision=2 WHERE public_id='obs-ai-action-1'");c.commit();c.close()
        with pytest.raises(ValueError,match='diverged'):store.reverse_acceptance(suggestion_public_id='suggestion-1',action_public_id='action-2',now_us=12)
    finally:opened.close()
