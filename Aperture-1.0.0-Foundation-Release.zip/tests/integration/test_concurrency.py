from pathlib import Path
import threading
from natureai_next.domain.catalog import Asset,AssetLifecycle,MediaType
from natureai_next.infrastructure.database.connection import SqliteConnectionFactory
from natureai_next.infrastructure.database.migrations import CORE_MIGRATIONS,MigrationRunner
from natureai_next.infrastructure.database.unit_of_work import SqliteUnitOfWork

def test_concurrent_reads_and_serialized_writes(tmp_path:Path)->None:
    f=SqliteConnectionFactory(tmp_path/'db.sqlite3');c=f.connect();MigrationRunner(CORE_MIGRATIONS,'0.1').apply(c);c.execute("INSERT INTO library_info VALUES(1,'lib',1,1,'0.1','x','en','[]','clean')");c.close()
    errors=[]
    def writer(n:int)->None:
        try:
            with SqliteUnitOfWork(f) as u:u.assets.add(Asset(f'a{n}',MediaType.IMAGE,AssetLifecycle.ACTIVE,n,n));u.commit()
        except Exception as e:errors.append(e)
    threads=[threading.Thread(target=writer,args=(n,)) for n in range(20)]
    [t.start() for t in threads];[t.join() for t in threads]
    c=f.connect(read_only=True)
    try:assert not errors and c.execute('SELECT count(*) FROM assets').fetchone()[0]==20
    finally:c.close()
