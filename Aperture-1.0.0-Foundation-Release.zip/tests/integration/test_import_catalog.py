from datetime import datetime,timezone
from pathlib import Path
from uuid import uuid4
from PIL import Image
from natureai_next.application.catalog_maintenance import CatalogMaintenanceService
from natureai_next.application.import_service import ImportService
from natureai_next.application.library_service import LibraryService
from natureai_next.domain.importing import DuplicatePolicy,ImportStoragePolicy
from natureai_next.infrastructure.database.unit_of_work import SqliteUnitOfWork
from natureai_next.infrastructure.filesystem.importing import DirectorySourceScanner,ShardedManagedFileStore,StreamingFileFingerprinter
from natureai_next.infrastructure.imaging.pillow_adapter import PillowImageDecoder
from natureai_next.infrastructure.metadata.pillow_reader import PillowMetadataReader

class Clock:
    def now_utc(self):return datetime.now(timezone.utc)
class Ids:
    def new_uuid(self):return uuid4()

def setup(tmp_path):
    opened=LibraryService(Clock(),Ids()).create(tmp_path/'lib',display_name='Import')
    finger=StreamingFileFingerprinter(chunk_size=1024)
    store=ShardedManagedFileStore(opened.layout.managed_originals,finger)
    service=ImportService(uow_factory=lambda:SqliteUnitOfWork(opened.connection_factory),scanner=DirectorySourceScanner(),fingerprinter=finger,managed_store=store,decoder=PillowImageDecoder(),metadata_reader=PillowMetadataReader(),clock=Clock(),ids=Ids())
    maintenance=CatalogMaintenanceService(uow_factory=lambda:SqliteUnitOfWork(opened.connection_factory),fingerprinter=finger,managed_store=store,clock=Clock(),ids=Ids())
    return opened,service,maintenance

def image(path,color='red'):
    Image.new('RGB',(40,20),color).save(path)

def test_managed_import_is_idempotent_and_immutable(tmp_path):
    source=tmp_path/'source.jpg';image(source)
    opened,service,_=setup(tmp_path)
    try:
        first=service.plan([source],storage_policy=ImportStoragePolicy.MANAGED,duplicate_policy=DuplicatePolicy.SKIP)
        result=service.execute(first);assert result.imported==1 and result.failed==0
        second=service.plan([source],storage_policy=ImportStoragePolicy.MANAGED,duplicate_policy=DuplicatePolicy.SKIP)
        again=service.execute(second);assert again.skipped==1
        c=opened.connection_factory.connect(read_only=True)
        try:
            assert c.execute('SELECT count(*) FROM assets').fetchone()[0]==1
            managed=Path(c.execute('SELECT normalized_path FROM file_instances').fetchone()[0])
            assert managed.exists()
            assert managed.read_bytes()==source.read_bytes()
            assert c.execute('SELECT count(*) FROM metadata_snapshots').fetchone()[0]==1
            assert tuple(c.execute('SELECT pixel_width,pixel_height FROM image_properties').fetchone())==(40,20)
        finally:c.close()
    finally:opened.close()

def test_duplicate_can_attach_referenced_file(tmp_path):
    a=tmp_path/'a.jpg';b=tmp_path/'b.jpg';image(a);b.write_bytes(a.read_bytes())
    opened,service,_=setup(tmp_path)
    try:
        assert service.execute(service.plan([a],storage_policy=ImportStoragePolicy.REFERENCED,duplicate_policy=DuplicatePolicy.ADD_FILE_INSTANCE)).imported==1
        result=service.execute(service.plan([b],storage_policy=ImportStoragePolicy.REFERENCED,duplicate_policy=DuplicatePolicy.ADD_FILE_INSTANCE))
        assert result.attached==1
        c=opened.connection_factory.connect(read_only=True)
        try:assert c.execute('SELECT count(*) FROM assets').fetchone()[0]==1 and c.execute('SELECT count(*) FROM file_instances').fetchone()[0]==2
        finally:c.close()
    finally:opened.close()

def test_missing_relink_trash_restore_and_purge(tmp_path):
    source=tmp_path/'source.jpg';image(source)
    opened,service,maintenance=setup(tmp_path)
    try:
        result=service.execute(service.plan([source],storage_policy=ImportStoragePolicy.REFERENCED,duplicate_policy=DuplicatePolicy.SKIP))
        file_id=result.results[0].file_public_id;asset_id=result.results[0].asset_public_id
        moved=tmp_path/'moved.jpg';source.rename(moved)
        assert maintenance.refresh_availability()==1
        maintenance.relink(file_id,moved)
        assert maintenance.trash(asset_id) and maintenance.restore(asset_id) and maintenance.trash(asset_id)
        assert maintenance.purge(asset_id)
        c=opened.connection_factory.connect(read_only=True)
        try:assert c.execute('SELECT lifecycle_state FROM assets').fetchone()[0]=='purged'
        finally:c.close()
    finally:opened.close()

def test_corrupt_file_is_isolated_and_recorded_without_catalog_changes(tmp_path):
    bad=tmp_path/'bad.jpg';bad.write_text('not an image')
    opened,service,_=setup(tmp_path)
    try:
        plan=service.plan([bad],storage_policy=ImportStoragePolicy.REFERENCED,duplicate_policy=DuplicatePolicy.SKIP)
        assert len(plan.items)==1
        assert plan.items[0].decision.value=='reject_source'
        result=service.execute(plan)
        assert result.total==1 and result.failed==1 and result.imported==0
        assert result.results[0].source_path==str(bad)
        assert result.results[0].error_code=='image_decode_error'
        c=opened.connection_factory.connect(read_only=True)
        try:assert c.execute('SELECT count(*) FROM assets').fetchone()[0]==0
        finally:c.close()
    finally:opened.close()

def test_mixed_folder_continues_after_zip_and_corrupt_files(tmp_path):
    source_dir=tmp_path/'mixed';source_dir.mkdir()
    good=source_dir/'good.jpg';image(good)
    bad=source_dir/'bad.jpg';bad.write_text('not an image')
    archive=source_dir/'photos.zip';archive.write_bytes(b'PK\x03\x04not-a-real-image')
    opened,service,_=setup(tmp_path)
    try:
        plan=service.plan([source_dir],storage_policy=ImportStoragePolicy.REFERENCED,duplicate_policy=DuplicatePolicy.SKIP)
        assert len(plan.items)==3
        assert service.load_plan(plan.public_id)==plan
        result=service.execute(plan)
        assert result.total==3
        assert result.imported==1
        assert result.failed==2
        failed={Path(item.source_path).name:item.error_code for item in result.results if item.state=='failed'}
        assert failed=={'bad.jpg':'image_decode_error','photos.zip':'unsupported_format'}
        c=opened.connection_factory.connect(read_only=True)
        try:
            assert c.execute('SELECT count(*) FROM assets').fetchone()[0]==1
            assert c.execute("SELECT count(*) FROM import_plan_items WHERE state='failed'").fetchone()[0]==2
        finally:c.close()
    finally:opened.close()

def test_persisted_plan_can_be_reloaded_and_reexecuted(tmp_path):
    source=tmp_path/'source.jpg';image(source)
    opened,service,_=setup(tmp_path)
    try:
        plan=service.plan([source],storage_policy=ImportStoragePolicy.REFERENCED,duplicate_policy=DuplicatePolicy.SKIP)
        loaded=service.load_plan(plan.public_id)
        assert loaded==plan
        first=service.execute(loaded);second=service.execute(service.load_plan(plan.public_id))
        assert first.imported==1 and second.skipped==1
    finally:opened.close()

def test_hybrid_creates_managed_primary_and_referenced_alternate(tmp_path):
    source=tmp_path/'source.jpg';image(source)
    opened,service,_=setup(tmp_path)
    try:
        result=service.execute(service.plan([source],storage_policy=ImportStoragePolicy.HYBRID,duplicate_policy=DuplicatePolicy.SKIP))
        assert result.imported==1
        c=opened.connection_factory.connect(read_only=True)
        try:assert [r[0] for r in c.execute('SELECT storage_mode FROM file_instances ORDER BY id')]==['managed','referenced']
        finally:c.close()
    finally:opened.close()
