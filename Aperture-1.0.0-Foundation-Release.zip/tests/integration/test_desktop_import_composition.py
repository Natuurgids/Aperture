from __future__ import annotations

import sys
import types
from pathlib import Path

from natureai_next.application.catalog_browsing import CatalogEditService, CatalogQueryService
from natureai_next.application.ai_review import SuggestionService
from natureai_next.application.import_service import ImportService
from natureai_next.application.search import QuickSearchService
from natureai_next.infrastructure.imaging.catalog_thumbnails import PillowCatalogThumbnailProvider
from natureai_next.application.library_service import LibraryService
from natureai_next.bootstrap import cli
from natureai_next.bootstrap.container import build_foundation_container


def test_desktop_bootstrap_composes_production_import_service(tmp_path: Path, monkeypatch) -> None:
    foundation = build_foundation_container(config_root=tmp_path / "config")
    library_root = tmp_path / "library"
    opened = LibraryService(foundation.clock, foundation.uuid_generator).create(
        library_root,
        display_name="Desktop Import",
    )
    opened.close()

    captured: dict[str, object] = {}

    def run_desktop(**kwargs: object) -> int:
        captured.update(kwargs)
        return 17

    class FakeAIReviewWorkspace:
        def __init__(self, **kwargs: object) -> None:
            self.kwargs = kwargs

    fake_ai_module = types.ModuleType("natureai_next.ui.qt.ai_review")
    fake_ai_module.AIReviewWorkspace = FakeAIReviewWorkspace  # type: ignore[attr-defined]
    monkeypatch.setitem(sys.modules, "natureai_next.ui.qt.ai_review", fake_ai_module)

    fake_module = types.ModuleType("natureai_next.ui.qt.application")
    fake_module.run_desktop = run_desktop  # type: ignore[attr-defined]
    monkeypatch.setitem(sys.modules, "natureai_next.ui.qt.application", fake_module)

    result = cli.main(
        [
            "--library",
            str(library_root),
            "--config-root",
            str(tmp_path / "config"),
        ]
    )

    assert result == 17
    assert captured["library_name"] == "Desktop Import"
    assert captured["session_path"] == library_root / "session.json"
    assert isinstance(captured["import_service"], ImportService)
    assert isinstance(captured["catalog_service"], CatalogQueryService)
    assert isinstance(captured["catalog_edit_service"], CatalogEditService)
    assert isinstance(captured["thumbnail_service"], PillowCatalogThumbnailProvider)
    assert isinstance(captured["search_service"], QuickSearchService)
    factory = captured["ai_review_workspace_factory"]
    assert callable(factory)
    assert factory(lambda: ("asset-1",)).__class__.__name__ == "FakeAIReviewWorkspace"
