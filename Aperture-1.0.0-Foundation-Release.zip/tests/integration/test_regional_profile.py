from pathlib import Path
from natureai_next.domain.regional import RegionalCountry, RegionalProfile
from natureai_next.infrastructure.database.connection import SqliteConnectionFactory
from natureai_next.infrastructure.database.migrations import CORE_MIGRATIONS, MigrationRunner
from natureai_next.infrastructure.database.regional import SqliteRegionalProfileStore


def test_regional_profile_round_trip_and_country_evidence(tmp_path: Path) -> None:
    db=tmp_path/'library.sqlite3'; factory=SqliteConnectionFactory(db)
    c=factory.connect(); MigrationRunner(CORE_MIGRATIONS,'0.14.0').apply(c)
    c.execute("INSERT INTO taxonomy_sources(public_id,name,source_version,package_checksum,license_json,installed_at_us,activated_at_us,active) VALUES('src','src','1.0.0','x','{}',1,1,1)")
    source_id=c.execute("SELECT id FROM taxonomy_sources WHERE public_id='src'").fetchone()[0]
    c.execute("INSERT INTO taxa(public_id,source_id,source_taxon_id,scientific_name,rank,status) VALUES('taxon-robin',?,'1','Erithacus rubecula','species','accepted')",(source_id,))
    taxon_id=c.execute("SELECT id FROM taxa WHERE public_id='taxon-robin'").fetchone()[0]
    c.execute("INSERT INTO taxon_regions(taxon_id,region_code,occurrence_status,source) VALUES(?,?,?,?)",(taxon_id,'NL','native','test-source'))
    c.commit(); c.close()
    store=SqliteRegionalProfileStore(factory)
    profile=RegionalProfile('EU',(RegionalCountry('NL','EU','Netherlands',0,'test-source'),),True,('en','nl','scientific'))
    store.save(profile,now_us=2)
    assert store.load()==profile
    evidence=store.evidence_for_taxon('taxon-robin')
    assert evidence.level=='selected_country'
    assert evidence.label=='Verified in Netherlands'
