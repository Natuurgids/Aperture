from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

from natureai_next.application.library_service import LibraryService
from natureai_next.application.taxonomy import TaxonomyEmbeddingRefreshCoordinator
from natureai_next.domain.ai import TaxonomyEmbeddingRefreshPlan
from natureai_next.infrastructure.database.ai_generation import (
    SqliteTaxonomyEmbeddingRefreshPlanSource,
)
from natureai_next.infrastructure.diagnostics.system_services import SystemClock, SystemUuidGenerator


@dataclass
class _Plans:
    values: tuple[TaxonomyEmbeddingRefreshPlan, ...]

    def active_plans(self) -> tuple[TaxonomyEmbeddingRefreshPlan, ...]:
        return self.values


class _Embeddings:
    def __init__(self) -> None:
        self.calls: list[dict[str, object]] = []

    def invalidate(self, **kwargs: object) -> int:
        self.calls.append(dict(kwargs))
        return 4


@dataclass
class _Submitted:
    public_id: str


def test_refresh_invalidates_and_submits_deterministic_jobs() -> None:
    plan = TaxonomyEmbeddingRefreshPlan(7, "text-v1", "prompts", "bioclip")
    embeddings = _Embeddings()
    commands = []

    def submit(command):
        commands.append(command)
        return _Submitted("job-1")

    coordinator = TaxonomyEmbeddingRefreshCoordinator(
        plans=_Plans((plan,)),
        embeddings=embeddings,
        submit_job=submit,
        language_tags=("en", "nl", "en"),
        region_codes=("nl", "BG"),
        batch_size=64,
    )
    assert coordinator.refresh("source-release", now_us=123) == ("job-1",)
    assert embeddings.calls == [{
        "model_variant_id": 7,
        "preprocessing_identity": "text-v1",
        "prompt_set_public_id": "prompts",
    }]
    assert len(commands) == 1
    command = commands[0]
    assert command.job_type == "ai.embed_taxonomy_text.v1"
    assert command.priority == 25
    assert command.payload["taxonomy_source_public_id"] == "source-release"
    assert command.payload["language_tags"] == ["en", "nl"]
    assert command.payload["region_codes"] == ["NL", "BG"]
    assert command.payload["batch_size"] == 64
    assert command.idempotency_key.startswith("taxonomy-text-refresh:")


def test_sqlite_refresh_plan_source_resolves_active_variant_and_prompt(tmp_path: Path) -> None:
    opened = LibraryService(SystemClock(), SystemUuidGenerator()).create(
        tmp_path / "library", display_name="Refresh plan"
    )
    try:
        connection = opened.connection_factory.connect()
        connection.execute(
            "INSERT INTO model_packages(public_id,model_identity,semantic_version,model_family,artifact_checksum,manifest_json,license_json,install_path_token,installation_state,installed_at_us,active) VALUES('pkg','bioclip','1','bioclip','x','{}','{}','x','installed',1,1)"
        )
        package_id = int(connection.execute("SELECT id FROM model_packages WHERE public_id='pkg'").fetchone()[0])
        connection.execute(
            "INSERT INTO model_variants(public_id,package_id,variant_identity,runtime,precision,device_requirements_json,preprocessing_identity,embedding_dimension,active) VALUES('variant',?,'default','torch','fp32','{}','text-v2',512,1)",
            (package_id,),
        )
        connection.execute(
            "INSERT INTO prompt_sets(public_id,identity,semantic_version,model_family,manifest_json,checksum,installed_at_us,active) VALUES('prompt','wildlife','1','bioclip','{}','aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa',1,1)"
        )
        connection.commit()
        variant_id = int(connection.execute("SELECT id FROM model_variants WHERE public_id='variant'").fetchone()[0])
        connection.close()

        assert SqliteTaxonomyEmbeddingRefreshPlanSource(opened.connection_factory).active_plans() == (
            TaxonomyEmbeddingRefreshPlan(variant_id, "text-v2", "prompt", "bioclip"),
        )
    finally:
        opened.close()
