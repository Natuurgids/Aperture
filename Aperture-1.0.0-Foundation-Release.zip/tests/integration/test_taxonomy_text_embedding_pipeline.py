from __future__ import annotations

import json
from pathlib import Path

from natureai_next.application.ai_review import TaxonomyTextEmbeddingService
from natureai_next.application.library_service import LibraryService
from natureai_next.domain.ai import EmbeddingVector, TaxonomyTextLabel
from natureai_next.infrastructure.database.ai_generation import (
    SqliteTaxonomyEmbeddingStore,
    SqliteTaxonomyLabelSource,
)
from natureai_next.infrastructure.diagnostics.system_services import SystemClock, SystemUuidGenerator
from natureai_next.jobs.ai_handlers import TaxonomyTextEmbeddingJobHandler


def _seed(opened) -> int:
    connection = opened.connection_factory.connect()
    connection.execute(
        "INSERT INTO taxonomy_sources(public_id,name,source_version,package_checksum,license_json,installed_at_us,active,attribution_text,manifest_json) VALUES('source','Fixture','1','x','{}',1,1,'fixture','{}')"
    )
    source_id = int(connection.execute("SELECT id FROM taxonomy_sources WHERE public_id='source'").fetchone()[0])
    connection.execute(
        "INSERT INTO taxa(public_id,source_id,source_taxon_id,scientific_name,rank,status,kingdom,major_group) VALUES('accepted',?,'1','Accepted plant','species','accepted','Plantae','Plants')",
        (source_id,),
    )
    accepted_id = int(connection.execute("SELECT id FROM taxa WHERE public_id='accepted'").fetchone()[0])
    connection.execute(
        "INSERT INTO taxa(public_id,source_id,source_taxon_id,scientific_name,rank,status,accepted_taxon_id) VALUES('synonym',?,'2','Old plant name','species','synonym',?)",
        (source_id, accepted_id),
    )
    connection.execute(
        "INSERT INTO taxon_names(taxon_id,language_tag,region_code,name,name_type,preferred,source) VALUES(?,?,?,?,?,?,?)",
        (accepted_id, 'en', None, 'Accepted plant common', 'vernacular', 1, 'fixture'),
    )
    connection.execute(
        "INSERT INTO taxon_names(taxon_id,language_tag,region_code,name,name_type,preferred,source) VALUES(?,?,?,?,?,?,?)",
        (accepted_id, 'nl', 'NL', 'Geaccepteerde plant', 'vernacular', 1, 'fixture'),
    )
    connection.execute(
        "INSERT INTO model_packages(public_id,model_identity,semantic_version,model_family,artifact_checksum,manifest_json,license_json,install_path_token,installation_state,installed_at_us,active) VALUES('package','bioclip','1','bioclip','x','{}','{}','x','installed',1,1)"
    )
    package_id = int(connection.execute("SELECT id FROM model_packages WHERE public_id='package'").fetchone()[0])
    connection.execute(
        "INSERT INTO model_variants(public_id,package_id,variant_identity,runtime,precision,device_requirements_json,preprocessing_identity,embedding_dimension,active) VALUES('variant',?,'default','torch','fp32','{}','text-v1',2,1)",
        (package_id,),
    )
    variant_id = int(connection.execute("SELECT id FROM model_variants WHERE public_id='variant'").fetchone()[0])
    connection.commit()
    connection.close()
    return variant_id


def test_active_taxonomy_labels_and_embedding_generation(tmp_path: Path) -> None:
    opened = LibraryService(SystemClock(), SystemUuidGenerator()).create(tmp_path / 'library', display_name='Taxonomy text')
    try:
        variant_id = _seed(opened)
        source = SqliteTaxonomyLabelSource(opened.connection_factory)
        labels = source.active_labels(language_tags=('nl',), region_codes=('NL',))
        assert {(item.label_kind, item.text) for item in labels} == {
            ('scientific', 'Accepted plant'),
            ('vernacular', 'Geaccepteerde plant'),
            ('synonym', 'Old plant name'),
            ('broad_group', 'Plantae'),
            ('broad_group', 'Plants'),
        }

        counter = iter(range(100))
        service = TaxonomyTextEmbeddingService(
            labels=source,
            store=SqliteTaxonomyEmbeddingStore(opened.connection_factory),
            embed_text=lambda texts: tuple(
                EmbeddingVector((float(index + 1), 1.0)) for index, _ in enumerate(texts)
            ),
            public_id_factory=lambda label: f'embedding-{next(counter)}',
        )
        progress: list[tuple[int, int]] = []
        result = service.rebuild(
            model_variant_id=variant_id,
            preprocessing_identity='text-v1',
            prompt_set_public_id=None,
            now_us=50,
            language_tags=('nl',),
            region_codes=('NL',),
            batch_size=2,
            progress=lambda current, total: progress.append((current, total)),
        )
        assert result.labels_seen == 5
        assert result.embeddings_written == 5
        assert result.batches == 3
        assert progress[-1] == (5, 5)
        connection = opened.connection_factory.connect(read_only=True)
        row = connection.execute(
            "SELECT generation_identity,taxonomy_source_ids_json FROM taxonomy_text_embeddings WHERE valid=1 LIMIT 1"
        ).fetchone()
        connection.close()
        assert len(str(row[0])) == 64
        assert json.loads(str(row[1])) == ["source"]
    finally:
        opened.close()


class _Cancellation:
    def raise_if_cancelled(self) -> None:
        return None


class _Job:
    payload_json = json.dumps({
        'schema_version': 1,
        'model_variant_id': 7,
        'preprocessing_identity': 'text-v1',
        'now_us': 100,
        'batch_size': 2,
        'language_tags': ['en'],
        'region_codes': ['NL'],
    })


class _Context:
    job = _Job()
    cancellation = _Cancellation()

    def __init__(self) -> None:
        self.progress: list[tuple[int, int | None, str | None, str | None]] = []

    def report_progress(self, current: int, total: int | None, unit: str | None, message: str | None) -> None:
        self.progress.append((current, total, unit, message))


def test_taxonomy_embedding_job_handler_reports_durable_result() -> None:
    class Service:
        def rebuild(self, **kwargs):
            assert kwargs['model_variant_id'] == 7
            kwargs['progress'](2, 3)
            from natureai_next.application.ai_review import TaxonomyEmbeddingBuildResult
            return TaxonomyEmbeddingBuildResult(3, 3, 2)

    context = _Context()
    result = TaxonomyTextEmbeddingJobHandler(lambda payload: Service()).execute(context)
    assert result == {'labels_seen': 3, 'embeddings_written': 3, 'batches': 2}
    assert context.progress == [(2, 3, 'labels', 'Embedding taxonomy labels')]
