from __future__ import annotations

import hashlib
from datetime import datetime, timezone
from io import BytesIO
from pathlib import Path
from uuid import UUID

import pytest
from PIL import Image

from natureai_next.application.exporting import ResumableDerivativeExportService
from natureai_next.application.library_service import LibraryService
from natureai_next.domain.catalog import Asset, AssetLifecycle, AvailabilityState, FileInstance, FileRole, MediaType, StorageMode
from natureai_next.domain.exporting import CollisionPolicy, DerivativeExportPlan, DerivativeFormat, ExportItemState, ExportSelection
from natureai_next.infrastructure.database.derivative_export_plans import SqliteResumableDerivativeExportStore
from natureai_next.infrastructure.database.exporting import SqliteExportCatalogReader
from natureai_next.infrastructure.database.unit_of_work import SqliteUnitOfWork
from natureai_next.infrastructure.exporting.derivatives import LocalDerivativeExportWriter
from natureai_next.infrastructure.imaging.pillow_adapter import PillowImageDecoder


class Clock:
    def now_utc(self) -> datetime:
        return datetime(2026, 7, 13, tzinfo=timezone.utc)


class Ids:
    value = 1200

    def new_uuid(self) -> UUID:
        self.value += 1
        return UUID(int=self.value)


class CountingWriter(LocalDerivativeExportWriter):
    def __init__(self) -> None:
        super().__init__(PillowImageDecoder())
        self.written: list[str] = []

    def write_item(self, **kwargs):  # type: ignore[no-untyped-def]
        item = kwargs["item"]
        self.written.append(item.asset_public_id)
        return super().write_item(**kwargs)


def _png_bytes(colour: tuple[int, int, int]) -> bytes:
    buffer = BytesIO()
    Image.new("RGB", (80, 40), colour).save(buffer, format="PNG")
    return buffer.getvalue()


def _library(tmp_path: Path):
    opened = LibraryService(Clock(), Ids()).create(tmp_path / "Library", display_name="Derivatives")
    first = tmp_path / "first.png"
    second = tmp_path / "second.png"
    first_payload = _png_bytes((10, 20, 30))
    second_payload = _png_bytes((40, 50, 60))
    first.write_bytes(first_payload)
    with SqliteUnitOfWork(opened.connection_factory) as uow:
        for index, (asset_id, file_id, source, payload) in enumerate(
            (("asset-1", "file-1", first, first_payload), ("asset-2", "file-2", second, second_payload)), start=1
        ):
            asset = uow.assets.add(
                Asset(asset_id, MediaType.IMAGE, AssetLifecycle.ACTIVE, index, index, title=f"Bird & {index}")
            )
            file = uow.files.add(
                FileInstance(
                    file_id,
                    asset.id or 0,
                    StorageMode.REFERENCED,
                    FileRole.ORIGINAL,
                    str(source),
                    str(source).casefold(),
                    len(payload),
                    index,
                    hashlib.sha256(payload).hexdigest(),
                    AvailabilityState.AVAILABLE,
                    "image/png",
                    "PNG",
                    index,
                    index,
                )
            )
            assert uow.connection is not None
            uow.connection.execute("UPDATE assets SET primary_file_instance_id=? WHERE id=?", (file.id, asset.id))
        uow.commit()
    return opened, first, second, second_payload


def test_resumable_derivative_export_retries_only_failed_items(tmp_path: Path) -> None:
    opened, _first, second, second_payload = _library(tmp_path)
    now = iter(range(10_000, 12_000)).__next__
    writer = CountingWriter()
    store = SqliteResumableDerivativeExportStore(opened.connection_factory)
    service = ResumableDerivativeExportService(SqliteExportCatalogReader(opened.connection_factory), writer, store)
    plan = DerivativeExportPlan(
        "derivative-resume-1",
        tmp_path / "output",
        ExportSelection(include_all_active=True),
        format=DerivativeFormat.JPEG,
        max_width=40,
        max_height=40,
        naming_template="{asset_id}",
        collision_policy=CollisionPolicy.REPLACE,
        created_at_us=9_000,
    )
    try:
        with pytest.raises(RuntimeError, match="1 derivative export item"):
            service.execute(plan, now_us=now)
        assert writer.written == ["asset-1", "asset-2"]
        items = store.list_items(plan.public_id)
        assert [item.state for item in items] == [ExportItemState.SUCCEEDED, ExportItemState.FAILED]
        first_output = plan.destination_directory / "asset-1.jpg"
        first_mtime = first_output.stat().st_mtime_ns

        second.write_bytes(second_payload)
        writer.written.clear()
        result = service.execute(plan, now_us=now)
        assert writer.written == ["asset-2"]
        assert result.asset_count == 2
        assert first_output.stat().st_mtime_ns == first_mtime
        assert all(item.state is ExportItemState.SUCCEEDED for item in store.list_items(plan.public_id))
        assert result.manifest_path is not None and result.manifest_path.is_file()
        assert all(item.xmp_sha256 for item in store.list_items(plan.public_id))
    finally:
        opened.close()


def test_corrupt_completed_derivative_or_xmp_is_rebuilt(tmp_path: Path) -> None:
    opened, _first, second, second_payload = _library(tmp_path)
    second.write_bytes(second_payload)
    now = iter(range(20_000, 22_000)).__next__
    writer = CountingWriter()
    store = SqliteResumableDerivativeExportStore(opened.connection_factory)
    service = ResumableDerivativeExportService(SqliteExportCatalogReader(opened.connection_factory), writer, store)
    plan = DerivativeExportPlan(
        "derivative-resume-2",
        tmp_path / "output",
        ExportSelection(include_all_active=True),
        format=DerivativeFormat.PNG,
        naming_template="{asset_id}",
        collision_policy=CollisionPolicy.REPLACE,
        include_manifest=False,
    )
    try:
        service.execute(plan, now_us=now)
        (plan.destination_directory / "asset-1.png.xmp").write_bytes(b"corrupt")
        writer.written.clear()
        service.execute(plan, now_us=now)
        assert writer.written == ["asset-1"]
        assert b"Bird &amp; 1" in (plan.destination_directory / "asset-1.png.xmp").read_bytes()
    finally:
        opened.close()


def test_running_derivative_items_are_recovered(tmp_path: Path) -> None:
    opened, _first, second, second_payload = _library(tmp_path)
    second.write_bytes(second_payload)
    store = SqliteResumableDerivativeExportStore(opened.connection_factory)
    writer = LocalDerivativeExportWriter(PillowImageDecoder())
    plan = DerivativeExportPlan("derivative-resume-3", tmp_path / "output", ExportSelection(include_all_active=True))
    try:
        records = SqliteExportCatalogReader(opened.connection_factory).read_derivative_records(None)
        store.prepare(plan=plan, items=writer.assign_items(plan=plan, records=records), now_us=1)
        claimed = store.claim_next_item(plan.public_id, 2)
        assert claimed is not None and claimed.state is ExportItemState.RUNNING
        assert store.recover_running_items(plan.public_id, 3) == 1
        assert store.list_items(plan.public_id)[0].state is ExportItemState.PENDING
    finally:
        opened.close()
