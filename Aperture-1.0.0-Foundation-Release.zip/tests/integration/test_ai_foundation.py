from __future__ import annotations

from pathlib import Path
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
from PIL import Image
import pytest

from natureai_next.application.ai import AIEmbeddingService, EmbeddingItem
from natureai_next.application.library_service import LibraryService
from natureai_next.domain.ai import EmbeddingVector
from natureai_next.infrastructure.ai.gpu import GpuResourceCoordinator
from natureai_next.infrastructure.ai.package import ModelPackageInstaller, ModelPackageVerifier, build_model_package
from natureai_next.infrastructure.ai.preprocessing import BioClipImagePreprocessor
from natureai_next.infrastructure.database.ai import SqliteAIRepository
from natureai_next.infrastructure.diagnostics.system_services import SystemClock, SystemUuidGenerator


def _package(tmp_path: Path):
    key=Ed25519PrivateKey.generate()
    public=key.public_key().public_bytes(serialization.Encoding.Raw,serialization.PublicFormat.Raw)
    manifest={
        "package_id":"bioclip-test-1","model_identity":"bioclip","semantic_version":"1.0.0",
        "model_family":"bioclip","upstream_source":"fixture","license_name":"MIT",
        "attribution_text":"Fixture model","minimum_application_version":"0.1.0","signing_key_id":"test",
        "variants":[{"identity":"torch-fp32","runtime":"torch","precision":"fp32","providers":["cpu","cuda"],"preprocessing_identity":"bioclip-center-v1","embedding_dimension":3,"input_size":32,"normalized_output":True,"artifact_path":"model.pt"}],
    }
    path=build_model_package(tmp_path/'model.zip',private_key=key,manifest=manifest,artifacts={"model.pt":b"fixture-model"})
    return path,ModelPackageVerifier({"test":public})


def test_model_install_embedding_and_exact_search(tmp_path:Path)->None:
    opened=LibraryService(SystemClock(),SystemUuidGenerator()).create(tmp_path/'library',display_name='AI')
    try:
        package,verifier=_package(tmp_path)
        assert ModelPackageInstaller(opened.connection_factory,tmp_path/'models',verifier).install(package)=='bioclip-test-1'
        repository=SqliteAIRepository(opened.connection_factory);variant=repository.active_variant('bioclip');assert variant is not None
        c=opened.connection_factory.connect();
        c.execute("INSERT INTO assets(public_id,media_type,lifecycle_state,created_at_us,modified_at_us) VALUES('a1','image','active',1,1)")
        c.execute("INSERT INTO assets(public_id,media_type,lifecycle_state,created_at_us,modified_at_us) VALUES('a2','image','active',1,1)");c.close()
        repository.store_embedding(asset_public_id='a1',model_variant_id=variant.id,preprocessing_identity=variant.preprocessing_identity,vector=EmbeddingVector((1,0,0)),source_sha256=None,execution_provider='test:cpu',precision='fp32',application_version='0.8.0')
        repository.store_embedding(asset_public_id='a2',model_variant_id=variant.id,preprocessing_identity=variant.preprocessing_identity,vector=EmbeddingVector((0,1,0)),source_sha256=None,execution_provider='test:cpu',precision='fp32',application_version='0.8.0')
        matches=repository.exact_search(variant.id,variant.preprocessing_identity,EmbeddingVector((.9,.1,0)),2)
        assert [m.asset_public_id for m in matches]==['a1','a2']
    finally:opened.close()


def test_tampered_model_package_rejected(tmp_path:Path)->None:
    package,verifier=_package(tmp_path)
    import zipfile
    with zipfile.ZipFile(package,'a') as archive:archive.writestr('model.pt',b'tampered')
    with pytest.raises(ValueError,match='checksum'):verifier.verify(package)


class _FakeProvider:
    identity='fake'
    def __init__(self)->None:self.calls=0
    def diagnostics(self):raise AssertionError
    def load(self,*args,**kwargs):raise AssertionError
    def embed_images(self,model,images):
        self.calls+=1
        if len(images)>1:raise RuntimeError('CUDA out of memory')
        return tuple(EmbeddingVector((1,2,3)) for _ in images)
    def embed_text(self,model,texts):return tuple(EmbeddingVector((1,0,0)) for _ in texts)
    def unload(self,model):return None
    def clear_device_cache(self):return None


def test_embedding_service_reduces_batch_after_oom(tmp_path:Path)->None:
    opened=LibraryService(SystemClock(),SystemUuidGenerator()).create(tmp_path/'library',display_name='AI')
    try:
        package,verifier=_package(tmp_path);ModelPackageInstaller(opened.connection_factory,tmp_path/'models',verifier).install(package)
        repo=SqliteAIRepository(opened.connection_factory);variant=repo.active_variant('bioclip');assert variant
        c=opened.connection_factory.connect();
        for i in range(3):c.execute("INSERT INTO assets(public_id,media_type,lifecycle_state,created_at_us,modified_at_us) VALUES(?, 'image','active',1,1)",(f'a{i}',))
        c.close()
        items=[]
        for i in range(3):
            path=tmp_path/f'{i}.jpg';Image.new('RGB',(40,30),(i*20,0,0)).save(path);items.append(EmbeddingItem(f'a{i}',path,None))
        service=AIEmbeddingService(repo,_FakeProvider(),BioClipImagePreprocessor(32,'bioclip-center-v1'),GpuResourceCoordinator())
        result=service.embed_images(model=object(),model_variant_id=variant.id,precision='fp32',items=items,initial_batch_size=3)
        assert result.completed==('a0','a1','a2') and result.final_batch_size==1 and result.retries==1
    finally:opened.close()
