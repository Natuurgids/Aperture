from __future__ import annotations

import csv
import json
from datetime import datetime, timezone
from pathlib import Path
from uuid import UUID

import pytest

from natureai_next.application.exporting import ExportService
from natureai_next.application.library_service import LibraryService
from natureai_next.domain.catalog import Asset, AssetLifecycle, AvailabilityState, FileInstance, FileRole, MediaType, StorageMode, Tag
from natureai_next.domain.exporting import CollisionPolicy, ExportFormat, ExportPlan, ExportSelection
from natureai_next.infrastructure.database.exporting import SqliteExportCatalogReader
from natureai_next.infrastructure.database.unit_of_work import SqliteUnitOfWork
from natureai_next.infrastructure.exporting.metadata import LocalMetadataExportWriter


class Clock:
    def now_utc(self) -> datetime:
        return datetime(2026, 7, 13, tzinfo=timezone.utc)


class Ids:
    value = 100

    def new_uuid(self) -> UUID:
        self.value += 1
        return UUID(int=self.value)


def _library(tmp_path: Path):
    opened = LibraryService(Clock(), Ids()).create(tmp_path / "Library", display_name="Wildlife")
    with SqliteUnitOfWork(opened.connection_factory) as uow:
        asset = uow.assets.add(Asset("asset-1", MediaType.IMAGE, AssetLifecycle.ACTIVE, 10, 11, title="Great tit", rating=5, caption="Garden bird"))
        file = uow.files.add(FileInstance("file-1", asset.id or 0, StorageMode.REFERENCED, FileRole.ORIGINAL, "C:/Photos/bird.jpg", "c:/photos/bird.jpg", 123, 9, "a" * 64, AvailabilityState.AVAILABLE, "image/jpeg", "JPEG", 10, 10))
        tag = uow.tags.add(Tag("tag-1", "bird", "Bird", 10))
        uow.tags.attach(asset_id=asset.id or 0, tag_id=tag.id or 0, source="user", created_at_us=10)
        assert uow.connection is not None
        uow.connection.execute("UPDATE assets SET primary_file_instance_id=? WHERE id=?", (file.id, asset.id))
        uow.connection.execute("INSERT INTO image_properties(asset_id,file_instance_id,pixel_width,pixel_height,has_alpha) VALUES(?,?,?,?,0)", (asset.id, file.id, 6000, 4000))
        uow.connection.execute("INSERT INTO observations(public_id,asset_id,observation_type,confirmation_state,source,created_at_us,modified_at_us) VALUES('obs-1',?,'organism','confirmed','user',10,10)", (asset.id,))
        uow.commit()
    return opened


def _counts(opened) -> dict[str, int]:
    connection = opened.connection_factory.connect(read_only=True)
    try:
        tables = ("assets", "file_instances", "tags", "asset_tags", "observations", "audit_log", "event_outbox", "jobs")
        return {table: int(connection.execute(f"SELECT COUNT(*) FROM {table}").fetchone()[0]) for table in tables}
    finally:
        connection.close()


def test_json_export_is_deterministic_and_does_not_mutate_library(tmp_path: Path) -> None:
    opened = _library(tmp_path)
    try:
        before = _counts(opened)
        destination = tmp_path / "exports" / "catalog.json"
        result = ExportService(SqliteExportCatalogReader(opened.connection_factory), LocalMetadataExportWriter()).execute(
            ExportPlan("plan-1", destination, ExportFormat.JSON, ExportSelection(include_all_active=True), created_at_us=50)
        )
        assert result.asset_count == 1
        assert result.bytes_written == destination.stat().st_size
        document = json.loads(destination.read_text(encoding="utf-8"))
        assert document["schema_version"] == 1
        assert document["export"]["plan_public_id"] == "plan-1"
        assert document["assets"][0]["tags"] == ["Bird"]
        assert document["assets"][0]["observations"][0]["public_id"] == "obs-1"
        assert _counts(opened) == before
    finally:
        opened.close()


def test_csv_export_and_collision_policy(tmp_path: Path) -> None:
    opened = _library(tmp_path)
    try:
        destination = tmp_path / "catalog.csv"
        service = ExportService(SqliteExportCatalogReader(opened.connection_factory), LocalMetadataExportWriter())
        plan = ExportPlan("plan-2", destination, ExportFormat.CSV, ExportSelection(("asset-1",)), created_at_us=60)
        service.execute(plan)
        with destination.open("r", encoding="utf-8-sig", newline="") as stream:
            rows = list(csv.DictReader(stream))
        assert rows[0]["public_id"] == "asset-1"
        assert rows[0]["tags"] == "Bird"
        with pytest.raises(FileExistsError):
            service.execute(plan)
        replaced = ExportPlan("plan-3", destination, ExportFormat.CSV, ExportSelection(("asset-1",)), CollisionPolicy.REPLACE, created_at_us=61)
        assert service.execute(replaced).asset_count == 1
    finally:
        opened.close()


def test_explicit_selection_rejects_missing_or_inactive_assets(tmp_path: Path) -> None:
    opened = _library(tmp_path)
    try:
        service = ExportService(SqliteExportCatalogReader(opened.connection_factory), LocalMetadataExportWriter())
        with pytest.raises(KeyError):
            service.execute(ExportPlan("plan-4", tmp_path / "missing.json", ExportFormat.JSON, ExportSelection(("missing",))))
        assert not (tmp_path / "missing.json").exists()
    finally:
        opened.close()


def test_original_file_export_uses_safe_names_checksums_and_manifest(tmp_path: Path) -> None:
    import hashlib

    from natureai_next.application.exporting import OriginalFileExportService
    from natureai_next.domain.exporting import OriginalFileExportPlan
    from natureai_next.infrastructure.exporting.files import LocalOriginalFileExportWriter

    opened = _library(tmp_path)
    try:
        source = tmp_path / "source.jpg"
        content = b"offline-wildlife-original"
        source.write_bytes(content)
        checksum = hashlib.sha256(content).hexdigest()
        connection = opened.connection_factory.connect()
        try:
            connection.execute(
                "UPDATE file_instances SET normalized_path=?,file_size=?,sha256=? WHERE public_id='file-1'",
                (str(source), len(content), checksum),
            )
            connection.commit()
        finally:
            connection.close()

        before = _counts(opened)
        destination = tmp_path / "original-export"
        plan = OriginalFileExportPlan(
            public_id="original-plan-1",
            destination_directory=destination,
            selection=ExportSelection(("asset-1",)),
            naming_template="{title}-{asset_id}{original_ext}",
            created_at_us=100,
        )
        result = OriginalFileExportService(
            SqliteExportCatalogReader(opened.connection_factory),
            LocalOriginalFileExportWriter(),
        ).execute(plan)

        assert result.asset_count == 1
        assert result.bytes_written == len(content)
        exported = destination / "Great tit-asset-1.jpg"
        assert exported.read_bytes() == content
        assert result.files[0].sha256 == checksum
        assert result.manifest_path == destination / "natureai-export-manifest.json"
        manifest = json.loads(result.manifest_path.read_text(encoding="utf-8"))
        assert manifest["plan_public_id"] == "original-plan-1"
        assert manifest["files"][0]["relative_path"] == exported.name
        assert _counts(opened) == before
    finally:
        opened.close()


def test_original_export_suffixes_collisions_and_rejects_source_changes(tmp_path: Path) -> None:
    import hashlib

    from natureai_next.application.exporting import OriginalFileExportService
    from natureai_next.domain.exporting import OriginalFileExportPlan
    from natureai_next.infrastructure.exporting.files import LocalOriginalFileExportWriter

    opened = _library(tmp_path)
    try:
        source = tmp_path / "bird.jpg"
        source.write_bytes(b"bird")
        checksum = hashlib.sha256(b"bird").hexdigest()
        connection = opened.connection_factory.connect()
        try:
            connection.execute(
                "UPDATE file_instances SET normalized_path=?,file_size=?,sha256=? WHERE public_id='file-1'",
                (str(source), 4, checksum),
            )
            connection.commit()
        finally:
            connection.close()
        destination = tmp_path / "exports"
        destination.mkdir()
        (destination / "bird.jpg").write_bytes(b"existing")
        service = OriginalFileExportService(
            SqliteExportCatalogReader(opened.connection_factory),
            LocalOriginalFileExportWriter(),
        )
        result = service.execute(
            OriginalFileExportPlan(
                "original-plan-2",
                destination,
                ExportSelection(("asset-1",)),
                naming_template="{original_stem}{original_ext}",
                collision_policy=CollisionPolicy.SUFFIX,
                include_manifest=False,
            )
        )
        assert result.files[0].relative_path == "bird (2).jpg"
        assert (destination / "bird.jpg").read_bytes() == b"existing"
        assert (destination / "bird (2).jpg").read_bytes() == b"bird"

        source.write_bytes(b"changed")
        with pytest.raises(IOError, match="source size changed|source checksum mismatch"):
            service.execute(
                OriginalFileExportPlan(
                    "original-plan-3",
                    tmp_path / "failed-export",
                    ExportSelection(("asset-1",)),
                )
            )
        assert not any((tmp_path / "failed-export").glob("*.jpg"))
    finally:
        opened.close()


def test_naming_template_validation_and_windows_safe_components() -> None:
    from natureai_next.infrastructure.exporting.files import safe_windows_component, validate_naming_template

    validate_naming_template("{capture_date}-{title}-{asset_id}{original_ext}")
    with pytest.raises(ValueError, match="unsupported naming template tokens"):
        validate_naming_template("{unknown}")
    with pytest.raises(ValueError, match="format specifications"):
        validate_naming_template("{revision:04d}")
    assert safe_windows_component('CON') == '_CON'
    assert safe_windows_component('bird<name>:?.jpg') == 'bird_name___.jpg'


def test_derivative_export_renders_orientation_safe_image_xmp_and_manifest(tmp_path: Path) -> None:
    import hashlib

    from PIL import Image

    from natureai_next.application.exporting import DerivativeExportService
    from natureai_next.domain.exporting import DerivativeExportPlan, DerivativeFormat
    from natureai_next.infrastructure.exporting.derivatives import LocalDerivativeExportWriter
    from natureai_next.infrastructure.imaging.pillow_adapter import PillowImageDecoder

    opened = _library(tmp_path)
    try:
        source = tmp_path / "portrait-source.jpg"
        image = Image.new("RGB", (1200, 800), (20, 90, 40))
        exif = Image.Exif()
        exif[274] = 6
        image.save(source, format="JPEG", exif=exif)
        checksum = hashlib.sha256(source.read_bytes()).hexdigest()
        connection = opened.connection_factory.connect()
        try:
            connection.execute(
                "UPDATE file_instances SET normalized_path=?,file_size=?,sha256=? WHERE public_id='file-1'",
                (str(source), source.stat().st_size, checksum),
            )
            connection.execute("UPDATE assets SET user_notes='Seen near <pond> & reeds' WHERE public_id='asset-1'")
            connection.commit()
        finally:
            connection.close()

        before = _counts(opened)
        destination = tmp_path / "derivatives"
        plan = DerivativeExportPlan(
            public_id="derivative-plan-1",
            destination_directory=destination,
            selection=ExportSelection(("asset-1",)),
            format=DerivativeFormat.JPEG,
            max_width=300,
            max_height=300,
            quality=88,
            naming_template="{title}-{asset_id}",
            created_at_us=200,
        )
        result = DerivativeExportService(
            SqliteExportCatalogReader(opened.connection_factory),
            LocalDerivativeExportWriter(PillowImageDecoder()),
        ).execute(plan)

        assert result.asset_count == 1
        exported = destination / "Great tit-asset-1.jpg"
        sidecar = destination / "Great tit-asset-1.jpg.xmp"
        assert exported.is_file()
        assert sidecar.is_file()
        with Image.open(exported) as rendered:
            assert rendered.size == (200, 300)
        xmp = sidecar.read_text(encoding="utf-8")
        assert "Great tit" in xmp
        assert "Garden bird" in xmp
        assert "Seen near &lt;pond&gt; &amp; reeds" in xmp
        assert "<rdf:li>Bird</rdf:li>" in xmp
        assert result.files[0].sha256 == hashlib.sha256(exported.read_bytes()).hexdigest()
        assert result.files[0].xmp_sha256 == hashlib.sha256(sidecar.read_bytes()).hexdigest()
        manifest = json.loads((destination / "natureai-derivative-manifest.json").read_text(encoding="utf-8"))
        assert manifest["format"] == "jpeg"
        assert manifest["files"][0]["pixel_width"] == 200
        assert manifest["files"][0]["pixel_height"] == 300
        assert _counts(opened) == before
    finally:
        opened.close()


def test_derivative_export_validates_limits_and_collision_policy(tmp_path: Path) -> None:
    from PIL import Image

    from natureai_next.application.exporting import DerivativeExportService
    from natureai_next.domain.exporting import DerivativeExportPlan, DerivativeFormat
    from natureai_next.infrastructure.exporting.derivatives import LocalDerivativeExportWriter
    from natureai_next.infrastructure.imaging.pillow_adapter import PillowImageDecoder

    with pytest.raises(ValueError, match="dimensions"):
        DerivativeExportPlan("bad", tmp_path / "out", ExportSelection(("asset-1",)), max_width=0)
    with pytest.raises(ValueError, match="quality"):
        DerivativeExportPlan("bad", tmp_path / "out", ExportSelection(("asset-1",)), quality=101)

    opened = _library(tmp_path)
    try:
        source = tmp_path / "source.png"
        Image.new("RGB", (40, 20), (1, 2, 3)).save(source)
        connection = opened.connection_factory.connect()
        try:
            connection.execute(
                "UPDATE file_instances SET normalized_path=?,file_size=?,sha256=NULL WHERE public_id='file-1'",
                (str(source), source.stat().st_size),
            )
            connection.commit()
        finally:
            connection.close()
        destination = tmp_path / "derivatives"
        destination.mkdir()
        (destination / "asset-1.png").write_bytes(b"existing")
        service = DerivativeExportService(
            SqliteExportCatalogReader(opened.connection_factory),
            LocalDerivativeExportWriter(PillowImageDecoder()),
        )
        with pytest.raises(FileExistsError):
            service.execute(
                DerivativeExportPlan(
                    "collision",
                    destination,
                    ExportSelection(("asset-1",)),
                    format=DerivativeFormat.PNG,
                    naming_template="{asset_id}",
                    include_xmp_sidecars=False,
                    include_manifest=False,
                )
            )
        result = service.execute(
            DerivativeExportPlan(
                "suffix",
                destination,
                ExportSelection(("asset-1",)),
                format=DerivativeFormat.PNG,
                naming_template="{asset_id}",
                collision_policy=CollisionPolicy.SUFFIX,
                include_xmp_sidecars=False,
                include_manifest=False,
            )
        )
        assert result.files[0].relative_path == "asset-1 (2).png"
        assert (destination / "asset-1.png").read_bytes() == b"existing"
    finally:
        opened.close()
