from pathlib import Path


def test_aperture_branding_and_navigation_are_wired():
    root = Path(__file__).resolve().parents[2]
    application = (root / "src/natureai_next/ui/qt/application.py").read_text(encoding="utf-8")
    product = (root / "src/natureai_next/ui/qt/product_pages.py").read_text(encoding="utf-8")
    assert "QTreeWidget" in application
    assert '"Branding & Project"' in application
    assert '"Diagnostics"' in application
    assert "About Aperture" in application
    assert "Powered by NatureAI_Next" in product
    assert "Copy system information" in product
