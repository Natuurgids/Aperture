from pathlib import Path
from natureai_next.domain.search import Predicate, PredicateOperator, StructuredQuery
from natureai_next.infrastructure.database.connection import SqliteConnectionFactory
from natureai_next.infrastructure.database.migrations import CORE_MIGRATIONS, MigrationRunner
from natureai_next.infrastructure.database.search import SqliteCollectionAdapter, SqliteGeographyAdapter, SqliteSavedSearchAdapter, SqliteSearchAdapter
from natureai_next.ports.search import LocationInput, SearchRequest

def factory(tmp_path:Path):
    f=SqliteConnectionFactory(tmp_path/'library.sqlite3')
    c=f.connect();MigrationRunner(CORE_MIGRATIONS,'0.6.0').apply(c);c.execute("INSERT INTO library_info VALUES(1,'lib',1,4,'0.1','Test','en','[]','clean')")
    for i,(title,rating) in enumerate((('Great Crested Grebe',5),('Oak woodland',3)),1):
        c.execute("INSERT INTO assets(public_id,media_type,lifecycle_state,title,rating,created_at_us,modified_at_us) VALUES(?,'image','active',?,?,1,1)",(f'a{i}',title,rating))
    c.commit();c.close();return f

def test_fts_structured_saved_search_and_collections(tmp_path):
    f=factory(tmp_path);search=SqliteSearchAdapter(f)
    result=search.search(SearchRequest(StructuredQuery(Predicate('text',PredicateOperator.CONTAINS,'Grebe'))))
    assert [x.public_id for x in result.rows]==['a1'];assert search.fts_parity()==(2,2)
    q=StructuredQuery(Predicate('rating',PredicateOperator.GTE,4));saved=SqliteSavedSearchAdapter(f)
    saved.save_search(public_id='s1',name='Best',query=q,now_us=2);assert saved.list_saved_searches()[0].query==q
    collections=SqliteCollectionAdapter(f);collections.create_manual(public_id='c1',name='Birds',description=None,parent_public_id=None,now_us=2);collections.add_assets(collection_public_id='c1',asset_public_ids=('a1',),now_us=3)
    collections.create_smart(public_id='c2',name='Top',description=None,parent_public_id='c1',query=q,now_us=4)
    rows=collections.list_collections();assert rows[0].asset_count==1;assert rows[1].parent_public_id=='c1'

def test_geographic_radius_and_validation(tmp_path):
    f=factory(tmp_path);geo=SqliteGeographyAdapter(f)
    geo.set_asset_location(asset_public_id='a1',location_public_id='l1',location=LocationInput(52.37,4.90,country_code='NL',place_name='Amsterdam'),role='capture',now_us=2)
    geo.set_asset_location(asset_public_id='a2',location_public_id='l2',location=LocationInput(42.70,23.32,country_code='BG',place_name='Sofia'),role='capture',now_us=2)
    assert geo.assets_in_radius(latitude=52.37,longitude=4.90,radius_km=10)==('a1',)


def test_quick_search_matches_filename_title_notes_and_tags(tmp_path):
    f = factory(tmp_path)
    c = f.connect()
    c.execute(
        "INSERT INTO file_instances(public_id,asset_id,storage_mode,role,normalized_path,path_key,file_size,availability_state,sha256,created_at_us,modified_at_us) "
        "VALUES('f1',(SELECT id FROM assets WHERE public_id='a1'),'referenced','original','D:/Wildlife/grebe_spring.jpg','d:/wildlife/grebe_spring.jpg',1,'available',?,1,1)",
        ('1' * 64,),
    )
    c.execute("UPDATE assets SET primary_file_instance_id=(SELECT id FROM file_instances WHERE public_id='f1'), user_notes='reed bed' WHERE public_id='a1'")
    c.execute("INSERT INTO tags(public_id,normalized_name,display_name,created_at_us) VALUES('t1','waterbird','Waterbird',1)")
    c.execute("INSERT INTO asset_tags(asset_id,tag_id,source,created_at_us) SELECT a.id,t.id,'user',1 FROM assets a,tags t WHERE a.public_id='a1' AND t.public_id='t1'")
    c.commit()
    c.close()
    search = SqliteSearchAdapter(f)
    search.rebuild_fts()
    for text in ('grebe_spring', 'Great', 'reed', 'Waterbird'):
        result = search.search(SearchRequest(StructuredQuery(Predicate('text', PredicateOperator.CONTAINS, text))))
        assert [row.public_id for row in result.rows] == ['a1']
    assert result.rows[0].primary_path.endswith('grebe_spring.jpg')


def test_structured_filters_and_taxonomy_names(tmp_path):
    from natureai_next.application.search import QuickSearchService
    from natureai_next.domain.search import StructuredAssetFilters

    f = factory(tmp_path)
    c = f.connect()
    c.execute(
        "INSERT INTO file_instances(public_id,asset_id,storage_mode,role,normalized_path,path_key,file_size,availability_state,sha256,created_at_us,modified_at_us) "
        "VALUES('f1',(SELECT id FROM assets WHERE public_id='a1'),'referenced','original','D:/Wildlife/robin.jpg','d:/wildlife/robin.jpg',1,'available',?,1,1)",
        ('2' * 64,),
    )
    c.execute(
        "UPDATE assets SET primary_file_instance_id=(SELECT id FROM file_instances WHERE public_id='f1'), "
        "color_label='green',pick_state='pick',capture_time_utc_us=150 WHERE public_id='a1'"
    )
    c.execute("INSERT INTO image_properties(asset_id,pixel_width,pixel_height,orientation) SELECT id,4000,3000,1 FROM assets WHERE public_id='a1'")
    c.execute("INSERT INTO tags(public_id,normalized_name,display_name,created_at_us) VALUES('bird-tag','birds','Birds',1)")
    c.execute("INSERT INTO asset_tags(asset_id,tag_id,source,created_at_us) SELECT a.id,t.id,'user',1 FROM assets a,tags t WHERE a.public_id='a1' AND t.public_id='bird-tag'")
    c.execute("INSERT INTO taxonomy_sources(public_id,name,source_version,package_checksum,license_json,installed_at_us,active) VALUES('source','Test','1','x','{}',1,1)")
    c.execute(
        "INSERT INTO taxa(source_id,source_taxon_id,public_id,scientific_name,rank,status,kingdom) "
        "VALUES((SELECT id FROM taxonomy_sources WHERE public_id='source'),'1','taxon-robin','Erithacus rubecula','species','accepted','Animalia')"
    )
    c.execute("INSERT INTO taxon_names(taxon_id,language_tag,region_code,name,name_type,preferred,source) SELECT id,'en',NULL,'European Robin','vernacular',1,'Test' FROM taxa WHERE public_id='taxon-robin'")
    c.execute(
        "INSERT INTO observations(public_id,asset_id,taxon_id,observation_type,confirmation_state,source,created_at_us,modified_at_us,revision) "
        "SELECT 'obs-robin',a.id,t.id,'organism','confirmed','user',1,1,1 FROM assets a,taxa t WHERE a.public_id='a1' AND t.public_id='taxon-robin'"
    )
    c.commit()
    c.close()

    service = QuickSearchService(SqliteSearchAdapter(f))
    filters = StructuredAssetFilters(
        minimum_rating=4,
        color_label='green',
        pick_state='pick',
        captured_from_us=100,
        captured_to_us=200,
        minimum_width=3000,
        minimum_height=2000,
        tag='Birds',
        taxonomy_name='European Robin',
    )
    result = service.page(filters=filters, limit=20)
    assert [row.public_id for row in result.rows] == ['a1']
    assert service.page(filters=StructuredAssetFilters(taxonomy_name='rubecula'), limit=20).rows[0].public_id == 'a1'
    assert service.page(filters=StructuredAssetFilters(taxonomy_name='European'), limit=20).rows[0].public_id == 'a1'
    assert service.page(filters=StructuredAssetFilters(minimum_width=5000), limit=20).rows == ()


def test_calendar_date_filters_use_utc_or_exif_local_capture_date(tmp_path):
    from datetime import datetime, timezone
    from natureai_next.application.search import QuickSearchService
    from natureai_next.domain.search import StructuredAssetFilters

    f = factory(tmp_path)
    c = f.connect()
    utc_us = int(datetime(2024, 5, 10, 23, 30, tzinfo=timezone.utc).timestamp() * 1_000_000)
    c.execute("UPDATE assets SET capture_time_utc_us=? WHERE public_id='a1'", (utc_us,))
    c.execute("UPDATE assets SET capture_local_text='2024:05:11 08:15:00' WHERE public_id='a2'")
    c.commit()
    c.close()

    service = QuickSearchService(SqliteSearchAdapter(f))
    may_10 = service.page(filters=StructuredAssetFilters(
        captured_from_date='2024-05-10', captured_to_date='2024-05-10'
    ), limit=20)
    assert [row.public_id for row in may_10.rows] == ['a1']

    may_11 = service.page(filters=StructuredAssetFilters(
        captured_from_date='2024-05-11', captured_to_date='2024-05-11'
    ), limit=20)
    assert [row.public_id for row in may_11.rows] == ['a2']

    inclusive = service.page(filters=StructuredAssetFilters(
        captured_from_date='2024-05-10', captured_to_date='2024-05-11'
    ), limit=20)
    assert [row.public_id for row in inclusive.rows] == ['a1', 'a2']


def test_library_views_service_saved_search_and_manual_collection(tmp_path):
    from datetime import UTC, datetime
    from uuid import UUID

    from natureai_next.application.search import LibraryViewsService
    from natureai_next.domain.search import StructuredAssetFilters

    class Clock:
        def now_utc(self):
            return datetime(2026, 7, 13, 10, 0, tzinfo=UTC)

    class Ids:
        values = iter((UUID('00000000-0000-0000-0000-000000000101'), UUID('00000000-0000-0000-0000-000000000102')))
        def new_uuid(self):
            return next(self.values)

    f = factory(tmp_path)
    search = SqliteSearchAdapter(f)
    service = LibraryViewsService(
        saved=SqliteSavedSearchAdapter(f),
        collections=SqliteCollectionAdapter(f),
        search=search,
        clock=Clock(),
        ids=Ids(),
    )

    saved = service.save_current_search(
        name='Top wildlife', text='', filters=StructuredAssetFilters(minimum_rating=4)
    )
    assert saved.name == 'Top wildlife'
    assert [row.public_id for row in service.page_saved_search(public_id=saved.public_id, limit=10).rows] == ['a1']

    service.create_manual_collection(name='Publication candidates')
    collection = service.list_collections()[0]
    service.add_assets_to_collection(collection_public_id=collection.public_id, asset_public_ids=('a1', 'a1'))
    rows = service.page_collection(public_id=collection.public_id, limit=10).rows
    assert [row.public_id for row in rows] == ['a1']
    assert service.list_collections()[0].asset_count == 1

    service.delete_saved_search(saved.public_id)
    assert service.list_saved_searches() == ()

def test_collection_management_and_smart_collection(tmp_path):
    from datetime import UTC, datetime
    from uuid import UUID

    from natureai_next.application.search import LibraryViewsService
    from natureai_next.domain.search import StructuredAssetFilters

    class Clock:
        def now_utc(self):
            return datetime(2026, 7, 13, 10, 0, tzinfo=UTC)

    class Ids:
        values = iter((
            UUID('00000000-0000-0000-0000-000000000201'),
            UUID('00000000-0000-0000-0000-000000000202'),
        ))
        def new_uuid(self):
            return next(self.values)

    f = factory(tmp_path)
    service = LibraryViewsService(
        saved=SqliteSavedSearchAdapter(f),
        collections=SqliteCollectionAdapter(f),
        search=SqliteSearchAdapter(f),
        clock=Clock(),
        ids=Ids(),
    )

    service.create_manual_collection(name='Candidates', description='Initial')
    manual = service.list_collections()[0]
    service.add_assets_to_collection(collection_public_id=manual.public_id, asset_public_ids=('a1',))
    service.update_collection(public_id=manual.public_id, name='Publication candidates', description='Ready')
    updated = next(item for item in service.list_collections() if item.public_id == manual.public_id)
    assert updated.name == 'Publication candidates'
    assert updated.description == 'Ready'
    assert updated.asset_count == 1

    service.remove_assets_from_collection(collection_public_id=manual.public_id, asset_public_ids=('a1',))
    assert service.page_collection(public_id=manual.public_id, limit=10).rows == ()

    service.create_smart_collection(
        name='Top rated', text='', filters=StructuredAssetFilters(minimum_rating=4), description='Dynamic'
    )
    smart = next(item for item in service.list_collections() if item.collection_type == 'smart')
    assert [row.public_id for row in service.page_collection(public_id=smart.public_id, limit=10).rows] == ['a1']

    service.delete_collection(manual.public_id)
    assert all(item.public_id != manual.public_id for item in service.list_collections())
