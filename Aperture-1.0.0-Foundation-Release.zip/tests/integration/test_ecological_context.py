from pathlib import Path
from natureai_next.application.ecology import EcologicalContextService
from natureai_next.infrastructure.database.connection import SqliteConnectionFactory
from natureai_next.infrastructure.database.ecology import SqliteEcologicalContextStore
from natureai_next.infrastructure.database.migrations import CORE_MIGRATIONS
from natureai_next.infrastructure.database.migrations.core import MigrationRunner


def test_import_and_query_ecological_context(tmp_path: Path):
    db=tmp_path/'library.sqlite3'; factory=SqliteConnectionFactory(db); c0=factory.connect(); MigrationRunner(CORE_MIGRATIONS,'0.16.1').apply(c0); c0.close()
    c=factory.connect();
    try:
        c.execute("INSERT INTO taxonomy_sources(public_id,name,source_version,package_checksum,license_json,installed_at_us,active) VALUES('source-1','Test','1','x','{}',1,1)"); source_id=c.execute('SELECT id FROM taxonomy_sources').fetchone()[0]; c.execute("INSERT INTO taxa(source_id,source_taxon_id,public_id,scientific_name,rank,status) VALUES(?, '1','taxon-1','Erithacus rubecula','species','accepted')",(source_id,))
    finally:c.close()
    csv_path=tmp_path/'ecology.csv'
    csv_path.write_text('scientific_name,conservation_status,seasonal_months,migration_status,habitats,source_name,source_version,source_url\nErithacus rubecula,LC,"1,2,3",resident,"forest;garden",Test,2026,https://example.invalid\nUnknown taxon,EN,1,migrant,wetland,Test,2026,https://example.invalid\n',encoding='utf-8')
    service=EcologicalContextService(SqliteEcologicalContextStore(factory),now_us=lambda:42)
    assert service.import_csv(csv_path)==1
    item=service.for_taxon('taxon-1')
    assert item is not None
    assert item.conservation_status=='LC'
    assert item.seasonal_months==(1,2,3)
    assert item.habitats==('forest','garden')
    assert item.season_label(2)=='Expected this month'
    assert item.season_label(8)=='Outside recorded season'
    assert service.import_csv(csv_path)==1
    assert service.count()==1

def test_preview_normalizes_authorship_and_hybrid_symbol(tmp_path: Path):
    db=tmp_path/'library.sqlite3'; factory=SqliteConnectionFactory(db); c0=factory.connect(); MigrationRunner(CORE_MIGRATIONS,'0.16.1').apply(c0); c0.close()
    c=factory.connect()
    try:
        c.execute("INSERT INTO taxonomy_sources(public_id,name,source_version,package_checksum,license_json,installed_at_us,active) VALUES('source-1','Test','1','x','{}',1,1)")
        source_id=c.execute('SELECT id FROM taxonomy_sources').fetchone()[0]
        c.execute("INSERT INTO taxa(source_id,source_taxon_id,public_id,scientific_name,authorship,rank,status) VALUES(?, '1','taxon-cat','Felis catus','Linnaeus','species','accepted')",(source_id,))
        c.execute("INSERT INTO taxa(source_id,source_taxon_id,public_id,scientific_name,authorship,rank,status) VALUES(?, '2','taxon-elm','Ulmus × hollandica','Mill.','species','accepted')",(source_id,))
    finally:c.close()
    csv_path=tmp_path/'ecology.csv'
    csv_path.write_text('scientific_name,conservation_status,source_name\nFelis catus Linnaeus,LC,Test\nUlmus x hollandica Mill.,LC,Test\nNot in taxonomy,EN,Test\n',encoding='utf-8')
    service=EcologicalContextService(SqliteEcologicalContextStore(factory),now_us=lambda:42)
    preview=service.preview_csv(csv_path)
    assert preview.matched_count==2
    assert preview.unmatched_count==1
    assert [row.match_kind for row in preview.rows[:2]]==['normalized','normalized']
    assert service.import_preview(preview)==2
    report=tmp_path/'unmatched.csv'; assert service.write_unmatched_report(preview,report)==1
    assert 'Not in taxonomy' in report.read_text(encoding='utf-8-sig')
