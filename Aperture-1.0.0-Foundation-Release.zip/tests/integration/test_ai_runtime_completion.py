from __future__ import annotations

from pathlib import Path

from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
from PIL import Image

from natureai_next.application.ai import AIEmbeddingService, EmbeddingItem
from natureai_next.application.ai_runtime import InferenceRunService, VectorIndexService
from natureai_next.application.library_service import LibraryService
from natureai_next.domain.ai import EmbeddingVector
from natureai_next.infrastructure.ai.gpu import GpuResourceCoordinator
from natureai_next.infrastructure.ai.package import ModelPackageInstaller, ModelPackageVerifier, build_model_package
from natureai_next.infrastructure.ai.preprocessing import BioClipImagePreprocessor
from natureai_next.infrastructure.database.ai import SqliteAIRepository
from natureai_next.infrastructure.diagnostics.system_services import SystemClock, SystemUuidGenerator


class _Provider:
    identity = "fixture"
    def diagnostics(self): raise AssertionError
    def load(self, *args, **kwargs): return object()
    def embed_images(self, model, images): return tuple(EmbeddingVector((1.0, float(i + 1), 0.5)) for i, _ in enumerate(images))
    def embed_text(self, model, texts): return tuple(EmbeddingVector((1.0, 0.0, 0.0)) for _ in texts)
    def unload(self, model): return None
    def clear_device_cache(self): return None


def _install(opened, tmp_path: Path) -> int:
    key = Ed25519PrivateKey.generate()
    public = key.public_key().public_bytes(serialization.Encoding.Raw, serialization.PublicFormat.Raw)
    manifest = {
        "package_id": "runtime-fixture", "model_identity": "bioclip", "semantic_version": "1.0.0",
        "model_family": "bioclip", "upstream_source": "fixture", "license_name": "MIT",
        "attribution_text": "fixture", "minimum_application_version": "0.1.0", "signing_key_id": "test",
        "variants": [{"identity":"fp32","runtime":"torch","precision":"fp32","providers":["cpu"],
        "preprocessing_identity":"prep-v1","embedding_dimension":3,"input_size":32,
        "normalized_output":True,"artifact_path":"model.pt"}],
    }
    package = build_model_package(tmp_path / "model.zip", private_key=key, manifest=manifest, artifacts={"model.pt": b"x"})
    ModelPackageInstaller(opened.connection_factory, tmp_path / "models", ModelPackageVerifier({"test": public})).install(package)
    variant = SqliteAIRepository(opened.connection_factory).active_variant("bioclip")
    assert variant is not None
    return variant.id


def test_inference_run_and_index_fallback(tmp_path: Path) -> None:
    opened = LibraryService(SystemClock(), SystemUuidGenerator()).create(tmp_path / "library", display_name="AI")
    try:
        variant_id = _install(opened, tmp_path)
        connection = opened.connection_factory.connect()
        for index in range(2):
            connection.execute("INSERT INTO assets(public_id,media_type,lifecycle_state,created_at_us,modified_at_us) VALUES(?, 'image','active',1,1)", (f"a{index}",))
        connection.close()
        items = []
        for index in range(2):
            path = tmp_path / f"{index}.jpg"
            Image.new("RGB", (40, 30), (index * 30, 0, 0)).save(path)
            items.append(EmbeddingItem(f"a{index}", path, None))
        repository = SqliteAIRepository(opened.connection_factory)
        embedding = AIEmbeddingService(repository, _Provider(), BioClipImagePreprocessor(32, "prep-v1"), GpuResourceCoordinator())
        result = InferenceRunService(repository, embedding).embed_images(
            model=object(), model_variant_id=variant_id, precision="fp32", items=items,
            initial_batch_size=2, execution_provider="fixture:cpu", device="cpu",
        )
        assert len(result.completed) == 2
        connection = opened.connection_factory.connect(read_only=True)
        run = connection.execute("SELECT outcome,completed_item_count,failed_item_count FROM inference_runs").fetchone()
        connection.close()
        assert tuple(run) == ("succeeded", 2, 0)
        indexes = VectorIndexService(repository, tmp_path / "indexes")
        built = indexes.rebuild(variant_id, "prep-v1")
        assert indexes.parity(variant_id, "prep-v1", built.directory)
        (built.directory / "vectors.bin").write_bytes(b"corrupt")
        matches = indexes.search_with_fallback(index_id=built.index_id, directory=built.directory,
            model_variant_id=variant_id, preprocessing_identity="prep-v1", query=EmbeddingVector((1, 1, .5)), limit=2)
        assert len(matches) == 2
        connection = opened.connection_factory.connect(read_only=True)
        state = connection.execute("SELECT state FROM vector_index_generations WHERE id=?", (built.index_id,)).fetchone()[0]
        connection.close()
        assert state == "corrupt"
    finally:
        opened.close()
