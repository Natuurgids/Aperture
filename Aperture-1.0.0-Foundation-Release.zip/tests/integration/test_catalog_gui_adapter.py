from datetime import datetime, timezone
from pathlib import Path
from uuid import uuid4

from PIL import Image

from natureai_next.application.import_service import ImportService
from natureai_next.application.library_service import LibraryService
from natureai_next.domain.importing import DuplicatePolicy, ImportStoragePolicy
from natureai_next.infrastructure.database.catalog_gui import SqliteCatalogGuiAdapter
from natureai_next.ports.catalog_queries import MetadataPatch
from natureai_next.infrastructure.database.unit_of_work import SqliteUnitOfWork
from natureai_next.infrastructure.filesystem.importing import (
    DirectorySourceScanner,
    ShardedManagedFileStore,
    StreamingFileFingerprinter,
)
from natureai_next.infrastructure.imaging.pillow_adapter import PillowImageDecoder
from natureai_next.infrastructure.metadata.pillow_reader import PillowMetadataReader


class Clock:
    def now_utc(self):
        return datetime.now(timezone.utc)


class Ids:
    def new_uuid(self):
        return uuid4()


def test_catalog_adapter_pages_imported_assets_with_derivative_schema(tmp_path: Path) -> None:
    source = tmp_path / "bird.jpg"
    Image.new("RGB", (40, 20), "red").save(source)
    opened = LibraryService(Clock(), Ids()).create(tmp_path / "library", display_name="Catalog")
    fingerprinter = StreamingFileFingerprinter(chunk_size=1024)
    service = ImportService(
        uow_factory=lambda: SqliteUnitOfWork(opened.connection_factory),
        scanner=DirectorySourceScanner(),
        fingerprinter=fingerprinter,
        managed_store=ShardedManagedFileStore(opened.layout.managed_originals, fingerprinter),
        decoder=PillowImageDecoder(),
        metadata_reader=PillowMetadataReader(),
        clock=Clock(),
        ids=Ids(),
    )
    try:
        summary = service.execute(
            service.plan(
                [source],
                storage_policy=ImportStoragePolicy.REFERENCED,
                duplicate_policy=DuplicatePolicy.SKIP,
            )
        )
        assert summary.imported == 1
        adapter = SqliteCatalogGuiAdapter(opened.connection_factory)
        page = adapter.page_assets(limit=20)
        assert page.total_count == 1
        assert len(page.rows) == 1
        assert page.rows[0].primary_path == str(source.resolve())
        assert page.rows[0].thumbnail_path is None
        detail = adapter.get_asset_detail(page.rows[0].public_id)
        assert detail is not None
        assert detail.pixel_width == 40
        assert detail.pixel_height == 20
    finally:
        opened.close()


def test_catalog_adapter_saves_metadata_and_tags_atomically(tmp_path: Path) -> None:
    source = tmp_path / "flower.jpg"
    Image.new("RGB", (30, 30), "green").save(source)
    opened = LibraryService(Clock(), Ids()).create(tmp_path / "library-metadata", display_name="Metadata")
    fingerprinter = StreamingFileFingerprinter(chunk_size=1024)
    service = ImportService(
        uow_factory=lambda: SqliteUnitOfWork(opened.connection_factory),
        scanner=DirectorySourceScanner(),
        fingerprinter=fingerprinter,
        managed_store=ShardedManagedFileStore(opened.layout.managed_originals, fingerprinter),
        decoder=PillowImageDecoder(),
        metadata_reader=PillowMetadataReader(),
        clock=Clock(),
        ids=Ids(),
    )
    try:
        assert service.execute(
            service.plan(
                [source],
                storage_policy=ImportStoragePolicy.REFERENCED,
                duplicate_policy=DuplicatePolicy.SKIP,
            )
        ).imported == 1
        original_bytes = source.read_bytes()
        original_mtime_ns = source.stat().st_mtime_ns
        adapter = SqliteCatalogGuiAdapter(opened.connection_factory)
        public_id = adapter.page_assets(limit=10).rows[0].public_id
        detail = adapter.get_asset_detail(public_id)
        assert detail is not None
        result = adapter.update_metadata_and_tags(
            public_id=public_id,
            expected_revision=detail.revision,
            patch=MetadataPatch(
                title="Green flower",
                caption="Catalog caption",
                user_notes="Observed locally",
                rating=5,
                color_label="green",
                pick_state="pick",
            ),
            tag_names=("Flower", "Bulgaria", "flower"),
            modified_at_us=1_700_000_000_000_000,
        )
        assert result.new_revision == detail.revision + 1
        saved = adapter.get_asset_detail(public_id)
        assert saved is not None
        assert saved.title == "Green flower"
        assert saved.caption == "Catalog caption"
        assert saved.user_notes == "Observed locally"
        assert saved.rating == 5
        assert saved.color_label == "green"
        assert saved.pick_state == "pick"
        assert saved.tags == ("Bulgaria", "Flower")
        with __import__("pytest").raises(RuntimeError, match="asset_revision_conflict"):
            adapter.update_metadata_and_tags(
                public_id=public_id,
                expected_revision=detail.revision,
                patch=MetadataPatch(None, None, None, None, None, None),
                tag_names=(),
                modified_at_us=1_700_000_000_000_001,
            )
        still_saved = adapter.get_asset_detail(public_id)
        assert still_saved is not None
        assert still_saved.title == "Green flower"
        assert still_saved.tags == ("Bulgaria", "Flower")
        assert source.read_bytes() == original_bytes
        assert source.stat().st_mtime_ns == original_mtime_ns
    finally:
        opened.close()


def test_catalog_adapter_pages_exact_import_session_ids(tmp_path: Path) -> None:
    sources = []
    for index, color in enumerate(("red", "green", "blue"), start=1):
        source = tmp_path / f"bird-{index}.jpg"
        Image.new("RGB", (20 + index, 20), color).save(source)
        sources.append(source)
    opened = LibraryService(Clock(), Ids()).create(tmp_path / "library-import-session", display_name="Session")
    fingerprinter = StreamingFileFingerprinter(chunk_size=1024)
    service = ImportService(
        uow_factory=lambda: SqliteUnitOfWork(opened.connection_factory),
        scanner=DirectorySourceScanner(), fingerprinter=fingerprinter,
        managed_store=ShardedManagedFileStore(opened.layout.managed_originals, fingerprinter),
        decoder=PillowImageDecoder(), metadata_reader=PillowMetadataReader(), clock=Clock(), ids=Ids(),
    )
    try:
        summary = service.execute(service.plan(sources, storage_policy=ImportStoragePolicy.REFERENCED, duplicate_policy=DuplicatePolicy.SKIP))
        ids = tuple(result.asset_public_id for result in summary.results if result.asset_public_id)
        adapter = SqliteCatalogGuiAdapter(opened.connection_factory)
        selected = adapter.page_assets_by_public_ids((ids[2], ids[0]))
        assert selected.total_count == 2
        assert {row.public_id for row in selected.rows} == {ids[0], ids[2]}
        assert selected.next_cursor is None
    finally:
        opened.close()
