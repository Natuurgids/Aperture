from datetime import datetime,timezone
from pathlib import Path
from uuid import UUID
import pytest
from natureai_next.application.library_service import LibraryService
from natureai_next.infrastructure.database.unit_of_work import SqliteUnitOfWork
from natureai_next.domain.catalog import Asset,AssetLifecycle,MediaType
from natureai_next.infrastructure.filesystem.library_lock import LibraryLockedError

class Clock:
    def now_utc(self)->datetime:return datetime(2026,1,2,tzinfo=timezone.utc)
class Ids:
    value=0
    def new_uuid(self)->UUID:
        self.value+=1;return UUID(int=self.value)

def test_create_use_backup_close_reopen(tmp_path:Path)->None:
    service=LibraryService(Clock(),Ids())
    opened=service.create(tmp_path/'Wildlife',display_name='Wildlife')
    with SqliteUnitOfWork(opened.connection_factory) as uow:
        stored=uow.assets.add(Asset('asset-1',MediaType.IMAGE,AssetLifecycle.ACTIVE,1,1,title='Bird'))
        assert stored.id==1;uow.commit()
    backup=opened.backup_database(opened.layout.backups/'first.sqlite3')
    assert backup.exists() and opened.integrity().healthy
    with pytest.raises(LibraryLockedError):service.open(opened.layout.root)
    opened.close()
    reopened=service.open(tmp_path/'Wildlife')
    try:
        c=reopened.connection_factory.connect(read_only=True)
        try:assert c.execute('SELECT title FROM assets').fetchone()[0]=='Bird'
        finally:c.close()
    finally:reopened.close()
    assert not reopened.layout.lock_file.exists()

def test_stale_same_host_lock_is_recovered(tmp_path: Path) -> None:
    import json
    import socket

    service = LibraryService(Clock(), Ids())
    opened = service.create(tmp_path / 'Stale', display_name='Stale')
    root = opened.layout.root
    lock_path = opened.layout.lock_file
    opened.close()
    lock_path.write_text(json.dumps({
        'pid': 2_000_000_000,
        'host': socket.gethostname(),
        'created_at_us': 1,
    }), encoding='utf-8')

    reopened = service.open(root)
    try:
        assert reopened.layout.lock_file.exists()
    finally:
        reopened.close()
    assert not lock_path.exists()


def test_foreign_host_lock_is_not_removed(tmp_path: Path) -> None:
    import json

    service = LibraryService(Clock(), Ids())
    opened = service.create(tmp_path / 'Foreign', display_name='Foreign')
    root = opened.layout.root
    lock_path = opened.layout.lock_file
    opened.close()
    lock_path.write_text(json.dumps({
        'pid': 2_000_000_000,
        'host': 'another-computer',
        'created_at_us': 1,
    }), encoding='utf-8')

    with pytest.raises(LibraryLockedError):
        service.open(root)
    assert lock_path.exists()

def test_open_library_close_is_idempotent(tmp_path):
    service = LibraryService(Clock(), Ids())
    opened = service.create(tmp_path / "idempotent", display_name="Idempotent")
    opened.close()
    opened.close()
    assert not opened.layout.lock_file.exists()
