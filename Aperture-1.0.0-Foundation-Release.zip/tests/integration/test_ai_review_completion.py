from __future__ import annotations

import itertools
import json
from pathlib import Path

import pytest

from natureai_next.application.ai_review import PromptSetService, ReviewFilter, SuggestionService
from natureai_next.application.library_service import LibraryService
from natureai_next.domain.ai import ConfidenceBand, SuggestionCandidate
from natureai_next.infrastructure.ai.prompts import load_prompt_set, prompt_set_checksum, validate_prompt_set
from natureai_next.infrastructure.database.ai_review import (
    SqlitePromptSetStore,
    SqliteSuggestionStore,
)
from natureai_next.infrastructure.diagnostics.system_services import SystemClock, SystemUuidGenerator


def _seed(opened):
    connection = opened.connection_factory.connect()
    connection.execute(
        "INSERT INTO assets(public_id,media_type,lifecycle_state,title,created_at_us,modified_at_us) "
        "VALUES('asset-1','image','active','Bee orchid',1,1)"
    )
    connection.execute(
        "INSERT INTO assets(public_id,media_type,lifecycle_state,created_at_us,modified_at_us) "
        "VALUES('asset-2','image','active',1,1)"
    )
    connection.execute(
        "INSERT INTO taxonomy_sources(public_id,name,source_version,package_checksum,license_json,"
        "installed_at_us,active,attribution_text,manifest_json) "
        "VALUES('source-1','Fixture','1.0','checksum','{}',1,1,'Fixture','{}')"
    )
    source_id = connection.execute(
        "SELECT id FROM taxonomy_sources WHERE public_id='source-1'"
    ).fetchone()[0]
    connection.execute(
        "INSERT INTO taxa(public_id,source_id,source_taxon_id,scientific_name,rank,status) "
        "VALUES('taxon-1',?,'1','Ophrys apifera','species','accepted')",
        (source_id,),
    )
    taxon_id = connection.execute("SELECT id FROM taxa WHERE public_id='taxon-1'").fetchone()[0]
    connection.execute(
        "INSERT INTO taxon_regions(taxon_id,region_code,occurrence_status,source) "
        "VALUES(?,'NL','native','fixture')",
        (taxon_id,),
    )
    connection.execute(
        "INSERT INTO model_packages(public_id,model_identity,semantic_version,model_family,"
        "artifact_checksum,manifest_json,license_json,install_path_token,installation_state,"
        "installed_at_us,active) "
        "VALUES('pkg','bioclip','1','bioclip','x','{}','{}','x','installed',1,1)"
    )
    package_id = connection.execute("SELECT id FROM model_packages WHERE public_id='pkg'").fetchone()[0]
    connection.execute(
        "INSERT INTO model_variants(public_id,package_id,variant_identity,runtime,precision,"
        "device_requirements_json,preprocessing_identity,embedding_dimension,active) "
        "VALUES('variant',?,'v','torch','fp32','{}','prep',2,1)",
        (package_id,),
    )
    variant_id = connection.execute(
        "SELECT id FROM model_variants WHERE public_id='variant'"
    ).fetchone()[0]
    connection.execute(
        "INSERT INTO inference_runs(public_id,model_variant_id,execution_provider,parameter_json,"
        "application_version,started_at_us,outcome,precision) "
        "VALUES('run',?,'fake','{}','0.9.1',1,'succeeded','fp32')",
        (variant_id,),
    )
    run_id = connection.execute("SELECT id FROM inference_runs WHERE public_id='run'").fetchone()[0]
    connection.commit()
    connection.close()
    return run_id


def _create_suggestions(store: SqliteSuggestionStore, run_id: int) -> tuple[str, str]:
    ids = iter(("suggestion-1", "suggestion-2"))
    created = store.create_suggestions(
        asset_public_id="asset-1",
        inference_run_id=run_id,
        suggestions=(
            SuggestionCandidate(
                "taxon-1", "Ophrys apifera", 0.8, 0.82, 1, ConfidenceBand.HIGH, "species"
            ),
            SuggestionCandidate(
                "taxon-1", "Ophrys apifera", 0.7, 0.72, 2, ConfidenceBand.MEDIUM, "species"
            ),
        ),
        provenance={"model": "bioclip", "preprocessing": "prep"},
        geographic_context={"region": "NL"},
        now_us=10,
        id_factory=lambda: next(ids),
    )
    return created[0], created[1]


def test_prompt_set_install_activation_and_compatibility(tmp_path: Path):
    opened = LibraryService(SystemClock(), SystemUuidGenerator()).create(
        tmp_path / "lib", display_name="Prompt sets"
    )
    try:
        path = tmp_path / "prompts.json"
        path.write_text(
            json.dumps(
                {
                    "schema_version": 1,
                    "identity": "europe-plants",
                    "semantic_version": "1.0.0",
                    "model_family": "bioclip",
                    "minimum_application_version": "0.9.0",
                    "prompts": [
                        {
                            "label": "Bee orchid",
                            "text": "a wildlife photograph of Ophrys apifera",
                            "taxon_public_id": "taxon-1",
                            "broad_group": "flowering_plants",
                        }
                    ],
                }
            ),
            encoding="utf-8",
        )
        service = PromptSetService(
            SqlitePromptSetStore(opened.connection_factory),
            loader=load_prompt_set,
            checksum=prompt_set_checksum,
            validator=validate_prompt_set,
        )
        installed = service.install(
            path,
            public_id="prompt-set-1",
            now_us=20,
            activate=True,
            model_family="bioclip",
        )
        assert installed.active
        assert service.list()[0].checksum == installed.checksum
        with pytest.raises(ValueError, match="incompatible"):
            service.install(
                path,
                public_id="prompt-set-2",
                now_us=21,
                model_family="different-model",
            )
    finally:
        opened.close()


def test_batch_review_is_atomic_and_emits_audit_and_outbox(tmp_path: Path):
    opened = LibraryService(SystemClock(), SystemUuidGenerator()).create(
        tmp_path / "lib", display_name="Batch review"
    )
    try:
        run_id = _seed(opened)
        store = SqliteSuggestionStore(opened.connection_factory)
        first, second = _create_suggestions(store, run_id)
        action_ids = itertools.count(1)
        result = store.batch_review(
            (first, second),
            action="reject",
            action_id_factory=lambda: f"batch-{next(action_ids)}",
            now_us=30,
            reason="not a match",
        )
        assert result.reviewed == (first, second)
        connection = opened.connection_factory.connect(read_only=True)
        try:
            assert connection.execute("SELECT count(*) FROM ai_review_actions").fetchone()[0] == 2
            assert connection.execute("SELECT count(*) FROM audit_log").fetchone()[0] == 2
            assert connection.execute("SELECT count(*) FROM event_outbox").fetchone()[0] == 2
        finally:
            connection.close()
    finally:
        opened.close()


def test_batch_review_rolls_back_every_item_on_failure(tmp_path: Path):
    opened = LibraryService(SystemClock(), SystemUuidGenerator()).create(
        tmp_path / "lib", display_name="Batch rollback"
    )
    try:
        run_id = _seed(opened)
        store = SqliteSuggestionStore(opened.connection_factory)
        first, _ = _create_suggestions(store, run_id)
        with pytest.raises(KeyError):
            store.batch_review(
                (first, "missing"),
                action="reject",
                action_id_factory=iter(("action-1", "action-2")).__next__,
                now_us=30,
            )
        assert store.page(state="pending").items[0].public_id == first
        connection = opened.connection_factory.connect(read_only=True)
        try:
            assert connection.execute("SELECT count(*) FROM ai_review_actions").fetchone()[0] == 0
            assert connection.execute("SELECT count(*) FROM audit_log").fetchone()[0] == 0
            assert connection.execute("SELECT count(*) FROM event_outbox").fetchone()[0] == 0
        finally:
            connection.close()
    finally:
        opened.close()


def test_supersession_and_detail_projection(tmp_path: Path):
    opened = LibraryService(SystemClock(), SystemUuidGenerator()).create(
        tmp_path / "lib", display_name="Supersession"
    )
    try:
        run_id = _seed(opened)
        store = SqliteSuggestionStore(opened.connection_factory)
        first, second = _create_suggestions(store, run_id)
        service = SuggestionService(store)
        service.supersede(
            first,
            second,
            action_public_id="supersede-1",
            now_us=40,
            reason="new model run",
        )
        detail = service.detail(second, region_code="NL")
        assert detail.taxon_scientific_name == "Ophrys apifera"
        assert detail.regional_occurrence_status == "native"
        assert detail.model_variant_public_id == "variant"
        assert store.page(state="superseded").items[0].public_id == first
    finally:
        opened.close()


def test_page_for_asset_isolates_one_photograph(tmp_path: Path):
    opened = LibraryService(SystemClock(), SystemUuidGenerator()).create(
        tmp_path / "lib", display_name="Photograph taxonomy"
    )
    try:
        run_id = _seed(opened)
        store = SqliteSuggestionStore(opened.connection_factory)
        first, second = _create_suggestions(store, run_id)
        store.create_suggestions(
            asset_public_id="asset-2",
            inference_run_id=run_id,
            suggestions=(
                SuggestionCandidate(
                    "taxon-1", "Ophrys apifera", 0.6, 0.62, 1, ConfidenceBand.MEDIUM, "species"
                ),
            ),
            provenance={"model": "bioclip"},
            geographic_context={},
            now_us=11,
            id_factory=lambda: "suggestion-asset-2",
        )
        page = SuggestionService(store).page_for_asset(
            "asset-1", filter=ReviewFilter()
        )
        assert tuple(item.public_id for item in page.items) == (first, second)
        assert {item.asset_public_id for item in page.items} == {"asset-1"}
    finally:
        opened.close()


def test_accept_and_reject_others_resolves_one_photograph_atomically(tmp_path: Path):
    opened = LibraryService(SystemClock(), SystemUuidGenerator()).create(
        tmp_path / "lib", display_name="Resolve photograph"
    )
    try:
        run_id = _seed(opened)
        store = SqliteSuggestionStore(opened.connection_factory)
        first, second = _create_suggestions(store, run_id)
        sequence = itertools.count(1)
        result = SuggestionService(store).accept_and_reject_others(
            first,
            action_id_factory=lambda: f"resolve-{next(sequence)}",
            now_us=50,
        )
        assert result.reviewed == (first, second)
        assert store.detail(first).suggestion.review_state.value == "accepted"
        assert store.detail(second).suggestion.review_state.value == "rejected"
        connection = opened.connection_factory.connect(read_only=True)
        try:
            assert connection.execute("SELECT count(*) FROM observations").fetchone()[0] == 1
            assert connection.execute("SELECT count(*) FROM ai_review_actions").fetchone()[0] == 2
        finally:
            connection.close()
    finally:
        opened.close()


def test_reject_other_options_after_acceptance(tmp_path: Path):
    opened = LibraryService(SystemClock(), SystemUuidGenerator()).create(
        tmp_path / "lib", display_name="Reject alternatives"
    )
    try:
        run_id = _seed(opened)
        store = SqliteSuggestionStore(opened.connection_factory)
        first, second = _create_suggestions(store, run_id)
        service = SuggestionService(store)
        service.accept(first, action_public_id="accept-one", now_us=50)
        result = service.reject_other_suggestions(
            first,
            action_id_factory=lambda: "reject-other",
            now_us=51,
        )
        assert result.reviewed == (second,)
        assert store.detail(first).suggestion.review_state.value == "accepted"
        assert store.detail(second).suggestion.review_state.value == "rejected"
    finally:
        opened.close()
