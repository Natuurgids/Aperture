from __future__ import annotations
import json
from pathlib import Path
import pytest
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
from natureai_next.application.library_service import LibraryService
from natureai_next.domain.taxonomy import LicenseMetadata,ObservationDraft,ObservationType,RegionOfInterestDraft
from natureai_next.infrastructure.database.taxonomy import SqliteObservationAdapter,SqliteTaxonomyAdapter,SqliteUserTaxonAdapter
from natureai_next.infrastructure.diagnostics.system_services import SystemClock,SystemUuidGenerator
from natureai_next.infrastructure.taxonomy.package import Ed25519TaxonomyPackageVerifier,build_taxonomy_package

@pytest.fixture
def opened(tmp_path:Path):
    value=LibraryService(SystemClock(),SystemUuidGenerator()).create(tmp_path/'library',display_name='Taxonomy')
    c=value.connection_factory.connect();now=1
    c.execute("INSERT INTO assets(public_id,media_type,lifecycle_state,created_at_us,modified_at_us) VALUES('asset-1','image','active',?,?)",(now,now));c.close()
    try:yield value
    finally:value.close()

def package(tmp_path:Path,*,cycle:bool=False):
    key=Ed25519PrivateKey.generate();public=key.public_key().public_bytes(serialization.Encoding.Raw,serialization.PublicFormat.Raw)
    taxa=[{'source_taxon_id':'root','scientific_name':'Animalia','rank':'kingdom','status':'accepted'},{'source_taxon_id':'bird','scientific_name':'Aves','rank':'class','status':'accepted','parent_source_taxon_id':'root'},{'source_taxon_id':'old','scientific_name':'Old bird','rank':'class','status':'synonym','accepted_source_taxon_id':'bird'}]
    if cycle:taxa[0]['parent_source_taxon_id']='bird'
    path=build_taxonomy_package(tmp_path/'tax.zip',private_key=key,key_id='test',package_id='pkg-1',source_name='TestTax',source_version='1',minimum_app_version='0.1.0',license_metadata=LicenseMetadata('CC0',None,'Test attribution',True),taxa=taxa,names=[{'source_taxon_id':'bird','name':'Birds','name_type':'vernacular','source':'test','language_tag':'en','region_code':'NL','preferred':True}],regions=[{'source_taxon_id':'bird','region_code':'NL','occurrence_status':'native','source':'test'}])
    return path,Ed25519TaxonomyPackageVerifier({'test':public})

def test_signed_install_search_closure_and_observation(opened,tmp_path):
    path,verifier=package(tmp_path);data=verifier.verify(path);catalog=SqliteTaxonomyAdapter(opened.connection_factory);source_id=catalog.install(data,now_us=2)
    assert catalog.verify_closure(source_id)==(4,4)
    found=catalog.search('Bird',language_tag='en',region_code='NL');assert found[0].scientific_name=='Aves';assert found[0].preferred_name=='Birds'
    obs=SqliteObservationAdapter(opened.connection_factory);created=obs.create(public_id='obs-1',asset_public_id='asset-1',draft=ObservationDraft(ObservationType.ORGANISM,taxon_public_id=found[0].public_id),now_us=3)
    updated=obs.update(public_id='obs-1',expected_revision=1,draft=ObservationDraft(ObservationType.ORGANISM,taxon_public_id=found[0].public_id,notes='confirmed'),now_us=4)
    assert updated.revision==2
    c=opened.connection_factory.connect();assert c.execute('SELECT COUNT(*) FROM observation_revisions').fetchone()[0]==2;c.close()

def test_failed_cycle_leaves_prior_active(opened,tmp_path):
    path,verifier=package(tmp_path);catalog=SqliteTaxonomyAdapter(opened.connection_factory);catalog.install(verifier.verify(path),now_us=2)
    cycle_path,cycle_verifier=package(tmp_path/'cycle',cycle=True)
    with pytest.raises(ValueError,match='cycle'):catalog.install(cycle_verifier.verify(cycle_path),now_us=3)
    assert len(catalog.active_sources())==1

def test_signature_and_payload_tamper_rejected(tmp_path):
    path,verifier=package(tmp_path)
    import zipfile
    with zipfile.ZipFile(path,'a') as z:z.writestr('taxa.jsonl',b'{}\n')
    with pytest.raises(ValueError,match='checksum'):verifier.verify(path)

def test_user_taxon_mapping_and_roi(opened,tmp_path):
    path,verifier=package(tmp_path);catalog=SqliteTaxonomyAdapter(opened.connection_factory);catalog.install(verifier.verify(path),now_us=2);taxon=catalog.search('Aves')[0]
    users=SqliteUserTaxonAdapter(opened.connection_factory);users.create(public_id='u1',display_name='Mystery bird',scientific_name=None,rank=None,now_us=3);users.map_to_taxon(user_taxon_public_id='u1',taxon_public_id=taxon.public_id,now_us=4)
    obs=SqliteObservationAdapter(opened.connection_factory);assert obs.create_roi(public_id='roi1',asset_public_id='asset-1',draft=RegionOfInterestDraft('rectangle',{'points':[[0.1,0.2],[0.4,0.6]]}),now_us=5)=='roi1'
