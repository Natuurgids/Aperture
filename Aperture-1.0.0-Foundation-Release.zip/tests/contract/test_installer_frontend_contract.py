from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def test_cmd_uses_installer_frontend_and_forwards_arguments() -> None:
    text = (ROOT / 'Install Aperture.cmd').read_text(encoding='utf-8')
    assert 'install_aperture_frontend.ps1' in text
    assert 'if "%~1"==""' in text
    assert '-InstallerArguments %*' in text
    assert text.count('install_aperture_frontend.ps1') == 2


def test_frontend_supports_drive_selection_existing_library_and_unattended_mode() -> None:
    text = (ROOT / 'scripts' / 'install_aperture_frontend.ps1').read_text(encoding='utf-8')
    for token in ('/silent', '/drive=', '/profile=', '/library=', '/useexisting', '/createnew'):
        assert token in text
    assert "'Aperture-Library'" in text
    assert 'ExistingLibrary' in text
    assert 'Installation Summary' in text
    assert 'natureai-next-admin library-create' in text


def test_readme_explains_storage_growth_and_standard_folder() -> None:
    text = (ROOT / 'README FIRST.txt').read_text(encoding='utf-8')
    assert 'Aperture-Library' in text
    assert 'grows over time' in text
    assert '/silent /drive=D /profile=FullAI' in text


def test_frontend_forwards_named_parameters_and_lists_all_fixed_drives() -> None:
    text = (ROOT / 'scripts' / 'install_aperture_frontend.ps1').read_text(encoding='utf-8')
    assert '[System.IO.DriveInfo]::GetDrives()' in text
    assert "Where-Object { $_.DriveType -eq 'Fixed' -and $_.IsReady }" in text
    assert 'not writable without elevated permission' in text
    assert '& $installScript -InstallProfile $options.Profile -TorchBuild $options.TorchBuild' in text
    assert '@installArguments' not in text


def test_new_library_is_created_before_default_library_registration() -> None:
    text = (ROOT / 'scripts' / 'install_aperture_frontend.ps1').read_text(encoding='utf-8')
    first_install = text.index('$initialLibraryArgument = if ($existingLibrary)')
    create_library = text.index('natureai-next-admin library-create')
    register_library = text.index('Registering the new Aperture Library')
    assert first_install < create_library < register_library
    assert '-DefaultLibrary $initialLibraryArgument' in text
    assert '-SkipPackageInstallation' in text
    assert '-SkipDependencyInstallation' in text


def test_frontend_rediscovers_bootstrapped_conda_in_localappdata() -> None:
    text = (ROOT / 'scripts' / 'install_aperture_frontend.ps1').read_text(encoding='utf-8')
    assert 'Resolve-ApertureCondaExecutable' in text
    assert "Join-Path $env:LOCALAPPDATA 'miniconda3\\Scripts\\conda.exe'" in text
    assert '$condaPath = Resolve-ApertureCondaExecutable' in text
