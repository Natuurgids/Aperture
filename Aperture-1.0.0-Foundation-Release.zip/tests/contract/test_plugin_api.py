from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

import pytest

from natureai_next.plugin_api import MetadataField, MetadataReadResult, PluginCapability
from natureai_next.plugins.manifest import parse_manifest, validate_compatibility
from natureai_next.plugins.registry import PluginRegistry
from natureai_next.shared.errors import PluginError


def manifest_document() -> dict[str, object]:
    return {
        "plugin_id": "org.example.metadata",
        "display_name": "Example Metadata",
        "version": "1.2.0",
        "provider": "Example",
        "description": "Reads example metadata",
        "license": "MIT",
        "plugin_api_specifier": ">=1.0,<2",
        "minimum_application_version": "0.1.0",
        "capabilities": ["filesystem.asset_read"],
        "entry_point": "example.plugin:Plugin",
    }


def test_manifest_parses_and_is_compatible() -> None:
    manifest = parse_manifest(manifest_document())
    assert manifest.capabilities == frozenset({PluginCapability.FILESYSTEM_ASSET_READ})
    validate_compatibility(manifest, api_version="1.0.0", application_version="0.1.0")


def test_incompatible_manifest_is_rejected() -> None:
    document = manifest_document()
    document["plugin_api_specifier"] = ">=2"
    with pytest.raises(PluginError):
        validate_compatibility(parse_manifest(document), api_version="1.0.0", application_version="0.1.0")


@dataclass(frozen=True)
class Reader:
    reader_id: str = "org.example.metadata.reader"
    supported_mime_types: frozenset[str] = frozenset({"image/jpeg"})

    def read(self, source: Path) -> MetadataReadResult:
        return MetadataReadResult((MetadataField("filename", source.name, self.reader_id),), ())


def test_registry_enforces_declared_capability_and_namespace() -> None:
    registry = PluginRegistry(parse_manifest(manifest_document()))
    registry.register_metadata_reader(Reader())
    assert registry.metadata_readers == (Reader(),)


def test_registry_rejects_reader_outside_plugin_namespace() -> None:
    registry = PluginRegistry(parse_manifest(manifest_document()))
    with pytest.raises(PluginError):
        registry.register_metadata_reader(Reader(reader_id="org.other.reader"))
