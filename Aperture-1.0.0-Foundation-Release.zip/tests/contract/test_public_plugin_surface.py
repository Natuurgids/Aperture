from natureai_next import plugin_api


def test_public_plugin_symbols_are_explicit() -> None:
    assert "PluginManifest" in plugin_api.__all__
    assert "PLUGIN_API_VERSION" in plugin_api.__all__
    assert not any(name.startswith("_") for name in plugin_api.__all__)
