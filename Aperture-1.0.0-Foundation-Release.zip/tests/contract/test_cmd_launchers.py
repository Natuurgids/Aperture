from pathlib import Path


def test_uninstall_cmd_uses_command_parser_for_confirm_switch() -> None:
    root = Path(__file__).resolve().parents[2]
    text = (root / "Uninstall Aperture.cmd").read_text(encoding="utf-8")
    assert "-File \"%~dp0scripts\\uninstall_windows.ps1\" -Confirm:$false" not in text
    assert text.count("-Command") >= 3
    assert text.count("-Confirm:$false") >= 3
    assert "-RemoveEnvironment -RemoveApplicationData -RemoveInstallationReports -Confirm:$false" in text
