from pathlib import Path
import sqlite3,time
import pytest
from natureai_next.infrastructure.database.connection import SqliteConnectionFactory
from natureai_next.infrastructure.database.migrations import CORE_MIGRATIONS,MigrationRunner

@pytest.mark.performance
def test_100k_asset_insert_and_keyset_query(tmp_path:Path)->None:
    f=SqliteConnectionFactory(tmp_path/'benchmark.sqlite3');c=f.connect();MigrationRunner(CORE_MIGRATIONS,'benchmark').apply(c)
    c.execute("INSERT INTO library_info VALUES(1,'lib',1,1,'0.1','Benchmark','en','[]','clean')")
    rows=((f'asset-{n:06d}','image','active',n,n,1) for n in range(100_000))
    started=time.perf_counter();c.execute('BEGIN IMMEDIATE');c.executemany("INSERT INTO assets(public_id,media_type,lifecycle_state,created_at_us,modified_at_us,revision) VALUES(?,?,?,?,?,?)",rows);c.execute('COMMIT');insert_s=time.perf_counter()-started
    started=time.perf_counter();page=c.execute("SELECT id,public_id FROM assets WHERE lifecycle_state='active' AND id>? ORDER BY id LIMIT 200",(99_000,)).fetchall();query_ms=(time.perf_counter()-started)*1000
    plan=' '.join(str(r[3]) for r in c.execute("EXPLAIN QUERY PLAN SELECT id,public_id FROM assets WHERE lifecycle_state='active' AND id>? ORDER BY id LIMIT 200",(99_000,)))
    c.close()
    assert len(page)==200
    assert insert_s<10.0
    assert query_ms<100.0
    assert 'SEARCH assets' in plan
