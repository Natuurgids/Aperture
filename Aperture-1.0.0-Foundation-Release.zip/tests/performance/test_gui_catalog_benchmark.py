import time
import pytest
from natureai_next.application.catalog_browsing import CatalogQueryService
from natureai_next.ports.catalog_queries import AssetGridRow,AssetPage
from natureai_next.ui.presentation.library import LibraryPresenter

class SyntheticReader:
    total=100_000
    def page_assets(self,*,limit:int,after_id:int|None=None)->AssetPage:
        start=(after_id or 0)+1;end=min(start+limit,self.total+1)
        rows=tuple(AssetGridRow(f'asset-{i}',i,1,None,None,None,None,None,None,None,None,None,None) for i in range(start,end))
        return AssetPage(rows,rows[-1].internal_id if rows and rows[-1].internal_id<self.total else None,self.total)
    def get_asset_detail(self,public_id:str):return None

@pytest.mark.performance
def test_100k_catalog_presenter_materializes_only_requested_pages()->None:
    p=LibraryPresenter(CatalogQueryService(SyntheticReader()),page_size=200);started=time.perf_counter();p.refresh()
    for _ in range(4):p.load_more()
    elapsed=time.perf_counter()-started
    assert p.state.total_count==100_000 and len(p.state.rows)==1_000 and elapsed<1.0
