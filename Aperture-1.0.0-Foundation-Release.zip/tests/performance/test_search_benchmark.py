import time
from pathlib import Path
from natureai_next.domain.search import Group, LogicalOperator, Predicate, PredicateOperator, StructuredQuery
from natureai_next.infrastructure.database.connection import SqliteConnectionFactory
from natureai_next.infrastructure.database.migrations import CORE_MIGRATIONS, MigrationRunner
from natureai_next.infrastructure.database.search import SqliteSearchAdapter
from natureai_next.ports.search import SearchRequest

def test_structured_search_scales_to_100k_assets(tmp_path:Path):
    f=SqliteConnectionFactory(tmp_path/'bench.sqlite3');c=f.connect();MigrationRunner(CORE_MIGRATIONS,'0.6.0').apply(c)
    rows=((f'a{i}','image','active',f'Bird photograph {i}' if i%100==0 else f'Landscape {i}',i%6,1,1) for i in range(100_000))
    c.executemany("INSERT INTO assets(public_id,media_type,lifecycle_state,title,rating,created_at_us,modified_at_us) VALUES(?,?,?,?,?,?,?)",rows);c.commit();c.close()
    adapter=SqliteSearchAdapter(f);q=StructuredQuery(Group(LogicalOperator.AND,(Predicate('rating',PredicateOperator.GTE,4),Predicate('title',PredicateOperator.CONTAINS,'Bird'))))
    start=time.perf_counter();page=adapter.search(SearchRequest(q,limit=200));elapsed=time.perf_counter()-start
    assert page.total_count>0;assert elapsed<5.0
