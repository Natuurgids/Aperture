import pytest
from natureai_next.domain.jobs import JobState,validate_job_transition

def test_transition_policy_accepts_retry_and_rejects_terminal_reopen():
    validate_job_transition(JobState.FAILED,JobState.QUEUED)
    with pytest.raises(ValueError):validate_job_transition(JobState.SUCCEEDED,JobState.QUEUED)


def test_original_export_job_handler_builds_versioned_plan(tmp_path) -> None:
    import json
    from types import SimpleNamespace

    from natureai_next.domain.exporting import OriginalFileExportResult
    from natureai_next.domain.jobs import JobRecord, JobState
    from natureai_next.jobs.export_handlers import OriginalFileExportJobHandler

    class Service:
        plan = None

        def execute(self, plan):
            self.plan = plan
            return OriginalFileExportResult(plan.public_id, plan.destination_directory, (), None, None)

    class Cancellation:
        calls = 0

        def raise_if_cancelled(self):
            self.calls += 1

    progress = []
    service = Service()
    job = JobRecord(
        public_id="job-export-1",
        job_type="export.original_files.v1",
        payload_version=1,
        payload_json=json.dumps(
            {
                "schema_version": 1,
                "destination_directory": str(tmp_path / "export"),
                "asset_public_ids": ["asset-1"],
                "naming_template": "{asset_id}{original_ext}",
                "collision_policy": "suffix",
                "include_manifest": False,
            }
        ),
        state=JobState.RUNNING,
        priority=0,
        resource_class="io",
        created_at_us=123,
        modified_at_us=123,
    )
    context = SimpleNamespace(
        job=job,
        cancellation=Cancellation(),
        report_progress=lambda current, total, unit, message: progress.append((current, total, unit, message)),
    )
    result = OriginalFileExportJobHandler(service).execute(context)
    assert service.plan is not None
    assert service.plan.selection.asset_public_ids == ("asset-1",)
    assert service.plan.collision_policy.value == "suffix"
    assert service.plan.include_manifest is False
    assert result["asset_count"] == 0
    assert progress[0][:3] == (0, None, "assets")
    assert progress[-1][:3] == (0, 0, "assets")
