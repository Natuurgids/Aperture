from natureai_next.shared.errors import ErrorCode, ErrorDescriptor, NatureAIError, Retryability


def test_error_descriptor_is_stable_and_user_safe() -> None:
    descriptor = ErrorDescriptor(
        code=ErrorCode.CONFIG_INVALID,
        summary="Invalid configuration.",
        retryability=Retryability.USER_ACTION,
        remediation="Reset the setting.",
    )
    error = NatureAIError(descriptor)
    assert str(error) == "Invalid configuration."
    assert error.descriptor.code.value == "configuration.invalid"


def test_error_descriptor_default_context_is_immutable_and_not_shared() -> None:
    first = ErrorDescriptor(ErrorCode.INTERNAL_UNEXPECTED, "First")
    second = ErrorDescriptor(ErrorCode.INTERNAL_UNEXPECTED, "Second")

    assert first.context == {}
    assert second.context == {}
    assert first.context is not second.context

    try:
        first.context["key"] = "value"  # type: ignore[index]
    except TypeError:
        pass
    else:
        raise AssertionError("ErrorDescriptor.context must be immutable")
