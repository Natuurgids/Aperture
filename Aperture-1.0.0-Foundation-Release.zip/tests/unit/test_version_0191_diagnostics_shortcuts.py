from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]

def test_maintenance_center_exposes_operational_locations() -> None:
    source=(ROOT/'src/natureai_next/ui/qt/maintenance_center.py').read_text(encoding='utf-8')
    for text in ('Operational locations','SQLite database','Library manifest','Application logs','Copy Path','Open Folder'):
        assert text in source

def test_shortcut_inventory_includes_viewer_and_inspector() -> None:
    source=(ROOT/'src/natureai_next/ui/qt/accessibility.py').read_text(encoding='utf-8')
    for text in ('Previous image','Next image','Fit image','Actual size','Save metadata','Discard metadata edits'):
        assert text in source

def test_packaged_help_documents_new_shortcuts_and_database_path() -> None:
    shortcuts=(ROOT/'src/natureai_next/resources/help/accessibility/ACCESSIBILITY_AND_KEYBOARD.md').read_text(encoding='utf-8')
    maintenance=(ROOT/'src/natureai_next/resources/help/operations/maintenance-center.md').read_text(encoding='utf-8')
    assert '## Viewer' in shortcuts and 'Ctrl+S' in shortcuts
    assert 'library.sqlite3' in maintenance and 'Operational locations' in maintenance
