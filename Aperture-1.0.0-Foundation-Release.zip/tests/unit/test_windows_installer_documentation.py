from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def test_windows_installer_build_assets_are_in_source_release() -> None:
    assert (ROOT / "BUILD_WINDOWS_INSTALLER_README.md").is_file()
    assert (ROOT / "scripts/build_aperture_windows_installer.ps1").is_file()
    assert (ROOT / "docs/developer/build-windows-installer.md").is_file()


def test_windows_installer_guide_is_bundled_in_help() -> None:
    bundled = ROOT / "src/natureai_next/resources/help/developer/build-windows-installer.md"
    help_system = (ROOT / "src/natureai_next/ui/qt/help_system.py").read_text(encoding="utf-8")
    application = (ROOT / "src/natureai_next/ui/qt/application.py").read_text(encoding="utf-8")
    assert bundled.is_file()
    assert 'HelpTopic("build-windows-installer", "Build Windows Installer"' in help_system
    assert '("Build Windows Installer", "build-windows-installer")' in application


def test_installer_guide_names_expected_output_and_tools() -> None:
    guide = (ROOT / "docs/developer/build-windows-installer.md").read_text(encoding="utf-8")
    for phrase in ("PyInstaller", "Inno Setup", "Aperture-0.18.2-Setup.exe", "sha256"):
        assert phrase.casefold() in guide.casefold()
