from pathlib import Path
from PIL import Image
from natureai_next.infrastructure.imaging.catalog_thumbnails import PillowCatalogThumbnailProvider


def test_catalog_thumbnail_provider_returns_bounded_jpeg(tmp_path: Path) -> None:
    source = tmp_path / "wide.png"
    Image.new("RGBA", (800, 200), (10, 20, 30, 128)).save(source)
    data = PillowCatalogThumbnailProvider().load(source_path=source, cached_path=None, max_size=120)
    assert data is not None
    output = tmp_path / "thumb.jpg"
    output.write_bytes(data)
    with Image.open(output) as image:
        assert image.format == "JPEG"
        assert image.width <= 120
        assert image.height <= 120
        assert image.mode == "RGB"


def test_catalog_thumbnail_provider_returns_none_for_missing_source(tmp_path: Path) -> None:
    assert PillowCatalogThumbnailProvider().load(
        source_path=tmp_path / "missing.jpg", cached_path=None, max_size=120
    ) is None


def test_catalog_thumbnail_provider_persists_and_reuses_cache(tmp_path: Path) -> None:
    source = tmp_path / "source.png"
    Image.new("RGB", (640, 480), (40, 50, 60)).save(source)
    cache_root = tmp_path / "cache" / "thumbnails"
    provider = PillowCatalogThumbnailProvider(thumbnail_root=cache_root, preview_root=tmp_path / "cache" / "previews")

    first = provider.load(source_path=source, cached_path=None, max_size=192)
    assert first is not None
    cached_files = list(cache_root.rglob("*.jpg"))
    assert len(cached_files) == 1
    first_mtime = cached_files[0].stat().st_mtime_ns

    second = provider.load(source_path=source, cached_path=None, max_size=192)
    assert second == first
    assert cached_files[0].stat().st_mtime_ns == first_mtime


def test_catalog_thumbnail_provider_rebuilds_corrupt_cache(tmp_path: Path) -> None:
    source = tmp_path / "source.jpg"
    Image.new("RGB", (500, 300), (70, 80, 90)).save(source)
    cache_root = tmp_path / "cache" / "thumbnails"
    provider = PillowCatalogThumbnailProvider(thumbnail_root=cache_root)

    original = provider.load(source_path=source, cached_path=None, max_size=160)
    assert original is not None
    cached_file = next(cache_root.rglob("*.jpg"))
    cached_file.write_bytes(b"corrupt")

    rebuilt = provider.load(source_path=source, cached_path=None, max_size=160)
    assert rebuilt == original
    assert cached_file.read_bytes() == original


def test_catalog_thumbnail_provider_uses_separate_preview_cache(tmp_path: Path) -> None:
    source = tmp_path / "source.jpg"
    Image.new("RGB", (1200, 900), (100, 110, 120)).save(source)
    thumbnail_root = tmp_path / "cache" / "thumbnails"
    preview_root = tmp_path / "cache" / "previews"
    provider = PillowCatalogThumbnailProvider(thumbnail_root=thumbnail_root, preview_root=preview_root)

    assert provider.load(source_path=source, cached_path=None, max_size=192) is not None
    assert provider.load(source_path=source, cached_path=None, max_size=900) is not None

    assert len(list(thumbnail_root.rglob("*.jpg"))) == 1
    assert len(list(preview_root.rglob("*.jpg"))) == 1
