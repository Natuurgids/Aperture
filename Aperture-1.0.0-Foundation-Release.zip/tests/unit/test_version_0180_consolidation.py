from pathlib import Path


def test_backup_recovery_application_has_history_management() -> None:
    source = Path("src/natureai_next/ui/qt/maintenance_center.py").read_text(encoding="utf-8")
    for phrase in ("Verified backup history", "Restore Selected", "Verify Selected", "Delete Selected"):
        assert phrase in source


def test_main_application_exposes_update_history() -> None:
    source = Path("src/natureai_next/ui/qt/application.py").read_text(encoding="utf-8")
    assert 'QAction("Update History…"' in source
    assert "UpdateHistoryStore" in source


def test_native_updater_records_outcome_and_cleans_package() -> None:
    source = Path("src/natureai_next/bootstrap/native_updater.py").read_text(encoding="utf-8")
    assert 'status="installed"' in source
    assert 'status="failed"' in source
    assert "package.unlink(missing_ok=True)" in source
