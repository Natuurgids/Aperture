from pathlib import Path

from natureai_next.application.update_history import UpdateHistoryEntry, UpdateHistoryStore


def test_update_history_round_trip_and_reverse_order(tmp_path: Path) -> None:
    path = tmp_path / "updates" / "update-history.jsonl"
    store = UpdateHistoryStore()
    store.append(path, UpdateHistoryEntry(version="0.17.11", status="failed", detail="locked"))
    store.append(path, UpdateHistoryEntry(version="0.18.0", status="installed"))
    entries = store.load(path)
    assert [entry.version for entry in entries] == ["0.18.0", "0.17.11"]
    assert entries[1].detail == "locked"
    assert entries[0].created_at_utc


def test_update_history_ignores_malformed_lines(tmp_path: Path) -> None:
    path = tmp_path / "history.jsonl"
    path.write_text('not-json\n{"version":"0.18.0","status":"installed"}\n', encoding="utf-8")
    entries = UpdateHistoryStore().load(path)
    assert len(entries) == 1
    assert entries[0].status == "installed"
