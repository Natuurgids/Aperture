from pathlib import Path
import pytest
from natureai_next.infrastructure.ai.residency import ModelResidencyManager


class Provider:
    identity = "fixture"
    def __init__(self): self.loads = 0; self.unloads = 0
    def load(self, artifact_path: Path, *, device: str, precision: str): self.loads += 1; return object()
    def unload(self, model): self.unloads += 1
    def diagnostics(self): raise AssertionError
    def embed_images(self, model, images): return ()
    def embed_text(self, model, texts): return ()
    def clear_device_cache(self): return None


def test_residency_reuses_and_evicts_idle_model(tmp_path: Path) -> None:
    now = [0.0]
    provider = Provider()
    manager = ModelResidencyManager(idle_seconds=5, monotonic=lambda: now[0])
    artifact = tmp_path / "model.pt"; artifact.write_bytes(b"x")
    with manager.acquire("model", provider, artifact, device="cpu", precision="fp32") as first:
        with manager.acquire("model", provider, artifact, device="cpu", precision="fp32") as second:
            assert first is second
            assert manager.evict_idle() == ()
    assert provider.loads == 1
    now[0] = 6.0
    assert manager.evict_idle() == ("model",)
    assert provider.unloads == 1


def test_residency_rejects_unbalanced_release() -> None:
    manager = ModelResidencyManager()
    with pytest.raises(RuntimeError): manager.release("missing")
