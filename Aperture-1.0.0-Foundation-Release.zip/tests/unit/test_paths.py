from pathlib import Path

from natureai_next.bootstrap.paths import resolve_application_paths


def test_config_root_override_is_deterministic(tmp_path: Path) -> None:
    paths = resolve_application_paths(tmp_path / "root")
    assert paths.config_file == (tmp_path / "root" / "app-config.toml").resolve()
    assert paths.preferences_file == (tmp_path / "root" / "roaming" / "user-preferences.toml").resolve()
