import pytest
from natureai_next.domain.search import Group, LogicalOperator, Predicate, PredicateOperator, QueryValidationError, StructuredQuery, query_from_dict, query_to_dict, validate_query
from natureai_next.infrastructure.database.search import compile_query

def test_query_round_trip_and_parameterized_compilation():
    q=StructuredQuery(Group(LogicalOperator.AND,(Predicate('rating',PredicateOperator.GTE,4),Predicate('tag',PredicateOperator.EQ,'Birds'))))
    assert query_from_dict(query_to_dict(q))==q
    compiled=compile_query(q)
    assert compiled.parameters==(4,'birds')
    assert 'Birds' not in compiled.sql

def test_rejects_fields_operators_and_depth():
    with pytest.raises(QueryValidationError):validate_query(StructuredQuery(Predicate('drop table assets',PredicateOperator.EQ,1)))
    with pytest.raises(QueryValidationError):validate_query(StructuredQuery(Predicate('rating',PredicateOperator.CONTAINS,'x')))
    node=Predicate('rating',PredicateOperator.EQ,1)
    from natureai_next.domain.search import Not
    for _ in range(9):node=Not(node)
    with pytest.raises(QueryValidationError):validate_query(StructuredQuery(node))


def test_quick_search_service_builds_bounded_text_request():
    from natureai_next.application.search import QuickSearchService

    class Port:
        request = None
        def search(self, request):
            self.request = request
            return "page"

    port = Port()
    service = QuickSearchService(port)
    assert service.page(text="  Great   Grebe  ", limit=50) == "page"
    assert port.request.query.root.value == "Great Grebe"
    assert port.request.limit == 50
    with pytest.raises(ValueError):
        service.page(text="   ", limit=10)


def test_structured_filter_service_combines_all_active_predicates():
    from natureai_next.application.search import QuickSearchService
    from natureai_next.domain.search import Group, StructuredAssetFilters

    class Port:
        request = None
        def search(self, request):
            self.request = request
            return "page"

    port = Port()
    service = QuickSearchService(port)
    filters = StructuredAssetFilters(
        minimum_rating=4,
        color_label="green",
        pick_state="pick",
        captured_from_date="2024-05-01",
        captured_to_date="2024-05-31",
        minimum_width=2000,
        minimum_height=1000,
        tag="Birds",
        taxonomy_name="Erithacus rubecula",
    )
    assert service.page(text=" robin ", filters=filters, limit=25, after_id=5) == "page"
    root = port.request.query.root
    assert isinstance(root, Group)
    assert [predicate.field for predicate in root.children] == [
        "text", "rating", "color_label", "pick_state", "capture_date",
        "capture_date", "pixel_width", "pixel_height", "tag", "taxon_name",
    ]
    assert port.request.after_id == 5


def test_structured_filter_service_validates_ranges_and_empty_request():
    from natureai_next.application.search import QuickSearchService
    from natureai_next.domain.search import StructuredAssetFilters

    class Port:
        def search(self, request):
            return request

    service = QuickSearchService(Port())
    with pytest.raises(ValueError):
        service.page(limit=10)
    with pytest.raises(ValueError):
        service.page(filters=StructuredAssetFilters(minimum_rating=6), limit=10)
    with pytest.raises(ValueError):
        service.page(filters=StructuredAssetFilters(captured_from_date="2024-06-01", captured_to_date="2024-05-01"), limit=10)
    with pytest.raises(ValueError):
        service.page(filters=StructuredAssetFilters(captured_from_date="01-05-2024"), limit=10)
    with pytest.raises(ValueError):
        service.page(filters=StructuredAssetFilters(minimum_width=-1), limit=10)
