from __future__ import annotations

from pathlib import Path


def test_ai_review_widget_is_created_after_qapplication() -> None:
    source = Path("src/natureai_next/ui/qt/application.py").read_text(encoding="utf-8")
    app_index = source.index("app = QApplication")
    main_window_index = source.index("window = MainWindow")
    widget_index = source.index("self._ai_review_workspace = ai_review_workspace_factory")
    assert app_index < main_window_index
    assert widget_index < main_window_index  # widget construction occurs inside MainWindow.__init__


def test_bootstrap_passes_factory_not_constructed_widget() -> None:
    source = Path("src/natureai_next/bootstrap/cli.py").read_text(encoding="utf-8")
    assert "def ai_review_workspace_factory(" in source
    assert "ai_review_workspace_factory=ai_review_workspace_factory" in source
    assert "ai_review_workspace=ai_review_workspace" not in source
