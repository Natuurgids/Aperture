from pathlib import Path


def test_normal_launcher_is_native_gui_entry_without_script_parent():
    script = Path("scripts/install_windows.ps1").read_text(encoding="utf-8")
    pyproject = Path("pyproject.toml").read_text(encoding="utf-8")
    assert 'aperture = "natureai_next.bootstrap.aperture_launcher:main"' in pyproject
    normal_definition = next(line for line in script.splitlines() if "Name = 'Aperture';" in line)
    assert "Target = $apertureExecutable" in normal_definition
    assert "powershell" not in normal_definition.lower()
    assert "wscript" not in normal_definition.lower()


def test_latest_import_is_an_explicit_switchable_library_view():
    source = Path("src/natureai_next/ui/qt/library.py").read_text(encoding="utf-8")
    assert 'self._view_selector.addItem("All Library", "library")' in source
    assert '"latest-import"' in source
    assert "_view_selection_changed" in source
    assert "self.clear_active_view()" in source
