from dataclasses import dataclass
from datetime import UTC, datetime
from pathlib import Path
from natureai_next.application.catalog_browsing import CatalogEditService,CatalogQueryService
from natureai_next.ports.catalog_queries import AssetDetail,AssetGridRow,AssetPage,MetadataChangeResult,MetadataPatch
from natureai_next.ui.presentation.commands import CommandDefinition,CommandRegistry
from natureai_next.ui.presentation.inspector import InspectorPresenter
from natureai_next.ui.presentation.library import LibraryPresenter
from natureai_next.ui.presentation.selection import SelectionModel
from natureai_next.ui.presentation.session import SessionState,SessionStateStore
from natureai_next.ui.presentation.viewer import ViewerPresenter,ZoomMode

class Reader:
    def page_assets(self,*,limit:int,after_id:int|None=None)->AssetPage:
        start=(after_id or 0)+1;rows=tuple(AssetGridRow(f'a{i}',i,1,None,None,None,None,None,None,None,None,None,None) for i in range(start,min(start+limit,6)))
        return AssetPage(rows,rows[-1].internal_id if rows and rows[-1].internal_id<5 else None,5)
    def get_asset_detail(self,public_id:str)->AssetDetail|None:return AssetDetail(public_id,1,'old',None,None,2,None,None,None,None,None,None,None,())
class Editor:
    def __init__(self)->None:self.patch=None;self.tags=()
    def update_metadata(self,*,public_id:str,expected_revision:int,patch:MetadataPatch,modified_at_us:int)->MetadataChangeResult:
        before=MetadataPatch('old',None,None,2,None,None);self.patch=patch;return MetadataChangeResult(public_id,expected_revision,expected_revision+1,before,patch)
    def update_metadata_and_tags(self,*,public_id:str,expected_revision:int,patch:MetadataPatch,tag_names:tuple[str,...],modified_at_us:int)->MetadataChangeResult:
        self.tags=tag_names
        return self.update_metadata(public_id=public_id,expected_revision=expected_revision,patch=patch,modified_at_us=modified_at_us)
    def set_tags(self,**kwargs:object)->None:pass
class Clock:
    def now_utc(self)->datetime:return datetime(2026,1,1,tzinfo=UTC)

def test_library_paginates_without_materializing_all()->None:
    p=LibraryPresenter(CatalogQueryService(Reader()),page_size=2);p.refresh();assert len(p.state.rows)==2 and p.state.total_count==5;p.load_more();assert len(p.state.rows)==4

def test_stale_refresh_is_discarded()->None:
    p=LibraryPresenter(CatalogQueryService(Reader()),2);old=p.begin_refresh();p.begin_refresh();assert not p.complete_refresh(old)

def test_selection_survives_by_identity_and_range()->None:
    s=SelectionModel();s.select_one('a2');s.select_range(('a1','a2','a3','a4'),'a4');assert s.snapshot.selected_ids==frozenset({'a2','a3','a4'});s.retain_existing({'a3','a4'});assert s.snapshot.selected_ids==frozenset({'a3','a4'})

def test_inspector_draft_validation_commit_and_undo()->None:
    editor=Editor();p=InspectorPresenter(CatalogQueryService(Reader()),CatalogEditService(editor,Clock()));p.load('a1');p.edit(title='new',rating=5);p.commit();assert editor.patch.title=='new';assert p.undo()

def test_viewer_navigation_and_zoom()->None:
    v=ViewerPresenter();v.open(('a','b','c'),'b')
    assert v.previous() and v.state.current_id=='a'
    assert v.last() and v.state.current_id=='c'
    assert v.first() and v.state.current_id=='a'
    v.zoom(2.5);assert v.state.zoom_mode==ZoomMode.CUSTOM
    v.zoom_by(2.0);assert v.state.zoom_factor==5.0
    v.fit();assert v.state.zoom_mode==ZoomMode.FIT
    v.actual();assert v.state.zoom_mode==ZoomMode.ACTUAL


def test_viewer_rejects_invalid_open_and_zoom()->None:
    import pytest
    v=ViewerPresenter()
    with pytest.raises(ValueError):v.open((), 'a')
    with pytest.raises(ValueError):v.open(('a',), 'b')
    v.open(('a',), 'a')
    with pytest.raises(ValueError):v.zoom(100.0)
    with pytest.raises(ValueError):v.zoom_by(0.0)

def test_command_registry_enforces_ids()->None:
    called=[];r=CommandRegistry();r.register(CommandDefinition('asset.rate5','Rate 5','5',lambda:called.append(1)));assert r.invoke('asset.rate5') and called==[1]

def test_session_state_roundtrip(tmp_path:Path)->None:
    path=tmp_path/'session.json';store=SessionStateStore();state=SessionState(workspace='viewer',grid_thumbnail_size=256,inspector_visible=False);store.save(path,state);assert store.load(path)==state


def test_catalog_edit_service_normalizes_case_insensitive_tags()->None:
    editor=Editor();service=CatalogEditService(editor,Clock())
    service.update_with_tags(
        public_id='a1',
        expected_revision=1,
        patch=MetadataPatch('new',None,None,5,None,None),
        tag_names=(' Flower ', 'flower', 'Bulgaria', ''),
    )
    assert editor.tags == ('Bulgaria','Flower')
