from pathlib import Path


def test_observation_workspace_is_routed_from_ai_review() -> None:
    root = Path(__file__).resolve().parents[2]
    application = (root / 'src/natureai_next/ui/qt/application.py').read_text(encoding='utf-8')
    review = (root / 'src/natureai_next/ui/qt/ai_review.py').read_text(encoding='utf-8')
    workspace = (root / 'src/natureai_next/ui/qt/observations.py').read_text(encoding='utf-8')
    assert '"Observation History"' in application
    assert 'observation_requested.connect(self.open_observation_history)' in application
    assert 'Accept && Next' in review
    assert 'Observation History' in review
    assert 'Evidence photographs' in workspace
    assert 'viewer_requested.emit' in workspace
    assert 'Observation timeline —' in workspace
    assert 'setMinimumHeight(180)' in workspace
    assert 'UserRole + 1' in workspace
    assert 'No confirmed timeline entries are available' in workspace


def test_life_lists_and_statistics_workspace_is_available() -> None:
    root = Path(__file__).resolve().parents[2]
    application = (root / 'src/natureai_next/ui/qt/application.py').read_text(encoding='utf-8')
    workspace = (root / 'src/natureai_next/ui/qt/observation_statistics.py').read_text(encoding='utf-8')
    assert 'Life Lists & Statistics' in application
    assert 'open_observation_statistics' in application
    assert 'Personal life list by biological group' in workspace
    assert 'Most observed species' in workspace
