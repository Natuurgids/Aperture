from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def test_regional_setup_uses_activity_center_and_standard_actions() -> None:
    source = (ROOT / "src/natureai_next/ui/qt/regional_setup.py").read_text(encoding="utf-8")
    assert 'self.resize(940,700)' in source
    assert 'can take multiple minutes' in source
    assert 'QPushButton("Save & Install")' in source
    assert 'activity_center().start(' in source
    assert 'QProgressDialog' not in source
    assert 'QMessageBox.information' not in source


def test_main_window_separates_activity_and_health() -> None:
    source = (ROOT / "src/natureai_next/ui/qt/application.py").read_text(encoding="utf-8")
    assert 'QAction("Activity Center…"' in source
    assert 'self.menuBar().addMenu("&Tools")' in source
    assert 'QAction("Health Check…"' in source


def test_activity_updates_are_delivered_to_qobject_slots() -> None:
    source = (ROOT / "src/natureai_next/ui/qt/activity.py").read_text(encoding="utf-8")
    assert "worker.progressed.connect(self._progress)" in source
    assert "worker.succeeded.connect(self._success)" in source
    assert "worker.failed.connect(self._failure)" in source
    assert "worker.progressed.connect(lambda" not in source
    assert "@Slot(object, int, int, str)" in source


def test_shutdown_is_blocked_while_background_work_runs() -> None:
    source = (ROOT / "src/natureai_next/ui/qt/application.py").read_text(encoding="utf-8")
    assert '"Background work is still running"' in source
    assert '"Keep running"' in source
    assert '"Cancel tasks and exit"' in source
    assert "self._activity_center.cancel_all()" in source


def test_activity_center_supports_durable_resume_and_retry() -> None:
    source = (ROOT / "src/natureai_next/ui/qt/activity.py").read_text(encoding="utf-8")
    assert 'state = "interrupted"' in source
    assert 'QPushButton("Resume / Retry")' in source
    assert "def register_recovery" in source
    assert "def retry" in source
    assert "activity.json" in source


def test_activity_center_is_a_first_class_navigation_workspace() -> None:
    application = (ROOT / "src/natureai_next/ui/qt/application.py").read_text(encoding="utf-8")
    activity = (ROOT / "src/natureai_next/ui/qt/activity.py").read_text(encoding="utf-8")
    assert '"Activity Center", "Observation History", "Life Lists & Statistics", "Settings"' in application
    assert 'elif name == "Activity Center"' in application
    assert 'self._stack.addWidget(self._activity_workspace)' in application
    assert 'self._navigation.setCurrentRow(self.WORKSPACES.index("Activity Center"))' in application
    assert 'restored_workspace == "Jobs"' in application
    assert 'class ActivityCenterWidget(QWidget)' in activity


def test_navigation_activity_label_reports_running_or_attention_counts() -> None:
    source = (ROOT / "src/natureai_next/ui/qt/application.py").read_text(encoding="utf-8")
    assert 'nav_label += f" ({running})"' in source
    assert 'nav_label += f" (!{failed})"' in source
