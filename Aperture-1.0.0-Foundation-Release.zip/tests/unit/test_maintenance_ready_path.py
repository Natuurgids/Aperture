from pathlib import Path


def test_maintenance_ready_path_does_not_use_open_mkstemp_placeholder() -> None:
    source = (Path(__file__).resolve().parents[2] / "src" / "natureai_next" / "ui" / "qt" / "application.py").read_text(encoding="utf-8")
    restore_section = source[source.index("def restore_library"):source.index("def check_for_updates")]
    assert "tempfile.mkstemp" not in restore_section
    assert "uuid.uuid4().hex" in restore_section
    assert 'glob("maintenance-ready-*.json*")' in restore_section
