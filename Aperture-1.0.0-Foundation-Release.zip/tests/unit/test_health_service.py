from __future__ import annotations

import json
from pathlib import Path

from natureai_next.application.backup import LibraryBackupService
from natureai_next.application.health import HealthSeverity, LibraryHealthService
from natureai_next.application.library_service import LibraryService
from natureai_next.infrastructure.diagnostics.system_services import SystemClock, SystemUuidGenerator


def _open_library(tmp_path: Path):
    return LibraryService(SystemClock(), SystemUuidGenerator()).create(tmp_path / "library", display_name="Health Test")


def test_health_service_checks_live_library_and_warns_without_backup(tmp_path: Path) -> None:
    with _open_library(tmp_path) as opened:
        service = LibraryHealthService(
            layout=opened.layout,
            connection_factory=opened.connection_factory,
            update_settings_path=opened.layout.root / "update-settings.json",
        )
        report = service.assess()
        by_key = {item.key: item for item in report.checks}
        assert by_key["database"].severity is HealthSeverity.OK
        assert by_key["manifest"].severity is HealthSeverity.OK
        assert by_key["backups"].severity is HealthSeverity.WARNING
        assert by_key["updates"].severity is HealthSeverity.WARNING
        assert report.healthy


def test_health_service_recognizes_verified_backup(tmp_path: Path) -> None:
    with _open_library(tmp_path) as opened:
        LibraryBackupService(opened.backup_database, library_name="Health Test").create(
            opened.layout.backups / "health.sqlite3"
        )
        service = LibraryHealthService(
            layout=opened.layout,
            connection_factory=opened.connection_factory,
            update_settings_path=opened.layout.root / "update-settings.json",
        )
        check = {item.key: item for item in service.assess().checks}["backups"]
        assert check.severity is HealthSeverity.OK
        assert "1 verified backup" in check.summary


def test_safe_repair_creates_missing_rebuildable_directories_and_cleans_temp(tmp_path: Path) -> None:
    with _open_library(tmp_path) as opened:
        opened.layout.previews.rmdir()
        stale = opened.layout.temp / "interrupted.part"
        stale.write_bytes(b"partial")
        service = LibraryHealthService(
            layout=opened.layout,
            connection_factory=opened.connection_factory,
            update_settings_path=opened.layout.root / "update-settings.json",
        )
        before = {item.key: item for item in service.assess().checks}
        assert before["directories"].repairable
        assert before["temporary"].repairable
        result = service.repair_safe_items()
        assert opened.layout.previews.is_dir()
        assert not stale.exists()
        assert result.repaired


def test_broken_manifest_is_reported_as_error(tmp_path: Path) -> None:
    with _open_library(tmp_path) as opened:
        opened.layout.manifest.write_text("not json", encoding="utf-8")
        service = LibraryHealthService(
            layout=opened.layout,
            connection_factory=opened.connection_factory,
            update_settings_path=opened.layout.root / "update-settings.json",
        )
        report = service.assess()
        manifest = {item.key: item for item in report.checks}["manifest"]
        assert manifest.severity is HealthSeverity.ERROR
        assert not report.healthy
