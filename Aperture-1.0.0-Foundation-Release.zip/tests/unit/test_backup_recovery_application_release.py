from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def test_maintenance_center_gui_entry_points_are_packaged() -> None:
    project = (ROOT / "pyproject.toml").read_text(encoding="utf-8")
    assert 'aperture-maintenance-center = "natureai_next.bootstrap.maintenance_center:main"' in project
    assert 'aperture-backup-recovery = "natureai_next.bootstrap.maintenance_center:main"' in project


def test_about_is_top_level_and_restore_opens_maintenance_center() -> None:
    source = (ROOT / "src/natureai_next/ui/qt/application.py").read_text(encoding="utf-8")
    assert "self.menuBar().addAction(self._about_action)" in source
    assert "help_menu.addAction(self._about_action)" not in source
    assert 'Path(os.sys.prefix) / "pythonw.exe"' in source
    assert 'natureai_next.bootstrap.maintenance_center' in source
    assert 'maintenance-launch.jsonl' in source


def test_installer_creates_maintenance_center_shortcut() -> None:
    installer = (ROOT / "scripts/install_windows.ps1").read_text(encoding="utf-8")
    assert "Aperture Maintenance Center" in installer
    assert "aperture-maintenance-center.exe" in installer
    assert "aperture-backup-recovery.ico" in installer


def test_restore_warning_describes_close_restore_restart() -> None:
    source = (ROOT / "src/natureai_next/ui/qt/maintenance_center.py").read_text(encoding="utf-8")
    assert "Aperture will close while" in source
    assert "Aperture will restart automatically" in source
    assert "_request_aperture_close" in source
    assert "_launch_aperture" in source


def test_restore_offers_backup_and_no_backup_paths() -> None:
    source = (ROOT / "src/natureai_next/ui/qt/maintenance_center.py").read_text(encoding="utf-8")
    assert "Back Up and Restore" in source
    assert "Restore Without Backup" in source
    assert "create_emergency_backup" in source


def test_visible_updater_progress_is_packaged() -> None:
    source = (ROOT / "src/natureai_next/bootstrap/native_updater.py").read_text(encoding="utf-8")
    assert "Aperture Maintenance Center" in source
    assert "Updating Aperture" in source
    assert "Installing the new Aperture version" in source
    assert "Aperture {version} installed successfully" in source
