from __future__ import annotations

import base64, json
from pathlib import Path
import pytest

from natureai_next.application.ai_resources import load_trusted_key_file


def test_load_trusted_key_file(tmp_path: Path) -> None:
    path = tmp_path / "keys.json"
    path.write_text(json.dumps({"natureai": base64.b64encode(b"x" * 32).decode("ascii")}), encoding="utf-8")
    assert load_trusted_key_file(path) == {"natureai": b"x" * 32}


def test_load_trusted_key_file_rejects_wrong_key_length(tmp_path: Path) -> None:
    path = tmp_path / "keys.json"
    path.write_text(json.dumps({"natureai": base64.b64encode(b"short").decode("ascii")}), encoding="utf-8")
    with pytest.raises(ValueError, match="32 bytes"):
        load_trusted_key_file(path)
