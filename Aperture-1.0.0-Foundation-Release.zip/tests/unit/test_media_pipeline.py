import hashlib,json
from pathlib import Path
from PIL import Image
import pytest
from natureai_next.infrastructure.imaging.cache import DerivativeCache,DerivativeSpec
from natureai_next.infrastructure.imaging.pillow_adapter import ImageDecodeError,PillowImageDecoder
from natureai_next.infrastructure.metadata.pillow_reader import PillowMetadataReader

def test_probe_uses_content_and_cache_is_deterministic(tmp_path:Path):
    source=tmp_path/'wildlife.bin';Image.new('RGB',(800,400)).save(source,format='PNG')
    decoder=PillowImageDecoder();probe=decoder.probe(source)
    assert probe.format_name=='PNG' and probe.pixel_width==800
    cache=DerivativeCache(tmp_path/'cache',decoder,decoder.renderer_identity);spec=DerivativeSpec('thumbnail',200,200)
    first,manifest=cache.get_or_create(source,spec);second,again=cache.get_or_create(source,spec)
    assert first==second and manifest.cache_key==again.cache_key
    assert Image.open(first).size==(200,100)
    assert hashlib.sha256(first.read_bytes()).hexdigest()==manifest.output_sha256

def test_corrupt_image_isolated_as_decode_error(tmp_path:Path):
    source=tmp_path/'bad.jpg';source.write_bytes(b'not an image')
    with pytest.raises(ImageDecodeError):PillowImageDecoder().probe(source)

def test_metadata_is_bounded_and_normalized(tmp_path:Path):
    source=tmp_path/'a.jpg';Image.new('RGB',(32,16)).save(source)
    result=PillowMetadataReader().read(source)
    assert result.normalized['pixel_width']==32 and result.normalized['pixel_height']==16
