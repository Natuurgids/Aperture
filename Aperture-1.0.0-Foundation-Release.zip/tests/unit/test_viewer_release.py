from pathlib import Path


ROOT = Path(__file__).resolve().parents[2]


def test_qt_viewer_is_packaged_and_wired_to_library() -> None:
    viewer = (ROOT / "src/natureai_next/ui/qt/viewer.py").read_text(encoding="utf-8")
    library = (ROOT / "src/natureai_next/ui/qt/library.py").read_text(encoding="utf-8")
    application = (ROOT / "src/natureai_next/ui/qt/application.py").read_text(encoding="utf-8")

    for fragment in (
        "class ViewerDialog",
        "class ZoomableImageView",
        "max_size=4096",
        "AnchorUnderMouse",
        "ScrollHandDrag",
        "fit_image",
        "actual_size",
        "request_id != self._request_id",
    ):
        assert fragment in viewer

    assert "viewer_requested = Signal" in library
    assert "itemDoubleClicked" in library
    assert "Open viewer" in library
    assert "ViewerDialog" in application
    assert "self._library.viewer_requested.connect(self._open_viewer)" in application


def test_library_preview_decode_is_not_performed_in_detail_slot() -> None:
    library = (ROOT / "src/natureai_next/ui/qt/library.py").read_text(encoding="utf-8")
    assert "class _PreviewWorker" in library
    assert "max_size=1200" in library
    detail_block = library.split("def _detail_ready", 1)[1].split("def _preview_ready", 1)[0]
    assert "self._thumbnails.load" not in detail_block
