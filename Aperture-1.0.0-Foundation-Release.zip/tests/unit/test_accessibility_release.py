from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def test_accessibility_module_and_shortcut_help_are_packaged():
    module = (ROOT / "src/natureai_next/ui/qt/accessibility.py").read_text(encoding="utf-8")
    shell = (ROOT / "src/natureai_next/ui/qt/application.py").read_text(encoding="utf-8")
    assert "apply_accessibility_defaults" in module
    assert "KeyboardShortcutsDialog" in module
    assert 'QKeySequence("Ctrl+/")' in shell
    assert "self.apply_accessibility_defaults()" in shell


def test_core_shortcuts_include_backup_and_restore():
    module = (ROOT / "src/natureai_next/ui/qt/accessibility.py").read_text(encoding="utf-8")
    assert "Ctrl+Shift+B" in module
    assert "Ctrl+Shift+R" in module
    assert "Aperture keyboard shortcuts" in module


def test_health_center_actions_have_explicit_accessible_names():
    health = (ROOT / "src/natureai_next/ui/qt/health.py").read_text(encoding="utf-8")
    assert "Back up the current Aperture library" in health
    assert "Restore an Aperture library backup" in health
    assert "Check the configured location for Aperture updates" in health
