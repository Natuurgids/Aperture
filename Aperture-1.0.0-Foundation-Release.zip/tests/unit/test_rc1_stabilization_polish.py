from pathlib import Path


def test_startup_timing_and_maintenance_polish_are_packaged():
    root = Path(__file__).resolve().parents[2]
    timing = (root / "src/natureai_next/bootstrap/startup_timing.py").read_text(encoding="utf-8")
    app = (root / "src/natureai_next/ui/qt/application.py").read_text(encoding="utf-8")
    maintenance = (root / "src/natureai_next/ui/qt/maintenance_center.py").read_text(encoding="utf-8")
    assert "startup-timing.jsonl" in timing
    assert 'startup_timeline.mark("main-window-visible")' in app
    assert "QTimer.singleShot(0, self.refresh_backups)" in maintenance
    assert "Maintenance operation progress" in maintenance


def test_stabilization_guides_exist_in_source_and_help():
    root = Path(__file__).resolve().parents[2]
    for relative in (
        "docs/operations/startup-performance.md",
        "docs/user-guide/taxonomy-library.md",
        "src/natureai_next/resources/help/operations/startup-performance.md",
        "src/natureai_next/resources/help/user-guide/taxonomy-library.md",
    ):
        assert (root / relative).is_file(), relative
