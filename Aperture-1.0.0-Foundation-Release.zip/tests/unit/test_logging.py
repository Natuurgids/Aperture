from __future__ import annotations

import json
import logging
from pathlib import Path

from natureai_next.infrastructure.diagnostics.logging import JsonFormatter, LogContext


def test_json_formatter_adds_context_and_sanitizes_paths() -> None:
    record = logging.LogRecord("natureai_next.test", logging.INFO, __file__, 1, "hello", (), None)
    record.context = {"source": Path("C:/private/photos/bird.jpg")}  # type: ignore[attr-defined]
    tokens = LogContext(correlation_id="corr-1", job_id="job-1").install()
    try:
        payload = json.loads(JsonFormatter().format(record))
    finally:
        LogContext.reset(tokens)
    assert payload["correlation_id"] == "corr-1"
    assert payload["job_id"] == "job-1"
    assert payload["context"]["source"] == "bird.jpg"
