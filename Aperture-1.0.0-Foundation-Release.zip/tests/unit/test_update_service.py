import hashlib
import json
from pathlib import Path

import pytest

from natureai_next.application.updates import OfflineUpdateService, UpdateSettings, UpdateSettingsStore


def _source(tmp_path: Path, *, version: str = "0.17.3", contents: bytes = b"release") -> Path:
    source = tmp_path / "updates"; source.mkdir()
    package = source / f"Aperture-{version}.zip"; package.write_bytes(contents)
    (source / "notes.md").write_text("# Release notes\nSafe update.\n", encoding="utf-8")
    (source / "update-index.json").write_text(json.dumps({
        "format": "natureai-next.update-index", "format_version": 1,
        "product": "Aperture", "version": version, "minimum_supported_version": "0.17.0",
        "channel": "stable", "package": package.name,
        "sha256": hashlib.sha256(contents).hexdigest(), "release_notes": "notes.md",
    }), encoding="utf-8")
    return source


def test_update_discovery_verifies_package_and_reads_notes(tmp_path: Path) -> None:
    candidate = OfflineUpdateService(current_version="0.17.2").check(_source(tmp_path))
    assert candidate is not None
    assert candidate.version == "0.17.3"
    assert "Safe update" in candidate.release_notes


def test_current_or_older_release_is_not_offered(tmp_path: Path) -> None:
    assert OfflineUpdateService(current_version="0.17.3").check(_source(tmp_path)) is None


def test_corrupt_package_is_rejected(tmp_path: Path) -> None:
    source = _source(tmp_path)
    (source / "Aperture-0.17.3.zip").write_bytes(b"tampered")
    with pytest.raises(ValueError, match="checksum"):
        OfflineUpdateService(current_version="0.17.2").check(source)


def test_verified_update_is_staged_with_request(tmp_path: Path) -> None:
    service = OfflineUpdateService(current_version="0.17.2")
    candidate = service.check(_source(tmp_path)); assert candidate is not None
    staged = service.stage(candidate, tmp_path / "stage")
    assert staged.staged_package.read_bytes() == b"release"
    assert json.loads(staged.request_path.read_text(encoding="utf-8"))["status"] == "staged"


def test_update_settings_round_trip(tmp_path: Path) -> None:
    path = tmp_path / "updates.json"
    store = UpdateSettingsStore()
    expected = UpdateSettings(source=Path(r"\\server\software\Aperture"), check_at_startup=True)
    store.save(path, expected)
    assert store.load(path) == expected
