from pathlib import Path


def test_update_handoff_is_started_before_application_quit() -> None:
    source = Path("src/natureai_next/ui/qt/application.py").read_text(encoding="utf-8")
    launch = source.index("helper = launch_helper")
    quit_app = source.index("app.quit", launch)
    assert launch < quit_app
    assert "wait_for_helper_ready(helper, staged.request_path" in source
    assert "Back Up and Install" in source
    assert "Install Without Backup" in source


def test_native_updater_marks_helper_ready_before_waiting() -> None:
    source = Path("src/natureai_next/bootstrap/native_updater.py").read_text(encoding="utf-8")
    ready = source.index('"helper-ready"')
    waiting = source.index('"waiting-for-exit"')
    assert ready < waiting
