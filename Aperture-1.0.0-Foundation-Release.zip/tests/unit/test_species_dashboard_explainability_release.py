from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]

def test_species_dashboard_receives_ecology_service():
    text=(ROOT/'src/natureai_next/ui/qt/application.py').read_text()
    assert 'ecology_service=self._ai_review_workspace.ecology_service' in text

def test_species_dashboard_contains_seasonal_and_conservation_sections():
    text=(ROOT/'src/natureai_next/ui/qt/observations.py').read_text()
    assert 'Conservation, seasonality & habitat' in text
    assert 'Seasonal presence:' in text
    assert 'Species Dashboard & Observation History' in text

def test_ai_review_explanation_is_evidence_honest():
    text=(ROOT/'src/natureai_next/ui/qt/ai_review.py').read_text()
    assert 'Why this suggestion?' in text
    assert 'Feature-level visual explanations' in text
    assert 'does not change identification confidence' in text
