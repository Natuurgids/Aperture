from pathlib import Path


def test_health_center_is_library_focused_and_has_recovery_actions() -> None:
    health = Path("src/natureai_next/ui/qt/health.py").read_text(encoding="utf-8")
    assert "Aperture Health Center" in health
    assert "Run Full Database Check" in health
    assert "Repair Safe Items" in health
    assert "Back Up Library…" in health
    assert "Restore Library…" in health
    assert "Check for Updates…" in health


def test_desktop_launcher_injects_library_health_service() -> None:
    launcher = Path("src/natureai_next/bootstrap/cli.py").read_text(encoding="utf-8")
    assert "LibraryHealthService(" in launcher
    assert "connection_factory=opened.connection_factory" in launcher
