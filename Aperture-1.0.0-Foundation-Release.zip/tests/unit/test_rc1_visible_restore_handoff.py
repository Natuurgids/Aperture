from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def test_restore_is_visible_and_reports_progress() -> None:
    source = (ROOT / "src/natureai_next/ui/qt/maintenance_center.py").read_text(encoding="utf-8")
    assert "The Maintenance Center will remain visible and show progress" in source
    assert "Creating and verifying the emergency backup" in source
    assert "Closing Aperture safely before restore" in source
    assert "Waiting for the library lock to be released" in source
    assert "Restoring the selected database" in source
    assert "Restore complete. Restarting Aperture" in source
    assert "self.show(); self.raise_(); self.activateWindow()" in source


def test_emergency_backup_is_created_before_aperture_shutdown() -> None:
    source = (ROOT / "src/natureai_next/ui/qt/maintenance_center.py").read_text(encoding="utf-8")
    backup = source.index("emergency = _create_emergency_backup")
    shutdown = source.index("if not _request_aperture_close")
    assert backup < shutdown
    assert "LibraryRecoveryService().verify(result.database_path)" in source


def test_restore_has_persistent_history_and_foreign_key_validation() -> None:
    source = (ROOT / "src/natureai_next/ui/qt/maintenance_center.py").read_text(encoding="utf-8")
    assert 'restore-history.jsonl' in source
    assert 'PRAGMA foreign_key_check' in source
    assert '_append_restore_log(self.library, "failed"' in source
