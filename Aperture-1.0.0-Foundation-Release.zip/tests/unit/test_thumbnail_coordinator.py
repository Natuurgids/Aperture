from pathlib import Path
from threading import Event
from natureai_next.ui.presentation.thumbnails import ThumbnailCoordinator

def test_coalesces_requests_and_delivers_current_generation(tmp_path:Path)->None:
    p=tmp_path/'x.bin';p.write_bytes(b'abc');c=ThumbnailCoordinator(max_workers=1,max_cache_bytes=10);g=c.new_generation();done=Event();results=[]
    def cb(key:str,data:bytes|None)->None:results.append((key,data));
    def cb2(key:str,data:bytes|None)->None:results.append((key,data));done.set()
    c.request('k',p,g,cb);c.request('k',p,g,cb2);assert done.wait(2);assert results==[('k',b'abc'),('k',b'abc')];c.close()

def test_discards_obsolete_generation(tmp_path:Path)->None:
    p=tmp_path/'x.bin';p.write_bytes(b'abc');c=ThumbnailCoordinator(max_workers=1);g=c.new_generation();c.new_generation();called=[];c.request('k',p,g,lambda k,d:called.append(d));c.close();assert called==[]
