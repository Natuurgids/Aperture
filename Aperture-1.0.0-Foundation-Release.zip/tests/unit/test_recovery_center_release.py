from pathlib import Path


def test_recovery_actions_are_available_in_desktop_shell() -> None:
    application = Path("src/natureai_next/ui/qt/application.py").read_text(encoding="utf-8")
    assert 'QAction("Restore Library…", self)' in application
    assert 'QKeySequence("Ctrl+Shift+R")' in application
    assert 'QAction("Verify Backup…", self)' in application
    assert 'QAction("Manage Backups…", self)' in application
    assert "toolbar.addAction(self._restore_action)" in application
    assert "file_menu.addAction(self._restore_action)" in application
    assert "settings_menu.addAction(self._restore_action)" in application
    assert '"--ready-file"' in application
    assert "The Maintenance Center started but did not display a window" in application


def test_restart_safe_restore_script_is_packaged() -> None:
    script = Path("scripts/restore_staged_backup.ps1").read_text(encoding="utf-8")
    assert "natureai-next.pending-restore" in script
    assert "Get-FileHash -Algorithm SHA256" in script
    assert "pre-restore-rollback" in script
