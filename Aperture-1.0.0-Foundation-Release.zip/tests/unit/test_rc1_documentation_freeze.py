from pathlib import Path


def test_roadmap_is_packaged_and_registered() -> None:
    root = Path(__file__).resolve().parents[2]
    roadmap = (root / "docs" / "user-guide" / "roadmap.md").read_text(encoding="utf-8")
    packaged = (root / "src" / "natureai_next" / "resources" / "help" / "user-guide" / "roadmap.md").read_text(encoding="utf-8")
    help_system = (root / "src" / "natureai_next" / "ui" / "qt" / "help_system.py").read_text(encoding="utf-8")
    application = (root / "src" / "natureai_next" / "ui" / "qt" / "application.py").read_text(encoding="utf-8")

    assert roadmap == packaged
    assert "Version 2 — Knowledge and Library Management" in roadmap
    assert "Offline maps" in roadmap
    assert "Version 5 — Intelligent Search and Discovery" in roadmap
    assert 'HelpTopic("roadmap"' in help_system
    assert 'Roadmap && Future Releases' in application


def test_handover_is_packaged_and_registered() -> None:
    root = Path(__file__).resolve().parents[2]
    handover = (root / "docs" / "PROJECT_HANDOVER.md").read_text(encoding="utf-8")
    packaged = (root / "src" / "natureai_next" / "resources" / "help" / "PROJECT_HANDOVER.md").read_text(encoding="utf-8")
    assert handover == packaged
    assert "NatureAI_Next" in handover
    assert "BioCLIP" in handover
    assert "runtime is frozen" in handover.lower()
