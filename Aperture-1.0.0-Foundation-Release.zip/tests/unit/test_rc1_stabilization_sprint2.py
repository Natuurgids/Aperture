from pathlib import Path

from natureai_next.bootstrap.startup_timing import StartupTimeline, latest_startup_summary


def test_latest_startup_summary_skips_invalid_tail(tmp_path: Path):
    log = tmp_path / "startup-timing.jsonl"
    log.write_text('{"events":[{"stage":"main-window-visible","elapsed_ms":123.4}]}\nnot-json\n', encoding='utf-8')
    value = latest_startup_summary(log)
    assert value is not None
    assert value['events'][-1]['elapsed_ms'] == 123.4


def test_desktop_receives_startup_timeline_and_lock_has_exit_fallback():
    root = Path(__file__).resolve().parents[2]
    cli = (root / 'src/natureai_next/bootstrap/cli.py').read_text(encoding='utf-8')
    lock = (root / 'src/natureai_next/infrastructure/filesystem/library_lock.py').read_text(encoding='utf-8')
    maintenance = (root / 'src/natureai_next/ui/qt/maintenance_center.py').read_text(encoding='utf-8')
    assert 'startup_timeline=startup' in cli
    assert 'atexit.register(self.release)' in lock
    assert 'Startup performance' in maintenance
    assert 'Open Startup Log' in maintenance
