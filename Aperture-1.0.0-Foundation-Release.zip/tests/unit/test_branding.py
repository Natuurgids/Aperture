from pathlib import Path
import pytest
from natureai_next.application.branding import BrandingSettings, BrandingStore


def test_branding_defaults_and_round_trip(tmp_path: Path):
    path = tmp_path / "branding.toml"
    store = BrandingStore()
    defaults = store.load(path)
    assert defaults.application_name == "Aperture"
    assert defaults.powered_by == "NatureAI_Next"
    assert defaults.donation_url == "https://natuurgids.org"
    changed = BrandingSettings(application_name="Fork", powered_by="NatureAI_Next", organization_name="Example", project_website="https://example.org", donation_label="Donate", donation_url="https://example.org/donate")
    store.save(path, changed)
    assert store.load(path) == changed


def test_branding_rejects_unsafe_url():
    with pytest.raises(ValueError):
        BrandingSettings(donation_url="file:///tmp/nope").validate()
