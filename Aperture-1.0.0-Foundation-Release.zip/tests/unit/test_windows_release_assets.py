from __future__ import annotations

from pathlib import Path


ROOT = Path(__file__).resolve().parents[2]


def test_windows_launchers_are_packaged() -> None:
    expected = (
        "start_natureai_next.bat",
        "start_natureai_next_debug.bat",
        "select_natureai_library.bat",
        "start_admin_console.bat",
        "verify_install.bat",
    )
    for name in expected:
        path = ROOT / "scripts" / name
        assert path.is_file(), name
        assert path.read_text(encoding="utf-8").strip(), name


def test_installer_creates_machine_local_launchers_and_shortcuts() -> None:
    script = (ROOT / "scripts" / "install_windows.ps1").read_text(encoding="utf-8")
    required_fragments = (
        "function Install-WindowsLaunchers",
        "launcher_common.ps1",
        "Scripts\\aperture.exe",
        "start_natureai_next_debug.ps1",
        "select_natureai_library.ps1",
        "start_admin_console.cmd",
        "NatureAI Next - Select Library",
        "CreateDesktopShortcuts",
        "CreateStartMenuShortcuts",
        "function Register-WindowsApplication",
        "HKCU:\\Software\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\NatureAI Next",
        "DisplayVersion",
        "UninstallString",
        "ModifyPath",
        "Repair NatureAI Next",
        "Uninstall NatureAI Next",
        "function Add-NatureAIUserPath",
        "AddEnvironmentToUserPath",
        "natureai-next-resources",
    )
    for fragment in required_fragments:
        assert fragment in script, fragment


def test_uninstaller_removes_launchers_but_preserves_library_data_by_default() -> None:
    script = (ROOT / "scripts" / "uninstall_windows.ps1").read_text(encoding="utf-8")
    assert "Remove machine-local NatureAI Next launchers" in script
    assert "NatureAI libraries and source photographs were not touched" in script
    assert "RemoveApplicationData" in script


def test_windows_repair_script_is_packaged() -> None:
    path = ROOT / "scripts" / "repair_windows_integration.ps1"
    assert path.is_file()
    script = path.read_text(encoding="utf-8")
    assert "SkipDependencyInstallation" in script
    assert "SkipPackageInstallation" in script


def test_uninstaller_removes_installed_apps_registration() -> None:
    script = (ROOT / "scripts" / "uninstall_windows.ps1").read_text(encoding="utf-8")
    assert "Windows\\CurrentVersion\\Uninstall\\NatureAI Next" in script
    assert "Remove NatureAI Next Installed Apps registration" in script
    assert "InstallationRoot" in script
    assert "function Remove-NatureAIUserPath" in script


def test_installer_bootstraps_miniconda_without_system_python() -> None:
    script = (ROOT / "scripts" / "install_windows.ps1").read_text(encoding="utf-8")
    assert "function Install-MinicondaBootstrap" in script
    assert "Miniconda3-latest-Windows-x86_64.exe" in script
    assert "https://repo.anaconda.com/miniconda/" in script
    assert "repository index" in script
    assert "Get-FileHash" in script
    assert "Ensure-CondaExecutable" in script


def test_uninstaller_removes_maintenance_center_shortcut() -> None:
    script = (ROOT / "scripts" / "uninstall_windows.ps1").read_text(encoding="utf-8")
    assert "Aperture Maintenance Center.lnk" in script


def test_uninstaller_does_not_initialize_conda_channels() -> None:
    script = (ROOT / "scripts" / "uninstall_windows.ps1").read_text(encoding="utf-8")
    assert "conda env remove" not in script
    assert "env list --json" not in script
    assert "Resolve-NatureAIEnvironmentPath" in script
    assert "Remove-DirectoryWithRetry" in script
    assert "Aperture Maintenance Center.lnk" in script
