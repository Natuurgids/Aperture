from __future__ import annotations

import hashlib
import json
from pathlib import Path

import pytest

from natureai_next.application.backup import LibraryBackupService, suggested_backup_name


def test_backup_service_creates_checksum_manifest(tmp_path: Path) -> None:
    source = tmp_path / "source.sqlite3"
    source.write_bytes(b"verified aperture backup")

    def copy_backup(destination: Path) -> Path:
        destination.write_bytes(source.read_bytes())
        return destination

    service = LibraryBackupService(copy_backup, library_name="Field Library")
    result = service.create(tmp_path / "backups" / "field.sqlite3")

    assert result.database_path.read_bytes() == source.read_bytes()
    assert result.sha256 == hashlib.sha256(source.read_bytes()).hexdigest()
    payload = json.loads(result.manifest_path.read_text(encoding="utf-8"))
    assert payload["format"] == "natureai-next.database-backup"
    assert payload["format_version"] == 1
    assert payload["library_name"] == "Field Library"
    assert payload["database_file"] == "field.sqlite3"
    assert payload["sha256"] == result.sha256


def test_backup_service_never_overwrites_existing_backup(tmp_path: Path) -> None:
    destination = tmp_path / "existing.sqlite3"
    destination.write_bytes(b"keep")
    service = LibraryBackupService(lambda path: path, library_name="Library")

    with pytest.raises(FileExistsError):
        service.create(destination)

    assert destination.read_bytes() == b"keep"


def test_suggested_backup_name_is_safe_and_timestamped() -> None:
    name = suggested_backup_name("Birds / Bulgaria")
    assert name.startswith("Birds---Bulgaria-")
    assert name.endswith(".sqlite3")
    assert "/" not in name
