from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def test_help_browser_and_complete_help_menu_are_packaged():
    help_system = (ROOT / "src/natureai_next/ui/qt/help_system.py").read_text(encoding="utf-8")
    shell = (ROOT / "src/natureai_next/ui/qt/application.py").read_text(encoding="utf-8")
    assert "HelpBrowserDialog" in help_system
    assert "Search help topics" in help_system
    for label in ("Quick Start", "User Guide", "AI Workspace Guide", "Backup && Recovery Guide", "Troubleshooting"):
        assert label in shell
    assert 'QKeySequence("F1")' in shell
    assert "open_context_help" in shell


def test_ai_shortcuts_are_visible_in_dialog_workspace_and_docs():
    accessibility = (ROOT / "src/natureai_next/ui/qt/accessibility.py").read_text(encoding="utf-8")
    workspace = (ROOT / "src/natureai_next/ui/qt/ai_review.py").read_text(encoding="utf-8")
    guide = (ROOT / "docs/accessibility/ACCESSIBILITY_AND_KEYBOARD.md").read_text(encoding="utf-8")
    for shortcut in ("J", "K", "Shift+Enter", "Ctrl+Z"):
        assert shortcut in accessibility
        assert shortcut in workspace
        assert shortcut in guide


def test_all_registered_help_topics_resolve_to_files():
    import ast
    module = (ROOT / "src/natureai_next/ui/qt/help_system.py").read_text(encoding="utf-8")
    tree = ast.parse(module)
    paths = []
    for node in ast.walk(tree):
        if isinstance(node, ast.Call) and getattr(node.func, "id", None) == "HelpTopic" and len(node.args) >= 3:
            value = ast.literal_eval(node.args[2])
            paths.append(value)
    assert paths
    docs = ROOT / "docs"
    for relative in paths:
        assert (docs / relative).resolve().is_file(), relative


def test_help_guide_is_packaged():
    assert (ROOT / "docs/user-guide/help-system.md").is_file()


def test_packaged_help_is_available_inside_python_package() -> None:
    package_help = ROOT / "src" / "natureai_next" / "resources" / "help"
    assert (package_help / "getting-started" / "quick-start.md").is_file()
    assert (package_help / "user-guide" / "ai-and-resources.md").is_file()
    assert (package_help / "operations" / "offline-updates.md").is_file()
    assert (package_help / "RELEASE_NOTES.md").is_file()
