from __future__ import annotations

from pathlib import Path

import pytest

from natureai_next.application.configuration import LogLevel, Theme
from natureai_next.application.configuration_service import ConfigurationService
from natureai_next.infrastructure.filesystem.configuration_store import TomlConfigurationStore
from natureai_next.shared.errors import ConfigurationError


def service() -> ConfigurationService:
    return ConfigurationService(TomlConfigurationStore())


def test_precedence_and_source_tracking() -> None:
    effective = service().load_documents(
        (
            ("application", {"schema_version": 1, "application": {"theme": "dark"}}),
            ("user", {"application": {"theme": "light", "log_level": "DEBUG"}}),
        )
    )
    assert effective.settings.application.theme is Theme.LIGHT
    assert effective.settings.application.log_level is LogLevel.DEBUG
    assert effective.sources["application.theme"] == "user"


def test_unknown_values_are_preserved() -> None:
    effective = service().load_documents(
        (("user", {"future_section": {"value": 42}, "application": {"future_key": "x"}}),)
    )
    assert effective.unknown == {
        "future_section": {"value": 42},
        "application": {"future_key": "x"},
    }


def test_invalid_value_raises_typed_error() -> None:
    with pytest.raises(ConfigurationError) as caught:
        service().load_documents((("user", {"performance": {"io_workers": 0}}),))
    assert caught.value.descriptor.code == "configuration.invalid"


def test_round_trip_and_atomic_write(tmp_path: Path) -> None:
    path = tmp_path / "app-config.toml"
    effective = service().load_documents(
        (("user", {"application": {"theme": "dark"}, "future_section": {"enabled": True}}),)
    )
    service().save(path, effective)
    loaded = service().load_files((("user", path),))
    assert loaded.settings.application.theme is Theme.DARK
    assert loaded.unknown["future_section"] == {"enabled": True}
    assert list(tmp_path.glob("*.tmp")) == []


def test_unversioned_configuration_is_backed_up_and_migrated(tmp_path: Path) -> None:
    path = tmp_path / "app-config.toml"
    path.write_text('[application]\ntheme = "dark"\n', encoding="utf-8")
    effective = service().load_files((("user", path),))
    assert effective.settings.schema_version == 1
    assert (tmp_path / "app-config.toml.v0.bak").exists()
