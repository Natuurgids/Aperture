from pathlib import Path
import pytest
from natureai_next.domain.ai import EmbeddingVector
from natureai_next.infrastructure.ai.gpu import adaptive_batch_sizes
from natureai_next.infrastructure.indexing.vector import LocalVectorIndex,LocalVectorIndexBuilder


def test_embedding_roundtrip_and_normalization()->None:
    vector=EmbeddingVector((3.0,4.0));normalized=vector.normalized()
    assert normalized.dimension==2 and normalized.values[0]==pytest.approx(.6)
    assert EmbeddingVector.from_blob(normalized.to_blob(),2).values==pytest.approx(normalized.values)


def test_adaptive_batch_sizes_are_deterministic()->None:
    assert adaptive_batch_sizes(9)==(9,4,2,1)


def test_local_vector_index_build_search_and_corruption(tmp_path:Path)->None:
    directory=tmp_path/'index';index=LocalVectorIndexBuilder().build(directory,generation='g1',vectors={'a':EmbeddingVector((1,0)),'b':EmbeddingVector((0,1))})
    assert index.validate() and index.search(EmbeddingVector((.8,.2)),2)[0].asset_public_id=='a'
    data=directory/'vectors.bin';data.write_bytes(data.read_bytes()+b'x')
    assert not LocalVectorIndex(directory).validate()
    with pytest.raises(ValueError,match='corrupt'):LocalVectorIndex(directory).search(EmbeddingVector((1,0)),1)


def test_gpu_batch_estimation_is_bounded() -> None:
    from natureai_next.infrastructure.ai.gpu import estimate_initial_batch_size
    assert estimate_initial_batch_size(available_memory_bytes=8_000, reservation_bytes=2_000, estimated_bytes_per_item=1_000, configured_maximum=16) == 6
    assert estimate_initial_batch_size(available_memory_bytes=None, reservation_bytes=0, estimated_bytes_per_item=1, configured_maximum=16) == 1
