from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]
def test_settings_workspaces_are_in_main_stack():
    source=(ROOT/'src/natureai_next/ui/qt/application.py').read_text(encoding='utf-8')
    assert '"AI Resources", "Regional Knowledge", "Health Check", "Preferences"' in source
    assert 'AIResourcesWorkspace' in source
    assert 'RegionalKnowledgeWorkspace' in source
    assert 'HealthCheckWidget' in source
    assert 'self.menuBar().addMenu("&Settings")' in source
def test_ai_review_routes_resources_to_settings():
    source=(ROOT/'src/natureai_next/ui/qt/ai_review.py').read_text(encoding='utf-8')
    assert 'resources_requested = Signal()' in source
    assert 'self._resources.clicked.connect(self.resources_requested.emit)' in source
