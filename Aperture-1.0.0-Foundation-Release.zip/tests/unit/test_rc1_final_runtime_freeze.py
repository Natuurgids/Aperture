from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def test_normal_windows_launcher_is_windowless_and_detached() -> None:
    script = (ROOT / "scripts" / "install_windows.ps1").read_text(encoding="utf-8")
    pyproject = (ROOT / "pyproject.toml").read_text(encoding="utf-8")
    assert 'aperture = "natureai_next.bootstrap.aperture_launcher:main"' in pyproject
    assert "$apertureExecutable = Join-Path $EnvironmentPath 'Scripts\\aperture.exe'" in script
    normal = next(line for line in script.splitlines() if "Name = 'Aperture';" in line)
    assert "Target = $apertureExecutable" in normal
    assert "powershell" not in normal.lower()
    assert "Aperture (Debug)" in script


def test_import_completion_opens_exact_import_session_and_logs_sync() -> None:
    application = (ROOT / "src" / "natureai_next" / "ui" / "qt" / "application.py").read_text(encoding="utf-8")
    library = (ROOT / "src" / "natureai_next" / "ui" / "qt" / "library.py").read_text(encoding="utf-8")
    assert "self._library.show_imported(public_ids" in application
    assert "def show_imported" in library
    assert "import-sync.jsonl" in library
    assert "page_assets_by_public_ids" in (ROOT / "src" / "natureai_next" / "infrastructure" / "database" / "catalog_gui.py").read_text(encoding="utf-8")
