from natureai_next.application.ai_review import CosineCandidateRanker,near_duplicate_groups
from natureai_next.domain.ai import ConfidenceBand,EmbeddingVector

def test_ranker_orders_and_marks_unknown():
    r=CosineCandidateRanker(high=.9,medium=.7,low=.5)
    items=r.rank(EmbeddingVector((1,0)),(('t2','B',EmbeddingVector((0,1))),('t1','A',EmbeddingVector((1,0)))),region_code='NL',limit=5)
    assert [x.taxon_public_id for x in items]==['t1','t2']
    assert items[0].confidence_band is ConfidenceBand.HIGH and items[1].confidence_band is ConfidenceBand.UNKNOWN

def test_near_duplicate_groups_are_deterministic():
    groups=near_duplicate_groups({'b':EmbeddingVector((1,.001)),'a':EmbeddingVector((1,0)),'c':EmbeddingVector((0,1))},threshold=.99)
    assert groups==(('a','b'),)


def test_regional_ranker_applies_occurrence_adjustments():
    from natureai_next.application.ai_review import RegionalCandidateRanker

    base = CosineCandidateRanker(high=0.9, medium=0.7, low=0.5)
    ranker = RegionalCandidateRanker(base, native_boost=0.1, present_boost=0.0, absent_penalty=0.2)
    items = ranker.rank(
        EmbeddingVector((1.0, 0.0)),
        (
            ("native", "Native", EmbeddingVector((0.8, 0.6))),
            ("absent", "Absent", EmbeddingVector((0.9, 0.435889894))),
        ),
        region_code="NL",
        occurrence_by_taxon={"native": "native", "absent": "absent"},
        limit=2,
    )
    assert [item.taxon_public_id for item in items] == ["native", "absent"]
    assert items[0].calibrated_score > items[1].calibrated_score


def test_prompt_manifest_rejects_newer_application_requirement(tmp_path):
    import json

    from natureai_next.infrastructure.ai.prompts import load_prompt_set, validate_prompt_set

    path = tmp_path / "prompts.json"
    path.write_text(
        json.dumps(
            {
                "schema_version": 1,
                "identity": "future",
                "semantic_version": "1.0.0",
                "model_family": "bioclip",
                "minimum_application_version": "99.0.0",
                "prompts": [{"label": "Bird", "text": "a photograph of a bird"}],
            }
        ),
        encoding="utf-8",
    )
    manifest = load_prompt_set(path)
    import pytest

    with pytest.raises(ValueError, match="newer application"):
        validate_prompt_set(manifest, application_version="0.9.1")
