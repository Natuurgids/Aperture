from __future__ import annotations

import json
from pathlib import Path

import pytest

from natureai_next.infrastructure.filesystem.library_manifest import read_manifest


def _write(path: Path, value: dict, *, bom: bool = False) -> None:
    data = (json.dumps(value) + "\n").encode("utf-8")
    if bom:
        data = b"\xef\xbb\xbf" + data
    path.write_bytes(data)


def test_reads_current_manifest_without_backup(tmp_path: Path) -> None:
    path = tmp_path / "library.json"
    _write(path, {"format_version": 1, "library_public_id": "id", "display_name": "Test", "created_at_us": 1, "database_filename": "library.sqlite3"})
    manifest = read_manifest(path)
    assert manifest.display_name == "Test"
    assert not path.with_name("library.json.before-normalization").exists()


def test_normalizes_bom_and_known_legacy_fields(tmp_path: Path) -> None:
    path = tmp_path / "library.json"
    _write(path, {"format": "natureai-next-library-1", "library_public_id": "id", "library_name": "Legacy", "created_at_utc": "2026-07-15T10:00:00Z", "database_file": "library.sqlite3", "sha256": "abc", "size_bytes": 42}, bom=True)
    manifest = read_manifest(path)
    assert manifest.format_version == 1
    assert manifest.display_name == "Legacy"
    assert manifest.database_filename == "library.sqlite3"
    assert manifest.created_at_us > 0
    assert path.with_name("library.json.before-normalization").exists()
    assert not path.read_bytes().startswith(b"\xef\xbb\xbf")
    saved = json.loads(path.read_text("utf-8"))
    assert set(saved) == {"format_version", "library_public_id", "display_name", "created_at_us", "database_filename"}


def test_reports_all_unknown_fields(tmp_path: Path) -> None:
    path = tmp_path / "library.json"
    _write(path, {"format_version": 1, "library_public_id": "id", "display_name": "Test", "created_at_us": 1, "database_filename": "library.sqlite3", "mystery": 1, "other": 2})
    with pytest.raises(ValueError, match="mystery, other"):
        read_manifest(path)


def test_malformed_json_has_clear_error(tmp_path: Path) -> None:
    path = tmp_path / "library.json"
    path.write_text("{", encoding="utf-8")
    with pytest.raises(ValueError, match="not valid JSON"):
        read_manifest(path)
