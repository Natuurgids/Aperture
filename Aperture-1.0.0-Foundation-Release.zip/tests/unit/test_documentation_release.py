from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def test_required_release_guides_are_packaged() -> None:
    required = (
        "docs/README.md",
        "docs/getting-started/installation.md",
        "docs/getting-started/quick-start.md",
        "docs/user-guide/README.md",
        "docs/user-guide/import-export.md",
        "docs/user-guide/ai-and-resources.md",
        "docs/operations/backup-recovery.md",
        "docs/operations/troubleshooting.md",
        "docs/operations/offline-updates.md",
        "docs/developer/README.md",
        "docs/developer/release-process.md",
    )
    for relative in required:
        path = ROOT / relative
        assert path.is_file(), relative
        assert path.read_text(encoding="utf-8").strip(), relative


def test_documentation_preserves_product_engine_boundary() -> None:
    index = (ROOT / "docs/README.md").read_text(encoding="utf-8")
    developer = (ROOT / "docs/developer/README.md").read_text(encoding="utf-8")
    release = (ROOT / "RELEASE_NOTES.md").read_text(encoding="utf-8")
    assert "Aperture" in index
    assert "NatureAI_Next" in index
    assert "natureai_next" in developer
    assert "No database migration" in release
    assert "Version 2" in release
