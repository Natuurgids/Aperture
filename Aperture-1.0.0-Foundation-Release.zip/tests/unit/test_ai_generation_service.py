from __future__ import annotations

from pathlib import Path

from PIL import Image

from natureai_next.application.ai_generation import ActiveAIContext, LocalSuggestionGenerationService
from natureai_next.domain.ai import EmbeddingVector


class Source:
    def __init__(self, artifact: Path, image: Path) -> None:
        self.artifact = artifact
        self.image = image

    def active_context(self) -> ActiveAIContext:
        return ActiveAIContext(7, "bioclip", "1", "default", "fp32", "prep-v1", 32, self.artifact, "prompt-1", "fake", "cpu")

    def asset_paths(self, public_ids):
        return tuple((value, self.image) for value in public_ids)


class Repository:
    def __init__(self) -> None:
        self.finished = None

    def begin_inference_run(self, **kwargs):
        assert kwargs["requested_item_count"] == 1
        return 11

    def finish_inference_run(self, run_id, **kwargs):
        self.finished = (run_id, kwargs)


class Taxonomy:
    def candidates(self, **kwargs):
        return (
            ("taxon-1", "Robin", EmbeddingVector((1.0, 0.0))),
            ("group:birds", "Birds", EmbeddingVector((1.0, 0.0))),
        )


class Suggestions:
    def __init__(self) -> None:
        self.created = []

    def create(self, **kwargs):
        self.created.append(kwargs)
        return ("suggestion-1",)


class Provider:
    def load(self, path, **kwargs):
        assert path.is_file()
        return object()

    def embed_images(self, model, images):
        assert len(images) == 1
        return (EmbeddingVector((1.0, 0.0)),)

    def unload(self, model):
        return None


def test_local_generation_persists_ranked_evidence(tmp_path: Path) -> None:
    artifact = tmp_path / "model.pt"
    artifact.write_bytes(b"model")
    image = tmp_path / "bird.jpg"
    Image.new("RGB", (64, 48)).save(image)
    repository = Repository()
    suggestions = Suggestions()
    ids = iter(("run-public", "suggestion-public"))
    service = LocalSuggestionGenerationService(
        source=Source(artifact, image),
        ai_repository=repository,
        taxonomy_embeddings=Taxonomy(),
        suggestions=suggestions,
        id_factory=lambda: next(ids),
        now_us=lambda: 123,
        provider=Provider(),
    )

    result = service.generate_selected(("asset-1",))

    assert result.completed_assets == 1
    assert result.suggestions_created == 1
    assert result.failed == ()
    assert len(suggestions.created[0]["suggestions"]) == 1
    assert suggestions.created[0]["suggestions"][0].label == "Robin"
    assert repository.finished[1]["completed"] == 1


def test_local_generation_requires_selection(tmp_path: Path) -> None:
    artifact = tmp_path / "model.pt"
    artifact.write_bytes(b"model")
    image = tmp_path / "bird.jpg"
    Image.new("RGB", (32, 32)).save(image)
    service = LocalSuggestionGenerationService(
        source=Source(artifact, image), ai_repository=Repository(), taxonomy_embeddings=Taxonomy(),
        suggestions=Suggestions(), id_factory=lambda: "id", now_us=lambda: 1, provider=Provider(),
    )
    try:
        service.generate_selected(())
    except ValueError as exc:
        assert "Select at least one" in str(exc)
    else:
        raise AssertionError("empty selection must fail")
