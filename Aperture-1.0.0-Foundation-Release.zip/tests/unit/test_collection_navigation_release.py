from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def test_navigation_dock_can_be_restored_from_view_menu() -> None:
    application = (ROOT / 'src/natureai_next/ui/qt/application.py').read_text(encoding='utf-8')
    assert 'self._navigation_dock.toggleViewAction()' in application
    assert 'Reset workspace layout' in application
    assert 'def reset_workspace_layout' in application


def test_collections_navigation_routes_to_live_library_controls() -> None:
    application = (ROOT / 'src/natureai_next/ui/qt/application.py').read_text(encoding='utf-8')
    library = (ROOT / 'src/natureai_next/ui/qt/library.py').read_text(encoding='utf-8')
    assert 'def _workspace_changed' in application
    assert 'self._library.focus_collections()' in application
    assert 'def focus_collections' in library


def test_collection_assignment_uses_explicit_manual_collection_chooser() -> None:
    library = (ROOT / 'src/natureai_next/ui/qt/library.py').read_text(encoding='utf-8')
    assert 'Add selected to…' in library
    assert 'QInputDialog.getItem' in library
    assert 'Create a manual collection first.' in library
    assert 'collection_type' in library


def test_collection_reload_passes_user_data_only_once() -> None:
    library = (ROOT / 'src/natureai_next/ui/qt/library.py').read_text(encoding='utf-8')
    assert 'self._collections.addItem(label, str(getattr(item, "public_id")))' in library
    assert 'addItem(label, str(getattr(item, "public_id")), userData=' not in library


def test_core_panes_are_docked_and_not_floatable() -> None:
    application = (ROOT / 'src/natureai_next/ui/qt/application.py').read_text(encoding='utf-8')
    assert 'self._navigation_dock.setAllowedAreas(Qt.DockWidgetArea.LeftDockWidgetArea)' in application
    assert 'self._inspector_dock.setAllowedAreas(Qt.DockWidgetArea.RightDockWidgetArea)' in application
    assert 'DockWidgetFeature.DockWidgetFloatable' not in application
    assert 'self.restoreState(' not in application
    assert 'dock_state_b64=None' in application
    assert 'self._navigation_dock.setFloating(False)' in application
    assert 'self._inspector_dock.setFloating(False)' in application
