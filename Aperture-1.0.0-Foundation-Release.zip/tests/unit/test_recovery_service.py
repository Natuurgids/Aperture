from __future__ import annotations

import hashlib
import json
from pathlib import Path

import pytest

from natureai_next.application.recovery import LibraryRecoveryService


def _backup(directory: Path, name: str = "field.sqlite3", contents: bytes = b"catalog") -> Path:
    database = directory / name
    database.parent.mkdir(parents=True, exist_ok=True)
    database.write_bytes(contents)
    manifest = database.with_suffix(database.suffix + ".manifest.json")
    manifest.write_text(json.dumps({
        "format": "natureai-next.database-backup",
        "format_version": 1,
        "library_name": "Field Library",
        "created_at_utc": "2026-07-14T00:00:00+00:00",
        "database_file": database.name,
        "size_bytes": len(contents),
        "sha256": hashlib.sha256(contents).hexdigest(),
    }), encoding="utf-8")
    return database


def test_verify_backup_accepts_matching_manifest(tmp_path: Path) -> None:
    verified = LibraryRecoveryService().verify(_backup(tmp_path))
    assert verified.library_name == "Field Library"
    assert verified.sha256 == hashlib.sha256(b"catalog").hexdigest()


def test_verify_backup_rejects_tampering(tmp_path: Path) -> None:
    database = _backup(tmp_path)
    database.write_bytes(b"tampered")
    with pytest.raises(ValueError, match="size|checksum"):
        LibraryRecoveryService().verify(database)


def test_list_backups_ignores_invalid_files(tmp_path: Path) -> None:
    valid = _backup(tmp_path, "valid.sqlite3")
    (tmp_path / "invalid.sqlite3").write_bytes(b"no manifest")
    listed = LibraryRecoveryService().list_backups(tmp_path)
    assert [item.database_path for item in listed] == [valid.resolve()]


def test_stage_restore_requires_emergency_backup_and_writes_request(tmp_path: Path) -> None:
    service = LibraryRecoveryService()
    source = service.verify(_backup(tmp_path / "backups"))
    current = tmp_path / "library.sqlite3"
    current.write_bytes(b"current")
    emergency = _backup(tmp_path / "backups", "emergency.sqlite3", b"current")
    result = service.stage_restore(
        source,
        staging_directory=tmp_path / "recovery" / "staging",
        current_database=current,
        emergency_backup=emergency,
    )
    assert service.verify(result.staged_database).sha256 == source.sha256
    request = json.loads(result.request_path.read_text(encoding="utf-8"))
    assert request["format"] == "natureai-next.pending-restore"
    assert request["target_database"] == str(current.resolve())
    assert request["emergency_backup"] == str(emergency.resolve())


def test_stage_restore_refuses_missing_emergency_backup(tmp_path: Path) -> None:
    service = LibraryRecoveryService()
    source = service.verify(_backup(tmp_path / "backups"))
    current = tmp_path / "library.sqlite3"
    current.write_bytes(b"current")
    with pytest.raises(FileNotFoundError, match="emergency"):
        service.stage_restore(source, staging_directory=tmp_path / "stage", current_database=current, emergency_backup=tmp_path / "missing.sqlite3")
