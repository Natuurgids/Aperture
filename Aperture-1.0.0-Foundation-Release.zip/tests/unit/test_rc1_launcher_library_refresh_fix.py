from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]

def test_windowless_launcher_reads_same_configuration_as_debug_launcher() -> None:
    source = (ROOT / "src" / "natureai_next" / "bootstrap" / "aperture_launcher.py").read_text(encoding="utf-8")
    assert 'os.environ.get("APPDATA")' in source
    assert '/ "NatureAI" / "NatureAI Next" / "launcher.json"' in source
    assert 'LOCALAPPDATA' not in source

def test_all_library_requests_complete_rc_scale_page() -> None:
    source = (ROOT / "src" / "natureai_next" / "ui" / "qt" / "library.py").read_text(encoding="utf-8")
    assert "self._service.page(limit=500" in source
    assert "self._thumbnail_limit = 8" in source
    assert "def _drain_thumbnail_queue" in source

def test_zero_import_does_not_create_empty_latest_import_view() -> None:
    source = (ROOT / "src" / "natureai_next" / "ui" / "qt" / "library.py").read_text(encoding="utf-8")
    assert "if not normalized_ids:" in source
    assert "self.clear_active_view()" in source
