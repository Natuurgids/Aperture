from pathlib import Path
from types import SimpleNamespace

from natureai_next.domain.exporting import OriginalFileExportResult
from natureai_next.jobs.export_handlers import ResumableOriginalFileExportJobHandler


class Service:
    def __init__(self):
        self.plan = None

    def execute(self, plan, **kwargs):
        self.plan = plan
        kwargs["cancellation_check"]()
        kwargs["progress"](1, 1, "done")
        return OriginalFileExportResult(plan.public_id, plan.destination_directory, (), None, None)


class Cancellation:
    def __init__(self):
        self.checked = 0

    def raise_if_cancelled(self):
        self.checked += 1


def test_resumable_export_job_uses_versioned_payload_and_progress(tmp_path: Path) -> None:
    service = Service()
    cancellation = Cancellation()
    progress = []
    context = SimpleNamespace(
        job=SimpleNamespace(
            public_id="job-export-1",
            created_at_us=10,
            payload_json=(
                '{"schema_version":2,"destination_directory":"'
                + str(tmp_path).replace("\\", "\\\\")
                + '","asset_public_ids":["asset-1"]}'
            ),
        ),
        cancellation=cancellation,
        report_progress=lambda current, total, unit, message: progress.append((current, total, unit, message)),
    )
    result = ResumableOriginalFileExportJobHandler(service, lambda: 20).execute(context)
    assert result["asset_count"] == 0
    assert service.plan.public_id == "job-export-1"
    assert service.plan.selection.asset_public_ids == ("asset-1",)
    assert cancellation.checked == 1
    assert progress == [(1, 1, "assets", "done")]

from natureai_next.domain.exporting import DerivativeExportResult, DerivativeFormat
from natureai_next.jobs.export_handlers import ResumableDerivativeExportJobHandler


class DerivativeService:
    def __init__(self):
        self.plan = None

    def execute(self, plan, **kwargs):
        self.plan = plan
        kwargs["cancellation_check"]()
        kwargs["progress"](2, 2, "done")
        return DerivativeExportResult(plan.public_id, plan.destination_directory, (), None, None)


def test_resumable_derivative_job_uses_versioned_payload_and_progress(tmp_path: Path) -> None:
    service = DerivativeService()
    cancellation = Cancellation()
    progress = []
    context = SimpleNamespace(
        job=SimpleNamespace(
            public_id="job-derivative-1",
            created_at_us=11,
            payload_json=(
                '{"schema_version":2,"destination_directory":"'
                + str(tmp_path).replace("\\", "\\\\")
                + '","asset_public_ids":["asset-1"],"format":"png","max_width":1200,"max_height":800}'
            ),
        ),
        cancellation=cancellation,
        report_progress=lambda current, total, unit, message: progress.append((current, total, unit, message)),
    )
    result = ResumableDerivativeExportJobHandler(service, lambda: 21).execute(context)
    assert result["asset_count"] == 0
    assert service.plan.public_id == "job-derivative-1"
    assert service.plan.format is DerivativeFormat.PNG
    assert service.plan.max_width == 1200
    assert service.plan.max_height == 800
    assert cancellation.checked == 1
    assert progress == [(2, 2, "assets", "done")]
