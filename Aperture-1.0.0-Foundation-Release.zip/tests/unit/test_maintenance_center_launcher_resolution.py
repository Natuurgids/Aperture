from pathlib import Path


def test_application_launches_installed_module_with_pythonw_and_waits_for_window_ready():
    source = Path("src/natureai_next/ui/qt/application.py").read_text(encoding="utf-8")
    assert 'Path(os.sys.prefix) / "pythonw.exe"' in source
    assert '"natureai_next.bootstrap.maintenance_center"' in source
    assert '"--ready-file"' in source
    assert 'maintenance-launch.jsonl' in source
    assert 'window-ready' in source


def test_maintenance_center_writes_ready_file_after_first_ui_event():
    source = Path("src/natureai_next/ui/qt/maintenance_center.py").read_text(encoding="utf-8")
    assert 'parser.add_argument("--ready-file", type=Path)' in source
    assert 'app.processEvents()' in source
    assert '"status": "window-ready"' in source
