from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def test_aperture_is_packaged_as_a_gui_script() -> None:
    pyproject = (ROOT / "pyproject.toml").read_text(encoding="utf-8")
    assert '[project.gui-scripts]' in pyproject
    assert 'aperture = "natureai_next.bootstrap.aperture_launcher:main"' in pyproject


def test_normal_shortcut_targets_installed_aperture_gui_executable() -> None:
    script = (ROOT / "scripts" / "install_windows.ps1").read_text(encoding="utf-8")
    assert "$apertureExecutable = Join-Path $EnvironmentPath 'Scripts\\aperture.exe'" in script
    normal = next(line for line in script.splitlines() if "Name = 'Aperture';" in line)
    assert "Target = $apertureExecutable" in normal
    assert "Arguments = ''" in normal
    assert "powershell" not in normal.lower()
    assert "wscript" not in normal.lower()
    assert "pythonw" not in normal.lower()


def test_gui_launcher_reads_saved_library_and_calls_cli() -> None:
    source = (ROOT / "src" / "natureai_next" / "bootstrap" / "aperture_launcher.py").read_text(encoding="utf-8")
    assert '"NatureAI" / "NatureAI Next" / "launcher.json"' in source
    assert 'cli_main(["--library", str(library), "--log-level", "INFO"])' in source
