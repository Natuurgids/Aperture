from pathlib import Path


def test_update_manager_is_exposed_in_settings_and_help() -> None:
    application = Path("src/natureai_next/ui/qt/application.py").read_text(encoding="utf-8")
    assert '"Updates"' in application
    assert 'QAction("Check for Updates…", self)' in application
    assert "settings_menu.addAction(self._check_updates_action)" in application
    assert "help_menu.addAction(self._check_updates_action)" in application
    assert "OfflineUpdateService" in application
    assert "Back Up and Install" in application
    assert "Install Without Backup" in application
    assert "app.quit" in application
