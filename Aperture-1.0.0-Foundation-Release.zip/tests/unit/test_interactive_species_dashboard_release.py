from pathlib import Path

def test_interactive_species_dashboard_controls_are_present() -> None:
    root=Path(__file__).resolve().parents[2]
    workspace=(root/'src/natureai_next/ui/qt/observations.py').read_text(encoding='utf-8')
    adapter=(root/'src/natureai_next/infrastructure/database/observation_intelligence.py').read_text(encoding='utf-8')
    assert 'All countries' in workspace
    assert 'All collections' in workspace
    assert 'Personal observations vs expected season' in workspace
    assert 'Related taxa' in workspace
    assert 'def related_taxa' in adapter
