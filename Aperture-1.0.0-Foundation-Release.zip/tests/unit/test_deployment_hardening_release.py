from __future__ import annotations

import json
from pathlib import Path

from scripts.deployment_preflight import validate_release

ROOT = Path(__file__).resolve().parents[2]


def test_deployment_preflight_passes_release_tree() -> None:
    report = validate_release(ROOT)
    assert report["product"] == "Aperture"
    assert report["engine"] == "NatureAI_Next"
    assert report["passed"] is True


def test_installer_runs_preflight_before_environment_mutation() -> None:
    script = (ROOT / "scripts/install_windows.ps1").read_text(encoding="utf-8")
    assert "SkipDeploymentPreflight" in script
    assert "deployment_preflight.py" in script
    assert script.index("Validating release package before installation") < script.index("$script:CondaExecutable = Resolve-CondaExecutable")


def test_diagnostics_bundle_and_deployment_guide_are_packaged() -> None:
    diagnostics = (ROOT / "scripts/collect_installer_diagnostics.ps1").read_text(encoding="utf-8")
    guide = (ROOT / "docs/operations/deployment-and-upgrades.md").read_text(encoding="utf-8")
    assert "Compress-Archive" in diagnostics
    assert "deployment-preflight.json" in diagnostics
    assert "libraries or photographs" in diagnostics
    assert "Repair Aperture" in guide
    assert "preserved by default" in guide
