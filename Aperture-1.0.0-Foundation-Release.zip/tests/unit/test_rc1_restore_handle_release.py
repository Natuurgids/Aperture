from pathlib import Path
import sqlite3

from natureai_next.infrastructure.database.restore import (
    replace_database_with_retry,
    validate_database_and_close,
)


def test_validation_releases_sqlite_handle_before_replace(tmp_path: Path) -> None:
    source = tmp_path / "library.sqlite3.restore.tmp"
    target = tmp_path / "library.sqlite3"
    connection = sqlite3.connect(source)
    connection.execute("CREATE TABLE sample(id INTEGER PRIMARY KEY)")
    connection.commit()
    connection.close()
    target.write_bytes(b"old")

    validate_database_and_close(source)
    replace_database_with_retry(source, target)

    assert not source.exists()
    check = sqlite3.connect(target)
    try:
        assert check.execute("PRAGMA integrity_check").fetchone()[0] == "ok"
    finally:
        check.close()


def test_retry_logger_receives_locked_replace_errors(tmp_path: Path, monkeypatch) -> None:
    source = tmp_path / "source"
    target = tmp_path / "target"
    source.write_bytes(b"new")
    target.write_bytes(b"old")
    calls = []
    real_replace = __import__("os").replace
    count = {"value": 0}

    def flaky_replace(src, dst):
        count["value"] += 1
        if count["value"] < 3:
            raise PermissionError(32, "file in use")
        return real_replace(src, dst)

    monkeypatch.setattr("natureai_next.infrastructure.database.restore.os.replace", flaky_replace)
    monkeypatch.setattr("natureai_next.infrastructure.database.restore.time.sleep", lambda _delay: None)
    replace_database_with_retry(source, target, retry_logger=lambda attempt, exc: calls.append((attempt, str(exc))))
    assert [attempt for attempt, _ in calls] == [1, 2]
    assert target.read_bytes() == b"new"


def test_maintenance_restore_uses_close_and_retry_helpers() -> None:
    source = Path("src/natureai_next/ui/qt/maintenance_center.py").read_text(encoding="utf-8")
    assert "validate_database_and_close(temp)" in source
    assert "replace_database_with_retry(" in source
    assert '"validated-and-closed"' in source
