from __future__ import annotations

import json
from pathlib import Path

import pytest

from natureai_next.application.native_handoff import wait_for_helper_ready
from natureai_next.infrastructure.filesystem.library_lock import recover_stale_library_lock


class _Process:
    returncode: int | None = None

    def poll(self) -> int | None:
        return self.returncode


def test_helper_ready_handshake_accepts_acknowledged_request(tmp_path: Path) -> None:
    request = tmp_path / "pending-update.json"
    request.write_text(json.dumps({"status": "helper-ready"}), encoding="utf-8")
    wait_for_helper_ready(_Process(), request, timeout_seconds=0.2)  # type: ignore[arg-type]


def test_helper_ready_handshake_rejects_failed_helper(tmp_path: Path) -> None:
    request = tmp_path / "pending-update.json"
    request.write_text(json.dumps({"status": "failed", "detail": "bad package"}), encoding="utf-8")
    with pytest.raises(RuntimeError, match="bad package"):
        wait_for_helper_ready(_Process(), request, timeout_seconds=0.2)  # type: ignore[arg-type]


def test_update_ui_waits_for_helper_acknowledgement() -> None:
    source = Path("src/natureai_next/ui/qt/application.py").read_text(encoding="utf-8")
    assert "wait_for_helper_ready(helper, staged.request_path" in source
    assert source.index("wait_for_helper_ready(helper") < source.index("app.quit")


def test_native_updater_waits_for_library_unlock_before_install() -> None:
    source = Path("src/natureai_next/bootstrap/native_updater.py").read_text(encoding="utf-8")
    assert '_write_status(request_path, payload, "waiting-for-library-unlock")' in source
    assert source.index("_wait_for_library_unlock") < source.index('"-m", "pip"')


def test_absent_lock_is_already_recovered(tmp_path: Path) -> None:
    assert recover_stale_library_lock(tmp_path / ".natureai-next.lock") is True
