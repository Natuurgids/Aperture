from pathlib import Path


def test_backup_button_is_available_in_desktop_shell() -> None:
    application = Path("src/natureai_next/ui/qt/application.py").read_text(encoding="utf-8")
    assert 'QAction("Back Up Library…", self)' in application
    assert 'QKeySequence("Ctrl+Shift+B")' in application
    assert "toolbar.addAction(self._backup_action)" in application
    assert "file_menu.addAction(self._backup_action)" in application
    assert "settings_menu.addAction(self._backup_action)" in application
    assert "Aperture never overwrites an existing backup" in application


def test_desktop_launcher_injects_open_library_backup_service() -> None:
    launcher = Path("src/natureai_next/bootstrap/cli.py").read_text(encoding="utf-8")
    assert "LibraryBackupService(opened.backup_database" in launcher
    assert "default_backup_directory=opened.layout.backups" in launcher
