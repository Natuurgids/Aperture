from __future__ import annotations

import json
from pathlib import Path

from natureai_next.application.native_handoff import augment_request
from natureai_next.bootstrap import native_recovery, native_updater


def test_augment_request_adds_runtime_handoff(tmp_path: Path) -> None:
    request = tmp_path / "pending-update.json"
    request.write_text('{"format":"natureai-next.pending-update","format_version":1}\n', encoding="utf-8")
    library = tmp_path / "library"
    library.mkdir()
    augment_request(request, parent_pid=123, library_path=library)
    payload = json.loads(request.read_text(encoding="utf-8"))
    assert payload["parent_pid"] == 123
    assert payload["library_path"] == str(library.resolve())


def test_native_updater_rejects_tampered_package(tmp_path: Path) -> None:
    package = tmp_path / "release.zip"
    package.write_bytes(b"tampered")
    request = tmp_path / "pending-update.json"
    request.write_text(json.dumps({
        "format": "natureai-next.pending-update",
        "format_version": 1,
        "version": "9.9.9",
        "package": package.name,
        "sha256": "0" * 64,
    }), encoding="utf-8")
    try:
        native_updater.main(["--request", str(request), "--parent-pid", "999999", "--library", str(tmp_path)])
    except ValueError as exc:
        assert "verification failed" in str(exc)
    else:
        raise AssertionError("tampered update was accepted")


def test_native_recovery_rejects_tampered_database(tmp_path: Path) -> None:
    staged = tmp_path / "restore.sqlite3"
    staged.write_bytes(b"tampered")
    target = tmp_path / "library.sqlite3"
    target.write_bytes(b"current")
    emergency = tmp_path / "emergency.sqlite3"
    emergency.write_bytes(b"backup")
    request = tmp_path / "pending-restore.json"
    request.write_text(json.dumps({
        "format": "natureai-next.pending-restore",
        "format_version": 1,
        "staged_database": str(staged),
        "target_database": str(target),
        "emergency_backup": str(emergency),
        "sha256": "0" * 64,
    }), encoding="utf-8")
    try:
        native_recovery.main(["--request", str(request), "--parent-pid", "999999", "--library", str(tmp_path)])
    except ValueError as exc:
        assert "verification failed" in str(exc)
    else:
        raise AssertionError("tampered restore was accepted")
