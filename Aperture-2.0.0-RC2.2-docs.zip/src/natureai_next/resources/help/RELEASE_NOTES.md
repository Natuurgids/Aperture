# Aperture 2.0.0 RC1 — Release Candidate 1

**Product:** Aperture  
**Engine:** NatureAI Next  
**Release status:** Feature-complete release candidate  
**Release date:** 16 July 2026

## Purpose

Aperture 2.0 RC1 is the frozen Release 2 candidate for final field validation. It is an offline-first, single-user desktop application for nature enthusiasts who organise photographs, review AI-assisted identifications, maintain observations, and use selected regional resources without requiring a permanent network connection.

No new functionality is planned between RC1 and the stable 2.0 release. Only confirmed release-blocking or high-severity defects should change the candidate.

## Release 2 highlights

- Aperture Library with managed and referenced photographs.
- Import, browsing, viewer, metadata, collections, and observation workflows.
- BioCLIP integration through the NatureAI Next engine.
- User review before AI suggestions become accepted observations.
- Multiple accepted observations may be associated with one photograph.
- Regional AI knowledge packages and resource management.
- Offline map acquisition from Geofabrik/OpenStreetMap regional extracts.
- Background map download, verification, conversion to MBTiles, installation, enable/disable, area selection, and offline display.
- Maintenance Center, Activity Center, health checks, cleanup, repair, backup, restore, and uninstall safeguards.
- Integrated Help browser, Vision, Philosophy, architecture, development documentation, About pages, licences, and system information.

## Confirmed map capability

The Release 2 offline map workflow is complete for the generated zoom range:

1. download the regional catalog;
2. select a provider leaf region;
3. download and verify the Geofabrik source archive;
4. convert it locally to raster MBTiles;
5. validate tiles, bounds, zoom metadata, and raster format;
6. register and enable the package;
7. select the installed area and open it in the Maps workspace.

The current renderer produces low-to-medium zoom packages. Higher-detail tile generation and richer globe-style map navigation are deferred.

## Deliberately deferred to Release 3 or later

- Species Dashboard search and matching-photo overview.
- Higher-detail map generation beyond the current maximum zoom.
- Multi-core and adaptive map rendering.
- Globe navigation, rotation, graphical coverage selection, and broader map maturity.
- Startup and platform-wide performance refinements.
- Central progress aggregation with one-second UI presentation as a platform standard.
- Projects, reporting, collaboration, portable field systems, and science-platform capabilities according to their future releases or branches.

## Known limitations

- Offline maps display only the zoom levels generated into the installed package.
- Map preparation may be lengthy because Release 2 conversion is intentionally lean and largely single-process.
- Provider source archives are much larger than the resulting low-to-medium zoom raster package.
- Internet access is required only to acquire online catalogs, source packages, application dependencies, or approved updates. Installed resources continue to work offline.
- Species Dashboard name search and matching-photo browsing are not included in RC1.

## Upgrade and data safety

- The Aperture Library is separate from the application installation.
- Upgrade, repair, and uninstall operations must not remove the Aperture Library unless the user performs a separate explicit data-removal action.
- Back up important libraries before release-candidate testing.
- Existing installed offline maps should be discovered without rerendering when their MBTiles and catalog records are valid.

## Validation focus

RC1 field validation should concentrate on:

- clean installation and upgrade;
- opening an existing Aperture Library;
- offline startup and normal offline operation;
- import, viewing, AI review, and multiple observations;
- resource installation and removal;
- offline map selection and display;
- Maintenance Center and Activity Center recovery behavior;
- backup, restore, repair, and uninstall preservation;
- Help, About, licences, and final documentation accuracy.
