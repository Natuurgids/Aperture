"""Application-wide durable background activity tracking for long-running Qt work."""
from __future__ import annotations

import inspect
import json
import threading
import time
import uuid
from dataclasses import asdict, dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Callable

from platformdirs import user_state_dir

try:
    from PySide6.QtCore import QObject, QThread, Signal, Slot
    from PySide6.QtWidgets import (
        QDialog, QHBoxLayout, QLabel, QListWidget, QListWidgetItem,
        QProgressBar, QPushButton, QTextBrowser, QVBoxLayout, QWidget,
    )
except ImportError as exc:  # pragma: no cover
    raise RuntimeError("PySide6 is required") from exc


class ActivityCancelled(RuntimeError):
    """Raised cooperatively when a user cancels a background activity."""


@dataclass
class ActivityRecord:
    title: str
    detail: str
    state: str = "queued"
    current: int = 0
    total: int = 0
    message: str = "Queued"
    started_at: str = ""
    finished_at: str = ""
    result: str = ""
    activity_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    kind: str = "generic"
    payload: dict[str, object] = field(default_factory=dict)
    technical_detail: str = ""
    recommended_action: str = ""


class _Worker(QObject):
    progressed = Signal(object, int, int, str)
    succeeded = Signal(object, object)
    failed = Signal(object, str)
    cancelled = Signal(object)
    finished = Signal()

    def __init__(self, record: ActivityRecord, operation: Callable[..., object], cancel_event: threading.Event) -> None:
        super().__init__()
        self._record = record
        self._operation = operation
        self._cancel_event = cancel_event

    @Slot()
    def run(self) -> None:
        try:
            progress = lambda c, t, m: self.progressed.emit(self._record, c, t, m)
            if len(inspect.signature(self._operation).parameters) >= 2:
                result = self._operation(progress, self._cancel_event.is_set)
            else:
                result = self._operation(progress)
            if self._cancel_event.is_set():
                raise ActivityCancelled("Cancelled by user")
        except (ActivityCancelled, InterruptedError):
            self.cancelled.emit(self._record)
        except Exception as exc:
            self.failed.emit(self._record, str(exc))
        else:
            self.succeeded.emit(self._record, result)
        finally:
            self.finished.emit()


class ActivityCenter(QObject):
    changed = Signal()

    def __init__(self) -> None:
        super().__init__()
        self._state_path = Path(user_state_dir("NatureAI Next", "NatureAI")) / "activity.json"
        self.records: list[ActivityRecord] = self._load()
        self._threads: dict[str, QThread] = {}
        self._workers: dict[str, _Worker] = {}
        self._cancel_events: dict[str, threading.Event] = {}
        self._operations: dict[str, Callable[..., object]] = {}
        self._recovery_factories: dict[str, Callable[[dict[str, object]], Callable[..., object]]] = {}
        self._last_progress_emit: dict[str, float] = {}

    def _load(self) -> list[ActivityRecord]:
        try:
            raw = json.loads(self._state_path.read_text(encoding="utf-8"))
        except (OSError, ValueError, TypeError):
            return []
        records: list[ActivityRecord] = []
        for item in raw if isinstance(raw, list) else []:
            try:
                record = ActivityRecord(**item)
            except TypeError:
                continue
            if record.state in {"running", "cancelling", "queued"}:
                record.state = "interrupted"
                record.message = "Interrupted when NatureAI stopped. Resume or retry is available."
                record.finished_at = datetime.now().isoformat(timespec="seconds")
            records.append(record)
        return records[:100]

    def _save(self) -> None:
        self._state_path.parent.mkdir(parents=True, exist_ok=True)
        temp = self._state_path.with_suffix(".tmp")
        temp.write_text(json.dumps([asdict(r) for r in self.records[:100]], indent=2), encoding="utf-8")
        temp.replace(self._state_path)

    @property
    def running_count(self) -> int:
        return sum(1 for item in self.records if item.state in {"running", "cancelling"})

    def register_recovery(self, kind: str, factory: Callable[[dict[str, object]], Callable[..., object]]) -> None:
        self._recovery_factories[kind] = factory
        self.changed.emit()

    def start(
        self,
        title: str,
        detail: str,
        operation: Callable[..., object],
        *,
        kind: str = "generic",
        payload: dict[str, object] | None = None,
    ) -> ActivityRecord:
        record = ActivityRecord(
            title=title,
            detail=detail,
            state="running",
            message="Starting…",
            started_at=datetime.now().isoformat(timespec="seconds"),
            kind=kind,
            payload=dict(payload or {}),
        )
        self.records.insert(0, record)
        self._operations[record.activity_id] = operation
        self._launch(record, operation)
        return record

    def _launch(self, record: ActivityRecord, operation: Callable[..., object]) -> None:
        cancel_event = threading.Event()
        thread = QThread(self)
        worker = _Worker(record, operation, cancel_event)
        worker.moveToThread(thread)
        thread.started.connect(worker.run)
        worker.progressed.connect(self._progress)
        worker.succeeded.connect(self._success)
        worker.failed.connect(self._failure)
        worker.cancelled.connect(self._cancelled)
        worker.finished.connect(thread.quit)
        worker.finished.connect(worker.deleteLater)
        thread.finished.connect(thread.deleteLater)
        thread.finished.connect(lambda activity_id=record.activity_id: self._cleanup(activity_id))
        self._threads[record.activity_id] = thread
        self._workers[record.activity_id] = worker
        self._cancel_events[record.activity_id] = cancel_event
        self._save(); self.changed.emit(); thread.start()

    def cancel(self, record: ActivityRecord) -> None:
        event = self._cancel_events.get(record.activity_id)
        if event is None or record.state not in {"running", "cancelling"}:
            return
        event.set()
        record.state = "cancelling"
        record.message = "Cancelling at the next safe checkpoint…"
        self._save(); self.changed.emit()

    def cancel_all(self) -> None:
        for record in list(self.records):
            self.cancel(record)

    def retry(self, record: ActivityRecord) -> bool:
        if record.state not in {"failed", "cancelled", "interrupted"}:
            return False
        operation = self._operations.get(record.activity_id)
        if operation is None:
            factory = self._recovery_factories.get(record.kind)
            if factory is None:
                return False
            operation = factory(record.payload)
            self._operations[record.activity_id] = operation
        record.state = "running"
        record.message = "Resuming from the last safe checkpoint…"
        record.finished_at = ""
        self._launch(record, operation)
        return True

    def can_retry(self, record: ActivityRecord) -> bool:
        return record.state in {"failed", "cancelled", "interrupted"} and (
            record.activity_id in self._operations or record.kind in self._recovery_factories
        )

    @Slot(object, int, int, str)
    def _progress(self, record: ActivityRecord, current: int, total: int, message: str) -> None:
        record.current = current; record.total = total; record.message = message
        now = time.monotonic()
        last = self._last_progress_emit.get(record.activity_id, 0.0)
        # Keep worker progress unrestricted but persist/refresh the UI at most
        # once per second, plus phase boundaries and completion.
        boundary = current in {0, total}
        if boundary or now - last >= 1.0:
            self._last_progress_emit[record.activity_id] = now
            self._save(); self.changed.emit()

    @Slot(object, object)
    def _success(self, record: ActivityRecord, result: object) -> None:
        record.state = "completed"; record.current = max(record.current, record.total); record.message = "Completed"
        record.finished_at = datetime.now().isoformat(timespec="seconds")
        record.result = str(result); self._save(); self.changed.emit()

    @staticmethod
    def _logical_error(message: str) -> tuple[str, str]:
        lowered = message.casefold()
        if "unique constraint failed: taxa.public_id" in lowered:
            return (
                "The taxonomy update found records that are already installed. Your current taxonomy is still available.",
                "Resume the repaired installation. The verified download does not need to be downloaded again.",
            )
        if "database is locked" in lowered:
            return (
                "Aperture could not finish the database step because another operation was using the library.",
                "Wait for other work to finish, then choose Resume / Retry.",
            )
        if "checksum" in lowered or "verification" in lowered:
            return (
                "The downloaded resource could not be verified and was not installed.",
                "Retry the download. Your currently installed data remains unchanged.",
            )
        return (
            "The operation could not be completed. Existing installed data remains available where possible.",
            "Open Technical details, then choose Resume / Retry or clean the incomplete activity data.",
        )

    @Slot(object, str)
    def _failure(self, record: ActivityRecord, message: str) -> None:
        logical, action = self._logical_error(message)
        record.state = "failed"; record.message = logical; record.technical_detail = message
        record.recommended_action = action
        record.finished_at = datetime.now().isoformat(timespec="seconds")
        self._save(); self.changed.emit()

    def clean_finished(self) -> int:
        before = len(self.records)
        self.records[:] = [r for r in self.records if r.state in {"running", "cancelling", "interrupted"}]
        removed = before - len(self.records)
        if removed:
            self._save(); self.changed.emit()
        return removed

    @Slot(object)
    def _cancelled(self, record: ActivityRecord) -> None:
        record.state = "cancelled"; record.message = "Cancelled. Partial downloads and checkpoints were preserved."
        record.finished_at = datetime.now().isoformat(timespec="seconds")
        self._save(); self.changed.emit()

    def _cleanup(self, activity_id: str) -> None:
        self._threads.pop(activity_id, None)
        self._workers.pop(activity_id, None)
        self._cancel_events.pop(activity_id, None)
        self._save(); self.changed.emit()


_CENTER: ActivityCenter | None = None

def activity_center() -> ActivityCenter:
    global _CENTER
    if _CENTER is None:
        _CENTER = ActivityCenter()
    return _CENTER


class ActivityCenterWidget(QWidget):
    """Reusable Activity Center content for the main workspace and dialog."""

    def __init__(self, parent: QWidget | None = None, *, show_close: bool = False) -> None:
        super().__init__(parent)
        self._center = activity_center()
        self._list = QListWidget()
        self._list.currentRowChanged.connect(self._selection_changed)
        self._title = QLabel("No background activity")
        self._title.setWordWrap(True)
        self._progress = QProgressBar(); self._progress.setRange(0, 100)
        self._details = QTextBrowser()
        self._cancel = QPushButton("Cancel task")
        self._retry = QPushButton("Resume / Retry")
        self._clean = QPushButton("Clean finished")
        self._cancel.clicked.connect(self._cancel_selected)
        self._retry.clicked.connect(self._retry_selected)
        self._clean.clicked.connect(self._center.clean_finished)
        layout = QVBoxLayout(self)
        layout.addWidget(QLabel("Running, interrupted, completed, and failed background operations are shown here."))
        layout.addWidget(self._list, 1); layout.addWidget(self._title); layout.addWidget(self._progress); layout.addWidget(self._details, 1)
        row = QHBoxLayout(); row.addWidget(self._cancel); row.addWidget(self._retry); row.addWidget(self._clean); row.addStretch(1)
        if show_close:
            close = QPushButton("Close")
            close.clicked.connect(self.window().close)
            row.addWidget(close)
        layout.addLayout(row)
        self._center.changed.connect(self.refresh)
        self.refresh()

    def _selected(self) -> ActivityRecord | None:
        row = self._list.currentRow()
        return self._center.records[row] if 0 <= row < len(self._center.records) else None

    @Slot()
    def _cancel_selected(self) -> None:
        record = self._selected()
        if record is not None:
            self._center.cancel(record)

    @Slot()
    def _retry_selected(self) -> None:
        record = self._selected()
        if record is not None:
            self._center.retry(record)

    @Slot()
    def refresh(self) -> None:
        selected = self._list.currentRow()
        self._list.clear()
        for record in self._center.records:
            marker = {"running": "▶", "cancelling": "◼", "completed": "✓", "failed": "⚠", "cancelled": "■", "interrupted": "↻"}.get(record.state, "○")
            self._list.addItem(QListWidgetItem(f"{marker} {record.title} — {record.message}"))
        if self._list.count(): self._list.setCurrentRow(min(max(selected, 0), self._list.count()-1))
        else: self._selection_changed(-1)

    @Slot(int)
    def _selection_changed(self, row: int) -> None:
        if row < 0 or row >= len(self._center.records):
            self._title.setText("No background activity"); self._progress.setValue(0); self._details.clear()
            self._cancel.setEnabled(False); self._retry.setEnabled(False); return
        record = self._center.records[row]
        self._title.setText(f"<b>{record.title}</b><br>{record.detail}<br>{record.message}")
        percent = int(record.current * 100 / record.total) if record.total else (100 if record.state == "completed" else 0)
        self._progress.setValue(max(0, min(percent, 100)))
        self._details.setPlainText(
            f"State: {record.state}\nStarted: {record.started_at or '-'}\nFinished: {record.finished_at or '-'}\n"
            f"Progress: {record.current} / {record.total or '?'}\n\n{record.result or record.message}"
            + (f"\n\nRecommended action:\n{record.recommended_action}" if record.recommended_action else "")
            + (f"\n\nTechnical details:\n{record.technical_detail}" if record.technical_detail else "")
        )
        self._cancel.setEnabled(record.state in {"running", "cancelling"})
        self._retry.setEnabled(self._center.can_retry(record))


class ActivityCenterDialog(QDialog):
    """Compatibility dialog using the same Activity Center content."""

    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.setWindowTitle("Activity Center")
        self.resize(860, 600)
        layout = QVBoxLayout(self)
        content = ActivityCenterWidget(self)
        layout.addWidget(content)
        close = QPushButton("Close")
        close.clicked.connect(self.accept)
        row = QHBoxLayout(); row.addStretch(1); row.addWidget(close)
        layout.addLayout(row)
